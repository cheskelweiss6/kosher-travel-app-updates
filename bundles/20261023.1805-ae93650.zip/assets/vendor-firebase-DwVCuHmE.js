var RI=Object.defineProperty;var vI=(r,e,t)=>e in r?RI(r,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[e]=t;var G=(r,e,t)=>vI(r,typeof e!="symbol"?e+"":e,t);const PI=()=>{};var Qd={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sp=function(r){const e=[];let t=0;for(let n=0;n<r.length;n++){let s=r.charCodeAt(n);s<128?e[t++]=s:s<2048?(e[t++]=s>>6|192,e[t++]=s&63|128):(s&64512)===55296&&n+1<r.length&&(r.charCodeAt(n+1)&64512)===56320?(s=65536+((s&1023)<<10)+(r.charCodeAt(++n)&1023),e[t++]=s>>18|240,e[t++]=s>>12&63|128,e[t++]=s>>6&63|128,e[t++]=s&63|128):(e[t++]=s>>12|224,e[t++]=s>>6&63|128,e[t++]=s&63|128)}return e},bI=function(r){const e=[];let t=0,n=0;for(;t<r.length;){const s=r[t++];if(s<128)e[n++]=String.fromCharCode(s);else if(s>191&&s<224){const i=r[t++];e[n++]=String.fromCharCode((s&31)<<6|i&63)}else if(s>239&&s<365){const i=r[t++],o=r[t++],a=r[t++],u=((s&7)<<18|(i&63)<<12|(o&63)<<6|a&63)-65536;e[n++]=String.fromCharCode(55296+(u>>10)),e[n++]=String.fromCharCode(56320+(u&1023))}else{const i=r[t++],o=r[t++];e[n++]=String.fromCharCode((s&15)<<12|(i&63)<<6|o&63)}}return e.join("")},Op={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(r,e){if(!Array.isArray(r))throw Error("encodeByteArray takes an array as a parameter");this.init_();const t=e?this.byteToCharMapWebSafe_:this.byteToCharMap_,n=[];for(let s=0;s<r.length;s+=3){const i=r[s],o=s+1<r.length,a=o?r[s+1]:0,u=s+2<r.length,B=u?r[s+2]:0,l=i>>2,d=(i&3)<<4|a>>4;let C=(a&15)<<2|B>>6,g=B&63;u||(g=64,o||(C=64)),n.push(t[l],t[d],t[C],t[g])}return n.join("")},encodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?btoa(r):this.encodeByteArray(Sp(r),e)},decodeString(r,e){return this.HAS_NATIVE_SUPPORT&&!e?atob(r):bI(this.decodeStringToByteArray(r,e))},decodeStringToByteArray(r,e){this.init_();const t=e?this.charToByteMapWebSafe_:this.charToByteMap_,n=[];for(let s=0;s<r.length;){const i=t[r.charAt(s++)],a=s<r.length?t[r.charAt(s)]:0;++s;const B=s<r.length?t[r.charAt(s)]:64;++s;const d=s<r.length?t[r.charAt(s)]:64;if(++s,i==null||a==null||B==null||d==null)throw new SI;const C=i<<2|a>>4;if(n.push(C),B!==64){const g=a<<4&240|B>>2;if(n.push(g),d!==64){const m=B<<6&192|d;n.push(m)}}}return n},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let r=0;r<this.ENCODED_VALS.length;r++)this.byteToCharMap_[r]=this.ENCODED_VALS.charAt(r),this.charToByteMap_[this.byteToCharMap_[r]]=r,this.byteToCharMapWebSafe_[r]=this.ENCODED_VALS_WEBSAFE.charAt(r),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[r]]=r,r>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(r)]=r,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(r)]=r)}}};class SI extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const OI=function(r){const e=Sp(r);return Op.encodeByteArray(e,!0)},Cu=function(r){return OI(r).replace(/\./g,"")},Np=function(r){try{return Op.decodeString(r,!0)}catch(e){console.error("base64Decode failed: ",e)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Fp(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const NI=()=>Fp().__FIREBASE_DEFAULTS__,FI=()=>{if(typeof process>"u"||typeof Qd>"u")return;const r=Qd.__FIREBASE_DEFAULTS__;if(r)return JSON.parse(r)},LI=()=>{if(typeof document>"u")return;let r;try{r=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const e=r&&Np(r[1]);return e&&JSON.parse(e)},qu=()=>{try{return PI()||NI()||FI()||LI()}catch(r){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${r}`);return}},Lp=r=>{var e,t;return(t=(e=qu())==null?void 0:e.emulatorHosts)==null?void 0:t[r]},kp=r=>{const e=Lp(r);if(!e)return;const t=e.lastIndexOf(":");if(t<=0||t+1===e.length)throw new Error(`Invalid host ${e} with no separate hostname and port!`);const n=parseInt(e.substring(t+1),10);return e[0]==="["?[e.substring(1,t-1),n]:[e.substring(0,t),n]},xp=()=>{var r;return(r=qu())==null?void 0:r.config},Vp=r=>{var e;return(e=qu())==null?void 0:e[`_${r}`]};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mp{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,n)=>{t?this.reject(t):this.resolve(n),typeof e=="function"&&(this.promise.catch(()=>{}),e.length===1?e(t):e(t,n))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Gp(r,e){if(r.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const t={alg:"none",type:"JWT"},n=e||"demo-project",s=r.iat||0,i=r.sub||r.user_id;if(!i)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const o={iss:`https://securetoken.google.com/${n}`,aud:n,iat:s,exp:s+3600,auth_time:s,sub:i,user_id:i,firebase:{sign_in_provider:"custom",identities:{}},...r};return[Cu(JSON.stringify(t)),Cu(JSON.stringify(o)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xe(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function kI(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(Xe())}function Up(){var e;const r=(e=qu())==null?void 0:e.forceEnvironment;if(r==="node")return!0;if(r==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function xI(){return typeof navigator<"u"&&navigator.userAgent==="Cloudflare-Workers"}function VI(){const r=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof r=="object"&&r.id!==void 0}function MI(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function GI(){const r=Xe();return r.indexOf("MSIE ")>=0||r.indexOf("Trident/")>=0}function Hp(){return!Up()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function qp(){return!Up()&&!!navigator.userAgent&&(navigator.userAgent.includes("Safari")||navigator.userAgent.includes("WebKit"))&&!navigator.userAgent.includes("Chrome")}function jp(){try{return typeof indexedDB=="object"}catch{return!1}}function UI(){return new Promise((r,e)=>{try{let t=!0;const n="validate-browser-context-for-indexeddb-analytics-module",s=self.indexedDB.open(n);s.onsuccess=()=>{s.result.close(),t||self.indexedDB.deleteDatabase(n),r(!0)},s.onupgradeneeded=()=>{t=!1},s.onerror=()=>{var i;e(((i=s.error)==null?void 0:i.message)||"")}}catch(t){e(t)}})}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const HI="FirebaseError";class In extends Error{constructor(e,t,n){super(t),this.code=e,this.customData=n,this.name=HI,Object.setPrototypeOf(this,In.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,qo.prototype.create)}}class qo{constructor(e,t,n){this.service=e,this.serviceName=t,this.errors=n}create(e,...t){const n=t[0]||{},s=`${this.service}/${e}`,i=this.errors[e],o=i?qI(i,n):"Error",a=`${this.serviceName}: ${o} (${s}).`;return new In(s,a,n)}}function qI(r,e){try{let t=0,n="";for(;t<r.length;){const s=r.indexOf("{$",t);if(s===-1){n+=r.substring(t);break}const i=r.indexOf("}",s+2);if(i===-1){n+=r.substring(t);break}const o=r.substring(s+2,i),a=e[o];n+=r.substring(t,s)+(a!=null?String(a):`<${o}?>`),t=i+1}return n}catch{return r}}function jI(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}function pn(r,e){if(r===e)return!0;const t=Object.keys(r),n=Object.keys(e);for(const s of t){if(!n.includes(s))return!1;const i=r[s],o=e[s];if($d(i)&&$d(o)){if(!pn(i,o))return!1}else if(i!==o)return!1}for(const s of n)if(!t.includes(s))return!1;return!0}function $d(r){return r!==null&&typeof r=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ci(r){const e=[];for(const[t,n]of Object.entries(r))Array.isArray(n)?n.forEach(s=>{e.push(encodeURIComponent(t)+"="+encodeURIComponent(s))}):e.push(encodeURIComponent(t)+"="+encodeURIComponent(n));return e.length?"&"+e.join("&"):""}function Wi(r){const e={};return r.replace(/^\?/,"").split("&").forEach(n=>{if(n){const[s,i]=n.split("=");e[decodeURIComponent(s)]=decodeURIComponent(i)}}),e}function Qi(r){const e=r.indexOf("?");if(!e)return"";const t=r.indexOf("#",e);return r.substring(e,t>0?t:void 0)}function JI(r,e){const t=new KI(r,e);return t.subscribe.bind(t)}class KI{constructor(e,t){this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then(()=>{e(this)}).catch(n=>{this.error(n)})}next(e){this.forEachObserver(t=>{t.next(e)})}error(e){this.forEachObserver(t=>{t.error(e)}),this.close(e)}complete(){this.forEachObserver(e=>{e.complete()}),this.close()}subscribe(e,t,n){let s;if(e===void 0&&t===void 0&&n===void 0)throw new Error("Missing Observer.");zI(e,["next","error","complete"])?s=e:s={next:e,error:t,complete:n},s.next===void 0&&(s.next=eB),s.error===void 0&&(s.error=eB),s.complete===void 0&&(s.complete=eB);const i=this.unsubscribeOne.bind(this,this.observers.length);return this.finalized&&this.task.then(()=>{try{this.finalError?s.error(this.finalError):s.complete()}catch{}}),this.observers.push(s),i}unsubscribeOne(e){this.observers===void 0||this.observers[e]===void 0||(delete this.observers[e],this.observerCount-=1,this.observerCount===0&&this.onNoObservers!==void 0&&this.onNoObservers(this))}forEachObserver(e){if(!this.finalized)for(let t=0;t<this.observers.length;t++)this.sendOne(t,e)}sendOne(e,t){this.task.then(()=>{if(this.observers!==void 0&&this.observers[e]!==void 0)try{t(this.observers[e])}catch(n){typeof console<"u"&&console.error&&console.error(n)}})}close(e){this.finalized||(this.finalized=!0,e!==void 0&&(this.finalError=e),this.task.then(()=>{this.observers=void 0,this.onNoObservers=void 0}))}}function zI(r,e){if(typeof r!="object"||r===null)return!1;for(const t of e)if(t in r&&typeof r[t]=="function")return!0;return!1}function eB(){}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function re(r){return r&&r._delegate?r._delegate:r}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function vr(r){try{return(r.startsWith("http://")||r.startsWith("https://")?new URL(r).hostname:r).endsWith(".cloudworkstations.dev")}catch{return!1}}async function ju(r){return(await fetch(r,{credentials:"include"})).ok}class Er{constructor(e,t,n){this.name=e,this.instanceFactory=t,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mr="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WI{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){const t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){const n=new Mp;if(this.instancesDeferred.set(t,n),this.isInitialized(t)||this.shouldAutoInitialize())try{const s=this.getOrInitializeService({instanceIdentifier:t});s&&n.resolve(s)}catch{}}return this.instancesDeferred.get(t).promise}getImmediate(e){const t=this.normalizeInstanceIdentifier(e==null?void 0:e.identifier),n=(e==null?void 0:e.optional)??!1;if(this.isInitialized(t)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:t})}catch(s){if(n)return null;throw s}else{if(n)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,!!this.shouldAutoInitialize()){if($I(e))try{this.getOrInitializeService({instanceIdentifier:Mr})}catch{}for(const[t,n]of this.instancesDeferred.entries()){const s=this.normalizeInstanceIdentifier(t);try{const i=this.getOrInitializeService({instanceIdentifier:s});n.resolve(i)}catch{}}}}clearInstance(e=Mr){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){const e=Array.from(this.instances.values());await Promise.all([...e.filter(t=>"INTERNAL"in t).map(t=>t.INTERNAL.delete()),...e.filter(t=>"_delete"in t).map(t=>t._delete())])}isComponentSet(){return this.component!=null}isInitialized(e=Mr){return this.instances.has(e)}getOptions(e=Mr){return this.instancesOptions.get(e)||{}}initialize(e={}){const{options:t={}}=e,n=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(n))throw Error(`${this.name}(${n}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const s=this.getOrInitializeService({instanceIdentifier:n,options:t});for(const[i,o]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(i);n===a&&o.resolve(s)}return s}onInit(e,t){const n=this.normalizeInstanceIdentifier(t),s=this.onInitCallbacks.get(n)??new Set;s.add(e),this.onInitCallbacks.set(n,s);const i=this.instances.get(n);return i&&e(i,n),()=>{s.delete(e)}}invokeOnInitCallbacks(e,t){const n=this.onInitCallbacks.get(t);if(n)for(const s of n)try{s(e,t)}catch{}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let n=this.instances.get(e);if(!n&&this.component&&(n=this.component.instanceFactory(this.container,{instanceIdentifier:QI(e),options:t}),this.instances.set(e,n),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(n,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,n)}catch{}return n||null}normalizeInstanceIdentifier(e=Mr){return this.component?this.component.multipleInstances?e:Mr:e}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function QI(r){return r===Mr?void 0:r}function $I(r){return r.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class YI{constructor(e){this.name=e,this.providers=new Map}addComponent(e){const t=this.getProvider(e.name);if(t.isComponentSet())throw new Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);const t=new WI(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var fe;(function(r){r[r.DEBUG=0]="DEBUG",r[r.VERBOSE=1]="VERBOSE",r[r.INFO=2]="INFO",r[r.WARN=3]="WARN",r[r.ERROR=4]="ERROR",r[r.SILENT=5]="SILENT"})(fe||(fe={}));const XI={debug:fe.DEBUG,verbose:fe.VERBOSE,info:fe.INFO,warn:fe.WARN,error:fe.ERROR,silent:fe.SILENT},ZI=fe.INFO,eD={[fe.DEBUG]:"log",[fe.VERBOSE]:"log",[fe.INFO]:"info",[fe.WARN]:"warn",[fe.ERROR]:"error"},tD=(r,e,...t)=>{if(e<r.logLevel)return;const n=new Date().toISOString(),s=eD[e];if(s)console[s](`[${n}]  ${r.name}:`,...t);else throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`)};class Bl{constructor(e){this.name=e,this._logLevel=ZI,this._logHandler=tD,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in fe))throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel=typeof e=="string"?XI[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if(typeof e!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,fe.DEBUG,...e),this._logHandler(this,fe.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,fe.VERBOSE,...e),this._logHandler(this,fe.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,fe.INFO,...e),this._logHandler(this,fe.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,fe.WARN,...e),this._logHandler(this,fe.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,fe.ERROR,...e),this._logHandler(this,fe.ERROR,...e)}}const nD=(r,e)=>e.some(t=>r instanceof t);let Yd,Xd;function rD(){return Yd||(Yd=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function sD(){return Xd||(Xd=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Jp=new WeakMap,AB=new WeakMap,Kp=new WeakMap,tB=new WeakMap,ll=new WeakMap;function iD(r){const e=new Promise((t,n)=>{const s=()=>{r.removeEventListener("success",i),r.removeEventListener("error",o)},i=()=>{t(lr(r.result)),s()},o=()=>{n(r.error),s()};r.addEventListener("success",i),r.addEventListener("error",o)});return e.then(t=>{t instanceof IDBCursor&&Jp.set(t,r)}).catch(()=>{}),ll.set(e,r),e}function oD(r){if(AB.has(r))return;const e=new Promise((t,n)=>{const s=()=>{r.removeEventListener("complete",i),r.removeEventListener("error",o),r.removeEventListener("abort",o)},i=()=>{t(),s()},o=()=>{n(r.error||new DOMException("AbortError","AbortError")),s()};r.addEventListener("complete",i),r.addEventListener("error",o),r.addEventListener("abort",o)});AB.set(r,e)}let RB={get(r,e,t){if(r instanceof IDBTransaction){if(e==="done")return AB.get(r);if(e==="objectStoreNames")return r.objectStoreNames||Kp.get(r);if(e==="store")return t.objectStoreNames[1]?void 0:t.objectStore(t.objectStoreNames[0])}return lr(r[e])},set(r,e,t){return r[e]=t,!0},has(r,e){return r instanceof IDBTransaction&&(e==="done"||e==="store")?!0:e in r}};function aD(r){RB=r(RB)}function uD(r){return r===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(e,...t){const n=r.call(nB(this),e,...t);return Kp.set(n,e.sort?e.sort():[e]),lr(n)}:sD().includes(r)?function(...e){return r.apply(nB(this),e),lr(Jp.get(this))}:function(...e){return lr(r.apply(nB(this),e))}}function cD(r){return typeof r=="function"?uD(r):(r instanceof IDBTransaction&&oD(r),nD(r,rD())?new Proxy(r,RB):r)}function lr(r){if(r instanceof IDBRequest)return iD(r);if(tB.has(r))return tB.get(r);const e=cD(r);return e!==r&&(tB.set(r,e),ll.set(e,r)),e}const nB=r=>ll.get(r);function BD(r,e,{blocked:t,upgrade:n,blocking:s,terminated:i}={}){const o=indexedDB.open(r,e),a=lr(o);return n&&o.addEventListener("upgradeneeded",u=>{n(lr(o.result),u.oldVersion,u.newVersion,lr(o.transaction),u)}),t&&o.addEventListener("blocked",u=>t(u.oldVersion,u.newVersion,u)),a.then(u=>{i&&u.addEventListener("close",()=>i()),s&&u.addEventListener("versionchange",B=>s(B.oldVersion,B.newVersion,B))}).catch(()=>{}),a}const lD=["get","getKey","getAll","getAllKeys","count"],hD=["put","add","delete","clear"],rB=new Map;function Zd(r,e){if(!(r instanceof IDBDatabase&&!(e in r)&&typeof e=="string"))return;if(rB.get(e))return rB.get(e);const t=e.replace(/FromIndex$/,""),n=e!==t,s=hD.includes(t);if(!(t in(n?IDBIndex:IDBObjectStore).prototype)||!(s||lD.includes(t)))return;const i=async function(o,...a){const u=this.transaction(o,s?"readwrite":"readonly");let B=u.store;return n&&(B=B.index(a.shift())),(await Promise.all([B[t](...a),s&&u.done]))[0]};return rB.set(e,i),i}aD(r=>({...r,get:(e,t,n)=>Zd(e,t)||r.get(e,t,n),has:(e,t)=>!!Zd(e,t)||r.has(e,t)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dD{constructor(e){this.container=e}getPlatformInfoString(){return this.container.getProviders().map(t=>{if(fD(t)){const n=t.getImmediate();return`${n.library}/${n.version}`}else return null}).filter(t=>t).join(" ")}}function fD(r){const e=r.getComponent();return(e==null?void 0:e.type)==="VERSION"}const vB="@firebase/app",ef="0.16.2";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Sn=new Bl("@firebase/app"),CD="@firebase/app-compat",pD="@firebase/analytics-compat",gD="@firebase/analytics",mD="@firebase/app-check-compat",_D="@firebase/app-check",ED="@firebase/auth",ID="@firebase/auth-compat",DD="@firebase/database",yD="@firebase/data-connect",wD="@firebase/database-compat",TD="@firebase/functions",AD="@firebase/functions-compat",RD="@firebase/installations",vD="@firebase/installations-compat",PD="@firebase/messaging",bD="@firebase/messaging-compat",SD="@firebase/performance",OD="@firebase/performance-compat",ND="@firebase/remote-config",FD="@firebase/remote-config-compat",LD="@firebase/storage",kD="@firebase/storage-compat",xD="@firebase/firestore",VD="@firebase/ai",MD="@firebase/firestore-compat",GD="firebase",UD="12.19.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const PB="[DEFAULT]",HD={[vB]:"fire-core",[CD]:"fire-core-compat",[gD]:"fire-analytics",[pD]:"fire-analytics-compat",[_D]:"fire-app-check",[mD]:"fire-app-check-compat",[ED]:"fire-auth",[ID]:"fire-auth-compat",[DD]:"fire-rtdb",[yD]:"fire-data-connect",[wD]:"fire-rtdb-compat",[TD]:"fire-fn",[AD]:"fire-fn-compat",[RD]:"fire-iid",[vD]:"fire-iid-compat",[PD]:"fire-fcm",[bD]:"fire-fcm-compat",[SD]:"fire-perf",[OD]:"fire-perf-compat",[ND]:"fire-rc",[FD]:"fire-rc-compat",[LD]:"fire-gcs",[kD]:"fire-gcs-compat",[xD]:"fire-fst",[MD]:"fire-fst-compat",[VD]:"fire-vertex","fire-js":"fire-js",[GD]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mo=new Map,qD=new Map,bB=new Map;function tf(r,e){try{r.container.addComponent(e)}catch(t){Sn.debug(`Component ${e.name} failed to register with FirebaseApp ${r.name}`,t)}}function is(r){const e=r.name;if(bB.has(e))return Sn.debug(`There were multiple attempts to register component ${e}.`),!1;bB.set(e,r);for(const t of mo.values())tf(t,r);for(const t of qD.values())tf(t,r);return!0}function jo(r,e){const t=r.container.getProvider("heartbeat").getImmediate({optional:!0});return t&&t.triggerHeartbeat(),r.container.getProvider(e)}function Ge(r){return r==null?!1:r.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const jD={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},Tn=new qo("app","Firebase",jD);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class JD{constructor(e,t,n){this._isDeleted=!1,this._options={...e},this._config={...t},this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=n,this.container.addComponent(new Er("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw Tn.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ms=UD;function KD(r,e={}){let t=r;typeof e!="object"&&(e={name:e});const n={name:PB,automaticDataCollectionEnabled:!0,...e},s=n.name;if(typeof s!="string"||!s)throw Tn.create("bad-app-name",{appName:String(s)});if(t||(t=xp()),!t)throw Tn.create("no-options");const i=mo.get(s);if(i)if(pn(t,i.options)){if(pn(n,i.config))return i;throw Tn.create("duplicate-app",{appName:s,mismatchedParam:"config",oldValue:JSON.stringify(i.config),newValue:JSON.stringify(n)})}else throw Tn.create("duplicate-app",{appName:s,mismatchedParam:"options",oldValue:JSON.stringify(i.options),newValue:JSON.stringify(t)});const o=new YI(s);for(const u of bB.values())o.addComponent(u);const a=new JD(t,n,o);return mo.set(s,a),a}function hl(r=PB){const e=mo.get(r);if(!e&&r===PB&&xp())return KD();if(!e)throw Tn.create("no-app",{appName:r});return e}function DO(){return Array.from(mo.values())}function hn(r,e,t){let n=HD[r]??r;t&&(n+=`-${t}`);const s=n.match(/\s|\//),i=e.match(/\s|\//);if(s||i){const o=[`Unable to register library "${n}" with version "${e}":`];s&&o.push(`library name "${n}" contains illegal characters (whitespace or "/")`),s&&i&&o.push("and"),i&&o.push(`version name "${e}" contains illegal characters (whitespace or "/")`),Sn.warn(o.join(" "));return}is(new Er(`${n}-version`,()=>({library:n,version:e}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zD="firebase-heartbeat-database",WD=1,_o="firebase-heartbeat-store";let sB=null;function zp(){return sB||(sB=BD(zD,WD,{upgrade:(r,e)=>{switch(e){case 0:try{r.createObjectStore(_o)}catch(t){console.warn(t)}}}}).catch(r=>{throw Tn.create("idb-open",{originalErrorMessage:r.message})})),sB}async function QD(r){try{const t=(await zp()).transaction(_o),n=await t.objectStore(_o).get(Wp(r));return await t.done,n}catch(e){if(e instanceof In)Sn.warn(e.message);else{const t=Tn.create("idb-get",{originalErrorMessage:e==null?void 0:e.message});Sn.warn(t.message)}}}async function nf(r,e){try{const n=(await zp()).transaction(_o,"readwrite");await n.objectStore(_o).put(e,Wp(r)),await n.done}catch(t){if(t instanceof In)Sn.warn(t.message);else{const n=Tn.create("idb-set",{originalErrorMessage:t==null?void 0:t.message});Sn.warn(n.message)}}}function Wp(r){return`${r.name}!${r.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $D=1024,YD=30;class XD{constructor(e){this.container=e,this._heartbeatsCache=null;const t=this.container.getProvider("app").getImmediate();this._storage=new ey(t),this._heartbeatsCachePromise=this._storage.read().then(n=>(this._heartbeatsCache=n,n))}async triggerHeartbeat(){var e,t;try{const s=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),i=rf();if(((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===i||this._heartbeatsCache.heartbeats.some(o=>o.date===i))return;if(this._heartbeatsCache.heartbeats.push({date:i,agent:s}),this._heartbeatsCache.heartbeats.length>YD){const o=ty(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(o,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(n){Sn.warn(n)}}async getHeartbeatsHeader(){var e;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((e=this._heartbeatsCache)==null?void 0:e.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const t=rf(),{heartbeatsToSend:n,unsentEntries:s}=ZD(this._heartbeatsCache.heartbeats),i=Cu(JSON.stringify({version:2,heartbeats:n}));return this._heartbeatsCache.lastSentHeartbeatDate=t,s.length>0?(this._heartbeatsCache.heartbeats=s,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),i}catch(t){return Sn.warn(t),""}}}function rf(){return new Date().toISOString().substring(0,10)}function ZD(r,e=$D){const t=[];let n=r.slice();for(const s of r){const i=t.find(o=>o.agent===s.agent);if(i){if(i.dates.push(s.date),sf(t)>e){i.dates.pop();break}}else if(t.push({agent:s.agent,dates:[s.date]}),sf(t)>e){t.pop();break}n=n.slice(1)}return{heartbeatsToSend:t,unsentEntries:n}}class ey{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return jp()?UI().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const t=await QD(this.app);return t!=null&&t.heartbeats?t:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return nf(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:e.heartbeats})}else return}async add(e){if(await this._canUseIndexedDBPromise){const n=await this.read();return nf(this.app,{lastSentHeartbeatDate:e.lastSentHeartbeatDate??n.lastSentHeartbeatDate,heartbeats:[...n.heartbeats,...e.heartbeats]})}else return}}function sf(r){return Cu(JSON.stringify({version:2,heartbeats:r})).length}function ty(r){if(r.length===0)return-1;let e=0,t=r[0].date;for(let n=1;n<r.length;n++)r[n].date<t&&(t=r[n].date,e=n);return e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ny(r){is(new Er("platform-logger",e=>new dD(e),"PRIVATE")),is(new Er("heartbeat",e=>new XD(e),"PRIVATE")),hn(vB,ef,r),hn(vB,ef,"esm2020"),hn("fire-js","")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ny("");var of=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var hr,Qp;(function(){var r;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function e(T,I){function y(){}y.prototype=I.prototype,T.F=I.prototype,T.prototype=new y,T.prototype.constructor=T,T.D=function(P,R,O){for(var D=Array(arguments.length-2),At=2;At<arguments.length;At++)D[At-2]=arguments[At];return I.prototype[R].apply(P,D)}}function t(){this.blockSize=-1}function n(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}e(n,t),n.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function s(T,I,y){y||(y=0);const P=Array(16);if(typeof I=="string")for(var R=0;R<16;++R)P[R]=I.charCodeAt(y++)|I.charCodeAt(y++)<<8|I.charCodeAt(y++)<<16|I.charCodeAt(y++)<<24;else for(R=0;R<16;++R)P[R]=I[y++]|I[y++]<<8|I[y++]<<16|I[y++]<<24;I=T.g[0],y=T.g[1],R=T.g[2];let O=T.g[3],D;D=I+(O^y&(R^O))+P[0]+3614090360&4294967295,I=y+(D<<7&4294967295|D>>>25),D=O+(R^I&(y^R))+P[1]+3905402710&4294967295,O=I+(D<<12&4294967295|D>>>20),D=R+(y^O&(I^y))+P[2]+606105819&4294967295,R=O+(D<<17&4294967295|D>>>15),D=y+(I^R&(O^I))+P[3]+3250441966&4294967295,y=R+(D<<22&4294967295|D>>>10),D=I+(O^y&(R^O))+P[4]+4118548399&4294967295,I=y+(D<<7&4294967295|D>>>25),D=O+(R^I&(y^R))+P[5]+1200080426&4294967295,O=I+(D<<12&4294967295|D>>>20),D=R+(y^O&(I^y))+P[6]+2821735955&4294967295,R=O+(D<<17&4294967295|D>>>15),D=y+(I^R&(O^I))+P[7]+4249261313&4294967295,y=R+(D<<22&4294967295|D>>>10),D=I+(O^y&(R^O))+P[8]+1770035416&4294967295,I=y+(D<<7&4294967295|D>>>25),D=O+(R^I&(y^R))+P[9]+2336552879&4294967295,O=I+(D<<12&4294967295|D>>>20),D=R+(y^O&(I^y))+P[10]+4294925233&4294967295,R=O+(D<<17&4294967295|D>>>15),D=y+(I^R&(O^I))+P[11]+2304563134&4294967295,y=R+(D<<22&4294967295|D>>>10),D=I+(O^y&(R^O))+P[12]+1804603682&4294967295,I=y+(D<<7&4294967295|D>>>25),D=O+(R^I&(y^R))+P[13]+4254626195&4294967295,O=I+(D<<12&4294967295|D>>>20),D=R+(y^O&(I^y))+P[14]+2792965006&4294967295,R=O+(D<<17&4294967295|D>>>15),D=y+(I^R&(O^I))+P[15]+1236535329&4294967295,y=R+(D<<22&4294967295|D>>>10),D=I+(R^O&(y^R))+P[1]+4129170786&4294967295,I=y+(D<<5&4294967295|D>>>27),D=O+(y^R&(I^y))+P[6]+3225465664&4294967295,O=I+(D<<9&4294967295|D>>>23),D=R+(I^y&(O^I))+P[11]+643717713&4294967295,R=O+(D<<14&4294967295|D>>>18),D=y+(O^I&(R^O))+P[0]+3921069994&4294967295,y=R+(D<<20&4294967295|D>>>12),D=I+(R^O&(y^R))+P[5]+3593408605&4294967295,I=y+(D<<5&4294967295|D>>>27),D=O+(y^R&(I^y))+P[10]+38016083&4294967295,O=I+(D<<9&4294967295|D>>>23),D=R+(I^y&(O^I))+P[15]+3634488961&4294967295,R=O+(D<<14&4294967295|D>>>18),D=y+(O^I&(R^O))+P[4]+3889429448&4294967295,y=R+(D<<20&4294967295|D>>>12),D=I+(R^O&(y^R))+P[9]+568446438&4294967295,I=y+(D<<5&4294967295|D>>>27),D=O+(y^R&(I^y))+P[14]+3275163606&4294967295,O=I+(D<<9&4294967295|D>>>23),D=R+(I^y&(O^I))+P[3]+4107603335&4294967295,R=O+(D<<14&4294967295|D>>>18),D=y+(O^I&(R^O))+P[8]+1163531501&4294967295,y=R+(D<<20&4294967295|D>>>12),D=I+(R^O&(y^R))+P[13]+2850285829&4294967295,I=y+(D<<5&4294967295|D>>>27),D=O+(y^R&(I^y))+P[2]+4243563512&4294967295,O=I+(D<<9&4294967295|D>>>23),D=R+(I^y&(O^I))+P[7]+1735328473&4294967295,R=O+(D<<14&4294967295|D>>>18),D=y+(O^I&(R^O))+P[12]+2368359562&4294967295,y=R+(D<<20&4294967295|D>>>12),D=I+(y^R^O)+P[5]+4294588738&4294967295,I=y+(D<<4&4294967295|D>>>28),D=O+(I^y^R)+P[8]+2272392833&4294967295,O=I+(D<<11&4294967295|D>>>21),D=R+(O^I^y)+P[11]+1839030562&4294967295,R=O+(D<<16&4294967295|D>>>16),D=y+(R^O^I)+P[14]+4259657740&4294967295,y=R+(D<<23&4294967295|D>>>9),D=I+(y^R^O)+P[1]+2763975236&4294967295,I=y+(D<<4&4294967295|D>>>28),D=O+(I^y^R)+P[4]+1272893353&4294967295,O=I+(D<<11&4294967295|D>>>21),D=R+(O^I^y)+P[7]+4139469664&4294967295,R=O+(D<<16&4294967295|D>>>16),D=y+(R^O^I)+P[10]+3200236656&4294967295,y=R+(D<<23&4294967295|D>>>9),D=I+(y^R^O)+P[13]+681279174&4294967295,I=y+(D<<4&4294967295|D>>>28),D=O+(I^y^R)+P[0]+3936430074&4294967295,O=I+(D<<11&4294967295|D>>>21),D=R+(O^I^y)+P[3]+3572445317&4294967295,R=O+(D<<16&4294967295|D>>>16),D=y+(R^O^I)+P[6]+76029189&4294967295,y=R+(D<<23&4294967295|D>>>9),D=I+(y^R^O)+P[9]+3654602809&4294967295,I=y+(D<<4&4294967295|D>>>28),D=O+(I^y^R)+P[12]+3873151461&4294967295,O=I+(D<<11&4294967295|D>>>21),D=R+(O^I^y)+P[15]+530742520&4294967295,R=O+(D<<16&4294967295|D>>>16),D=y+(R^O^I)+P[2]+3299628645&4294967295,y=R+(D<<23&4294967295|D>>>9),D=I+(R^(y|~O))+P[0]+4096336452&4294967295,I=y+(D<<6&4294967295|D>>>26),D=O+(y^(I|~R))+P[7]+1126891415&4294967295,O=I+(D<<10&4294967295|D>>>22),D=R+(I^(O|~y))+P[14]+2878612391&4294967295,R=O+(D<<15&4294967295|D>>>17),D=y+(O^(R|~I))+P[5]+4237533241&4294967295,y=R+(D<<21&4294967295|D>>>11),D=I+(R^(y|~O))+P[12]+1700485571&4294967295,I=y+(D<<6&4294967295|D>>>26),D=O+(y^(I|~R))+P[3]+2399980690&4294967295,O=I+(D<<10&4294967295|D>>>22),D=R+(I^(O|~y))+P[10]+4293915773&4294967295,R=O+(D<<15&4294967295|D>>>17),D=y+(O^(R|~I))+P[1]+2240044497&4294967295,y=R+(D<<21&4294967295|D>>>11),D=I+(R^(y|~O))+P[8]+1873313359&4294967295,I=y+(D<<6&4294967295|D>>>26),D=O+(y^(I|~R))+P[15]+4264355552&4294967295,O=I+(D<<10&4294967295|D>>>22),D=R+(I^(O|~y))+P[6]+2734768916&4294967295,R=O+(D<<15&4294967295|D>>>17),D=y+(O^(R|~I))+P[13]+1309151649&4294967295,y=R+(D<<21&4294967295|D>>>11),D=I+(R^(y|~O))+P[4]+4149444226&4294967295,I=y+(D<<6&4294967295|D>>>26),D=O+(y^(I|~R))+P[11]+3174756917&4294967295,O=I+(D<<10&4294967295|D>>>22),D=R+(I^(O|~y))+P[2]+718787259&4294967295,R=O+(D<<15&4294967295|D>>>17),D=y+(O^(R|~I))+P[9]+3951481745&4294967295,T.g[0]=T.g[0]+I&4294967295,T.g[1]=T.g[1]+(R+(D<<21&4294967295|D>>>11))&4294967295,T.g[2]=T.g[2]+R&4294967295,T.g[3]=T.g[3]+O&4294967295}n.prototype.v=function(T,I){I===void 0&&(I=T.length);const y=I-this.blockSize,P=this.C;let R=this.h,O=0;for(;O<I;){if(R==0)for(;O<=y;)s(this,T,O),O+=this.blockSize;if(typeof T=="string"){for(;O<I;)if(P[R++]=T.charCodeAt(O++),R==this.blockSize){s(this,P),R=0;break}}else for(;O<I;)if(P[R++]=T[O++],R==this.blockSize){s(this,P),R=0;break}}this.h=R,this.o+=I},n.prototype.A=function(){var T=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);T[0]=128;for(var I=1;I<T.length-8;++I)T[I]=0;I=this.o*8;for(var y=T.length-8;y<T.length;++y)T[y]=I&255,I/=256;for(this.v(T),T=Array(16),I=0,y=0;y<4;++y)for(let P=0;P<32;P+=8)T[I++]=this.g[y]>>>P&255;return T};function i(T,I){var y=a;return Object.prototype.hasOwnProperty.call(y,T)?y[T]:y[T]=I(T)}function o(T,I){this.h=I;const y=[];let P=!0;for(let R=T.length-1;R>=0;R--){const O=T[R]|0;P&&O==I||(y[R]=O,P=!1)}this.g=y}var a={};function u(T){return-128<=T&&T<128?i(T,function(I){return new o([I|0],I<0?-1:0)}):new o([T|0],T<0?-1:0)}function B(T){if(isNaN(T)||!isFinite(T))return d;if(T<0)return N(B(-T));const I=[];let y=1;for(let P=0;T>=y;P++)I[P]=T/y|0,y*=4294967296;return new o(I,0)}function l(T,I){if(T.length==0)throw Error("number format error: empty string");if(I=I||10,I<2||36<I)throw Error("radix out of range: "+I);if(T.charAt(0)=="-")return N(l(T.substring(1),I));if(T.indexOf("-")>=0)throw Error('number format error: interior "-" character');const y=B(Math.pow(I,8));let P=d;for(let O=0;O<T.length;O+=8){var R=Math.min(8,T.length-O);const D=parseInt(T.substring(O,O+R),I);R<8?(R=B(Math.pow(I,R)),P=P.j(R).add(B(D))):(P=P.j(y),P=P.add(B(D)))}return P}var d=u(0),C=u(1),g=u(16777216);r=o.prototype,r.m=function(){if(v(this))return-N(this).m();let T=0,I=1;for(let y=0;y<this.g.length;y++){const P=this.i(y);T+=(P>=0?P:4294967296+P)*I,I*=4294967296}return T},r.toString=function(T){if(T=T||10,T<2||36<T)throw Error("radix out of range: "+T);if(m(this))return"0";if(v(this))return"-"+N(this).toString(T);const I=B(Math.pow(T,6));var y=this;let P="";for(;;){const R=se(y,I).g;y=q(y,R.j(I));let O=((y.g.length>0?y.g[0]:y.h)>>>0).toString(T);if(y=R,m(y))return O+P;for(;O.length<6;)O="0"+O;P=O+P}},r.i=function(T){return T<0?0:T<this.g.length?this.g[T]:this.h};function m(T){if(T.h!=0)return!1;for(let I=0;I<T.g.length;I++)if(T.g[I]!=0)return!1;return!0}function v(T){return T.h==-1}r.l=function(T){return T=q(this,T),v(T)?-1:m(T)?0:1};function N(T){const I=T.g.length,y=[];for(let P=0;P<I;P++)y[P]=~T.g[P];return new o(y,~T.h).add(C)}r.abs=function(){return v(this)?N(this):this},r.add=function(T){const I=Math.max(this.g.length,T.g.length),y=[];let P=0;for(let R=0;R<=I;R++){let O=P+(this.i(R)&65535)+(T.i(R)&65535),D=(O>>>16)+(this.i(R)>>>16)+(T.i(R)>>>16);P=D>>>16,O&=65535,D&=65535,y[R]=D<<16|O}return new o(y,y[y.length-1]&-2147483648?-1:0)};function q(T,I){return T.add(N(I))}r.j=function(T){if(m(this)||m(T))return d;if(v(this))return v(T)?N(this).j(N(T)):N(N(this).j(T));if(v(T))return N(this.j(N(T)));if(this.l(g)<0&&T.l(g)<0)return B(this.m()*T.m());const I=this.g.length+T.g.length,y=[];for(var P=0;P<2*I;P++)y[P]=0;for(P=0;P<this.g.length;P++)for(let R=0;R<T.g.length;R++){const O=this.i(P)>>>16,D=this.i(P)&65535,At=T.i(R)>>>16,Or=T.i(R)&65535;y[2*P+2*R]+=D*Or,J(y,2*P+2*R),y[2*P+2*R+1]+=O*Or,J(y,2*P+2*R+1),y[2*P+2*R+1]+=D*At,J(y,2*P+2*R+1),y[2*P+2*R+2]+=O*At,J(y,2*P+2*R+2)}for(T=0;T<I;T++)y[T]=y[2*T+1]<<16|y[2*T];for(T=I;T<2*I;T++)y[T]=0;return new o(y,0)};function J(T,I){for(;(T[I]&65535)!=T[I];)T[I+1]+=T[I]>>>16,T[I]&=65535,I++}function X(T,I){this.g=T,this.h=I}function se(T,I){if(m(I))throw Error("division by zero");if(m(T))return new X(d,d);if(v(T))return I=se(N(T),I),new X(N(I.g),N(I.h));if(v(I))return I=se(T,N(I)),new X(N(I.g),I.h);if(T.g.length>30){if(v(T)||v(I))throw Error("slowDivide_ only works with positive integers.");for(var y=C,P=I;P.l(T)<=0;)y=ue(y),P=ue(P);var R=ce(y,1),O=ce(P,1);for(P=ce(P,2),y=ce(y,2);!m(P);){var D=O.add(P);D.l(T)<=0&&(R=R.add(y),O=D),P=ce(P,1),y=ce(y,1)}return I=q(T,R.j(I)),new X(R,I)}for(R=d;T.l(I)>=0;){for(y=Math.max(1,Math.floor(T.m()/I.m())),P=Math.ceil(Math.log(y)/Math.LN2),P=P<=48?1:Math.pow(2,P-48),O=B(y),D=O.j(I);v(D)||D.l(T)>0;)y-=P,O=B(y),D=O.j(I);m(O)&&(O=C),R=R.add(O),T=q(T,D)}return new X(R,T)}r.B=function(T){return se(this,T).h},r.and=function(T){const I=Math.max(this.g.length,T.g.length),y=[];for(let P=0;P<I;P++)y[P]=this.i(P)&T.i(P);return new o(y,this.h&T.h)},r.or=function(T){const I=Math.max(this.g.length,T.g.length),y=[];for(let P=0;P<I;P++)y[P]=this.i(P)|T.i(P);return new o(y,this.h|T.h)},r.xor=function(T){const I=Math.max(this.g.length,T.g.length),y=[];for(let P=0;P<I;P++)y[P]=this.i(P)^T.i(P);return new o(y,this.h^T.h)};function ue(T){const I=T.g.length+1,y=[];for(let P=0;P<I;P++)y[P]=T.i(P)<<1|T.i(P-1)>>>31;return new o(y,T.h)}function ce(T,I){const y=I>>5;I%=32;const P=T.g.length-y,R=[];for(let O=0;O<P;O++)R[O]=I>0?T.i(O+y)>>>I|T.i(O+y+1)<<32-I:T.i(O+y);return new o(R,T.h)}n.prototype.digest=n.prototype.A,n.prototype.reset=n.prototype.u,n.prototype.update=n.prototype.v,Qp=n,o.prototype.add=o.prototype.add,o.prototype.multiply=o.prototype.j,o.prototype.modulo=o.prototype.B,o.prototype.compare=o.prototype.l,o.prototype.toNumber=o.prototype.m,o.prototype.toString=o.prototype.toString,o.prototype.getBits=o.prototype.i,o.fromNumber=B,o.fromString=l,hr=o}).apply(typeof of<"u"?of:typeof self<"u"?self:typeof window<"u"?window:{});var Oa=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var $p,$i,Yp,$a,SB,Xp,Zp,eg;(function(){var r,e=Object.defineProperty;function t(c){c=[typeof globalThis=="object"&&globalThis,c,typeof window=="object"&&window,typeof self=="object"&&self,typeof Oa=="object"&&Oa];for(var h=0;h<c.length;++h){var f=c[h];if(f&&f.Math==Math)return f}throw Error("Cannot find global object")}var n=t(this);function s(c,h){if(h)e:{var f=n;c=c.split(".");for(var p=0;p<c.length-1;p++){var S=c[p];if(!(S in f))break e;f=f[S]}c=c[c.length-1],p=f[c],h=h(p),h!=p&&h!=null&&e(f,c,{configurable:!0,writable:!0,value:h})}}s("Symbol.dispose",function(c){return c||Symbol("Symbol.dispose")}),s("Array.prototype.values",function(c){return c||function(){return this[Symbol.iterator]()}}),s("Object.entries",function(c){return c||function(h){var f=[],p;for(p in h)Object.prototype.hasOwnProperty.call(h,p)&&f.push([p,h[p]]);return f}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var i=i||{},o=this||self;function a(c){var h=typeof c;return h=="object"&&c!=null||h=="function"}function u(c,h,f){return c.call.apply(c.bind,arguments)}function B(c,h,f){return B=u,B.apply(null,arguments)}function l(c,h){var f=Array.prototype.slice.call(arguments,1);return function(){var p=f.slice();return p.push.apply(p,arguments),c.apply(this,p)}}function d(c,h){function f(){}f.prototype=h.prototype,c.Z=h.prototype,c.prototype=new f,c.prototype.constructor=c,c.Ob=function(p,S,F){for(var Q=Array(arguments.length-2),le=2;le<arguments.length;le++)Q[le-2]=arguments[le];return h.prototype[S].apply(p,Q)}}var C=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?c=>c&&AsyncContext.Snapshot.wrap(c):c=>c;function g(c){const h=c.length;if(h>0){const f=Array(h);for(let p=0;p<h;p++)f[p]=c[p];return f}return[]}function m(c,h){for(let p=1;p<arguments.length;p++){const S=arguments[p];var f=typeof S;if(f=f!="object"?f:S?Array.isArray(S)?"array":f:"null",f=="array"||f=="object"&&typeof S.length=="number"){f=c.length||0;const F=S.length||0;c.length=f+F;for(let Q=0;Q<F;Q++)c[f+Q]=S[Q]}else c.push(S)}}class v{constructor(h,f){this.i=h,this.j=f,this.h=0,this.g=null}get(){let h;return this.h>0?(this.h--,h=this.g,this.g=h.next,h.next=null):h=this.i(),h}}function N(c){o.setTimeout(()=>{throw c},0)}function q(){var c=T;let h=null;return c.g&&(h=c.g,c.g=c.g.next,c.g||(c.h=null),h.next=null),h}class J{constructor(){this.h=this.g=null}add(h,f){const p=X.get();p.set(h,f),this.h?this.h.next=p:this.g=p,this.h=p}}var X=new v(()=>new se,c=>c.reset());class se{constructor(){this.next=this.g=this.h=null}set(h,f){this.h=h,this.g=f,this.next=null}reset(){this.next=this.g=this.h=null}}let ue,ce=!1,T=new J,I=()=>{const c=Promise.resolve(void 0);ue=()=>{c.then(y)}};function y(){for(var c;c=q();){try{c.h.call(c.g)}catch(f){N(f)}var h=X;h.j(c),h.h<100&&(h.h++,c.next=h.g,h.g=c)}ce=!1}function P(){this.u=this.u,this.C=this.C}P.prototype.u=!1,P.prototype.dispose=function(){this.u||(this.u=!0,this.N())},P.prototype[Symbol.dispose]=function(){this.dispose()},P.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function R(c,h){this.type=c,this.g=this.target=h,this.defaultPrevented=!1}R.prototype.h=function(){this.defaultPrevented=!0};var O=function(){if(!o.addEventListener||!Object.defineProperty)return!1;var c=!1,h=Object.defineProperty({},"passive",{get:function(){c=!0}});try{const f=()=>{};o.addEventListener("test",f,h),o.removeEventListener("test",f,h)}catch{}return c}();function D(c){return/^[\s\xa0]*$/.test(c)}function At(c,h){R.call(this,c?c.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,c&&this.init(c,h)}d(At,R),At.prototype.init=function(c,h){const f=this.type=c.type,p=c.changedTouches&&c.changedTouches.length?c.changedTouches[0]:null;this.target=c.target||c.srcElement,this.g=h,h=c.relatedTarget,h||(f=="mouseover"?h=c.fromElement:f=="mouseout"&&(h=c.toElement)),this.relatedTarget=h,p?(this.clientX=p.clientX!==void 0?p.clientX:p.pageX,this.clientY=p.clientY!==void 0?p.clientY:p.pageY,this.screenX=p.screenX||0,this.screenY=p.screenY||0):(this.clientX=c.clientX!==void 0?c.clientX:c.pageX,this.clientY=c.clientY!==void 0?c.clientY:c.pageY,this.screenX=c.screenX||0,this.screenY=c.screenY||0),this.button=c.button,this.key=c.key||"",this.ctrlKey=c.ctrlKey,this.altKey=c.altKey,this.shiftKey=c.shiftKey,this.metaKey=c.metaKey,this.pointerId=c.pointerId||0,this.pointerType=c.pointerType,this.state=c.state,this.i=c,c.defaultPrevented&&At.Z.h.call(this)},At.prototype.h=function(){At.Z.h.call(this);const c=this.i;c.preventDefault?c.preventDefault():c.returnValue=!1};var Or="closure_listenable_"+(Math.random()*1e6|0),QE=0;function $E(c,h,f,p,S){this.listener=c,this.proxy=null,this.src=h,this.type=f,this.capture=!!p,this.ha=S,this.key=++QE,this.da=this.fa=!1}function ga(c){c.da=!0,c.listener=null,c.proxy=null,c.src=null,c.ha=null}function ma(c,h,f){for(const p in c)h.call(f,c[p],p,c)}function YE(c,h){for(const f in c)h.call(void 0,c[f],f,c)}function Wh(c){const h={};for(const f in c)h[f]=c[f];return h}const Qh="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function $h(c,h){let f,p;for(let S=1;S<arguments.length;S++){p=arguments[S];for(f in p)c[f]=p[f];for(let F=0;F<Qh.length;F++)f=Qh[F],Object.prototype.hasOwnProperty.call(p,f)&&(c[f]=p[f])}}function _a(c){this.src=c,this.g={},this.h=0}_a.prototype.add=function(c,h,f,p,S){const F=c.toString();c=this.g[F],c||(c=this.g[F]=[],this.h++);const Q=Sc(c,h,p,S);return Q>-1?(h=c[Q],f||(h.fa=!1)):(h=new $E(h,this.src,F,!!p,S),h.fa=f,c.push(h)),h};function bc(c,h){const f=h.type;if(f in c.g){var p=c.g[f],S=Array.prototype.indexOf.call(p,h,void 0),F;(F=S>=0)&&Array.prototype.splice.call(p,S,1),F&&(ga(h),c.g[f].length==0&&(delete c.g[f],c.h--))}}function Sc(c,h,f,p){for(let S=0;S<c.length;++S){const F=c[S];if(!F.da&&F.listener==h&&F.capture==!!f&&F.ha==p)return S}return-1}var Oc="closure_lm_"+(Math.random()*1e6|0),Nc={};function Yh(c,h,f,p,S){if(Array.isArray(h)){for(let F=0;F<h.length;F++)Yh(c,h[F],f,p,S);return null}return f=ed(f),c&&c[Or]?c.J(h,f,a(p)?!!p.capture:!1,S):XE(c,h,f,!1,p,S)}function XE(c,h,f,p,S,F){if(!h)throw Error("Invalid event type");const Q=a(S)?!!S.capture:!!S;let le=Lc(c);if(le||(c[Oc]=le=new _a(c)),f=le.add(h,f,p,Q,F),f.proxy)return f;if(p=ZE(),f.proxy=p,p.src=c,p.listener=f,c.addEventListener)O||(S=Q),S===void 0&&(S=!1),c.addEventListener(h.toString(),p,S);else if(c.attachEvent)c.attachEvent(Zh(h.toString()),p);else if(c.addListener&&c.removeListener)c.addListener(p);else throw Error("addEventListener and attachEvent are unavailable.");return f}function ZE(){function c(f){return h.call(c.src,c.listener,f)}const h=eI;return c}function Xh(c,h,f,p,S){if(Array.isArray(h))for(var F=0;F<h.length;F++)Xh(c,h[F],f,p,S);else p=a(p)?!!p.capture:!!p,f=ed(f),c&&c[Or]?(c=c.i,F=String(h).toString(),F in c.g&&(h=c.g[F],f=Sc(h,f,p,S),f>-1&&(ga(h[f]),Array.prototype.splice.call(h,f,1),h.length==0&&(delete c.g[F],c.h--)))):c&&(c=Lc(c))&&(h=c.g[h.toString()],c=-1,h&&(c=Sc(h,f,p,S)),(f=c>-1?h[c]:null)&&Fc(f))}function Fc(c){if(typeof c!="number"&&c&&!c.da){var h=c.src;if(h&&h[Or])bc(h.i,c);else{var f=c.type,p=c.proxy;h.removeEventListener?h.removeEventListener(f,p,c.capture):h.detachEvent?h.detachEvent(Zh(f),p):h.addListener&&h.removeListener&&h.removeListener(p),(f=Lc(h))?(bc(f,c),f.h==0&&(f.src=null,h[Oc]=null)):ga(c)}}}function Zh(c){return c in Nc?Nc[c]:Nc[c]="on"+c}function eI(c,h){if(c.da)c=!0;else{h=new At(h,this);const f=c.listener,p=c.ha||c.src;c.fa&&Fc(c),c=f.call(p,h)}return c}function Lc(c){return c=c[Oc],c instanceof _a?c:null}var kc="__closure_events_fn_"+(Math.random()*1e9>>>0);function ed(c){return typeof c=="function"?c:(c[kc]||(c[kc]=function(h){return c.handleEvent(h)}),c[kc])}function Bt(){P.call(this),this.i=new _a(this),this.M=this,this.G=null}d(Bt,P),Bt.prototype[Or]=!0,Bt.prototype.removeEventListener=function(c,h,f,p){Xh(this,c,h,f,p)};function mt(c,h){var f,p=c.G;if(p)for(f=[];p;p=p.G)f.push(p);if(c=c.M,p=h.type||h,typeof h=="string")h=new R(h,c);else if(h instanceof R)h.target=h.target||c;else{var S=h;h=new R(p,c),$h(h,S)}S=!0;let F,Q;if(f)for(Q=f.length-1;Q>=0;Q--)F=h.g=f[Q],S=Ea(F,p,!0,h)&&S;if(F=h.g=c,S=Ea(F,p,!0,h)&&S,S=Ea(F,p,!1,h)&&S,f)for(Q=0;Q<f.length;Q++)F=h.g=f[Q],S=Ea(F,p,!1,h)&&S}Bt.prototype.N=function(){if(Bt.Z.N.call(this),this.i){var c=this.i;for(const h in c.g){const f=c.g[h];for(let p=0;p<f.length;p++)ga(f[p]);delete c.g[h],c.h--}}this.G=null},Bt.prototype.J=function(c,h,f,p){return this.i.add(String(c),h,!1,f,p)},Bt.prototype.K=function(c,h,f,p){return this.i.add(String(c),h,!0,f,p)};function Ea(c,h,f,p){if(h=c.i.g[String(h)],!h)return!0;h=h.concat();let S=!0;for(let F=0;F<h.length;++F){const Q=h[F];if(Q&&!Q.da&&Q.capture==f){const le=Q.listener,ze=Q.ha||Q.src;Q.fa&&bc(c.i,Q),S=le.call(ze,p)!==!1&&S}}return S&&!p.defaultPrevented}function tI(c,h){if(typeof c!="function")if(c&&typeof c.handleEvent=="function")c=B(c.handleEvent,c);else throw Error("Invalid listener argument");return Number(h)>2147483647?-1:o.setTimeout(c,h||0)}function td(c){c.g=tI(()=>{c.g=null,c.i&&(c.i=!1,td(c))},c.l);const h=c.h;c.h=null,c.m.apply(null,h)}class nI extends P{constructor(h,f){super(),this.m=h,this.l=f,this.h=null,this.i=!1,this.g=null}j(h){this.h=arguments,this.g?this.i=!0:td(this)}N(){super.N(),this.g&&(o.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function yi(c){P.call(this),this.h=c,this.g={}}d(yi,P);var nd=[];function rd(c){ma(c.g,function(h,f){this.g.hasOwnProperty(f)&&Fc(h)},c),c.g={}}yi.prototype.N=function(){yi.Z.N.call(this),rd(this)},yi.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var xc=o.JSON.stringify,rI=o.JSON.parse,sI=class{stringify(c){return o.JSON.stringify(c,void 0)}parse(c){return o.JSON.parse(c,void 0)}};function sd(){}function id(){}var wi={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function Vc(){R.call(this,"d")}d(Vc,R);function Mc(){R.call(this,"c")}d(Mc,R);var Nr={},od=null;function Ia(){return od=od||new Bt}Nr.Ia="serverreachability";function ad(c){R.call(this,Nr.Ia,c)}d(ad,R);function Ti(c){const h=Ia();mt(h,new ad(h))}Nr.STAT_EVENT="statevent";function ud(c,h){R.call(this,Nr.STAT_EVENT,c),this.stat=h}d(ud,R);function _t(c){const h=Ia();mt(h,new ud(h,c))}Nr.Ja="timingevent";function cd(c,h){R.call(this,Nr.Ja,c),this.size=h}d(cd,R);function Ai(c,h){if(typeof c!="function")throw Error("Fn must not be null and must be a function");return o.setTimeout(function(){c()},h)}function Ri(){this.g=!0}Ri.prototype.ua=function(){this.g=!1};function iI(c,h,f,p,S,F){c.info(function(){if(c.g)if(F){var Q="",le=F.split("&");for(let we=0;we<le.length;we++){var ze=le[we].split("=");if(ze.length>1){const nt=ze[0];ze=ze[1];const rn=nt.split("_");Q=rn.length>=2&&rn[1]=="type"?Q+(nt+"="+ze+"&"):Q+(nt+"=redacted&")}}}else Q=null;else Q=F;return"XMLHTTP REQ ("+p+") [attempt "+S+"]: "+h+`
`+f+`
`+Q})}function oI(c,h,f,p,S,F,Q){c.info(function(){return"XMLHTTP RESP ("+p+") [ attempt "+S+"]: "+h+`
`+f+`
`+F+" "+Q})}function Rs(c,h,f,p){c.info(function(){return"XMLHTTP TEXT ("+h+"): "+uI(c,f)+(p?" "+p:"")})}function aI(c,h){c.info(function(){return"TIMEOUT: "+h})}Ri.prototype.info=function(){};function uI(c,h){if(!c.g)return h;if(!h)return null;try{const F=JSON.parse(h);if(F){for(c=0;c<F.length;c++)if(Array.isArray(F[c])){var f=F[c];if(!(f.length<2)){var p=f[1];if(Array.isArray(p)&&!(p.length<1)){var S=p[0];if(S!="noop"&&S!="stop"&&S!="close")for(let Q=1;Q<p.length;Q++)p[Q]=""}}}}return xc(F)}catch{return h}}var Da={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},Bd={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},ld;function Gc(){}d(Gc,sd),Gc.prototype.g=function(){return new XMLHttpRequest},ld=new Gc;function vi(c){return encodeURIComponent(String(c))}function cI(c){var h=1;c=c.split(":");const f=[];for(;h>0&&c.length;)f.push(c.shift()),h--;return c.length&&f.push(c.join(":")),f}function qn(c,h,f,p){this.j=c,this.i=h,this.l=f,this.S=p||1,this.V=new yi(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new hd}function hd(){this.i=null,this.g="",this.h=!1}var dd={},Uc={};function Hc(c,h,f){c.M=1,c.A=wa(nn(h)),c.u=f,c.R=!0,fd(c,null)}function fd(c,h){c.F=Date.now(),ya(c),c.B=nn(c.A);var f=c.B,p=c.S;Array.isArray(p)||(p=[String(p)]),Rd(f.i,"t",p),c.C=0,f=c.j.L,c.h=new hd,c.g=Jd(c.j,f?h:null,!c.u),c.P>0&&(c.O=new nI(B(c.Y,c,c.g),c.P)),h=c.V,f=c.g,p=c.ba;var S="readystatechange";Array.isArray(S)||(S&&(nd[0]=S.toString()),S=nd);for(let F=0;F<S.length;F++){const Q=Yh(f,S[F],p||h.handleEvent,!1,h.h||h);if(!Q)break;h.g[Q.key]=Q}h=c.J?Wh(c.J):{},c.u?(c.v||(c.v="POST"),h["Content-Type"]="application/x-www-form-urlencoded",c.g.ea(c.B,c.v,c.u,h)):(c.v="GET",c.g.ea(c.B,c.v,null,h)),Ti(),iI(c.i,c.v,c.B,c.l,c.S,c.u)}qn.prototype.ba=function(c){c=c.target;const h=this.O;h&&Kn(c)==3?h.j():this.Y(c)},qn.prototype.Y=function(c){try{if(c==this.g)e:{const le=Kn(this.g),ze=this.g.ya(),we=this.g.ca();if(!(le<3)&&(le!=3||this.g&&(this.h.h||this.g.la()||Fd(this.g)))){this.K||le!=4||ze==7||(ze==8||we<=0?Ti(3):Ti(2)),qc(this);var h=this.g.ca();this.X=h;var f=BI(this);if(this.o=h==200,oI(this.i,this.v,this.B,this.l,this.S,le,h),this.o){if(this.U&&!this.L){t:{if(this.g){var p,S=this.g;if((p=S.g?S.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!D(p)){var F=p;break t}}F=null}if(c=F)Rs(this.i,this.l,c,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,jc(this,c);else{this.o=!1,this.m=3,_t(12),Fr(this),Pi(this);break e}}if(this.R){c=!0;let nt;for(;!this.K&&this.C<f.length;)if(nt=lI(this,f),nt==Uc){le==4&&(this.m=4,_t(14),c=!1),Rs(this.i,this.l,null,"[Incomplete Response]");break}else if(nt==dd){this.m=4,_t(15),Rs(this.i,this.l,f,"[Invalid Chunk]"),c=!1;break}else Rs(this.i,this.l,nt,null),jc(this,nt);if(Cd(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),le!=4||f.length!=0||this.h.h||(this.m=1,_t(16),c=!1),this.o=this.o&&c,!c)Rs(this.i,this.l,f,"[Invalid Chunked Response]"),Fr(this),Pi(this);else if(f.length>0&&!this.W){this.W=!0;var Q=this.j;Q.g==this&&Q.aa&&!Q.P&&(Q.j.info("Great, no buffering proxy detected. Bytes received: "+f.length),Xc(Q),Q.P=!0,_t(11))}}else Rs(this.i,this.l,f,null),jc(this,f);le==4&&Fr(this),this.o&&!this.K&&(le==4?Ud(this.j,this):(this.o=!1,ya(this)))}else TI(this.g),h==400&&f.indexOf("Unknown SID")>0?(this.m=3,_t(12)):(this.m=0,_t(13)),Fr(this),Pi(this)}}}catch{}finally{}};function BI(c){if(!Cd(c))return c.g.la();const h=Fd(c.g);if(h==="")return"";let f="";const p=h.length,S=Kn(c.g)==4;if(!c.h.i){if(typeof TextDecoder>"u")return Fr(c),Pi(c),"";c.h.i=new o.TextDecoder}for(let F=0;F<p;F++)c.h.h=!0,f+=c.h.i.decode(h[F],{stream:!(S&&F==p-1)});return h.length=0,c.h.g+=f,c.C=0,c.h.g}function Cd(c){return c.g?c.v=="GET"&&c.M!=2&&c.j.Aa:!1}function lI(c,h){var f=c.C,p=h.indexOf(`
`,f);return p==-1?Uc:(f=Number(h.substring(f,p)),isNaN(f)?dd:(p+=1,p+f>h.length?Uc:(h=h.slice(p,p+f),c.C=p+f,h)))}qn.prototype.cancel=function(){this.K=!0,Fr(this)};function ya(c){c.T=Date.now()+c.H,pd(c,c.H)}function pd(c,h){if(c.D!=null)throw Error("WatchDog timer not null");c.D=Ai(B(c.aa,c),h)}function qc(c){c.D&&(o.clearTimeout(c.D),c.D=null)}qn.prototype.aa=function(){this.D=null;const c=Date.now();c-this.T>=0?(aI(this.i,this.B),this.M!=2&&(Ti(),_t(17)),Fr(this),this.m=2,Pi(this)):pd(this,this.T-c)};function Pi(c){c.j.I==0||c.K||Ud(c.j,c)}function Fr(c){qc(c);var h=c.O;h&&typeof h.dispose=="function"&&h.dispose(),c.O=null,rd(c.V),c.g&&(h=c.g,c.g=null,h.abort(),h.dispose())}function jc(c,h){try{var f=c.j;if(f.I!=0&&(f.g==c||Jc(f.h,c))){if(!c.L&&Jc(f.h,c)&&f.I==3){try{var p=f.Ba.g.parse(h)}catch{p=null}if(Array.isArray(p)&&p.length==3){var S=p;if(S[0]==0){e:if(!f.v){if(f.g)if(f.g.F+3e3<c.F)Pa(f),Ra(f);else break e;Yc(f),_t(18)}}else f.xa=S[1],0<f.xa-f.K&&S[2]<37500&&f.F&&f.A==0&&!f.C&&(f.C=Ai(B(f.Va,f),6e3));_d(f.h)<=1&&f.ta&&(f.ta=void 0)}else kr(f,11)}else if((c.L||f.g==c)&&Pa(f),!D(h))for(S=f.Ba.g.parse(h),h=0;h<S.length;h++){let we=S[h];const nt=we[0];if(!(nt<=f.K))if(f.K=nt,we=we[1],f.I==2)if(we[0]=="c"){f.M=we[1],f.ba=we[2];const rn=we[3];rn!=null&&(f.ka=rn,f.j.info("VER="+f.ka));const xr=we[4];xr!=null&&(f.za=xr,f.j.info("SVER="+f.za));const zn=we[5];zn!=null&&typeof zn=="number"&&zn>0&&(p=1.5*zn,f.O=p,f.j.info("backChannelRequestTimeoutMs_="+p)),p=f;const Wn=c.g;if(Wn){const Sa=Wn.g?Wn.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(Sa){var F=p.h;F.g||Sa.indexOf("spdy")==-1&&Sa.indexOf("quic")==-1&&Sa.indexOf("h2")==-1||(F.j=F.l,F.g=new Set,F.h&&(Kc(F,F.h),F.h=null))}if(p.G){const Zc=Wn.g?Wn.g.getResponseHeader("X-HTTP-Session-Id"):null;Zc&&(p.wa=Zc,Pe(p.J,p.G,Zc))}}f.I=3,f.l&&f.l.ra(),f.aa&&(f.T=Date.now()-c.F,f.j.info("Handshake RTT: "+f.T+"ms")),p=f;var Q=c;if(p.na=jd(p,p.L?p.ba:null,p.W),Q.L){Ed(p.h,Q);var le=Q,ze=p.O;ze&&(le.H=ze),le.D&&(qc(le),ya(le)),p.g=Q}else Md(p);f.i.length>0&&va(f)}else we[0]!="stop"&&we[0]!="close"||kr(f,7);else f.I==3&&(we[0]=="stop"||we[0]=="close"?we[0]=="stop"?kr(f,7):$c(f):we[0]!="noop"&&f.l&&f.l.qa(we),f.A=0)}}Ti(4)}catch{}}var hI=class{constructor(c,h){this.g=c,this.map=h}};function gd(c){this.l=c||10,o.PerformanceNavigationTiming?(c=o.performance.getEntriesByType("navigation"),c=c.length>0&&(c[0].nextHopProtocol=="hq"||c[0].nextHopProtocol=="h2")):c=!!(o.chrome&&o.chrome.loadTimes&&o.chrome.loadTimes()&&o.chrome.loadTimes().wasFetchedViaSpdy),this.j=c?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function md(c){return c.h?!0:c.g?c.g.size>=c.j:!1}function _d(c){return c.h?1:c.g?c.g.size:0}function Jc(c,h){return c.h?c.h==h:c.g?c.g.has(h):!1}function Kc(c,h){c.g?c.g.add(h):c.h=h}function Ed(c,h){c.h&&c.h==h?c.h=null:c.g&&c.g.has(h)&&c.g.delete(h)}gd.prototype.cancel=function(){if(this.i=Id(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const c of this.g.values())c.cancel();this.g.clear()}};function Id(c){if(c.h!=null)return c.i.concat(c.h.G);if(c.g!=null&&c.g.size!==0){let h=c.i;for(const f of c.g.values())h=h.concat(f.G);return h}return g(c.i)}var Dd=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function dI(c,h){if(c){c=c.split("&");for(let f=0;f<c.length;f++){const p=c[f].indexOf("=");let S,F=null;p>=0?(S=c[f].substring(0,p),F=c[f].substring(p+1)):S=c[f],h(S,F?decodeURIComponent(F.replace(/\+/g," ")):"")}}}function jn(c){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let h;c instanceof jn?(this.l=c.l,bi(this,c.j),this.o=c.o,this.g=c.g,Si(this,c.u),this.h=c.h,zc(this,vd(c.i)),this.m=c.m):c&&(h=String(c).match(Dd))?(this.l=!1,bi(this,h[1]||"",!0),this.o=Oi(h[2]||""),this.g=Oi(h[3]||"",!0),Si(this,h[4]),this.h=Oi(h[5]||"",!0),zc(this,h[6]||"",!0),this.m=Oi(h[7]||"")):(this.l=!1,this.i=new Fi(null,this.l))}jn.prototype.toString=function(){const c=[];var h=this.j;h&&c.push(Ni(h,yd,!0),":");var f=this.g;return(f||h=="file")&&(c.push("//"),(h=this.o)&&c.push(Ni(h,yd,!0),"@"),c.push(vi(f).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),f=this.u,f!=null&&c.push(":",String(f))),(f=this.h)&&(this.g&&f.charAt(0)!="/"&&c.push("/"),c.push(Ni(f,f.charAt(0)=="/"?pI:CI,!0))),(f=this.i.toString())&&c.push("?",f),(f=this.m)&&c.push("#",Ni(f,mI)),c.join("")},jn.prototype.resolve=function(c){const h=nn(this);let f=!!c.j;f?bi(h,c.j):f=!!c.o,f?h.o=c.o:f=!!c.g,f?h.g=c.g:f=c.u!=null;var p=c.h;if(f)Si(h,c.u);else if(f=!!c.h){if(p.charAt(0)!="/")if(this.g&&!this.h)p="/"+p;else{var S=h.h.lastIndexOf("/");S!=-1&&(p=h.h.slice(0,S+1)+p)}if(S=p,S==".."||S==".")p="";else if(S.indexOf("./")!=-1||S.indexOf("/.")!=-1){p=S.lastIndexOf("/",0)==0,S=S.split("/");const F=[];for(let Q=0;Q<S.length;){const le=S[Q++];le=="."?p&&Q==S.length&&F.push(""):le==".."?((F.length>1||F.length==1&&F[0]!="")&&F.pop(),p&&Q==S.length&&F.push("")):(F.push(le),p=!0)}p=F.join("/")}else p=S}return f?h.h=p:f=c.i.toString()!=="",f?zc(h,vd(c.i)):f=!!c.m,f&&(h.m=c.m),h};function nn(c){return new jn(c)}function bi(c,h,f){c.j=f?Oi(h,!0):h,c.j&&(c.j=c.j.replace(/:$/,""))}function Si(c,h){if(h){if(h=Number(h),isNaN(h)||h<0)throw Error("Bad port number "+h);c.u=h}else c.u=null}function zc(c,h,f){h instanceof Fi?(c.i=h,_I(c.i,c.l)):(f||(h=Ni(h,gI)),c.i=new Fi(h,c.l))}function Pe(c,h,f){c.i.set(h,f)}function wa(c){return Pe(c,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),c}function Oi(c,h){return c?h?decodeURI(c.replace(/%25/g,"%2525")):decodeURIComponent(c):""}function Ni(c,h,f){return typeof c=="string"?(c=encodeURI(c).replace(h,fI),f&&(c=c.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),c):null}function fI(c){return c=c.charCodeAt(0),"%"+(c>>4&15).toString(16)+(c&15).toString(16)}var yd=/[#\/\?@]/g,CI=/[#\?:]/g,pI=/[#\?]/g,gI=/[#\?@]/g,mI=/#/g;function Fi(c,h){this.h=this.g=null,this.i=c||null,this.j=!!h}function Lr(c){c.g||(c.g=new Map,c.h=0,c.i&&dI(c.i,function(h,f){c.add(decodeURIComponent(h.replace(/\+/g," ")),f)}))}r=Fi.prototype,r.add=function(c,h){Lr(this),this.i=null,c=vs(this,c);let f=this.g.get(c);return f||this.g.set(c,f=[]),f.push(h),this.h+=1,this};function wd(c,h){Lr(c),h=vs(c,h),c.g.has(h)&&(c.i=null,c.h-=c.g.get(h).length,c.g.delete(h))}function Td(c,h){return Lr(c),h=vs(c,h),c.g.has(h)}r.forEach=function(c,h){Lr(this),this.g.forEach(function(f,p){f.forEach(function(S){c.call(h,S,p,this)},this)},this)};function Ad(c,h){Lr(c);let f=[];if(typeof h=="string")Td(c,h)&&(f=f.concat(c.g.get(vs(c,h))));else for(c=Array.from(c.g.values()),h=0;h<c.length;h++)f=f.concat(c[h]);return f}r.set=function(c,h){return Lr(this),this.i=null,c=vs(this,c),Td(this,c)&&(this.h-=this.g.get(c).length),this.g.set(c,[h]),this.h+=1,this},r.get=function(c,h){return c?(c=Ad(this,c),c.length>0?String(c[0]):h):h};function Rd(c,h,f){wd(c,h),f.length>0&&(c.i=null,c.g.set(vs(c,h),g(f)),c.h+=f.length)}r.toString=function(){if(this.i)return this.i;if(!this.g)return"";const c=[],h=Array.from(this.g.keys());for(let p=0;p<h.length;p++){var f=h[p];const S=vi(f);f=Ad(this,f);for(let F=0;F<f.length;F++){let Q=S;f[F]!==""&&(Q+="="+vi(f[F])),c.push(Q)}}return this.i=c.join("&")};function vd(c){const h=new Fi;return h.i=c.i,c.g&&(h.g=new Map(c.g),h.h=c.h),h}function vs(c,h){return h=String(h),c.j&&(h=h.toLowerCase()),h}function _I(c,h){h&&!c.j&&(Lr(c),c.i=null,c.g.forEach(function(f,p){const S=p.toLowerCase();p!=S&&(wd(this,p),Rd(this,S,f))},c)),c.j=h}function EI(c,h){const f=new Ri;if(o.Image){const p=new Image;p.onload=l(Jn,f,"TestLoadImage: loaded",!0,h,p),p.onerror=l(Jn,f,"TestLoadImage: error",!1,h,p),p.onabort=l(Jn,f,"TestLoadImage: abort",!1,h,p),p.ontimeout=l(Jn,f,"TestLoadImage: timeout",!1,h,p),o.setTimeout(function(){p.ontimeout&&p.ontimeout()},1e4),p.src=c}else h(!1)}function II(c,h){const f=new Ri,p=new AbortController,S=setTimeout(()=>{p.abort(),Jn(f,"TestPingServer: timeout",!1,h)},1e4);fetch(c,{signal:p.signal}).then(F=>{clearTimeout(S),F.ok?Jn(f,"TestPingServer: ok",!0,h):Jn(f,"TestPingServer: server error",!1,h)}).catch(()=>{clearTimeout(S),Jn(f,"TestPingServer: error",!1,h)})}function Jn(c,h,f,p,S){try{S&&(S.onload=null,S.onerror=null,S.onabort=null,S.ontimeout=null),p(f)}catch{}}function DI(){this.g=new sI}function Wc(c){this.i=c.Sb||null,this.h=c.ab||!1}d(Wc,sd),Wc.prototype.g=function(){return new Ta(this.i,this.h)};function Ta(c,h){Bt.call(this),this.H=c,this.o=h,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}d(Ta,Bt),r=Ta.prototype,r.open=function(c,h){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=c,this.D=h,this.readyState=1,ki(this)},r.send=function(c){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const h={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};c&&(h.body=c),(this.H||o).fetch(new Request(this.D,h)).then(this.Pa.bind(this),this.ga.bind(this))},r.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Li(this)),this.readyState=0},r.Pa=function(c){if(this.g&&(this.l=c,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=c.headers,this.readyState=2,ki(this)),this.g&&(this.readyState=3,ki(this),this.g)))if(this.responseType==="arraybuffer")c.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof o.ReadableStream<"u"&&"body"in c){if(this.j=c.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Pd(this)}else c.text().then(this.Oa.bind(this),this.ga.bind(this))};function Pd(c){c.j.read().then(c.Ma.bind(c)).catch(c.ga.bind(c))}r.Ma=function(c){if(this.g){if(this.o&&c.value)this.response.push(c.value);else if(!this.o){var h=c.value?c.value:new Uint8Array(0);(h=this.B.decode(h,{stream:!c.done}))&&(this.response=this.responseText+=h)}c.done?Li(this):ki(this),this.readyState==3&&Pd(this)}},r.Oa=function(c){this.g&&(this.response=this.responseText=c,Li(this))},r.Na=function(c){this.g&&(this.response=c,Li(this))},r.ga=function(){this.g&&Li(this)};function Li(c){c.readyState=4,c.l=null,c.j=null,c.B=null,ki(c)}r.setRequestHeader=function(c,h){this.A.append(c,h)},r.getResponseHeader=function(c){return this.h&&this.h.get(c.toLowerCase())||""},r.getAllResponseHeaders=function(){if(!this.h)return"";const c=[],h=this.h.entries();for(var f=h.next();!f.done;)f=f.value,c.push(f[0]+": "+f[1]),f=h.next();return c.join(`\r
`)};function ki(c){c.onreadystatechange&&c.onreadystatechange.call(c)}Object.defineProperty(Ta.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(c){this.m=c?"include":"same-origin"}});function bd(c){let h="";return ma(c,function(f,p){h+=p,h+=":",h+=f,h+=`\r
`}),h}function Qc(c,h,f){e:{for(p in f){var p=!1;break e}p=!0}p||(f=bd(f),typeof c=="string"?f!=null&&vi(f):Pe(c,h,f))}function Ve(c){Bt.call(this),this.headers=new Map,this.L=c||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}d(Ve,Bt);var yI=/^https?$/i,wI=["POST","PUT"];r=Ve.prototype,r.Fa=function(c){this.H=c},r.ea=function(c,h,f,p){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+c);h=h?h.toUpperCase():"GET",this.D=c,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():ld.g(),this.g.onreadystatechange=C(B(this.Ca,this));try{this.B=!0,this.g.open(h,String(c),!0),this.B=!1}catch(F){Sd(this,F);return}if(c=f||"",f=new Map(this.headers),p)if(Object.getPrototypeOf(p)===Object.prototype)for(var S in p)f.set(S,p[S]);else if(typeof p.keys=="function"&&typeof p.get=="function")for(const F of p.keys())f.set(F,p.get(F));else throw Error("Unknown input type for opt_headers: "+String(p));p=Array.from(f.keys()).find(F=>F.toLowerCase()=="content-type"),S=o.FormData&&c instanceof o.FormData,!(Array.prototype.indexOf.call(wI,h,void 0)>=0)||p||S||f.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[F,Q]of f)this.g.setRequestHeader(F,Q);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(c),this.v=!1}catch(F){Sd(this,F)}};function Sd(c,h){c.h=!1,c.g&&(c.j=!0,c.g.abort(),c.j=!1),c.l=h,c.o=5,Od(c),Aa(c)}function Od(c){c.A||(c.A=!0,mt(c,"complete"),mt(c,"error"))}r.abort=function(c){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=c||7,mt(this,"complete"),mt(this,"abort"),Aa(this))},r.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Aa(this,!0)),Ve.Z.N.call(this)},r.Ca=function(){this.u||(this.B||this.v||this.j?Nd(this):this.Xa())},r.Xa=function(){Nd(this)};function Nd(c){if(c.h&&typeof i<"u"){if(c.v&&Kn(c)==4)setTimeout(c.Ca.bind(c),0);else if(mt(c,"readystatechange"),Kn(c)==4){c.h=!1;try{const F=c.ca();e:switch(F){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var h=!0;break e;default:h=!1}var f;if(!(f=h)){var p;if(p=F===0){let Q=String(c.D).match(Dd)[1]||null;!Q&&o.self&&o.self.location&&(Q=o.self.location.protocol.slice(0,-1)),p=!yI.test(Q?Q.toLowerCase():"")}f=p}if(f)mt(c,"complete"),mt(c,"success");else{c.o=6;try{var S=Kn(c)>2?c.g.statusText:""}catch{S=""}c.l=S+" ["+c.ca()+"]",Od(c)}}finally{Aa(c)}}}}function Aa(c,h){if(c.g){c.m&&(clearTimeout(c.m),c.m=null);const f=c.g;c.g=null,h||mt(c,"ready");try{f.onreadystatechange=null}catch{}}}r.isActive=function(){return!!this.g};function Kn(c){return c.g?c.g.readyState:0}r.ca=function(){try{return Kn(this)>2?this.g.status:-1}catch{return-1}},r.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},r.La=function(c){if(this.g){var h=this.g.responseText;return c&&h.indexOf(c)==0&&(h=h.substring(c.length)),rI(h)}};function Fd(c){try{if(!c.g)return null;if("response"in c.g)return c.g.response;switch(c.F){case"":case"text":return c.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in c.g)return c.g.mozResponseArrayBuffer}return null}catch{return null}}function TI(c){const h={};c=(c.g&&Kn(c)>=2&&c.g.getAllResponseHeaders()||"").split(`\r
`);for(let p=0;p<c.length;p++){if(D(c[p]))continue;var f=cI(c[p]);const S=f[0];if(f=f[1],typeof f!="string")continue;f=f.trim();const F=h[S]||[];h[S]=F,F.push(f)}YE(h,function(p){return p.join(", ")})}r.ya=function(){return this.o},r.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function xi(c,h,f){return f&&f.internalChannelParams&&f.internalChannelParams[c]||h}function Ld(c){this.za=0,this.i=[],this.j=new Ri,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=xi("failFast",!1,c),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=xi("baseRetryDelayMs",5e3,c),this.Za=xi("retryDelaySeedMs",1e4,c),this.Ta=xi("forwardChannelMaxRetries",2,c),this.va=xi("forwardChannelRequestTimeoutMs",2e4,c),this.ma=c&&c.xmlHttpFactory||void 0,this.Ua=c&&c.Rb||void 0,this.Aa=c&&c.useFetchStreams||!1,this.O=void 0,this.L=c&&c.supportsCrossDomainXhr||!1,this.M="",this.h=new gd(c&&c.concurrentRequestLimit),this.Ba=new DI,this.S=c&&c.fastHandshake||!1,this.R=c&&c.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=c&&c.Pb||!1,c&&c.ua&&this.j.ua(),c&&c.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&c&&c.detectBufferingProxy||!1,this.ia=void 0,c&&c.longPollingTimeout&&c.longPollingTimeout>0&&(this.ia=c.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}r=Ld.prototype,r.ka=8,r.I=1,r.connect=function(c,h,f,p){_t(0),this.W=c,this.H=h||{},f&&p!==void 0&&(this.H.OSID=f,this.H.OAID=p),this.F=this.X,this.J=jd(this,null,this.W),va(this)};function $c(c){if(kd(c),c.I==3){var h=c.V++,f=nn(c.J);if(Pe(f,"SID",c.M),Pe(f,"RID",h),Pe(f,"TYPE","terminate"),Vi(c,f),h=new qn(c,c.j,h),h.M=2,h.A=wa(nn(f)),f=!1,o.navigator&&o.navigator.sendBeacon)try{f=o.navigator.sendBeacon(h.A.toString(),"")}catch{}!f&&o.Image&&(new Image().src=h.A,f=!0),f||(h.g=Jd(h.j,null),h.g.ea(h.A)),h.F=Date.now(),ya(h)}qd(c)}function Ra(c){c.g&&(Xc(c),c.g.cancel(),c.g=null)}function kd(c){Ra(c),c.v&&(o.clearTimeout(c.v),c.v=null),Pa(c),c.h.cancel(),c.m&&(typeof c.m=="number"&&o.clearTimeout(c.m),c.m=null)}function va(c){if(!md(c.h)&&!c.m){c.m=!0;var h=c.Ea;ue||I(),ce||(ue(),ce=!0),T.add(h,c),c.D=0}}function AI(c,h){return _d(c.h)>=c.h.j-(c.m?1:0)?!1:c.m?(c.i=h.G.concat(c.i),!0):c.I==1||c.I==2||c.D>=(c.Sa?0:c.Ta)?!1:(c.m=Ai(B(c.Ea,c,h),Hd(c,c.D)),c.D++,!0)}r.Ea=function(c){if(this.m)if(this.m=null,this.I==1){if(!c){this.V=Math.floor(Math.random()*1e5),c=this.V++;const S=new qn(this,this.j,c);let F=this.o;if(this.U&&(F?(F=Wh(F),$h(F,this.U)):F=this.U),this.u!==null||this.R||(S.J=F,F=null),this.S)e:{for(var h=0,f=0;f<this.i.length;f++){t:{var p=this.i[f];if("__data__"in p.map&&(p=p.map.__data__,typeof p=="string")){p=p.length;break t}p=void 0}if(p===void 0)break;if(h+=p,h>4096){h=f;break e}if(h===4096||f===this.i.length-1){h=f+1;break e}}h=1e3}else h=1e3;h=Vd(this,S,h),f=nn(this.J),Pe(f,"RID",c),Pe(f,"CVER",22),this.G&&Pe(f,"X-HTTP-Session-Id",this.G),Vi(this,f),F&&(this.R?h="headers="+vi(bd(F))+"&"+h:this.u&&Qc(f,this.u,F)),Kc(this.h,S),this.Ra&&Pe(f,"TYPE","init"),this.S?(Pe(f,"$req",h),Pe(f,"SID","null"),S.U=!0,Hc(S,f,null)):Hc(S,f,h),this.I=2}}else this.I==3&&(c?xd(this,c):this.i.length==0||md(this.h)||xd(this))};function xd(c,h){var f;h?f=h.l:f=c.V++;const p=nn(c.J);Pe(p,"SID",c.M),Pe(p,"RID",f),Pe(p,"AID",c.K),Vi(c,p),c.u&&c.o&&Qc(p,c.u,c.o),f=new qn(c,c.j,f,c.D+1),c.u===null&&(f.J=c.o),h&&(c.i=h.G.concat(c.i)),h=Vd(c,f,1e3),f.H=Math.round(c.va*.5)+Math.round(c.va*.5*Math.random()),Kc(c.h,f),Hc(f,p,h)}function Vi(c,h){c.H&&ma(c.H,function(f,p){Pe(h,p,f)}),c.l&&ma({},function(f,p){Pe(h,p,f)})}function Vd(c,h,f){f=Math.min(c.i.length,f);const p=c.l?B(c.l.Ka,c.l,c):null;e:{var S=c.i;let le=-1;for(;;){const ze=["count="+f];le==-1?f>0?(le=S[0].g,ze.push("ofs="+le)):le=0:ze.push("ofs="+le);let we=!0;for(let nt=0;nt<f;nt++){var F=S[nt].g;const rn=S[nt].map;if(F-=le,F<0)le=Math.max(0,S[nt].g-100),we=!1;else try{F="req"+F+"_"||"";try{var Q=rn instanceof Map?rn:Object.entries(rn);for(const[xr,zn]of Q){let Wn=zn;a(zn)&&(Wn=xc(zn)),ze.push(F+xr+"="+encodeURIComponent(Wn))}}catch(xr){throw ze.push(F+"type="+encodeURIComponent("_badmap")),xr}}catch{p&&p(rn)}}if(we){Q=ze.join("&");break e}}Q=void 0}return c=c.i.splice(0,f),h.G=c,Q}function Md(c){if(!c.g&&!c.v){c.Y=1;var h=c.Da;ue||I(),ce||(ue(),ce=!0),T.add(h,c),c.A=0}}function Yc(c){return c.g||c.v||c.A>=3?!1:(c.Y++,c.v=Ai(B(c.Da,c),Hd(c,c.A)),c.A++,!0)}r.Da=function(){if(this.v=null,Gd(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var c=4*this.T;this.j.info("BP detection timer enabled: "+c),this.B=Ai(B(this.Wa,this),c)}},r.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,_t(10),Ra(this),Gd(this))};function Xc(c){c.B!=null&&(o.clearTimeout(c.B),c.B=null)}function Gd(c){c.g=new qn(c,c.j,"rpc",c.Y),c.u===null&&(c.g.J=c.o),c.g.P=0;var h=nn(c.na);Pe(h,"RID","rpc"),Pe(h,"SID",c.M),Pe(h,"AID",c.K),Pe(h,"CI",c.F?"0":"1"),!c.F&&c.ia&&Pe(h,"TO",c.ia),Pe(h,"TYPE","xmlhttp"),Vi(c,h),c.u&&c.o&&Qc(h,c.u,c.o),c.O&&(c.g.H=c.O);var f=c.g;c=c.ba,f.M=1,f.A=wa(nn(h)),f.u=null,f.R=!0,fd(f,c)}r.Va=function(){this.C!=null&&(this.C=null,Ra(this),Yc(this),_t(19))};function Pa(c){c.C!=null&&(o.clearTimeout(c.C),c.C=null)}function Ud(c,h){var f=null;if(c.g==h){Pa(c),Xc(c),c.g=null;var p=2}else if(Jc(c.h,h))f=h.G,Ed(c.h,h),p=1;else return;if(c.I!=0){if(h.o)if(p==1){f=h.u?h.u.length:0,h=Date.now()-h.F;var S=c.D;p=Ia(),mt(p,new cd(p,f)),va(c)}else Md(c);else if(S=h.m,S==3||S==0&&h.X>0||!(p==1&&AI(c,h)||p==2&&Yc(c)))switch(f&&f.length>0&&(h=c.h,h.i=h.i.concat(f)),S){case 1:kr(c,5);break;case 4:kr(c,10);break;case 3:kr(c,6);break;default:kr(c,2)}}}function Hd(c,h){let f=c.Qa+Math.floor(Math.random()*c.Za);return c.isActive()||(f*=2),f*h}function kr(c,h){if(c.j.info("Error code "+h),h==2){var f=B(c.bb,c),p=c.Ua;const S=!p;p=new jn(p||"//www.google.com/images/cleardot.gif"),o.location&&o.location.protocol=="http"||bi(p,"https"),wa(p),S?EI(p.toString(),f):II(p.toString(),f)}else _t(2);c.I=0,c.l&&c.l.pa(h),qd(c),kd(c)}r.bb=function(c){c?(this.j.info("Successfully pinged google.com"),_t(2)):(this.j.info("Failed to ping google.com"),_t(1))};function qd(c){if(c.I=0,c.ja=[],c.l){const h=Id(c.h);(h.length!=0||c.i.length!=0)&&(m(c.ja,h),m(c.ja,c.i),c.h.i.length=0,g(c.i),c.i.length=0),c.l.oa()}}function jd(c,h,f){var p=f instanceof jn?nn(f):new jn(f);if(p.g!="")h&&(p.g=h+"."+p.g),Si(p,p.u);else{var S=o.location;p=S.protocol,h=h?h+"."+S.hostname:S.hostname,S=+S.port;const F=new jn(null);p&&bi(F,p),h&&(F.g=h),S&&Si(F,S),f&&(F.h=f),p=F}return f=c.G,h=c.wa,f&&h&&Pe(p,f,h),Pe(p,"VER",c.ka),Vi(c,p),p}function Jd(c,h,f){if(h&&!c.L)throw Error("Can't create secondary domain capable XhrIo object.");return h=c.Aa&&!c.ma?new Ve(new Wc({ab:f})):new Ve(c.ma),h.Fa(c.L),h}r.isActive=function(){return!!this.l&&this.l.isActive(this)};function Kd(){}r=Kd.prototype,r.ra=function(){},r.qa=function(){},r.pa=function(){},r.oa=function(){},r.isActive=function(){return!0},r.Ka=function(){};function ba(){}ba.prototype.g=function(c,h){return new Ot(c,h)};function Ot(c,h){Bt.call(this),this.g=new Ld(h),this.l=c,this.h=h&&h.messageUrlParams||null,c=h&&h.messageHeaders||null,h&&h.clientProtocolHeaderRequired&&(c?c["X-Client-Protocol"]="webchannel":c={"X-Client-Protocol":"webchannel"}),this.g.o=c,c=h&&h.initMessageHeaders||null,h&&h.messageContentType&&(c?c["X-WebChannel-Content-Type"]=h.messageContentType:c={"X-WebChannel-Content-Type":h.messageContentType}),h&&h.sa&&(c?c["X-WebChannel-Client-Profile"]=h.sa:c={"X-WebChannel-Client-Profile":h.sa}),this.g.U=c,(c=h&&h.Qb)&&!D(c)&&(this.g.u=c),this.A=h&&h.supportsCrossDomainXhr||!1,this.v=h&&h.sendRawJson||!1,(h=h&&h.httpSessionIdParam)&&!D(h)&&(this.g.G=h,c=this.h,c!==null&&h in c&&(c=this.h,h in c&&delete c[h])),this.j=new Ps(this)}d(Ot,Bt),Ot.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},Ot.prototype.close=function(){$c(this.g)},Ot.prototype.o=function(c){var h=this.g;if(typeof c=="string"){var f={};f.__data__=c,c=f}else this.v&&(f={},f.__data__=xc(c),c=f);h.i.push(new hI(h.Ya++,c)),h.I==3&&va(h)},Ot.prototype.N=function(){this.g.l=null,delete this.j,$c(this.g),delete this.g,Ot.Z.N.call(this)};function zd(c){Vc.call(this),c.__headers__&&(this.headers=c.__headers__,this.statusCode=c.__status__,delete c.__headers__,delete c.__status__);var h=c.__sm__;if(h){e:{for(const f in h){c=f;break e}c=void 0}(this.i=c)&&(c=this.i,h=h!==null&&c in h?h[c]:void 0),this.data=h}else this.data=c}d(zd,Vc);function Wd(){Mc.call(this),this.status=1}d(Wd,Mc);function Ps(c){this.g=c}d(Ps,Kd),Ps.prototype.ra=function(){mt(this.g,"a")},Ps.prototype.qa=function(c){mt(this.g,new zd(c))},Ps.prototype.pa=function(c){mt(this.g,new Wd)},Ps.prototype.oa=function(){mt(this.g,"b")},ba.prototype.createWebChannel=ba.prototype.g,Ot.prototype.send=Ot.prototype.o,Ot.prototype.open=Ot.prototype.m,Ot.prototype.close=Ot.prototype.close,eg=function(){return new ba},Zp=function(){return Ia()},Xp=Nr,SB={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Da.NO_ERROR=0,Da.TIMEOUT=8,Da.HTTP_ERROR=6,$a=Da,Bd.COMPLETE="complete",Yp=Bd,id.EventType=wi,wi.OPEN="a",wi.CLOSE="b",wi.ERROR="c",wi.MESSAGE="d",Bt.prototype.listen=Bt.prototype.J,$i=id,Ve.prototype.listenOnce=Ve.prototype.K,Ve.prototype.getLastError=Ve.prototype.Ha,Ve.prototype.getLastErrorCode=Ve.prototype.ya,Ve.prototype.getStatus=Ve.prototype.ca,Ve.prototype.getResponseJson=Ve.prototype.La,Ve.prototype.getResponseText=Ve.prototype.la,Ve.prototype.send=Ve.prototype.ea,Ve.prototype.setWithCredentials=Ve.prototype.Fa,$p=Ve}).apply(typeof Oa<"u"?Oa:typeof self<"u"?self:typeof window<"u"?window:{});/*!
* re2js
* RE2JS is the JavaScript port of RE2, a regular expression engine that provides linear time matching
*
* @version v2.9.0
* @author Oleksii Vasyliev
* @homepage https://github.com/le0pard/re2js#readme
* @repository [object Object]
* @license MIT
*/var Te,M=(Te=class{},G(Te,"FOLD_CASE",1),G(Te,"LITERAL",2),G(Te,"CLASS_NL",4),G(Te,"DOT_NL",8),G(Te,"ONE_LINE",16),G(Te,"NON_GREEDY",32),G(Te,"PERL_X",64),G(Te,"UNICODE_GROUPS",128),G(Te,"WAS_DOLLAR",256),G(Te,"LOOKBEHIND",512),G(Te,"MATCH_NL",Te.CLASS_NL|Te.DOT_NL),G(Te,"PERL",Te.CLASS_NL|Te.ONE_LINE|Te.PERL_X|Te.UNICODE_GROUPS),G(Te,"POSIX",0),G(Te,"UNANCHORED",0),G(Te,"ANCHOR_START",1),G(Te,"ANCHOR_BOTH",2),Te);const bs={CASE_INSENSITIVE:1,DOTALL:2,MULTILINE:4,DISABLE_UNICODE_GROUPS:8,LONGEST_MATCH:16,LOOKBEHINDS:512},Eo=128,OB=new Int32Array(Eo),NB=new Int32Array(Eo),Na=65535;for(let r=0;r<Eo;r++)r>=97&&r<=122?OB[r]=r-32:OB[r]=r,r>=65&&r<=90?NB[r]=r+32:NB[r]=r;var TB,V=(TB=class{static toUpperCase(r){if(r<Eo)return OB[r];const e=String.fromCodePoint(r).toUpperCase(),t=e.codePointAt(0)>Na?2:1;if(e.length>t)return r;const n=String.fromCodePoint(e.codePointAt(0)).toLowerCase(),s=n.codePointAt(0)>Na?2:1;return n.length>s||n.codePointAt(0)!==r?r:e.codePointAt(0)}static toLowerCase(r){if(r<Eo)return NB[r];const e=String.fromCodePoint(r).toLowerCase(),t=e.codePointAt(0)>Na?2:1;if(e.length>t)return r;const n=String.fromCodePoint(e.codePointAt(0)).toUpperCase(),s=n.codePointAt(0)>Na?2:1;return n.length>s||n.codePointAt(0)!==r?r:e.codePointAt(0)}},G(TB,"CODES",Object.freeze({"\x07":7,"\b":8,"	":9,"\n":10,"\v":11,"\f":12,"\r":13," ":32,'"':34,$:36,"&":38,"'":39,"(":40,")":41,"*":42,"+":43,"-":45,".":46,0:48,1:49,2:50,3:51,4:52,5:53,6:54,7:55,8:56,9:57,":":58,"<":60,">":62,"?":63,A:65,B:66,C:67,F:70,P:80,Q:81,U:85,Z:90,"[":91,"\\":92,"]":93,"^":94,_:95,"`":96,a:97,b:98,f:102,i:105,m:109,n:110,r:114,s:115,t:116,v:118,x:120,z:122,"{":123,"|":124,"}":125})),TB),_=class{constructor(r,e=!1){this.data=r,this.isStride1=e,this.SIZE=e?2:3}getLo(r){return this.data[r*this.SIZE]}getHi(r){return this.data[r*this.SIZE+1]}getStride(r){return this.isStride1?1:this.data[r*this.SIZE+2]}get length(){return this.data.length/this.SIZE}};const ry="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-",tg=new Uint8Array(256);for(let r=0;r<64;r++)tg[ry.charCodeAt(r)]=r;const ng=r=>{const e=[];let t=0,n=0;for(let s=0;s<r.length;s++){const i=tg[r.charCodeAt(s)];t|=(i&31)<<n,i&32?n+=5:(e.push(t),t=0,n=0)}return e},E=(r,e)=>{const t=ng(r),n=e?t.length/2:t.length/3,s=new Uint32Array(n*3);let i=0,o=0;for(let a=0;a<n;a++)i+=t[o++],s[a*3]=i,i+=t[o++],s[a*3+1]=i,s[a*3+2]=e?1:t[o++];return s},sy=r=>{const e=ng(r),t=new Map;let n=0;for(let s=0;s<e.length;s+=2){n+=e[s];const i=e[s+1],o=i>>>1^-(i&1);t.set(n,n+o)}return t};var Fa=class{constructor(r){this.initializer=r,this.cache=new Map}has(r){return r in this.initializer}get(r){if(this.cache.has(r))return this.cache.get(r);const e=this.initializer[r],t=e?e():null;return this.cache.set(r,t),t}},er,Nt=(er=class{static get CASE_ORBIT(){return this._CASE_ORBIT||(this._CASE_ORBIT=sy("rCgCIgCY+rQI4QiCuuBLgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCCgCBgCBgCBgCBgCBgCBgCB+7OB-BB-BB-BB-BB-BBskQB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BC-BB-BB-BB-BB-BB-BB-BByHBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBxHBCBBBCBBBCBBB3SBmMBkNBCBBBCBBB8MBCBBB6MB6MBCBBC+EB0MB2MBCBBB6MB+MBiGBmNBiNBCBBBmKBikzCBmNBqNBkIBsNBCBBBCBBBCBBB0NBCBBB0NDCBBB0NBCBBByNByNBCBBBCBBB2NBCBBDCBBCwDFCBCBDBCBCBDBCBCBDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB9EBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBCBDBCBBBhGBvDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBjICCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBH2iVBCBBBlKBwiVB+jVB+jVBCBBBlMBqEBuEBCBBBCBBBCBBBCBBBCBBB+hVB4hVB8hVBjNB7MC5MB5MCzMC1MB+0yCE5MB20yCC9MBu2yCBwyyCBo0yCChNBlNBo0yCBu-UBi0yCDlNC6-UBpNDrNIu+UDzNCm0yCBzNE0yyCBzNBpEBxNBxNBtEG1NLqxyCBkxyCnFoFrBCBBBCBBDCBBEkIBkIBkICoHHsCCqCBqCBqCCgEC+DB+DBmkOBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCC+BBgCBgCBgCBgCBgCBgCBgCBgCBrCBpCBpCBpCBmjOB-BB8BB-BB-BBgEB-BB-BByBBqgOBsDB-BBtwBB-BB-BB-BBsBBgDBCB-BB-BB-BBeB-BB-BB61OB-BB-BB-DB9DB9DBQB7DBmCE9CBrDBPBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBrFB-EBOBnHB3FB-FCCBBBNBCBBCjIBjIBjIBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB8kMB-BB6kMB-BB-BB-BB-BB-BB-BB-BB-BB-BBokMB-BB-BBkkMBkkMB-BB-BB-BB-BB-BB-BB-BB4jMB-BB-BB-BB-BB-BB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EBCBBBCBoiMBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBJCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBeBCBBBCBBBCBBBCBBBCBBBCBBBCBBBdBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDL-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-C64CgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOCgmOGgmODg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FDg8FBg8FBg8FhVg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBQBQBQBQBQBQDPBPBPBPBPBPjkC7mMB5mMBnmMBjmMBCBlmMB3lMBpiMBk8kCBCBBG-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FD-7FB-7FB-7F6FoglCEsuHRwjlCyDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCB0DBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBG1DD97OCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPEQCQCQCQCPCPCPCPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPB0EB0EBsFBsFBsFBsFBoGBoGBgIBgIBgHBgHB8HB8HDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQCSFPBPBzEBzEBRCxnOFSFrFBrFBrFBrFBREQBQClkOFPBPBnGBnGFQBQCljOCODPBPB-GB-GBNHSF-HB-HB7HB7HBRqJ53OE9tQBrmQH4Bc3BSgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfECBByZ0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzB34BgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CBCBBBt-UBruHBt+UB1iVBviVBCBBBCBBBCBBB3hVB5-UB9hVB7hVCCBBCCBBI9jVB9jVBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBICBBBCBBECBBN-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOC-lOG-lOzoeCBBBCBBBCBBBCBBBCBBBCBl8kCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBTCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBnECBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBKCBBBCBBBnglCBCBBBCBBBCBBBCBBBCBBECBBBvyyCDCBBBCBBBgDCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBn0yCB90yCB10yCBh0yCBn0yCCjxyCBzyyCBpxyCBg6BBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB-CBl0yCBvjlCBCBBBCBBBt2yCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBhkzCZCBB9a-5Bd-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCm6TCBB7gBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCH-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BmlBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvChDwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCFvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvC1DuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCCuCBuCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCCtCBtCk2BgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEO-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-D+CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCL-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-B74CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhrVgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BD1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BtxekCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjC")),this._CASE_ORBIT}static get Print(){return this._Print||(this._Print=new _(E("hB9CBjBLBCpWBDFBFGBCCCBSBCsMBClBBDxBBDCBC2BBJaBFFBSVBC-FBCvBBD6BBDkDBP6BBDwBBDOBCbBDCCBJBGfBIqCBCgFBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYBDCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPBLCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGBCCBCHBDBBDVBCGBCBBCEBDIBDBBDCBICBFBBCEBDRBLBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBGMBCCBCWBCPBDIBCCBCDBIBBCCBCBBDDBDJBIVBCCBCWBCJBCEBDIBCCBCDBIBBGCBCDBDJBCCBNMBCCBCyBBCCBCFBFPBDZBCCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBN5BBFcBmBBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDBhBnCBCjBBFmBBCjBBCOBCMBmBlGBCGGD4LBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBH1CBDFBD-TBCbBE4CBIVBKXBKTBNMBCCBCBBN9CBDJBHJBHNBCKBH4CBIqBBGlCBLeBCLBFLBFEEBoBBDEBMrBBFZBHKBE9BBDgCBCcBDKBHJBHNBDtBBDLBVsCBClFBJ7BBEOBE9BBGqBBDKBJqBBG1QBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBSXBJuBBSBBDaBCMBEhBBPgBBQrEBF5UBXKBWz4BBD9LBGsBBCGGD3BBIBBPXBKGBCGBCGBCGBCGBCGBCGBCGBC9DBjBZBC4CBN1GBbPBC+BBC1CBDmDBGqBBC9CBC1CBKvBBCszcBE2BBK7KBV3FBJ8GBV7BBEJBH3BBJlCBJLBHzDBMdBEtCBCKBFgBBC2BBKNBDJBDmDBZbBLFBDFBDFBKGBCGBC7BBF9DBDJBHj9KBNWBFwBBloItLBDpDBnBGBNEBGZBCEBCCCBCCBCCBoUBhBpBBHyBBCSBCDBFEBCmEBF9FBEFBDFBDFBDCBEGBCGBOBBDLBCZBCSBCBBCOBDNBjB6DBGCBFsBBE3CBCMBEwBwBBsBBjEcBEwBBQbBFjBBKdBGqBBGdBCkBBFNBrB9EBDJBHjBBFjBBFnBBJzBBMLBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBCnCBJIBxBSBCBBGgBBEaBGaBnB3BBFTBDxBBCBBGHBCCBCcBDCBFJBIIBI-BBhBmBBFLBK1BBEcBDaBGZBIDBNGBxCoCB4ByBBOyBBItBBJJBHlBBEcBJBBxGeBCpBBCCBDBBRFBJIBiBtBBJpBBXZBnBbBVWBKtCBFjBBK9BBCEBOYBIJBH0BBCRBJmBBK-CBCTBMRBCuBB-BGBCCCBCBCOBCKBH6BBGJBHDBCHBDBBDVBCGBCBBCEBCJBDBBDCBDHHGGBDGBEEBMJBCDDClBBCJBCDDCDBCJBCBBJBBe7CBCEBfnCBJJBnF1BBDlBBjBkCBMJBHMBU5BBHJBHTBdaBDOBFWB6F7BBlDyCBNHBDDDBGBCBBCdBCBBDLBKJBnCHBDtBBDKBcnCBJyCBOoCBIJB3CHB5ChBBPJBHIBCsBBCNBLcBEfBDVBCNBqCGBCBBCrBBECCBCCBHBJJBHFBCBBCkBBCBBCFBIJBHrBBFJB3HYBIQBCoBBEcB2CQQBwBBO6cBnDuDBCEBMjGBtyCiDBOvhBBRVBL68DBGmSB61G5BBn2B4RBIeBCJBFwCBCJBHdBDFBLlCBLJBCGBCUBGSBxN5BBnG6CBGYBDYBtBqCBF4BBIQBhCEBMGBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBDDBh7D8HBEzNBHWBQQBQtBBDWBKzDB9B1HBLmBBDpCBJvDBWlCB7DTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBD9VBQEBCOBxiBeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBENBDJBFBBhKeBS5BBGxOxOBoBB3GqBBFhGhGBdBCVBJBBhHGBCDBCBBCOBCkGBDPBqBrCBFJBFBByYjCBtC8BBjGDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBBvIrBBFjDBNOBDOBCOBCkBBLtFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBmgB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIBnkzVvHB",!1))),this._Print}},G(er,"_CASE_ORBIT",null),G(er,"_Print",null),G(er,"CATEGORIES",new Fa({C:()=>new _(E("AfBgDgBBOrWrWBHHBCBICCVuMuMnBBBzBBBE4B4BBGBcDBHQBXhGhGxBBB8BBBmDNB8BBByBBBQddBCCMEBhBGBsCiFiFJBBDBBXIICCBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBPMMBEB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKMMBDBbEByBPBDBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCB-FCBHBBHBBHBBECBIIIBLBDBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIB-BGGBLBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMBxhBPBXJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBF-6DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBrCHBxDUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIlkzVBxHvw-FB",!1)),Cc:()=>new _(E("AfgDgB",!0)),Cf:()=>new _(E("tFzqBzqBBEBXhGhGyBhMhMBxCxCs5D9-B9-BBDBbEByBEBCJBw03B6H6HBBBimEQQj7IPBhjiBDBwmFHBn0rYffB+CB",!1)),Cn:()=>new _(E("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBDBvzIBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-BB---BBB---BBB",!1)),Co:()=>new _(E("gg4B-nGh4hc9--BD9--B",!0)),Cs:()=>new _(E("gg2B--B",!0)),L:()=>new _(E("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICCiEEBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoCaBFDBuBqBBkBBBCiDBCQQBIIBLLBBBDRRCdBe4CBMZZBfBKBBFGGBUBFKKEYYBXBIKBGXBCGBRpBB7B1BBETTIJBQPBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNGB7BBBCCCBDBCXBCCCBIBCBBKDDBDBCWWBCBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNSSBkBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBkBFFkC4CBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBzC+C+CBtBBSHB3BdBOBBLrBBbjBBqBCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBhC1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBF1B1BB8zC8zCBjHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBxC2O2OBrBrBBDBGBBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBReBDlCByBIBDmDBDxCBVQBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBdRRBDBCJBLEBCoBBYCBCHBVWBEEEBwBBCEEBDDBDBDCCZCBDKBICBNFBDFBDFBKGBCGBCqBBCNBHyDBej9KBNWBFwBBloItLBDpDBnBGBNEBGCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBxB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOjBBnBbBKWB7HpBBHBBRFB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB1D-BBgBHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBqBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBGjCjCBLBhCBBCPPBNNB0mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBn7F0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFBmI9BBzEsBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCCBCBBCGBDEBKBBhHGBCDBCBBCOBCkGB8BjCBI1lB1lBBCBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),LC:()=>new _(E("hCZBHZB7BLLBVBCeBCiGBCDBFvGBDZBhGDBDBBECBCHHCCBCCCBSBCyCBCqEBJlFBClBBKoBB44ClBBCGGDqBBDCBhV1CBDFBjkCKBGqBBDCBhCrBBgCMBChBBmD1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGBmIFFDJBCEEBDBHGCBCBCFBFDDBCBGEBF1B1BB8zC8zCB6DBDmDBHDBEBBNlBBCGGzoetBBTbBnEtCBCWBEDBCsCBZBBE2Z2ZBpBBGIBIvCBh6TGBNEBqgBZBHZBmlBvCBhDjBBFjBB1DKBCOBCGBCBBCKBCOBCGBCBBk2ByBBOyBB+CVBLVB74C-BBhrV-BBhBYBDYBtpZ0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BJBCTBHFB2uCjCB",!1)),Ll:()=>new _(E("hDZB7BqBqBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDZBiGCCEEEBBBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBDCB5XFBjkCIBC2D2DBqBBgCMBChBBnD0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBBzIEEBEEcKFDBBJDBF2B2Bs1CvBBCEEBGCFCCBCCBEBGiDCBIICFFNlBBCGG0oesBCUaCoEMCBBBC+BCBGBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCbEE2ZqBBGIBIvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFB4vChBB",!1)),Lm:()=>new _(E("wVRBFLBPEBICCmEGG-OnHnHlFBBuIBBFgBgBKEEhFoFoF1mBgEgE2R72B72BsDkTkTxOFBvF+BBOjBjBBjBByVOORMBg-CBByHgGgG2OsBsBBDBGiDiDB+C+CBBB34bjnBjnBBEBvIzDzDdBB6DIBxCYYpDDBEBB2OXXqEtDtDWBBoDDBKngVngVuBBBh-BFBCpBBCIB0sBhBhB2K04D04DnrTDB9PCBpBBBnRMBhCBBCPPB9-P9-PBCBCGBCBByhM9BBqGGBud0Q0QsSAB",!1)),Lo:()=>new _(E("qFQQhIFFBCBxGBB7ZaBFDBuBfBCJBkBBBCiDBCZZBLLBBBDRRCdBe4CBMZZBfBWVBrBYBIKBGXBCGBRoBB8B1BBETTIJBROBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNFB8BBBCCCBDBCXBCCCBIBCBBKDDBDBYDBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNyDyDBnKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPByDrTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBpBkCkCBhBBC0BBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBxFuBBSHB3BdBOBBLrBBbjBBqBCBLdByDDBCFBCBBE7hB7hBBCB4-C3BBZWBKGBCGBCGBCGBCGBCGBCGBCGBoR2B2BF1CBJCCB4CBFGGBpBBC9CBSfBxBPBhQ-tGBhC0wUBC2jBBkCnBBJrIBFPBLBBjCyByBBkCBqFoDoDEGBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBuBEBDIBLEBCoBBYCBCHBVPBCFBEEEBwBBCEEBDDBDBDCCZBBEKBIPPBEBDFBDFBKGBCGByEiBBej9KBNWBFwBBloItLBDpDBkCCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBqDJBCsBBDeBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBhEtCBjDnBBJzBB9CzBBN2JBKVBLHB5EFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4FjBBnBDBCxJxJBoBBHBBRCBCBB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB0GHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBnBBCBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBB0BUBGSB0NnBB2MqCBGwFwFB0mHBqBfBiDyDBuwIiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBxzI2P2PBrBBiBiKiKBcBTrBBlPaBmHdBDwGwGBdBCCBCBBCGBDEBKiHiHBFBCDBCBBCOBCkGB8pBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Lt:()=>new _(E("lOGDnB2sH2sHBGBJHBJHBNQQwBAB",!1)),Lu:()=>new _(E("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBG+B+B9zCvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBB",!1)),M:()=>new _(E("gYvDB0IGBoIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCgBB3BCBCRBCGBLBBeCB5BCCBFBDBBDCBKLLBbbDCB5BCCBDBFBBDCBEffBEEMCB5BCCBGBCCBCCBVBBXFBCCB5BCCBFBDBBDCBICBLBBf8B8BBDBECBCDBKpBpBBDB4BCCBFBCCBCDBIBBMBBeCB5BCCBFBCCBCDBIBBMBBQNNBCB4BBBCGBCCBCDBKLLBeeBBBnCFFBEBCCCBGBTBB+BDDBFBNHBjDDDBHBMGBqCBBcECFBByBTBCBBGKBCjBBKlDlDBSBYDBFCBCCBDGBEDBOLBCLLBCBgWCBzdDBdCBeBBfBBhCfBKuBuBBBBC2D2DBjBjB3DLBFLB8GEB6BJBCcBDxBxBBsBBDLBVEBwBQBnBIBNCBfMB5BNBxBTB5ECBCUBFHHDCBnG-BBxWgBB--CCBuEhDhDBeBrRFBqDBB1udDBCJBhBBBxCBBxIEEFYYBDBF0C0CBzBzBBQBbRBOnBnBBGBaMBtBDBwBNBlBkCkCBMBNJJBuBuBBBBzBCCBBBDBBGBBCqBqBBDBGBBtHHBCBBx5TiXiXBOBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB7DCB2BOBqBDDBLLBCBuBKBI+B+BBBBlBNBRBBtBNNBBBxBNBJDBCBB9CLBHDD+ELBWDB4BBBCGBDBBDCBKLLBDDBFBEEBkCIBCDDCDBCEBCPPBzCzCBQBYyCyCBSBsHGBDIBcBBzCQBrDMBmDOBhIOB2HFBCBBDDBCCCBuEuEBFBDGBEddBIBpBGBCDBJKKBJBvBPBnGHBoGHBCHBzCVBCNB7DFBECCBCCBFBCjCjCBDBCBBCEB8KDBKBBCxBxBBFBEEBYmnFmnFHOBpmLRBhuCEB8BGB5gBCCB1BBIDByCMMBslTslTBizEizEBsBBDWB-QEBEFBJHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB",!1)),Mc:()=>new _(E("joC4B4BDCBJDBCBBzBBB7BCBHBBDBBLsBsB7BCBjC7B7BBBBJCCB2B2BB7B7BCHHBDDBLLnDBBCBBECBCCBLqBqBBBB+BDB+BBB7BCCBDBDBBCBBKBBdPPB7B7BBBBGCBCCBLrBrBBsCsCBBBHHBTBBrKBBgCsFsFBFFHDDBaaBLLBBBDGBWBBDFBDLLBBB5zBffiEIIBGBCBB7KDBDCBFBBCFBhHBB7BCCKCCBJJBEByExBxBGCCBDBCBB+BffFBBD9B9BDCBCEEBxBxBBGBJBBsFWW35EBB0-dBBD5C5CBzBzBBOBvEBBwBxBxBBFFBDDBBBvDBBDBBZuBuBCuDuDDBBGuHuHBCCBCCBCC0gZCCgEuBuBBBBFBB0DZZB8B8BxBCBKBBO+C+CBBBEBBCrFrFBBBgBBB7BBBCDBDBBDCBKLLB1C1CBBBIDDCDBCBBCmDmDBBBJBBErDrDBBBHCCBCBDuHuHBBBHDBDyDyDBBBJBBCuDuDCBBHoDoDCBBFmImIBBBK4H4HBEBCBBFDDCvEvEBBBJDBF1C1CeBB-BqGqGECCoGPPrDIID2G2GBDBFBBC-K-KBNNxBBBJBBCpvQpvQBBBlxD2BBpDBB0rYBBHFB",!1)),Me:()=>new _(E("okBBB1xF-wB-wBBCBCCBsshBCB",!1)),Mn:()=>new _(E("gYvDB0IEBqIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCfB4BCCFHBFEEBFBLBBe7B7BFDBJVVBbbDBB6BFFBFFBDDBBBEffBEEMBB6BFFBDBCBBFVVBXXBEBC7B7BDCCBCBJIIBMMBff+BNNzBEE4BCCBBBGCBCDBIBBMBBe7B7BDHHGBBVBBdBB6BBBFDBJVVBeepCIIBBBC7C7CDGBNHBjDDDBHBMGBqCBBcEC4BNBCEBCBBGKBCjBBKnDnDBCBCFBCBBDBBaBBFCBRDBODDBHHQgWgWBBBzdCBeBBfBBfBBhCBBCGBJDDBJBKuBuBBBBC2D2DBjBjB3DCBFBBKHHBBB8GBBD7B7BCGBCCCDHBHJBDxBxBBMBCeBDLBVDBxBCCBDBCGGpBIBNBBhBDBDBBCCB5BCCBEECCB7BHBDBB5ECBCMBCGBFHHEBBnG-BBxWMBFEEBKB--CCBuEhDhDBeBrRDBsDBB1udFFBIBhBBBxCBBxIEEFaaBGG4EBBbRBOnBnBBGBaKBvBCBxBDDBCBDBBoBkCkCBEBDBBDBBNJJwB0B0BCCBDBBGBBCrBrBBJJvHDDFx5Tx5TiXPBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB8D3B3BBNBqBDDBLLBBByBDBDBBI+B+BBBBlBEBCHB-BNNB1B1BBHBLDBDgDgDBBBDCCBHHD+E+EEHBWBB6BBBEmBmBBFBEEBnCFBOECPBB2CHBDCBCYY1CFBCFFBCCBvHvHBCBHBBCBBcBB2CHBDCCBrDrDCDDBEBCmDmDCDDBCBCEBkIIBCBBhIBBCFFxEDBDBBFhBhBBIBpBFBDDBJKKBEBDCBvBMBCBBnGCCBBBCqGqGBFBCFBCzCzCBUBDGBCBBCBB7DFBECCBCCBFBCpCpCBEEC8K8KBMMB1B1BBDBGCCYmnFmnFHOBpmLLBECBhuCEB8BGB5gBgCgCBCByC5lT5lTBizEizEBsBBDWBhRCBSHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB",!1)),N:()=>new _(E("wBJB5DBBGDDBBBitBJBnEJBnGJB9MJB3DJBFFBtDJB3DJB3DJBDFBvDMB0DJBJGBoDJBpDGBISBuDJBhDJB3DJBnCTBtIJBnCJBwWTBybCBwHJBHJBXJBtJJBhEKBmFJBHJB3FJB3CJBnEJBHJB3gBEEBEBHJBnGyBBDEB3W7BBvCVB3TdBqrBqYqYaIBPCB4KDBrEJBfHBCOBhBJBoBOBh7cJB9FJBhKFB7EJBnBJBnGJBXJB3CJB3MJB34UJBuPsBBN4BBSBB2KaBlBDBeJJnEEBrGJBvdHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBxBJBHJB3IeB-EJBrBDBxDGBnEdBhEJB9BJBxEJBITB8HJB3KJB3DJB3LJBnDJBHTBtCLBlNSB+CJB3UJB3CcBkHJBnCJB3BJBnLJBnDUBshBuDBimPJBnpCJB3CJBnEJBCGBvQJBnIWB+KCB6nXJBnuBTBNTBtDYB2iBxBBhqCJBnNJB3PJB4HJBtWIBhEJB4Y6BBCCBCDBtCsBBCOBjeMBk3CJB",!1)),Nd:()=>new _(E("wBJnxBJnEJnGJ9MJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJhDJ3DJnCJ3IJnCJn6BJnBJtJJhEJnFJHJ3FJ3CJnEJHJnuiBJnVJnBJnGJXJ3CJ3MJ34UJnsBJnkCJHJ9YJhEJ9BJxEJ3IJ3KJ3DJ3LJnDJHTtCJnNJnDJ3UJ3CJ3HJnCJ3BJnLJ3uQJnpCJ3CJnEJ3QJ37XJ12CxBhqCJnNJ3PJ4HJ2aJ30EJ",!0)),Nl:()=>new _(E("u3FCBwzCiBBDDB-zDaaBHBPCBs1dJBxyW0BBtOJJnEEBrhIuDBm8SCB",!1)),No:()=>new _(E("yFBBGDDBBB2pCFB5LFB5DCBmEGB6GGBSIByNJB2hBTB0jBJBhP20B20BEFBHJBnGPBqB3W3WB6BBvCVB3TdBqrB1kB1kBBCBrEJBfHBCOBhBJBoBOBxrdFBymWsBBiCDBSBB2KaBlBDB1pBHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBhLeB-EJBrBDBxDGBnETB8LTBmqBBBvNIBobSB0aUBn8SGB-YWBqhZTBNTBtDYBvqFIBid6BBCCBCDBtCsBBCOBjeMB",!1)),P:()=>new _(E("hBCBCFBCDBLBBEBBbCBCccCkBkBGEELBBEEE-VJJzOFBqBBB0BCCDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCmBmBBCBoCrCrCBDBFBBwDFBsFlTlTBHB4EuTuTtBBBvCCBoCBB+ECBCCBmBKB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBM9Z9ZBWBJTBCMBCLBfBBPBB6TDBeBB+hBNBwCBBgBJB0MVBgCDBhBBB8XDBCBBxDwEwEBtBBCfBDLBkNCBFJBDLBRNNjD7C7CjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HzqUzqUBxGxGBIBXiBBCNBCFFCBB2ECBCFBCDBLBBEBBbCBCccCCCBFB7MCB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDByO-J-JjBlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB",!1)),Pc:()=>new _(E("-Cg-Hg-HBUU-u3BBBZCBwHAB",!1)),Pd:()=>new _(E("tB9qB9qB0BiyDiyDmgBqgCqgCBEBiwDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J",!1)),Pe:()=>new _(E("pB0B0BgB+1D+1DC-6B-6BqtC4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECtBGCtNICEGCDBB-ozB6G6GeOCESSCCCrF0B0BgBGD",!1)),Pf:()=>new _(E("7F+6H+6HEddpuDCCFDDQEE",!1)),Pi:()=>new _(E("rFt7Ht7HDBBDaapuDCCFDDQEE",!1)),Po:()=>new _(E("hBCBCCBDECBLLBEEBcclCGGPBBI-V-VJzOzOBEBqB3B3BDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCxDxDrCEBFBBwDFBsFlTlTBHBmY9D9DBBBoCBB+ECBCCBmBFBCDB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBMjajaBJJBGBJIBDDBDCBEKBCCCBIB7kDDBCBBxDwEwEBFFBBBDDDBHBCBBCDDBLLBDBCJBDDBCCCBLBDCBtNCB6B+F+FjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HlxUlxUBFBDXXVBBDDBECBCDBICBHCCB2E2EBBBCCBDECBLLBEEBcclBDDB7M7MBBB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDB0ZlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB",!1)),Ps:()=>new _(E("oBzBzBgB-1D-1DC-6B-6B-rCEEnB4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECaTTCECtNICEGCDipzBipzB4GeeCMCESSCCCrFzBzBgBEEDAB",!1)),S:()=>new _(E("kBHHRCBgBCCcCCkBEBCBBDCCBCBDEEfgBgBrODBNNBGGBCCCBPB2DPPBxDxDsErIrIBBB3DCBDDDBvGvGLUUB4H4HIBBpEqLqLBHHB2H2H-DjEjEBGBlEwGwGqBmGmGiGCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WuLuLlL+E+EBgBBiLJBKIBhiBCCBBBMCBOCBOCBOBBmCOOoBCBOCBUhBB-BBBCDBCBBLCCBBBGFBCECFMMBFFBDBGDBC7B7BBFFB2LBFcBD+HBXKByCtCBXnTBtBwBBDeBLyMBX+BBFfBD1LBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBB8CBB0HBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BB6RWBKBBoDBB+EDBLDB+RCBiHPPB+9T+9TpEgBBuLPBhCBB3BHBtBDBjDCCBBBD7E7EHRRBBBgBCCcCCiEGBCGBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSmWmWBiKiKBGBnjC2kC2kCBbBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQQBgDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBrbaagBaagBaagBaagBaa9B-PB4BDBzBHBCNBCBBp2BwNwNttCEE+DiOiOBvIvIBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB",!1)),Sc:()=>new _(E("kB+D+DBCBqnB8D8DzPBBzPBBI2H2HoImSmS8sClmClmCBgBB37hBkuVkuVtD7E7E8GBBEBB3-HDB-4wBxtCxtC",!1)),Sk:()=>new _(E("+CCCoCHHFEEqQDBNNBGGBCCCBPB2DPPBjoBjoB15FCCBBBMCBOCBOCBOBB9kEBBkzdWBKBBoDBBxePPBniUniUBPB8bCCjF4g9B4g9BBDB",!1)),Sm:()=>new _(E("rBRRBBB+BCCuBFFmBgBgB-XwQwQBBB8xGOOoBCBOCBsEoBoBBDBHlClCBDBGBBFGDIgBgBBDDCgBgBBqIBhBBB7CffBXBpBFB2OKK3BHBwDxKxKBDBDeBLPBhIiEBX+BBFfBDhIBxBUBDFB9+zB5Z5ZCCBlFRRBBB+BCCkEHHBCBitDBBhrwBx+Bx+BagBgBagBgBagBgBagBgBat5Ft5FB-uC-uCBHB",!1)),So:()=>new _(E("mFDDFCCyerIrIBgEgEBvGvGLUUB4H4HkQ2L2LjEFBClElEwGqBqBoMCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WzWzW+EhBBiLJBKIBksBBBCDBCBBLCCBHHBEBCECFMMBPPCBBC7B7BBKKBDBDDBCBBCBBCGBCeBDBBCCCBdBtIHBFTBDGBDwCBCdBanBBHnCBXKByCtCBX2FBCIBC1BBJuDBC3HBtBrBBhC-HBhQvBBWBBHmBBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBBxKBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BBibDBLBBC+R+RBBBqqUPBuLPBhCBB3BHBuBCBlPEEFBBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSpgBpgBBGBnjC2kC2kCBGBFQBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQPBhDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBqlB-PB4BDBzBHBCNBCBBp2B96C96CiEyWyWBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E6HBG4WBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBB-B3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB",!1)),Z:()=>new _(E("gBgEgEgvFgsCgsCBJBeBBGwBwBh9DAB",!1)),Zl:()=>new _(E("ohIA",!0)),Zp:()=>new _(E("phIA",!0)),Zs:()=>new _(E("gBgEgEgvFgsCgsCBJBlBwBwBh9DAB",!1)),ASCII_Hex_Digit:()=>new _(E("wBJIFbF",!0)),Alphabetic:()=>new _(E("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICC3CeeBQBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoBNBCCCBCCBCCJaBFDBeKBG3BBCGBPlDBCHBFHBFCBLCBDRRBuBBOkDBZgBBKBBFGGBWBDSBUYBIKBGXBCGBIJJBoBBLLBEGBHrCBCPBCCBFOBOSBCHBDBBDVBCGBCEEBCBEHBDBBDBBCJJFBBCEBNBBLFFBBBCFBFBBDVBCGBCBBCBBCBBFEBFBBDBBFIIBCBCSSBEBMCBCIBCCBCVBCGBCBBCEBEIBCCBCBBEQQBCBWDBFCBCHBDBBDVBCGBCBBCEBEHBDBBDBBKBBFBBCEBORRBCCBEBECBCDBEBBCCCBEEBEEBBBELBFEBECBCCBEHHpBMBCCBCWBCPBEHBCCBCCBJBBCCBCBBDDBdDBCHBCCBCWBCJBCEBEHBCCBCCBJBBGCBCDBOCBNMBCCBCoBBDHBCCBCCBCGGBCBIEBXFBCCBCRBEXBCIBCDDBFBJFBCCCBGBTBBO5BBGGBH0B0BBECBDBCXBCCCBRBCCBDEBCHHPDBhBgCgCBGBCjBBFSBFPBCjBBkC2BBCDDBDBR-BBLDBDlBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBEKBITBMUBNTBNMBCCBCBBNzBBDSBPFFkC4CBIqBBGlCBLeBCLBFIBYdBDEBMrBBFZB3BbBF+BBDTBzBYYBMMBBByBzBBCOBCHB0BpBBDDBLrBBCKBP2BBXCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBUhBBM1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBFSSBnBBuZzBB34BkHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBCfBwB2O2OBBBaIBIEBDEBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBGHBEwDBoBIBDmDBDxCBVUBCgBBZzBBNjCBCtBtBBEBECCBBBLgBBGiBBOcBEyBBCLBQRRBOBLEBC2BBKNBTWBEkCBCCCZCBDPBDDBMFBDFBDFBKGBCGBCqBBCNBH6DBWj9KBNWBFwBBloItLBDpDBnBGBNEBGLBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmC0BBsIcBEwBBwBfBOdBGqBBGdBDjBBFHBCEBrB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCDBCBBGHBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOnBBjBbBEGGBVB7HpBBCBBEBBRFBzBCBEcBLJJBUBrBRBvBUBcWBKlCBsBEBL4BBKOOBXBYyBBSDBJiBBEKKB+BBCDBKBBLCCkBRBChBBDHHBCB-BGBCCCBCBCOBCJBI4BBYDBCHBDBBDVBCGBCBBCEBEHBDBBDBBEHHGGBdJBCDDClBBCJBCDDCDBCBBECCtBhCBCCBCDBVCBfhCBDBBC5F5FB0BBDGBaFBjB+BBCEE8B1BBDoCoCBZBDNBWGB6F4BBoD-BBgBHBDDDBGBCBBCdBCBBDBBDDB+CHBDtBBDFBCCCBccBxBBDJBSnCBGTTBnCBoDHB5CgBBgBIBCsBBCGBCyByBBcBDVBCNBqCGBCBBCrBBECCBCCBBBCDDBZZBEBCBBCkBBCBBCDBCYYBqBBlIWBKQBCoBBECBwDwCwCB4cBnDuDBSjGBtyCgDBQvhBBSFBa68DBGmSB61GuBBy2B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBF4BBIQBhCBBCNNBFBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBFi7Fi7FBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCVBJBBhHGBCDBCBBCOBCkGB8BjCBEEE1lBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1TZBHZBHZB3zD-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Dash:()=>new _(E("tB9qB9qB0BiyDiyDmgBqgCqgCBEB+BoBoBQnMnMlgDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J",!1)),Emoji:()=>new _(E("jBHHGJBwDFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDrGrGhFBBNBBPDDBIBsCZBCBBYVVDIBWBBvFhBBDvDBDBBCCBDyCBDCBCmIBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDDBEJBECCBEEDJBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB",!1)),Emoji_Component:()=>new _(E("jBHHGJB0+H2G2Gsp3B3+8B3+8BBYB8PEBxtBDBtzhY-CB",!1)),Emoji_Modifier:()=>new _(E("7-8DE",!0)),Emoji_Modifier_Base:()=>new _(E("9wJ8G8GRDB4jzD9B9BBBBDDDBBB2DBBDKBWSBEFFBBBCCBICCZqGqGBFFWFFBvFvFBBBEEB0CRRBBBKMMgSDDJHBHKKBIBDCB5B+B+BBCCBCCSCBCMBmHCBrBIB",!1)),Emoji_Presentation:()=>new _(E("64IBBuGDBEDDqQBBWBBzBLBsBUUOJJBSSBGGBJJGWWIBBCFFDIIFBBdkBkBCFFBBBC+B+BBBBZPP8aBB0BFFvlxDrGrG-FDDBIBsCZBCZZVDDBDBCCBWBBvFgBBNIBClCBCVBNqBBFEBNQBEEEBlCBCCCB5FBD+BBODBCXBTbbBOO3C0CBxBlCBHEEBBBDDBEDBMBBIIBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB",!1)),Extended_Pictographic:()=>new _(E("pFFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDoBoBBCBlDLBQBBQPPBmBmBBIBxDBBNBBPDDBIBU3BBcOBLVVDIBCDBKWBH7FBDvDBDBBCCBDyCBDCBCDBG9HBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDQBECCBEBDMB7GlBBNDB5BHBLFBpBHBfBBNDBDNBKmBBNuBBCJBC4FB5CHBPxEBhI9fB",!1)),Hex_Digit:()=>new _(E("wBJIFbFq1-BJIFbF",!0)),Lowercase:()=>new _(E("hDZBwBLLFlBlBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDiBBIBBfEBhDsBsBCEEDDBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBCDB5XFBjkCIBC2D2DB+FBiC0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBB6DOORMBuDEEBEEcKFDBBJDBFiBiBBOBFsasaBYBn6BvBBCEEBGCFCCBCCBGBEiDCBIICFFNlBBCGG0oesBCUaCBBBmEMCBBBC8BCBIBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCWDBCCCBBB2ZqBBCNBHvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBkODDBBBCpBBCIBmoByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFBmI9BB1lChBB",!1)),Math:()=>new _(E("rBRRBBBgBeeCuBuBFmBmBgB5W5WBBBDbbBDDBBBwQCBuwGccBBBMEEOPPBCBWEBMEBiCMBFEEBFFBDBTFFDJBCDDBEBHEEBDDBCCBBBCFBENBClClCBWBCFBCBBFBBFfBCHHBPPBqIBJDBVBB7CffBZBCZZMGB+NBBNJBFFBFBBDBBEEBPCCDFBMHBGBB6BCCeDBKCBxK-BBhI-PBxBUBDFB9+zB4Z4ZBEBCjFjFRCBeCCeCCkEHHBCBitDBBhrwBwoBwoBBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBBhwFDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB-uCIB",!1)),Quotation_Mark:()=>new _(E("iBFFkEQQ96HHBaBBowDqOqOBCBOCBixzBDB+FFF7CBB",!1)),Terminal_Punctuation:()=>new _(E("hBLLCMMBEE-ZJJiQ6B6BpCPPCCB1FsBsBBJBCsHsHB3B3BBEBCHBgBmImIB1nB1nBBtFtFFFB4JBB2YHBmY9D9DBBBoCBB+ECBEoBoBBCBDBB7JBBjLDBjFBBLBBCCBeCB8FEB-BBBldYYBKKBBBwlDCBzJOOFLLCBBEBBtNBB8ndBBuICBkHEB-LBB3CBBgD4E4EBBB0ECBgERRB6H6HnxUDDB6B6BBBBCDBqFLLCMMBEEiCDD7hBxBxBnkBoGoG3JBB5EFBlCFB6CDB5dEBtBDB+FGBxDDBgECBiEBBHRRB5C5CBDBtDrJrJB2D2DBBBNBBnLDBEOBqDBB6HCBmQCC8HBB4CBBFBB-MCBuBmUmUBrCrCBspBspBBDB6vRBBmEiCiCBBBLqRqRBoJoJBnwTnwTovHDB",!1)),Uppercase:()=>new _(E("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBGbbBOBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBBvgCZBHZBHZB",!1)),White_Space:()=>new _(E("JEBTlDlDbgvFgvFgsCKBeBBGwBwBh9DAB",!1))})),G(er,"SCRIPTS",new Fa({Adlam:()=>new _(E("go6DrCFJFB",!0)),Ahom:()=>new _(E("g4lCaDOFW",!0)),Anatolian_Hieroglyphs:()=>new _(E("ggxCmS",!0)),Arabic:()=>new _(E("gwBEBCFBCNBCCBCfBCJBMZBCrDBChBBxCvBBxHhBBGqCBCcBxy8BtPBDvEBhBPBxDEBCmEBk7DeBkCFBJIBiBFBh43BDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB",!1)),Armenian:()=>new _(E("xpBlBDxBDCks9BE",!0)),Avestan:()=>new _(E("g4iC1BEG",!0)),Balinese:()=>new _(E("g4GsCCxB",!0)),Bamum:()=>new _(E("g1pB3CpowB4R",!0)),Bassa_Vah:()=>new _(E("w26CdDF",!0)),Batak:()=>new _(E("g+GzBJD",!0)),Bengali:()=>new _(E("gsCDBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYB",!1)),Beria_Erfe:()=>new _(E("g17CYDY",!0)),Bhaiksuki:()=>new _(E("ggnCICsBCNLc",!0)),Bopomofo:()=>new _(E("qXB6wLqBxDf",!0)),Brahmi:()=>new _(E("ggkCtCFjBKA",!0)),Braille:()=>new _(E("ggK-H",!0)),Buginese:()=>new _(E("gwGbDB",!0)),Buhid:()=>new _(E("g6FT",!0)),Canadian_Aboriginal:()=>new _(E("ggF-TxRlC7tgCP",!0)),Carian:()=>new _(E("g1gCwB",!0)),Caucasian_Albanian:()=>new _(E("wphCzBMA",!0)),Chakma:()=>new _(E("gokC0BCR",!0)),Cham:()=>new _(E("gwqB2BKNDJDD",!0)),Cherokee:()=>new _(E("g9E1CDFz7lBvC",!0)),Chorasmian:()=>new _(E("w9jCb",!0)),Common:()=>new _(E("AgCBbFBbuBBCOBCEBYgBgBiOmBBGEBDTB1DKKHCC+THHPEEhB9E9ElQiEiEB6mB6mB2MDBjJwvBwvBBBBoCBBsGBBCumBumBOIIBCBCFBCCBDmYmYBKBD2CBCKBEKBCOBShBB-BlBBCCBDFBCaBCQBqBCBF5UBXKBW-cBhIzTBDpEBhQ9CBzMUBCCCBXBQHBFDB8CBBE7C7CB0E0EBOBhBlBBKxBxBB+BBgBwCBwB5C5CBmFBhuG-BBhoWhBBnDCBmFJB1HhFhFsMPPBzuUzuUBxGxGBIBXiBBCSBCDB0ECCBeBbFBbKBLuBuBBhChCBFBCGBLEBjICBFsBBEIBxCMB0BsBBlHaBltuBDB96D8HBEzNBHWBQQBgDzDB9B1HBLmBBD9BBEQBJBBIdBF8BB2GTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBByjFjCBtC8BBjWrBBFjDBNOBDOBCOBCkBBLtFB5BZBCBBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBnghYffB+CB",!1)),Coptic:()=>new _(E("ifNxkKzDGG",!0)),Cuneiform:()=>new _(E("ggoC5cnDuDCEMjG",!0)),Cypriot:()=>new _(E("ggiCFBDCCBqBBCBBEDD",!1)),Cypro_Minoan:()=>new _(E("w8rCiD",!0)),Cyrillic:()=>new _(E("ggBkEBDoFBx6FKBhFtCtCojEfBhie-CBv8VBBhw4B9BBiBAB",!1)),Deseret:()=>new _(E("gghCvC",!0)),Devanagari:()=>new _(E("goCwCFODZh7nBfhwcJ",!0)),Dives_Akuru:()=>new _(E("gomCGBDDDBGBCBBCdBCBBDLBKJB",!1)),Dogra:()=>new _(E("ggmC7B",!0)),Duployan:()=>new _(E("ggvDqDGMEIIJDD",!0)),Egyptian_Hieroglyphs:()=>new _(E("ggsC1iBL68D",!0)),Elbasan:()=>new _(E("gohCnB",!0)),Elymaic:()=>new _(E("g-jCW",!0)),Ethiopic:()=>new _(E("gwEoCBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBnvGWBKGBCGBCGBCGBCGBCGBCGBCGBjpfFBDFBDFBKGBCGBylvCGBCDBCBBCOB",!1)),Garay:()=>new _(E("gqjClBEcJB",!0)),Georgian:()=>new _(E("glElBBCGGDqBBCDBx8CqBBDCBhiElBBCGG",!1)),Glagolitic:()=>new _(E("ggL-Ch9sDGCQDGCBCE",!0)),Gothic:()=>new _(E("w5gCa",!0)),Grantha:()=>new _(E("g4kCDBCHBDBBDVBCGBCBBCEBDIBDBBDCBDHHGGBDGBEEB",!1)),Greek:()=>new _(E("wbDBCCBDDBCFFCCCBBBCCCBSBC+BBPPBnpGEBzBEBFEB1ChKhKBUBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBoJ-xiB-xiB7uVuCBSgj0Bgj0BBkCB",!1)),Gujarati:()=>new _(E("h0CCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGB",!1)),Gunjala_Gondi:()=>new _(E("grnCFCBCkBCBCFIJ",!0)),Gurmukhi:()=>new _(E("hwCCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPB",!1)),Gurung_Khema:()=>new _(E("go4C5B",!0)),Han:()=>new _(E("g0LZBC4CBN1GBwBCCaIBPDBle-tGBhC-vUBhoWtLBDpDBpodBBNGBqgkB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB",!1)),Hangul:()=>new _(E("goE-HvxHBiI9CyDeiCei3dckUj9KNWFwBl9JeEFDFDFDC",!0)),Hanifi_Rohingya:()=>new _(E("gojCnBJJ",!0)),Hanunoo:()=>new _(E("g5FU",!0)),Hatran:()=>new _(E("gniCSCBGE",!0)),Hebrew:()=>new _(E("xsB2BBJaBFFBpp9BZBCEBCCCBCCBCCBIB",!1)),Hiragana:()=>new _(E("hiM1CBHCBi7-C+IBTeeBBBulQAB",!1)),Imperial_Aramaic:()=>new _(E("giiCVCI",!0)),Inherited:()=>new _(E("gYvDB2IBBlOKBbhXhXBCB8qEtBBDLBlPCBCMBCGBFHHEBBnG-BBtQBBjGgBB65DDBsDBBmrzBPBRNBwejHjH7iEl+uBl+uBBsBBDWBhRCBSHBDGBfDBz6rYvHB",!1)),Inscriptional_Pahlavi:()=>new _(E("g7iCSGH",!0)),Inscriptional_Parthian:()=>new _(E("g6iCVDH",!0)),Javanese:()=>new _(E("gsqBtCDJFB",!0)),Kaithi:()=>new _(E("gkkCiCLA",!0)),Kannada:()=>new _(E("gkDMCCCWCJCEDICCCDIBGCCDDJCC",!0)),Katakana:()=>new _(E("hlM5CBDCBxHPBxGuBBC3CBvgzBJBCsBBzisBDBCGBCBBCgJgJBBBzBPPBCB",!1)),Kawi:()=>new _(E("g4nCQCoBEc",!0)),Kayah_Li:()=>new _(E("goqBtBCA",!0)),Kharoshthi:()=>new _(E("gwiCDCBGHCCCcDCFJII",!0)),Khitan_Small_Script:()=>new _(E("k-7C84G84GB0OBqBAB",!1)),Khmer:()=>new _(E("g8F9CDJHJnPf",!0)),Khojki:()=>new _(E("gwkCRCuB",!0)),Khudawadi:()=>new _(E("w1kC6BGJ",!0)),Kirat_Rai:()=>new _(E("gq7C5B",!0)),Lao:()=>new _(E("h0DBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDB",!1)),Latin:()=>new _(E("hCZBHZBwBQQGWBCeBCgOBoBEB8wGlBBHwBBGDBGMBClCBiC-HByLOORMBuEBBHccSoBB42CfBj1elDBExCBVOBxZqBBCIBCDB38TGB7gBZBHZBmhCFBCpBBCIBm61BeBHFB",!1)),Lepcha:()=>new _(E("ggH3BEOEC",!0)),Limbu:()=>new _(E("goGeBCLBFLBFEEBKB",!1)),Linear_A:()=>new _(E("gwhC2JKVLH",!0)),Linear_B:()=>new _(E("gggCLCZCSCBCODNjB6D",!0)),Lisu:()=>new _(E("wmpBvBx1eA",!0)),Lycian:()=>new _(E("g0gCc",!0)),Lydian:()=>new _(E("gpiCZGA",!0)),Mahajani:()=>new _(E("wqkCmB",!0)),Makasar:()=>new _(E("g3nCY",!0)),Malayalam:()=>new _(E("goDMCCCyBCCCFFPDZ",!0)),Mandaic:()=>new _(E("giCbDA",!0)),Manichaean:()=>new _(E("g2iCmBFL",!0)),Marchen:()=>new _(E("wjnCfDVCN",!0)),Masaram_Gondi:()=>new _(E("gonCGBCBBCrBBECCBCCBHBJJB",!1)),Medefaidrin:()=>new _(E("gy7C6C",!0)),Meetei_Mayek:()=>new _(E("g3qBWqGtBDJ",!0)),Mende_Kikakui:()=>new _(E("gg6DkGDP",!0)),Meroitic_Cursive:()=>new _(E("gtiCXFTDtB",!0)),Meroitic_Hieroglyphs:()=>new _(E("gsiCf",!0)),Miao:()=>new _(E("g47CqCF4BIQ",!0)),Modi:()=>new _(E("gwlCkCMJ",!0)),Mongolian:()=>new _(E("ggGBBDCCBSBH4CBIqBB2t-BMB",!1)),Mro:()=>new _(E("gy6CeCJFB",!0)),Multani:()=>new _(E("g0kCGBCCCBCBCOBCKB",!1)),Myanmar:()=>new _(E("ggE-EhqmBeiDfxibT",!0)),Nabataean:()=>new _(E("gkiCeJI",!0)),Nag_Mundari:()=>new _(E("wm5DpB",!0)),Nandinagari:()=>new _(E("gtmCHDtBDK",!0)),New_Tai_Lue:()=>new _(E("gsGrBFZHKEB",!0)),Newa:()=>new _(E("gglC7CCE",!0)),Nko:()=>new _(E("g+B6BDC",!0)),Nushu:()=>new _(E("h-7CvsQvsQBqMB",!1)),Nyiakeng_Puachue_Hmong:()=>new _(E("go4DsBENDJFB",!0)),Ogham:()=>new _(E("g0Fc",!0)),Ol_Chiki:()=>new _(E("wiHvB",!0)),Ol_Onal:()=>new _(E("wu5DqBFA",!0)),Old_Hungarian:()=>new _(E("gkjCyBOyBIF",!0)),Old_Italic:()=>new _(E("g4gCjBKC",!0)),Old_North_Arabian:()=>new _(E("g0iCf",!0)),Old_Permic:()=>new _(E("w6gCqB",!0)),Old_Persian:()=>new _(E("g9gCjBFN",!0)),Old_Sogdian:()=>new _(E("g4jCnB",!0)),Old_South_Arabian:()=>new _(E("gziCf",!0)),Old_Turkic:()=>new _(E("ggjCoC",!0)),Old_Uyghur:()=>new _(E("w7jCZ",!0)),Oriya:()=>new _(E("h4CCCHDBDVCGCBCEDIDBDCICFBCEDR",!0)),Osage:()=>new _(E("wlhCjBFjB",!0)),Osmanya:()=>new _(E("gkhCdDJ",!0)),Pahawh_Hmong:()=>new _(E("g46ClCLJCGCUGS",!0)),Palmyrene:()=>new _(E("gjiCf",!0)),Pau_Cin_Hau:()=>new _(E("g2mC4B",!0)),Phags_Pa:()=>new _(E("giqB3B",!0)),Phoenician:()=>new _(E("goiCbEA",!0)),Psalter_Pahlavi:()=>new _(E("g8iCRIDNG",!0)),Rejang:()=>new _(E("wpqBjBMA",!0)),Runic:()=>new _(E("g1FqCEK",!0)),Samaritan:()=>new _(E("ggCtBDO",!0)),Saurashtra:()=>new _(E("gkqBlCJL",!0)),Sharada:()=>new _(E("gskC-ChsCH",!0)),Shavian:()=>new _(E("wihCvB",!0)),Siddham:()=>new _(E("gslC1BDlB",!0)),Sidetic:()=>new _(E("gqiCZ",!0)),SignWriting:()=>new _(E("gg2DrUQECO",!0)),Sinhala:()=>new _(E("hsDCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBt-gCTB",!1)),Sogdian:()=>new _(E("w5jCpB",!0)),Sora_Sompeng:()=>new _(E("wmkCYIJ",!0)),Soyombo:()=>new _(E("wymCyC",!0)),Sundanese:()=>new _(E("g8G-BhIH",!0)),Sunuwar:()=>new _(E("g+mChBPJ",!0)),Syloti_Nagri:()=>new _(E("ggqBsB",!0)),Syriac:()=>new _(E("g4BNC7BDCxIK",!0)),Tagalog:()=>new _(E("g4FVKA",!0)),Tagbanwa:()=>new _(E("g7FMCCCB",!0)),Tai_Le:()=>new _(E("wqGdDE",!0)),Tai_Tham:()=>new _(E("gxG+BCcDKHJHN",!0)),Tai_Viet:()=>new _(E("g0qBiCZE",!0)),Tai_Yo:()=>new _(E("g25DeCVJB",!0)),Takri:()=>new _(E("g0lC5BHJ",!0)),Tamil:()=>new _(E("i8CBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBm+kCxBBOAB",!1)),Tangsa:()=>new _(E("wz6CuCCJ",!0)),Tangut:()=>new _(E("g-7CgBgBB+3GBhQeBiDyDB",!1)),Telugu:()=>new _(E("ggDMCCCWCPDICCCDIBCCCBDDDJII",!0)),Thaana:()=>new _(E("g8BxB",!0)),Thai:()=>new _(E("hwD5BGb",!0)),Tibetan:()=>new _(E("g4DnCCjBFmBCjBCOCGFB",!0)),Tifinagh:()=>new _(E("wpL3BIBPA",!0)),Tirhuta:()=>new _(E("gklCnCJJ",!0)),Todhri:()=>new _(E("guhCzB",!0)),Tolong_Siki:()=>new _(E("wtnCrBFJ",!0)),Toto:()=>new _(E("w04De",!0)),Tulu_Tigalari:()=>new _(E("g8kCJBCDDClBBCJBCDDCDBCJBCBBJBB",!1)),Ugaritic:()=>new _(E("g8gCdCA",!0)),Unknown:()=>new _(E("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-FB",!1)),Vai:()=>new _(E("gopBrJ",!0)),Vithkuqi:()=>new _(E("wrhCKCOCGCBCKCOCGCB",!0)),Wancho:()=>new _(E("g24D5BGA",!0)),Warang_Citi:()=>new _(E("glmCyCNA",!0)),Yezidi:()=>new _(E("g0jCpBCCDB",!0)),Yi:()=>new _(E("ggoBskBE2B",!0)),Zanabazar_Square:()=>new _(E("gwmCnC",!0))})),G(er,"FOLD_CATEGORIES",new Fa({L:()=>new _(E("laA",!0)),LC:()=>new _(E("laA",!0)),Ll:()=>new _(E("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGC3HrBrBCEEJHHCCBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHxC9zC9zCBuBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB",!1)),Lt:()=>new _(E("kOCCBCCBCClBCCtsHHBJHBJHBMQQwBAB",!1)),Lu:()=>new _(E("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpL2B2Bs1CvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB",!1)),M:()=>new _(E("5cgBgBlgHAB",!1)),Mn:()=>new _(E("5cgBgBlgHAB",!1)),Emoji:()=>new _(E("8mJA",!0)),Extended_Pictographic:()=>new _(E("8mJA",!0)),Lowercase:()=>new _(E("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHuBPBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB",!1)),Math:()=>new _(E("ycGDCHHFMMDDDCHHFAB",!1)),Uppercase:()=>new _(E("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpLiBiBBOBFsasaBYBn6BvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB",!1))})),G(er,"FOLD_SCRIPT",new Fa({Common:()=>new _(E("8cgBgB",!1)),Greek:()=>new _(E("1FwUwU",!1)),Inherited:()=>new _(E("5cgBgBlgHAB",!1))})),er),Ie,Z=(Ie=class{static isUnsearchable(e){return e===Ie.RUNE_ERROR||e>=Ie.MIN_HIGH_SURROGATE&&e<=Ie.MAX_LOW_SURROGATE}static is32(e,t){let n=0,s=e.length;for(;n<s;){const i=n+Math.floor((s-n)/2),o=e.getLo(i),a=e.getHi(i);if(o<=t&&t<=a){const u=e.getStride(i);return(t-o)%u===0}t<o?s=i:n=i+1}return!1}static is(e,t){if(t<=Ie.MAX_LATIN1){for(let n=0;n<e.length;n++){if(t>e.getHi(n))continue;const s=e.getLo(n);if(t<s)return!1;const i=e.getStride(n);return(t-s)%i===0}return!1}return e.length>0&&t>=e.getLo(0)&&Ie.is32(e,t)}static isPrint(e){return e<=Ie.MAX_LATIN1?e>=32&&e<Ie.MAX_ASCII||e>=161&&e!==173:Ie.is(Nt.Print,e)}static simpleFold(e){if(Nt.CASE_ORBIT.has(e))return Nt.CASE_ORBIT.get(e);if(e<=Ie.MAX_ASCII){const t=V.toLowerCase(e);return t!==e?t:V.toUpperCase(e)}return e}static equalsIgnoreCase(e,t){if(e===t)return!0;if(e<0||t<0)return!1;if(e<=Ie.MAX_ASCII&&t<=Ie.MAX_ASCII)return 65<=e&&e<=90&&(e|=32),65<=t&&t<=90&&(t|=32),e===t;for(let n=Ie.simpleFold(e);n!==e;n=Ie.simpleFold(n))if(n===t)return!0;return!1}},G(Ie,"MAX_RUNE",1114111),G(Ie,"RUNE_ERROR",65533),G(Ie,"MAX_ASCII",127),G(Ie,"MAX_LATIN1",255),G(Ie,"MAX_BMP",65535),G(Ie,"MIN_FOLD",65),G(Ie,"MAX_FOLD",125251),G(Ie,"MIN_HIGH_SURROGATE",55296),G(Ie,"MAX_HIGH_SURROGATE",56319),G(Ie,"MIN_LOW_SURROGATE",56320),G(Ie,"MAX_LOW_SURROGATE",57343),G(Ie,"MIN_SUPPLEMENTARY_CODE_POINT",65536),Ie);const dl=256,rg=new Uint8Array(dl);for(let r=0;r<dl;r++)rg[r]=97<=r&&r<=122||65<=r&&r<=90||48<=r&&r<=57||r===95?1:0;let iB=null,oB=null;var Se,$=(Se=class{static emptyInts(){return[]}static isByteArray(e){return Array.isArray(e)||Object.prototype.toString.call(e)==="[object Uint8Array]"}static isalnum(e){return V.CODES[0]<=e&&e<=V.CODES[9]||V.CODES.a<=e&&e<=V.CODES.z||V.CODES.A<=e&&e<=V.CODES.Z}static unhex(e){return V.CODES[0]<=e&&e<=V.CODES[9]?e-V.CODES[0]:V.CODES.a<=e&&e<=V.CODES.f?e-V.CODES.a+10:V.CODES.A<=e&&e<=V.CODES.F?e-V.CODES.A+10:-1}static escapeRune(e){let t="";if(Z.isPrint(e))Se.METACHARACTERS.indexOf(String.fromCodePoint(e))>=0&&(t+="\\"),t+=String.fromCodePoint(e);else switch(e){case V.CODES['"']:t+='\\"';break;case V.CODES["\\"]:t+="\\\\";break;case V.CODES["	"]:t+="\\t";break;case V.CODES[`
`]:t+="\\n";break;case V.CODES["\r"]:t+="\\r";break;case V.CODES["\b"]:t+="\\b";break;case V.CODES["\f"]:t+="\\f";break;default:{let n=e.toString(16);e<256?(t+="\\x",n.length===1&&(t+="0"),t+=n):t+=`\\x{${n}}`;break}}return t}static stringToRunes(e){const t=String(e),n=[];let s=0;for(;s<t.length;){const i=t.codePointAt(s);n.push(i),s+=i>Z.MAX_BMP?2:1}return new Int32Array(n)}static runeToString(e){return String.fromCodePoint(e)}static isWordRune(e){return e<dl?rg[e]===1:!1}static emptyOpContext(e,t){let n=0;return e<0&&(n|=Se.EMPTY_BEGIN_TEXT|Se.EMPTY_BEGIN_LINE),e===10&&(n|=Se.EMPTY_BEGIN_LINE),t<0&&(n|=Se.EMPTY_END_TEXT|Se.EMPTY_END_LINE),t===10&&(n|=Se.EMPTY_END_LINE),Se.isWordRune(e)!==Se.isWordRune(t)?n|=Se.EMPTY_WORD_BOUNDARY:n|=Se.EMPTY_NO_WORD_BOUNDARY,n}static quoteMeta(e){return e.split("").map(t=>Se.METACHARACTERS.indexOf(t)>=0?`\\${t}`:t).join("")}static charCount(e){return e>Z.MAX_BMP?2:1}static toArray(e){const t=e.length,n=new Array(t);for(let s=0;s<t;s++)n[s]=e[s];return n}static stringToUtf8ByteArray(e){if(globalThis.TextEncoder)return iB||(iB=new TextEncoder),iB.encode(e);{let t=[],n=0;for(let s=0;s<e.length;s++){let i=e.charCodeAt(s);i<128?t[n++]=i:i<2048?(t[n++]=i>>6|192,t[n++]=i&63|128):(i&64512)===Z.MIN_HIGH_SURROGATE&&s+1<e.length&&(e.charCodeAt(s+1)&64512)===Z.MIN_LOW_SURROGATE?(i=Z.MIN_SUPPLEMENTARY_CODE_POINT+((i&1023)<<10)+(e.charCodeAt(++s)&1023),t[n++]=i>>18|240,t[n++]=i>>12&63|128,t[n++]=i>>6&63|128,t[n++]=i&63|128):(t[n++]=i>>12|224,t[n++]=i>>6&63|128,t[n++]=i&63|128)}return t}}static utf8ByteArrayToString(e){if(globalThis.TextDecoder){oB||(oB=new TextDecoder("utf-8"));const t=e instanceof Uint8Array?e:new Uint8Array(e);return oB.decode(t)}else{let t=[],n=0,s=0;for(;n<e.length;){let i=e[n++];if(i<128)t[s++]=String.fromCharCode(i);else if(i>191&&i<224){let o=e[n++];t[s++]=String.fromCharCode((i&31)<<6|o&63)}else if(i>239&&i<365){let o=e[n++],a=e[n++],u=e[n++],B=((i&7)<<18|(o&63)<<12|(a&63)<<6|u&63)-Z.MIN_SUPPLEMENTARY_CODE_POINT;t[s++]=String.fromCharCode(Z.MIN_HIGH_SURROGATE+(B>>10)),t[s++]=String.fromCharCode(Z.MIN_LOW_SURROGATE+(B&1023))}else{let o=e[n++],a=e[n++];t[s++]=String.fromCharCode((i&15)<<12|(o&63)<<6|a&63)}}return t.join("")}}},G(Se,"METACHARACTERS","\\.+*?()|[]{}^$"),G(Se,"EMPTY_BEGIN_LINE",1),G(Se,"EMPTY_END_LINE",2),G(Se,"EMPTY_BEGIN_TEXT",4),G(Se,"EMPTY_END_TEXT",8),G(Se,"EMPTY_WORD_BOUNDARY",16),G(Se,"EMPTY_NO_WORD_BOUNDARY",32),G(Se,"EMPTY_ALL",-1),Se);const sg=(r=[],e=0)=>{const t=Object.create(null);for(let n=0;n<r.length;n++){const s=r[n],i=e+n;t[s]=i,t[i]=s}return Object.freeze(t)};var Br,os=(Br=class{getEncoding(){throw Error("not implemented")}asCharSequence(){throw Error("not implemented")}asBytes(){throw Error("not implemented")}length(){throw Error("not implemented")}isUTF8Encoding(){return this.getEncoding()===Br.Encoding.UTF_8}isUTF16Encoding(){return this.getEncoding()===Br.Encoding.UTF_16}},G(Br,"Encoding",sg(["UTF_16","UTF_8"])),Br),af=class extends os{constructor(r=null){super(),this.bytes=r}getEncoding(){return os.Encoding.UTF_8}asCharSequence(){return $.utf8ByteArrayToString(this.bytes)}asBytes(){return this.bytes}length(){return this.bytes.length}},iy=class extends os{constructor(r=null){super(),this.charSequence=r}getEncoding(){return os.Encoding.UTF_16}asCharSequence(){return this.charSequence}asBytes(){return $.stringToUtf8ByteArray(this.charSequence.toString())}length(){return this.charSequence.length}},zr=class{static utf16(r){return new iy(r)}static utf8(r){return $.isByteArray(r)?new af(r):new af($.stringToUtf8ByteArray(r))}},yt=class{static EOF(){return-8}constructor(){this.start=0,this.end=0}canCheckPrefix(){return!0}endPos(){return this.end-this.start}hasString(){return!1}hasAnyString(){return!1}prefixLength(){return 0}},Xt,oy=(Xt=class extends yt{constructor(e,t=0,n=e.length){super(),this.bytes=e,this.start=t,this.end=n}hasString(e,t){const n=e.bytes;if(n.length===0)return!0;const s=this.indexOf(this.bytes,n,this.start+t);return s!==-1&&s<=this.end-n.length}hasAnyString(e,t){return e.automaton8().searchUTF8(this.bytes,this.start+t,this.end)}step(e){if(e+=this.start,e>=this.end)return yt.EOF();const t=this.bytes[e]&255;if(t<128)return t<<3|1;let n,s,i=128,o=191;if(t>=194&&t<=223)n=2,s=t&31;else if(t>=224&&t<=239)n=3,s=t&15,t===224?i=160:t===237&&(o=159);else if(t>=240&&t<=244)n=4,s=t&7,t===240?i=144:t===244&&(o=143);else return Xt.RUNE_ERROR_STEP;if(e+n>this.end)return Xt.RUNE_ERROR_STEP;const a=this.bytes[e+1]&255;if(a<i||a>o)return Xt.RUNE_ERROR_STEP;if(s=s<<6|a&63,n>2){const u=this.bytes[e+2]&255;if((u&192)!==128)return Xt.RUNE_ERROR_STEP;if(s=s<<6|u&63,n>3){const B=this.bytes[e+3]&255;if((B&192)!==128)return Xt.RUNE_ERROR_STEP;s=s<<6|B&63}}return s<<3|n}index(e,t){t+=this.start;const n=this.indexOf(this.bytes,e.prefixUTF8,t);return n<0?n:n-t}context(e){e+=this.start;let t=-1;if(e>this.start&&e<=this.end){let s=e-1;if(t=this.bytes[s--],t>=128){let i=e-4;for(i<this.start&&(i=this.start);s>=i&&(this.bytes[s]&192)===128;)s--;s<this.start&&(s=this.start);const o=this.step(s-this.start);t=s+(o&7)===e?o>>3:Z.RUNE_ERROR}}const n=e<this.end?this.step(e-this.start)>>3:-1;return $.emptyOpContext(t,n)}indexOf(e,t,n=0){let s=t.length;if(s===0)return n<=this.end?n:-1;const i=t[0];let o=this.end-s;const a=typeof e.indexOf=="function";let u=n;for(;u<=o;){if(a){if(u=e.indexOf(i,u),u===-1||u>o)return-1}else{for(;u<=o&&e[u]!==i;)u++;if(u>o)return-1}let B=!0;for(let l=1;l<s;l++)if(e[u+l]!==t[l]){B=!1;break}if(B)return u;u++}return-1}prefixLength(e){return e.prefixUTF8.length}},G(Xt,"RUNE_ERROR_STEP",Z.RUNE_ERROR<<3|1),Xt),ay=class extends yt{constructor(r,e=0,t=r.length){super(),this.charSequence=r,this.start=e,this.end=t}hasString(r,e){const t=this.charSequence.indexOf(r.str,this.start+e);return t!==-1&&t<=this.end-r.str.length}hasAnyString(r,e){return r.automaton16().searchUTF16(this.charSequence,this.start+e,this.end)}step(r){if(r+=this.start,r>=this.end)return yt.EOF();const e=this.charSequence.charCodeAt(r);if(e<Z.MIN_HIGH_SURROGATE||e>Z.MAX_HIGH_SURROGATE||r+1>=this.end)return e<<3|1;const t=this.charSequence.charCodeAt(r+1);return t>=Z.MIN_LOW_SURROGATE&&t<=Z.MAX_LOW_SURROGATE?(e-Z.MIN_HIGH_SURROGATE)*1024+(t-Z.MIN_LOW_SURROGATE)+Z.MIN_SUPPLEMENTARY_CODE_POINT<<3|2:e<<3|1}index(r,e){e+=this.start;const t=this.charSequence.indexOf(r.prefix,e);return t<0||t>this.end-r.prefix.length?-1:t-e}context(r){r+=this.start;const e=r>this.start&&r<=this.end?this.charSequence.charCodeAt(r-1):-1,t=r<this.end?this.charSequence.charCodeAt(r):-1;return $.emptyOpContext(e,t)}prefixLength(r){return r.prefix.length}},be=class{static fromUTF8(r,e=0,t=r.length){return new oy(r,e,t)}static fromUTF16(r,e=0,t=r.length){return new ay(r,e,t)}},Jo=class extends Error{constructor(r){super(r),this.name="RE2JSException"}},Ae=class extends Jo{constructor(r,e=null){let t=`error parsing regexp: ${r}`;e&&(t+=`: \`${e}\``),super(t),this.name="RE2JSSyntaxException",this.message=t,this.error=r,this.input=e}getDescription(){return this.error}getPattern(){return this.input}},aB=class extends Jo{constructor(r){super(r),this.name="RE2JSCompileException"}},Rt=class extends Jo{constructor(r){super(r),this.name="RE2JSGroupException"}},uy=class extends Jo{constructor(r){super(r),this.name="RE2JSFlagsException"}},pu=class extends Jo{constructor(r){super(r),this.name="RE2JSInternalException"}},$r,uf=($r=class{static quoteReplacement(e,t=!1){return t?e.indexOf("\\")<0&&e.indexOf("$")<0?e:e.split("").map(n=>{const s=n.codePointAt(0);return s===V.CODES["\\"]||s===V.CODES.$?`\\${n}`:n}).join(""):e.indexOf("$")<0?e:e.split("").map(n=>n.codePointAt(0)===V.CODES.$?"$$":n).join("")}constructor(e,t){if(e===null)throw new Error("pattern is null");this.patternInput=e;const n=this.patternInput.re2();this.patternGroupCount=n.numberOfCapturingGroups(),this.groups=[],this.namedGroups=n.namedGroups,this.hasNamedGroups=Object.keys(this.namedGroups).length>0,this.numberOfInstructions=n.numberOfInstructions(),this.lookbehindState=null,t instanceof os?this.resetMatcherInput(t):$.isByteArray(t)?this.resetMatcherInput(zr.utf8(t)):this.resetMatcherInput(zr.utf16(t))}pattern(){return this.patternInput}reset(){return this.matcherInputLength=this.matcherInput.length(),this.appendPos=0,this.hasMatch=!1,this.hasGroups=!1,this.anchorFlag=0,this}resetMatcherInput(e){if(e===null)throw new Error("input is null");return e instanceof os||($.isByteArray(e)?e=zr.utf8(e):e=zr.utf16(e)),this.matcherInput=e,this.lookbehindState!==null?this.lookbehindState.reset():this.lookbehindState=this.patternInput.re2().createLookbehindState(),this.reset(),this}start(e=0){if(typeof e=="string"){const t=this.namedGroups[e];if(!Number.isFinite(t))throw new Rt(`group '${e}' not found`);e=t}return this.loadGroup(e),this.groups[2*e]}end(e=0){if(typeof e=="string"){const t=this.namedGroups[e];if(!Number.isFinite(t))throw new Rt(`group '${e}' not found`);e=t}return this.loadGroup(e),this.groups[2*e+1]}programSize(){return this.numberOfInstructions}group(e=0){if(typeof e=="string"){const s=this.namedGroups[e];if(!Number.isFinite(s))throw new Rt(`group '${e}' not found`);e=s}const t=this.start(e),n=this.end(e);return t<0&&n<0?null:this.substring(t,n)}getNamedGroups(){if(!this.hasMatch)throw new Rt("perhaps no match attempted");const e=Object.create(null);for(const t of Object.keys(this.namedGroups))e[t]=this.group(t);return e}groupCount(){return this.patternGroupCount}loadGroup(e){if(!Number.isInteger(e)||e<0||e>this.patternGroupCount)throw new Rt(`Group index out of bounds: ${e}`);if(!this.hasMatch)throw new Rt("perhaps no match attempted");if(e===0||this.hasGroups)return;const t=this.matcherInputLength,n=this.patternInput.re2().matchMachineInput(this.matcherInput,this.groups[0],t,this.anchorFlag,1+this.patternGroupCount,this.lookbehindState);if(!n[0])throw new Rt("inconsistency in matching group data");this.groups=n[1],this.hasGroups=!0}matches(){return this.genMatch(0,M.ANCHOR_BOTH)}lookingAt(){return this.genMatch(0,M.ANCHOR_START)}find(e=null){if(e!==null){if(!Number.isInteger(e)||e<0||e>this.matcherInputLength)throw new Rt(`start index out of bounds: ${e}`);return this.reset(),this.genMatch(e,0)}if(e=0,this.hasMatch&&(e=this.groups[1],this.groups[0]===this.groups[1])){const t=(this.matcherInput.isUTF16Encoding()?be.fromUTF16(this.matcherInput.asCharSequence(),0,this.matcherInputLength):be.fromUTF8(this.matcherInput.asBytes(),0,this.matcherInputLength)).step(e);t<0?e++:e+=t&7}return this.genMatch(e,M.UNANCHORED)}genMatch(e,t){const n=this.patternInput.re2().matchMachineInput(this.matcherInput,e,this.matcherInputLength,t,1,this.lookbehindState);return n[0]?(this.groups=n[1],this.hasMatch=!0,this.hasGroups=this.patternGroupCount===0,this.anchorFlag=t,!0):(this.hasMatch=!1,!1)}substring(e,t){return this.matcherInput.isUTF8Encoding()?$.utf8ByteArrayToString(this.matcherInput.asBytes().slice(e,t)):this.matcherInput.asCharSequence().substring(e,t).toString()}inputLength(){return this.matcherInputLength}appendReplacement(e,t=!1){let n="";const s=this.start(),i=this.end();return this.appendPos<s&&(n+=this.substring(this.appendPos,s)),this.appendPos=i,n+=t?this.appendReplacementInternalJava(e):this.appendReplacementInternalJs(e),n}appendReplacementInternalJava(e){let t="",n=0;const s=e.length;let i=0;for(;i<s;){const o=e.codePointAt(i);if(o===V.CODES["\\"]){if(n<i&&(t+=e.substring(n,i)),i++,i>=s)throw new Rt("character to be escaped is missing");n=i,i++;continue}if(o===V.CODES.$){if(n<i&&(t+=e.substring(n,i)),i+1>=s)throw new Rt("Illegal group reference: group index is missing");const a=e.codePointAt(i+1);if(V.CODES[0]<=a&&a<=V.CODES[9]){let u=a-V.CODES[0],B=i+2;for(;B<s;B++){const d=e.codePointAt(B);if(d<V.CODES[0]||d>V.CODES[9]||u*10+d-V.CODES[0]>this.patternGroupCount)break;u=u*10+d-V.CODES[0]}if(u>this.patternGroupCount)throw new Rt(`n > number of groups: ${u}`);const l=this.group(u);l!==null&&(t+=l),i=B,n=i}else if(a===V.CODES["{"]){let u=i+2;for(;u<s&&e.codePointAt(u)!==V.CODES["}"];)u++;if(u>=s)throw new Rt("named capture group is missing trailing '}'");const B=e.substring(i+2,u),l=this.group(B);l!==null&&(t+=l),i=u+1,n=i}else throw new Rt("Illegal group reference");continue}i++}return n<s&&(t+=e.substring(n,s)),t}appendReplacementInternalJs(e){const t=o=>o>=48&&o<=57,n=this.patternGroupCount;let s="",i=0;for(;i<e.length;){const o=e.indexOf("$",i);if(o<0)break;s+=e.substring(i,o),i=o;const a=e.charCodeAt(i+1);if(a===V.CODES.$)s+="$",i+=2;else if(a===V.CODES["&"])s+=this.group(0),i+=2;else if(a===V.CODES["`"])s+=this.substring(0,this.start(0)),i+=2;else if(a===V.CODES["'"])s+=this.substring(this.end(0),this.matcherInputLength),i+=2;else if(t(a)){let u=1,B=a-48;const l=e.charCodeAt(i+2);if(t(l)&&B*10+l-48<=n&&(u=2,B=B*10+l-48),B>=1&&B<=n){const d=this.group(B);d!==null&&(s+=d)}else s+=e.substring(i,i+1+u);i+=1+u}else if(a===V.CODES["<"]&&this.hasNamedGroups){const u=e.indexOf(">",i+2);if(u<0)s+="$<",i+=2;else{const B=e.substring(i+2,u);if(Object.prototype.hasOwnProperty.call(this.namedGroups,B)){const l=this.group(B);l!==null&&(s+=l)}i=u+1}}else s+="$",i+=1}return s+e.substring(i)}appendTail(){return this.substring(this.appendPos,this.matcherInputLength)}replaceAll(e,t=!1){return this.replace(e,!0,t)}replaceFirst(e,t=!1){return this.replace(e,!1,t)}replace(e,t=!0,n=!1){let s="";this.reset();const i=typeof e=="function";let o=null;if(i){if(this.groupCount()>=$r.MAX_REPLACER_ARGS)throw new Rt("Too many capture groups to safely invoke replacer function");o=this.matcherInput.isUTF8Encoding()?this.matcherInput.asBytes():this.matcherInput.asCharSequence()}for(;this.find()&&(s+=i?this.appendReplacementFunc(e,o):this.appendReplacement(e,n),!!t););return s+=this.appendTail(),s}appendReplacementFunc(e,t){let n="";const s=this.start(),i=this.end();this.appendPos<s&&(n+=this.substring(this.appendPos,s)),this.appendPos=i;const o=this.matchArray();return o.push(s,t),this.hasNamedGroups&&o.push(this.namedGroupsObject()),n+=String(e(...o)),n}matchArray(){const e=[this.group(0)];for(let t=1;t<=this.patternGroupCount;t++){const n=this.group(t);e.push(n===null?void 0:n)}return e}namedGroupsObject(){if(!this.hasNamedGroups)return;const e=this.getNamedGroups();for(const t in e)e[t]===null&&(e[t]=void 0);return e}},G($r,"MAX_REPLACER_ARGS",65535),$r),pe,L=(pe=class{static isRuneOp(e){return pe.RUNE<=e&&e<=pe.RUNE_ANY_NOT_NL}static escapeRunes(e){let t='"';for(let n of e)t+=$.escapeRune(n);return t+='"',t}constructor(e){this.op=e,this.out=0,this.arg=0,this.runes=new Int32Array(0),this.next=null}matchRune(e){if(this.runes.length===1){const o=this.runes[0];return this.arg&M.FOLD_CASE?Z.equalsIgnoreCase(o,e):e===o}const t=this.runes.length;if(t===0)return!1;if(t===2||t===4||t===6||t===8){for(let o=0;o<t;o+=2){if(e<this.runes[o])return!1;if(e<=this.runes[o+1])return!0}return!1}let n=0,s=t>>1;for(;s>1;){const o=s>>1;n+=this.runes[n+o<<1]<=e?o:0,s-=o}n+=this.runes[n<<1]<=e?1:0;const i=n-1;return i>=0&&e<=this.runes[i<<1|1]}matchRunePos(e){if(this.runes.length===1){const o=this.runes[0];return this.arg&M.FOLD_CASE?Z.equalsIgnoreCase(o,e)?0:-1:e===o?0:-1}const t=this.runes.length;if(t===0)return-1;if(t===2||t===4||t===6||t===8){for(let o=0;o<t;o+=2){if(e<this.runes[o])return-1;if(e<=this.runes[o+1])return Math.floor(o/2)}return-1}let n=0,s=t>>1;for(;s>1;){const o=s>>1;n+=this.runes[n+o<<1]<=e?o:0,s-=o}n+=this.runes[n<<1]<=e?1:0;const i=n-1;return i>=0&&e<=this.runes[i<<1|1]?i:-1}toString(){switch(this.op){case pe.ALT:return`alt -> ${this.out}, ${this.arg}`;case pe.ALT_MATCH:return`altmatch -> ${this.out}, ${this.arg}`;case pe.CAPTURE:return`cap ${this.arg} -> ${this.out}`;case pe.EMPTY_WIDTH:return`empty ${this.arg} -> ${this.out}`;case pe.MATCH:return`match${this.arg!==0?` ${this.arg}`:""}`;case pe.FAIL:return"fail";case pe.NOP:return`nop -> ${this.out}`;case pe.LB_WRITE:return`lbwrite ${this.arg} -> ${this.out}`;case pe.LB_CHECK:return`lbcheck ${this.arg} -> ${this.out}`;case pe.RUNE:return this.runes===null?"rune <null>":["rune ",pe.escapeRunes(this.runes),this.arg&M.FOLD_CASE?"/i":""," -> ",this.out].join("");case pe.RUNE1:return`rune1 ${pe.escapeRunes(this.runes)} -> ${this.out}`;case pe.RUNE_ANY:return`any -> ${this.out}`;case pe.RUNE_ANY_NOT_NL:return`anynotnl -> ${this.out}`;default:throw new Error("unhandled case in Inst.toString")}}},G(pe,"ALT",1),G(pe,"ALT_MATCH",2),G(pe,"CAPTURE",3),G(pe,"EMPTY_WIDTH",4),G(pe,"FAIL",5),G(pe,"MATCH",6),G(pe,"NOP",7),G(pe,"RUNE",8),G(pe,"RUNE1",9),G(pe,"RUNE_ANY",10),G(pe,"RUNE_ANY_NOT_NL",11),G(pe,"LB_WRITE",12),G(pe,"LB_CHECK",13),pe),Yr,cf=(Yr=class{constructor(e){this.sparse=new Int32Array(e),this.densePcs=new Int32Array(e),this.denseCaps=null,this.size=0,this.ncap=0,this.mainThreads=0}init(e){this.ncap=e;const t=Math.min(this.densePcs.length,Yr.INITIAL_THREADS)*e;(!this.denseCaps||this.denseCaps.length<t)&&(this.denseCaps=new Int32Array(t))}growCaps(e){const t=this.densePcs.length*this.ncap,n=new Int32Array(Math.min(t,Math.max(e,2*this.denseCaps.length)));n.set(this.denseCaps),this.denseCaps=n}contains(e){const t=this.sparse[e];return t<this.size&&this.densePcs[t]===e}isEmpty(){return this.size===0}add(e){const t=this.size++;return this.sparse[e]=t,this.densePcs[t]=e,t}clear(){this.size=0,this.mainThreads=0}toString(){let e="{";for(let t=0;t<this.size;t++)t!==0&&(e+=", "),e+=this.densePcs[t];return e+="}",e}},G(Yr,"INITIAL_THREADS",32),Yr),cy=class{constructor(r){this.pos=-1,this.pcs=new Int32Array(r.numInst()),this.size=0,this.lbTable=new Int32Array(r.numLb+1)}reset(){this.pos=-1,this.size=0}},By=class ig{static fromRE2(e){const t=new ig;return t.prog=e.prog,t.re2=e,t.q0=new cf(t.prog.numInst()),t.q1=new cf(t.prog.numInst()),t.addStack=new Int32Array(2*(t.prog.numInst()+1)),t.matched=!1,t.matchcap=new Int32Array(t.prog.numCap<2?2:t.prog.numCap),t.ncap=0,t}constructor(){this.prog=null,this.re2=null,this.q0=null,this.q1=null,this.addStack=null,this.matched=!1,this.matchcap=null,this.ncap=0,this.lbTable=null}init(e){this.ncap=e,e>this.matchcap.length?this.matchcap=new Int32Array(e).fill(-1):this.matchcap.fill(-1),this.q0.init(e),this.q1.init(e),this.prog.numLb>0&&((!this.lbTable||this.lbTable.length<this.prog.numLb+1)&&(this.lbTable=new Int32Array(this.prog.numLb+1)),this.lbTable.fill(-1))}submatches(){return this.ncap===0?$.emptyInts():$.toArray(this.matchcap.subarray(0,this.ncap))}match(e,t,n,s=null){const i=this.re2.cond;if(i===$.EMPTY_ALL||(n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return!1;this.matched=!1,this.matchcap.fill(-1);const o=this.prog.numLb>0,a=t;let u=t,B=!1;o&&(s!==null&&s.pos>=0&&s.pos<=t?(u=s.pos,B=!0):u=0);let l=o&&s!==null,d=this.q0,C=this.q1,g=e.step(u),m=g>>3,v=g&7,N=-1,q=0;g!==yt.EOF()&&(g=e.step(u+v),N=g>>3,q=g&7);let J;for(u===0?J=$.emptyOpContext(-1,m):J=e.context(u),o&&(B?this.restoreLookbehinds(s,d,J):this.spawnLookbehinds(d,u,J));;){if(d.mainThreads===0){if(i&$.EMPTY_BEGIN_TEXT&&u!==0||(n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&u!==0||this.matched)break;if(this.prog.numLb===0&&d.isEmpty()&&this.re2.prefix.length!==0&&N!==this.re2.prefixRune&&e.canCheckPrefix()){const ue=e.index(this.re2,u);if(ue<0)break;u+=ue,g=e.step(u),m=g>>3,v=g&7,g=e.step(u+v),N=g>>3,q=g&7,J=e.context(u)}}u>=a&&(l&&(this.saveLookbehinds(s,d,u),l=!1),!this.matched&&(u===0||n===M.UNANCHORED)&&(this.ncap>0&&(this.matchcap[0]=u),this.add(d,this.prog.start,u,this.matchcap,0,J)));const X=u+v;if(J=e.context(X),this.step(d,C,u,X,m,J,n,u===e.endPos()),v===0||this.ncap===0&&this.matched)break;u+=v,m=N,v=q,m!==-1&&(g=e.step(u+v),N=g>>3,q=g&7);const se=d;d=C,C=se}return d.clear(),C.clear(),this.matched}matchSet(e,t,n){const s=this.re2.cond;if(s===$.EMPTY_ALL)return[];if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return[];let i=this.prog.numLb>0?0:t,o=t,a=this.q0,u=this.q1,B=e.step(i),l=B>>3,d=B&7,C=-1,g=0;B!==yt.EOF()&&(B=e.step(i+d),C=B>>3,g=B&7);let m=i===0?$.emptyOpContext(-1,l):e.context(i);const v=new Set;for(this.prog.numLb>0&&this.spawnLookbehinds(a,i,m);!(a.mainThreads===0&&(s&$.EMPTY_BEGIN_TEXT&&i!==0||(n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&i!==0));){(i===0||n===M.UNANCHORED)&&i>=o&&this.add(a,this.prog.start,i,this.matchcap,0,m);const N=i+d;m=e.context(N);for(let J=0;J<a.size;J++){const X=a.densePcs[J],se=this.prog.inst[X],ue=J*this.ncap;let ce=!1;switch(se.op){case L.MATCH:if(n===M.ANCHOR_BOTH&&i!==e.endPos())break;v.add(se.arg);break;case L.RUNE:ce=se.matchRune(l);break;case L.RUNE1:ce=l===se.runes[0];break;case L.RUNE_ANY:ce=!0;break;case L.RUNE_ANY_NOT_NL:ce=l!==10;break;default:continue}ce&&this.add(u,se.out,N,a.denseCaps,ue,m)}if(a.clear(),d===0)break;i+=d,l=C,d=g,l!==-1&&(B=e.step(i+d),C=B>>3,g=B&7);const q=a;a=u,u=q}return u.clear(),Array.from(v).sort((N,q)=>N-q)}step(e,t,n,s,i,o,a,u){const B=this.re2.longest;for(let l=0;l<e.size;l++){const d=e.densePcs[l],C=l*this.ncap;if(B&&this.matched&&this.ncap>0&&this.matchcap[0]<e.denseCaps[C])continue;const g=this.prog.inst[d];let m=!1;switch(g.op){case L.MATCH:if(a===M.ANCHOR_BOTH&&!u)break;if(this.ncap>0&&(!B||!this.matched||this.matchcap[1]<n)){e.denseCaps[C+1]=n;for(let v=0;v<this.ncap;v++)this.matchcap[v]=e.denseCaps[C+v]}B||(e.size=0),this.matched=!0;break;case L.RUNE:m=g.matchRune(i);break;case L.RUNE1:m=i===g.runes[0];break;case L.RUNE_ANY:m=!0;break;case L.RUNE_ANY_NOT_NL:m=i!==10;break;default:continue}m&&this.add(t,g.out,s,e.denseCaps,C,o)}e.clear()}spawnLookbehinds(e,t,n){for(let s=0;s<this.prog.lbStarts.length;s++)this.add(e,this.prog.lbStarts[s],t,this.matchcap,0,n)}restoreLookbehinds(e,t,n){this.lbTable.set(e.lbTable);for(let s=0;s<e.size;s++)this.add(t,e.pcs[s],e.pos,this.matchcap,0,n)}saveLookbehinds(e,t,n){let s=0;for(let i=0;i<t.size;i++){const o=t.densePcs[i];this.prog.lbInst[o]===1&&L.isRuneOp(this.prog.inst[o].op)&&(e.pcs[s++]=o)}e.size=s,e.pos=n,e.lbTable.set(this.lbTable)}add(e,t,n,s,i,o){const a=this.addStack;let u=0;for(;;){for(;t!==0&&!e.contains(t);){const l=e.add(t),d=this.prog.inst[t];switch(d.op){case L.FAIL:t=0;break;case L.ALT:case L.ALT_MATCH:a[u++]=d.arg,a[u++]=0,t=d.out;break;case L.EMPTY_WIDTH:t=d.arg&~o?0:d.out;break;case L.NOP:t=d.out;break;case L.CAPTURE:d.arg<this.ncap&&(a[u++]=-d.arg-1,a[u++]=s[i+d.arg],s[i+d.arg]=n),t=d.out;break;case L.LB_WRITE:this.lbTable[Math.abs(d.arg)]=n,t=d.out;break;case L.LB_CHECK:d.arg>0?t=this.lbTable[d.arg]===n?d.out:0:t=this.lbTable[-d.arg]!==n?d.out:0;break;case L.MATCH:case L.RUNE:case L.RUNE1:case L.RUNE_ANY:case L.RUNE_ANY_NOT_NL:if(this.prog.lbInst[t]===0&&e.mainThreads++,this.ncap>0){const C=l*this.ncap;C+this.ncap>e.denseCaps.length&&e.growCaps(C+this.ncap);for(let g=0;g<this.ncap;g++)e.denseCaps[C+g]=s[i+g]}t=0;break;default:throw new pu("unhandled")}}if(u===0)return;u-=2;const B=a[u];B<0?(s[i-B-1]=a[u+1],t=0):t=B}}};const ly=(r,e,t)=>{let n=-2128831035;for(let s=0;s<r.length;s++)n^=r[s],n=Math.imul(n,16777619);n^=e,n=Math.imul(n,16777619);for(let s=0;s<t.length;s++)n^=t[s],n=Math.imul(n,16777619);return n},Bf=(r,e)=>{if(r.length!==e.length)return!1;for(let t=0;t<r.length;t++)if(r[t]!==e[t])return!1;return!0},lf=(r,e,t,n)=>r.flag===t&&Bf(r.nfaStates,e)&&Bf(r.matchIDs,n),uB=[],Mi=-1;var La=class{constructor(r,e,t){this.nfaStates=r,this.flag=e,this.isMatch=(e&og.FLAG_MATCH)!==0,this.matchIDs=t,this.next=null,this.nextAnchored=null}},Ee,og=(Ee=class{constructor(e,t=8388608){this.prog=e,this.maxMem=t,this.stateCache=new Map,this.stateCount=0,this.startStates=new Map,this.failed=!1;for(let n=0;n<e.numInst();n++){const s=e.getInst(n).op;if(s===L.LB_WRITE||s===L.LB_CHECK){this.failed=!0;break}}this.computeRuneClasses(),this.stateBudget=t,this.memBudget=t}computeRuneClasses(){const e=new Set,t=(s,i)=>{e.add(s),e.add(i+1)};for(let s=0;s<this.prog.numInst();s++){const i=this.prog.getInst(s);switch(i.op){case L.RUNE:case L.RUNE1:if(i.runes.length===1){if(t(i.runes[0],i.runes[0]),i.arg&M.FOLD_CASE)for(let o=Z.simpleFold(i.runes[0]);o!==i.runes[0];o=Z.simpleFold(o))t(o,o)}else for(let o=0;o<i.runes.length;o+=2)t(i.runes[o],i.runes[o+1]);break;case L.RUNE_ANY_NOT_NL:t(10,10);break;case L.EMPTY_WIDTH:i.arg&($.EMPTY_BEGIN_LINE|$.EMPTY_END_LINE)&&t(10,10),i.arg&($.EMPTY_WORD_BOUNDARY|$.EMPTY_NO_WORD_BOUNDARY)&&(t(48,57),t(65,90),t(95,95),t(97,122))}}e.delete(0),this.classBounds=Int32Array.from(e).sort(),this.numClasses=this.classBounds.length+1;const n=new Int32Array(Z.MAX_LATIN1+1);for(let s=0;s<=Z.MAX_LATIN1;s++)n[s]=this.searchClass(s);this.latin1Class=n}runeClass(e){return e<=Z.MAX_LATIN1?this.latin1Class[e]:this.searchClass(e)}searchClass(e){const t=this.classBounds;let n=0,s=t.length;for(;n<s;){const i=n+s>>1;t[i]<=e?n=i+1:s=i}return n}closure(e,t){const n=new Set,s=Array.from(e);let i=0;for(;s.length>0;){const o=s.pop();if(o===0||n.has(o))continue;n.add(o);const a=this.prog.getInst(o);switch(a.op){case L.ALT:case L.ALT_MATCH:s.push(a.out),s.push(a.arg);break;case L.NOP:case L.CAPTURE:s.push(a.out);break;case L.EMPTY_WIDTH:i|=a.arg,a.arg&~t||s.push(a.out)}}return{pcs:Array.from(n).sort((o,a)=>o-a),needflags:i}}getState(e,t,n){const s=ly(e,t,n),i=this.stateCache.get(s);if(i instanceof La){if(lf(i,e,t,n))return i}else if(i!==void 0){for(let u=0;u<i.length;u++)if(lf(i[u],e,t,n))return i[u]}const o=Ee.stateCost(e,n);if(this.memBudget<o)return null;this.memBudget-=o;const a=new La(e,t,n);return i===void 0?this.stateCache.set(s,a):i instanceof La?this.stateCache.set(s,[i,a]):i.push(a),this.stateCount++,a}static stateCost(e,t){const n=t.length===0?0:Ee.ARRAY_OVERHEAD+Ee.ELEMENT_SIZE*t.length;return Ee.STATE_OVERHEAD+Ee.ELEMENT_SIZE*e.length+n}*cachedStates(){for(const e of this.stateCache.values())e instanceof La?yield e:yield*e}makeState(e,t,n){const s=this.closure(e,t&Ee.FLAG_EMPTY_MASK);let i=t;return s.needflags===0&&(i&=Ee.FLAG_MATCH),i|=s.needflags<<Ee.FLAG_NEED_SHIFT,this.getState(s.pcs,i,n)}allocTable(e,t){const n=this.numClasses+1,s=Ee.TABLE_OVERHEAD+Ee.ELEMENT_SIZE*n;if(this.memBudget<s)return null;this.memBudget-=s;const i=new Array(n).fill(null);return t===M.UNANCHORED?e.next=i:e.nextAnchored=i,i}clearCache(){this.stateCache.clear(),this.stateCount=0,this.startStates.clear(),this.memBudget=this.stateBudget}resetCache(e){return this.clearCache(),this.getState(e.nfaStates,e.flag,e.matchIDs)}step(e,t,n,s){let i=s===M.UNANCHORED?e.next:e.nextAnchored;if(i!==null){const J=i[t];if(J!==null)return J}else if(i=this.allocTable(e,s),i===null)return null;const o=e.flag>>>Ee.FLAG_NEED_SHIFT,a=e.flag&Ee.FLAG_EMPTY_MASK;let u=a,B=0;n===10&&(u|=$.EMPTY_END_LINE,B|=$.EMPTY_BEGIN_LINE),n===Mi&&(u|=$.EMPTY_END_LINE|$.EMPTY_END_TEXT);const l=(e.flag&Ee.FLAG_LAST_WORD)!==0,d=n!==Mi&&$.isWordRune(n);u|=d===l?$.EMPTY_NO_WORD_BOUNDARY:$.EMPTY_WORD_BOUNDARY;let C=e.nfaStates;u&~a&o&&(C=this.closure(C,u).pcs);const g=[];let m=!1,v=uB;for(let J=0;J<C.length;J++){const X=this.prog.getInst(C[J]);X.op===L.MATCH?(m||(m=!0,v=[]),v.push(X.arg)):n!==Mi&&L.isRuneOp(X.op)&&X.matchRune(n)&&g.push(X.out)}v.length>1&&v.sort((J,X)=>J-X),s===M.UNANCHORED&&n!==Mi&&g.push(this.prog.start);let N=B;m&&(N|=Ee.FLAG_MATCH),d&&(N|=Ee.FLAG_LAST_WORD);const q=this.makeState(g,N,v);return q===null?null:(i[t]=q,q)}start(e,t){const n=e.context(t);let s;if(n&$.EMPTY_BEGIN_TEXT)s=$.EMPTY_BEGIN_TEXT|$.EMPTY_BEGIN_LINE;else if(n&$.EMPTY_BEGIN_LINE)s=$.EMPTY_BEGIN_LINE;else{const o=e.step(t),a=o>=0&&$.isWordRune(o>>3);s=(n&$.EMPTY_WORD_BOUNDARY)!==0!==a?Ee.FLAG_LAST_WORD:0}let i=this.startStates.get(s);if(i===void 0){if(i=this.makeState([this.prog.start],s,uB),i===null&&(this.clearCache(),i=this.makeState([this.prog.start],s,uB),i===null))return null;this.startStates.set(s,i)}return i}stepOrReset(e,t,n,s,i,o){let a=this.step(e,t,n,s);if(a!==null)return a;if(o.resetPos>=0&&i-o.resetPos<Ee.PROGRESS_PER_STATE*this.stateCount)return null;o.resetPos=i;const u=this.resetCache(e);return u===null?null:(a=this.step(u,t,n,s),a)}run(e,t,n,s,i){const o=e.endPos(),a=this.latin1Class,u=n===M.UNANCHORED,B={resetPos:-1};let l=t;for(;l<o;){const d=e.step(l),C=d>>3,g=d&7;if(g===0)break;const m=C<=Z.MAX_LATIN1?a[C]:this.runeClass(C);let v=u&&s.next!==null?s.next[m]:null;if(v===null&&(v=this.stepOrReset(s,m,C,n,l,B),v===null))return null;if(s=v,s.isMatch&&i(s,!1))return!0;if(!u&&s.nfaStates.length===0)return!1;l+=g}return s=this.stepOrReset(s,this.numClasses,Mi,n,l,B),s===null?null:s.isMatch&&i(s,!0)}match(e,t,n){if(this.failed)return null;if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return!1;const s=this.start(e,t);return s===null?null:this.run(e,t,n,s,(i,o)=>n!==M.ANCHOR_BOTH||o)}matchSet(e,t,n){if(this.failed)return null;if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return[];const s=this.start(e,t);if(s===null)return null;const i=new Set,o=(a,u)=>{if(n!==M.ANCHOR_BOTH||u)for(let B=0;B<a.matchIDs.length;B++)i.add(a.matchIDs[B]);return!1};return this.run(e,t,n,s,o)===null?null:Array.from(i).sort((a,u)=>a-u)}},G(Ee,"FLAG_EMPTY_MASK",255),G(Ee,"FLAG_MATCH",256),G(Ee,"FLAG_LAST_WORD",512),G(Ee,"FLAG_NEED_SHIFT",16),G(Ee,"STATE_OVERHEAD",150),G(Ee,"ARRAY_OVERHEAD",40),G(Ee,"ELEMENT_SIZE",8),G(Ee,"TABLE_OVERHEAD",48),G(Ee,"PROGRESS_PER_STATE",10),Ee);const hy=32,dy=500,cB=256,fy=262144;var Cy=class{constructor(){this.end=0,this.cap=new Int32Array(0),this.matchcap=new Int32Array(0),this.ncap=0,this.jobPc=new Int32Array(cB),this.jobArg=new Uint8Array(cB),this.jobPos=new Int32Array(cB),this.jobLen=0,this.visited=new Uint32Array(0)}reset(r,e,t){this.end=e,this.jobLen=0,this.ncap=t;const n=r.numInst()*(e+1)+hy-1>>>5;this.visited.length<n?this.visited=new Uint32Array(n):this.visited.fill(0,0,n),this.cap.length<t?this.cap=new Int32Array(t).fill(-1):this.cap.fill(-1,0,t),this.matchcap.length<t?this.matchcap=new Int32Array(t).fill(-1):this.matchcap.fill(-1,0,t)}shouldVisit(r,e){const t=r*(this.end+1)+e,n=t>>>5,s=1<<(t&31);return this.visited[n]&s?!1:(this.visited[n]|=s,!0)}push(r,e,t,n){if(r.prog.getInst(e).op!==L.FAIL&&(n||this.shouldVisit(e,t))){if(this.jobLen>=this.jobPc.length){const s=this.jobPc.length*2,i=new Int32Array(s);i.set(this.jobPc),this.jobPc=i;const o=new Uint8Array(s);o.set(this.jobArg),this.jobArg=o;const a=new Int32Array(s);a.set(this.jobPos),this.jobPos=a}this.jobPc[this.jobLen]=e,this.jobArg[this.jobLen]=n?1:0,this.jobPos[this.jobLen]=t,this.jobLen++}}tryBacktrack(r,e,t,n,s){const i=r.longest;for(this.push(r,t,n,!1);this.jobLen>0;){this.jobLen--;let o=this.jobPc[this.jobLen],a=this.jobArg[this.jobLen]===1,u=this.jobPos[this.jobLen],B=!0;for(;!(!B&&!this.shouldVisit(o,u));){B=!1;const l=r.prog.getInst(o);switch(l.op){case L.FAIL:break;case L.ALT:if(a){a=!1,o=l.arg;continue}else{this.push(r,o,u,!0),o=l.out;continue}case L.ALT_MATCH:{const d=r.prog.getInst(l.out);if(L.isRuneOp(d.op)){this.push(r,l.arg,u,!1),o=l.arg,u=this.end;continue}this.push(r,l.out,this.end,!1),o=l.out;continue}case L.RUNE:{const d=e.step(u);if(d===yt.EOF()||!l.matchRune(d>>3))break;u+=d&7,o=l.out;continue}case L.RUNE1:{const d=e.step(u);if(d===yt.EOF()||d>>3!==l.runes[0])break;u+=d&7,o=l.out;continue}case L.RUNE_ANY_NOT_NL:{const d=e.step(u);if(d===yt.EOF()||d>>3===10)break;u+=d&7,o=l.out;continue}case L.RUNE_ANY:{const d=e.step(u);if(d===yt.EOF())break;u+=d&7,o=l.out;continue}case L.CAPTURE:if(a){this.cap[l.arg]=u;break}else{l.arg<this.ncap&&(this.push(r,o,this.cap[l.arg],!0),this.cap[l.arg]=u),o=l.out;continue}case L.EMPTY_WIDTH:{const d=e.context(u);if(l.arg&~d)break;o=l.out;continue}case L.NOP:o=l.out;continue;case L.MATCH:{if(s===M.ANCHOR_BOTH&&u!==this.end)break;if(this.ncap===0)return!0;this.ncap>1&&(this.cap[1]=u);const d=this.matchcap[1];if((d===-1||i&&u>0&&u>d)&&this.matchcap.set(this.cap),!i||u===this.end)return!0;break}case L.LB_WRITE:case L.LB_CHECK:throw new pu("Backtracker cannot evaluate Lookbehind instructions");default:throw new pu("bad inst")}break}}return i&&this.matchcap.length>1&&this.matchcap[1]>=0}};const ka=[];var xa=class ag{static shouldBacktrack(e){return e.numInst()<=dy}static maxBitStateLen(e){return ag.shouldBacktrack(e)?Math.floor(fy/e.numInst()):0}static execute(e,t,n,s,i){const o=e.cond;if(o===$.EMPTY_ALL||(s===M.ANCHOR_START||s===M.ANCHOR_BOTH)&&n!==0||o&$.EMPTY_BEGIN_TEXT&&n!==0)return null;const a=ka.length>0?ka.pop():new Cy,u=t.endPos();a.reset(e.prog,u,i);let B=!1;if(o&$.EMPTY_BEGIN_TEXT||s===M.ANCHOR_START||s===M.ANCHOR_BOTH)a.ncap>0&&(a.cap[0]=n),a.tryBacktrack(e,t,e.prog.start,n,s)&&(B=!0);else{let d=-1;for(;n<=u&&d!==0;n+=d){if(e.prefix.length>0){const g=t.index(e,n);if(g<0)break;n+=g}if(a.ncap>0&&(a.cap[0]=n),a.tryBacktrack(e,t,e.prog.start,n,s)){B=!0;break}const C=t.step(n);d=C===yt.EOF()?0:C&7}}if(!B)return ka.push(a),null;const l=i===0?[]:$.toArray(a.matchcap.subarray(0,i));return ka.push(a),l}},hf=class{constructor(r){this.sparse=new Uint32Array(r),this.dense=new Uint32Array(r),this.size=0,this.nextIndex=0}empty(){return this.nextIndex>=this.size}next(){return this.dense[this.nextIndex++]}clear(){this.size=0,this.nextIndex=0}contains(r){return r<this.sparse.length&&this.sparse[r]<this.size&&this.dense[this.sparse[r]]===r}insert(r){this.contains(r)||this.insertNew(r)}insertNew(r){r>=this.sparse.length||(this.sparse[r]=this.size,this.dense[this.size]=r,this.size++)}};const py=(r,e,t,n)=>{const s=r.length,i=e.length;let o=0,a=0;const u=[],B=[];let l=!0,d=-1;const C=g=>{const m=g?r:e,v=g?o:a,N=g?t:n;return d>0&&m[v]<=u[d]?!1:(u.push(m[v],m[v+1]),g?o+=2:a+=2,d+=2,B.push(N),!0)};for(;o<s||a<i;)if(a>=i?l=C(!0):o>=s||e[a]<r[o]?l=C(!1):l=C(!0),!l)return null;return{merged:u,next:B}};var gy=class{constructor(r){this.start=r.start,this.numCap=r.numCap,this.inst=new Array(r.inst.length);for(let e=0;e<r.inst.length;e++){const t=r.inst[e],n=new L(t.op);n.out=t.out,n.arg=t.arg,n.runes=t.runes?new Int32Array(t.runes):new Int32Array(0),n.next=null,this.inst[e]=n}}};const my=r=>{const e=new gy(r);for(let t=0;t<e.inst.length;t++){const n=e.inst[t];if(n.op!==L.ALT&&n.op!==L.ALT_MATCH)continue;let s="out",i="arg",o=e.inst[n[i]];if(o.op!==L.ALT&&o.op!==L.ALT_MATCH&&(s="arg",i="out",o=e.inst[n[i]],o.op!==L.ALT&&o.op!==L.ALT_MATCH))continue;const a=e.inst[n[s]];if(a.op===L.ALT||a.op===L.ALT_MATCH)continue;let u="out",B="arg",l=!1;o.out===t?l=!0:o.arg===t&&(l=!0,u="arg",B="out"),l&&(o[u]=n[s]),n[s]===o[u]&&(n[i]=o[B])}return e},_y=r=>{if(r.inst.length>=1e3)return null;const e=new hf(r.inst.length),t=new hf(r.inst.length),n=new Array(r.inst.length),s=new Array(r.inst.length).fill(!1),i=o=>{let a=!0;const u=r.inst[o];if(t.contains(o))return!0;switch(t.insert(o),u.op){case L.ALT:case L.ALT_MATCH:{a=i(u.out)&&i(u.arg);let B=s[u.out],l=s[u.arg];if(B&&l)return!1;if(l){const m=u.out;u.out=u.arg,u.arg=m;const v=B;B=l,l=v}B&&(s[o]=!0,u.op=L.ALT_MATCH);const d=n[u.out]||[],C=n[u.arg]||[],g=py(d,C,u.out,u.arg);if(!g)return!1;n[o]=new Int32Array(g.merged),u.next=new Uint32Array(g.next);break}case L.CAPTURE:case L.EMPTY_WIDTH:case L.NOP:a=i(u.out),s[o]=s[u.out],n[o]=n[u.out]?new Int32Array(n[u.out]):new Int32Array(0),u.next=new Uint32Array(Math.floor(n[o].length/2)+1).fill(u.out);break;case L.MATCH:case L.FAIL:s[o]=u.op===L.MATCH;break;case L.RUNE:{if(s[o]=!1,u.next&&u.next.length>0)break;if(e.insert(u.out),!u.runes||u.runes.length===0){n[o]=new Int32Array(0),u.next=new Uint32Array([u.out]);break}let B=[];if(u.runes.length===1&&u.arg&M.FOLD_CASE){const l=u.runes[0];B.push(l,l);for(let d=Z.simpleFold(l);d!==l;d=Z.simpleFold(d))B.push(d,d);B.sort((d,C)=>d-C)}else for(let l=0;l<u.runes.length;l++)B.push(u.runes[l]);n[o]=new Int32Array(B),u.next=new Uint32Array(Math.floor(B.length/2)+1).fill(u.out),u.op=L.RUNE;break}case L.RUNE1:{if(s[o]=!1,u.next&&u.next.length>0)break;e.insert(u.out);let B=[];if(u.arg&M.FOLD_CASE){const l=u.runes[0];B.push(l,l);for(let d=Z.simpleFold(l);d!==l;d=Z.simpleFold(d))B.push(d,d);B.sort((d,C)=>d-C)}else B.push(u.runes[0],u.runes[0]);n[o]=new Int32Array(B),u.next=new Uint32Array(Math.floor(B.length/2)+1).fill(u.out),u.op=L.RUNE;break}case L.RUNE_ANY:if(s[o]=!1,u.next&&u.next.length>0)break;e.insert(u.out),n[o]=new Int32Array([0,Z.MAX_RUNE]),u.next=new Uint32Array([u.out]);break;case L.RUNE_ANY_NOT_NL:if(s[o]=!1,u.next&&u.next.length>0)break;e.insert(u.out),n[o]=new Int32Array([0,9,11,Z.MAX_RUNE]),u.next=new Uint32Array(Math.floor(n[o].length/2)+1).fill(u.out)}return a};for(e.clear(),e.insert(r.start);!e.empty();)if(t.clear(),!i(e.next()))return null;for(let o=0;o<r.inst.length;o++)n[o]&&(r.inst[o].runes=n[o]);return r},Ey=(r,e)=>{for(let t=0;t<e.inst.length;t++){const n=e.inst[t];switch(n.op){case L.ALT:case L.ALT_MATCH:case L.RUNE:break;case L.CAPTURE:case L.EMPTY_WIDTH:case L.NOP:case L.MATCH:case L.FAIL:r.inst[t].next=null;break;case L.RUNE1:case L.RUNE_ANY:case L.RUNE_ANY_NOT_NL:r.inst[t].next=null,r.inst[t].op=n.op,r.inst[t].runes=n.runes?new Int32Array(n.runes):new Int32Array(0)}}};var df=class ug{static compile(e){if(e.start===0||e.numLb>0)return null;const t=e.inst[e.start];if(t.op!==L.EMPTY_WIDTH||!(t.arg&$.EMPTY_BEGIN_TEXT))return null;let n=!1;for(let i=0;i<e.inst.length;i++)if(e.inst[i].op===L.ALT||e.inst[i].op===L.ALT_MATCH){n=!0;break}for(let i=0;i<e.inst.length;i++){const o=e.inst[i],a=e.inst[o.out].op;switch(o.op){case L.ALT:case L.ALT_MATCH:if(a===L.MATCH||e.inst[o.arg].op===L.MATCH)return null;break;case L.EMPTY_WIDTH:if(a===L.MATCH){if((o.arg&$.EMPTY_END_TEXT)===$.EMPTY_END_TEXT)continue;return null}break;default:if(a===L.MATCH&&n)return null}}let s=my(e);return s=_y(s),s!==null&&Ey(s,e),s}static next(e,t){const n=e.matchRunePos(t);return n>=0?e.next[n]:e.op===L.ALT_MATCH?e.out:0}static execute(e,t,n,s,i){const o=e.onepass;if(!o)return null;const a=new Int32Array(i).fill(-1);let u=!1,B=t.step(n),l=B>>3,d=B&7,C=yt.EOF(),g=-1,m=0;B!==yt.EOF()&&(C=t.step(n+d),C!==yt.EOF()&&(g=C>>3,m=C&7));let v=n===0?$.emptyOpContext(-1,l):t.context(n),N=o.start,q;for(;;){switch(q=o.inst[N],N=q.out,q.op){case L.MATCH:return s===M.ANCHOR_BOTH&&n!==t.endPos()?null:(u=!0,a.length>0&&(a[0]=0,a[1]=n),i===0?[]:$.toArray(a));case L.RUNE:if(!q.matchRune(l))return null;break;case L.RUNE1:if(l!==q.runes[0])return null;break;case L.RUNE_ANY:break;case L.RUNE_ANY_NOT_NL:if(l===10)return null;break;case L.ALT:case L.ALT_MATCH:N=ug.next(q,l);continue;case L.FAIL:return null;case L.NOP:continue;case L.EMPTY_WIDTH:if(q.arg&~v)return null;continue;case L.CAPTURE:q.arg<a.length&&(a[q.arg]=n);continue;default:throw new pu("bad inst")}if(d===0)break;v=$.emptyOpContext(l,g),n+=d,l=g,d=m,l!==-1&&(C=t.step(n+d),C!==yt.EOF()?(g=C>>3,m=C&7):(g=-1,m=0))}return u?i===0?[]:$.toArray(a):null}},ne,w=(ne=class{static isPseudoOp(e){return e>=ne.Op.LEFT_PAREN}static emptySubs(){return[]}static quoteIfHyphen(e){return e===V.CODES["-"]?"\\":""}static fromRegexp(e){const t=new ne(e.op);return t.flags=e.flags,t.subs=e.subs,t.runes=e.runes,t.cap=e.cap,t.min=e.min,t.max=e.max,t.name=e.name,t.namedGroups=e.namedGroups,t.lb=e.lb,t}constructor(e){this.op=e,this.flags=0,this.subs=ne.emptySubs(),this.runes=new Int32Array(0),this.min=0,this.max=0,this.cap=0,this.name=null,this.namedGroups=Object.create(null),this.lb=0}reinit(){this.flags=0,this.subs=ne.emptySubs(),this.runes=new Int32Array(0),this.cap=0,this.min=0,this.max=0,this.name=null,this.namedGroups=Object.create(null),this.lb=0}toString(){return this.appendTo()}appendTo(){let e="";switch(this.op){case ne.Op.NO_MATCH:e+="[^\\x00-\\x{10FFFF}]";break;case ne.Op.EMPTY_MATCH:e+="(?:)";break;case ne.Op.STAR:case ne.Op.PLUS:case ne.Op.QUEST:case ne.Op.REPEAT:{const t=this.subs[0];switch(t.op>ne.Op.CAPTURE||t.op===ne.Op.LITERAL&&t.runes.length>1?e+=`(?:${t.appendTo()})`:e+=t.appendTo(),this.op){case ne.Op.STAR:e+="*";break;case ne.Op.PLUS:e+="+";break;case ne.Op.QUEST:e+="?";break;case ne.Op.REPEAT:e+=`{${this.min}`,this.min!==this.max&&(e+=",",this.max>=0&&(e+=this.max)),e+="}"}this.flags&M.NON_GREEDY&&(e+="?");break}case ne.Op.CONCAT:for(let t of this.subs)t.op===ne.Op.ALTERNATE?e+=`(?:${t.appendTo()})`:e+=t.appendTo();break;case ne.Op.ALTERNATE:{let t="";for(let n of this.subs)e+=t,t="|",e+=n.appendTo();break}case ne.Op.LITERAL:this.flags&M.FOLD_CASE&&(e+="(?i:");for(let t of this.runes)e+=$.escapeRune(t);this.flags&M.FOLD_CASE&&(e+=")");break;case ne.Op.ANY_CHAR_NOT_NL:e+="(?-s:.)";break;case ne.Op.ANY_CHAR:e+="(?s:.)";break;case ne.Op.PLB:e+=`(?<=${this.subs[0].appendTo()})`;break;case ne.Op.NLB:e+=`(?<!${this.subs[0].appendTo()})`;break;case ne.Op.CAPTURE:this.name===null||this.name.length===0?e+="(":e+=`(?P<${this.name}>`,this.subs[0].op!==ne.Op.EMPTY_MATCH&&(e+=this.subs[0].appendTo()),e+=")";break;case ne.Op.BEGIN_TEXT:e+="\\A";break;case ne.Op.END_TEXT:this.flags&M.WAS_DOLLAR?e+="(?-m:$)":e+="\\z";break;case ne.Op.BEGIN_LINE:e+="^";break;case ne.Op.END_LINE:e+="$";break;case ne.Op.WORD_BOUNDARY:e+="\\b";break;case ne.Op.NO_WORD_BOUNDARY:e+="\\B";break;case ne.Op.CHAR_CLASS:if(this.runes.length%2!==0){e+="[invalid char class]";break}if(e+="[",this.runes.length===0)e+="^\\x00-\\x{10FFFF}";else if(this.runes[0]===0&&this.runes[this.runes.length-1]===Z.MAX_RUNE){e+="^";for(let t=1;t<this.runes.length-1;t+=2){const n=this.runes[t]+1,s=this.runes[t+1]-1;e+=ne.quoteIfHyphen(n),e+=$.escapeRune(n),n!==s&&(e+="-",e+=ne.quoteIfHyphen(s),e+=$.escapeRune(s))}}else for(let t=0;t<this.runes.length;t+=2){const n=this.runes[t],s=this.runes[t+1];e+=ne.quoteIfHyphen(n),e+=$.escapeRune(n),n!==s&&(e+="-",e+=ne.quoteIfHyphen(s),e+=$.escapeRune(s))}e+="]";break;default:e+=this.op}return e}maxCap(){let e=0;if(this.op===ne.Op.CAPTURE&&(e=this.cap),this.subs!==null)for(let t of this.subs){const n=t.maxCap();e<n&&(e=n)}return e}equals(e){if(!(e!==null&&e instanceof ne)||this.op!==e.op)return!1;switch(this.op){case ne.Op.END_TEXT:if((this.flags&M.WAS_DOLLAR)!==(e.flags&M.WAS_DOLLAR))return!1;break;case ne.Op.LITERAL:case ne.Op.CHAR_CLASS:if((this.flags&M.FOLD_CASE)!==(e.flags&M.FOLD_CASE))return!1;if(this.runes===null&&e.runes===null)break;if(this.runes===null||e.runes===null||this.runes.length!==e.runes.length)return!1;for(let t=0;t<this.runes.length;t++)if(this.runes[t]!==e.runes[t])return!1;break;case ne.Op.ALTERNATE:case ne.Op.CONCAT:if(this.subs.length!==e.subs.length)return!1;for(let t=0;t<this.subs.length;++t)if(!this.subs[t].equals(e.subs[t]))return!1;break;case ne.Op.STAR:case ne.Op.PLUS:case ne.Op.QUEST:if((this.flags&M.NON_GREEDY)!==(e.flags&M.NON_GREEDY)||!this.subs[0].equals(e.subs[0]))return!1;break;case ne.Op.REPEAT:if((this.flags&M.NON_GREEDY)!==(e.flags&M.NON_GREEDY)||this.min!==e.min||this.max!==e.max||!this.subs[0].equals(e.subs[0]))return!1;break;case ne.Op.CAPTURE:if(this.cap!==e.cap||(this.name===null?e.name!==null:this.name!==e.name)||!this.subs[0].equals(e.subs[0]))return!1;break;case ne.Op.PLB:case ne.Op.NLB:if(this.lb!==e.lb||!this.subs[0].equals(e.subs[0]))return!1}return!0}},G(ne,"Op",sg(["NO_MATCH","EMPTY_MATCH","LITERAL","CHAR_CLASS","ANY_CHAR_NOT_NL","ANY_CHAR","BEGIN_LINE","END_LINE","BEGIN_TEXT","END_TEXT","WORD_BOUNDARY","NO_WORD_BOUNDARY","CAPTURE","STAR","PLUS","QUEST","REPEAT","CONCAT","ALTERNATE","PLB","NLB","LEFT_PAREN","VERTICAL_BAR"])),ne),fl=class{static walk(r,e){const t=[];let n=r,s;for(;;){if(n.subs.length===0)s=e.leaf(n);else{const i=e.enter(n);if(i.result===void 0){t.push({re:n,state:i,i:0}),n=n.subs[0];continue}s=i.result}for(;;){if(t.length===0)return s;const i=t[t.length-1];if(e.child(i.re,i.state,s,i.i),i.i++,i.state.result===void 0&&i.i<i.re.subs.length){n=i.re.subs[i.i];break}t.pop(),s=i.state.result!==void 0?i.state.result:e.leave(i.re,i.state)}}}},ff=class{constructor(r,e){const t=new Map,n=[0],s=[0],i=[0],o=[0];for(const m of r){let v=0;for(let N=0;N<m.length;N++){const q=v*e+m[N];let J=t.get(q);J===void 0&&(J=n.length,t.set(q,J),n.push(v),s.push(m[N]),i.push(i[v]+1),o.push(0)),v=J}o[v]=1}const a=n.length,u=new Int32Array(a-1);for(let m=1;m<a;m++)u[m-1]=m;u.sort((m,v)=>n[m]-n[v]||s[m]-s[v]);const B=new Int32Array(a+1);for(let m=1;m<a;m++)B[n[m]+1]++;for(let m=0;m<a;m++)B[m+1]+=B[m];const l=new Int32Array(a-1);for(let m=0;m<u.length;m++)l[m]=s[u[m]];this.childStart=B,this.childUnit=l,this.childNode=u;const d=new Int32Array(a);for(let m=0;m<a;m++)d[m]=m;d.sort((m,v)=>i[m]-i[v]);const C=new Int32Array(a),g=Uint8Array.from(o);for(let m=1;m<a;m++){const v=d[m],N=n[v];if(N!==0){let q=C[N],J=this.next(q,s[v]);for(;J<0&&q!==0;)q=C[q],J=this.next(q,s[v]);C[v]=J>=0?J:0}g[v]|=g[C[v]]}this.fail=C,this.match=g}next(r,e){let t=this.childStart[r],n=this.childStart[r+1];const s=this.childUnit;for(;t<n;){const i=t+n>>1,o=s[i];if(o===e)return this.childNode[i];o<e?t=i+1:n=i}return-1}advance(r,e){for(;;){const t=this.next(r,e);if(t>=0)return t;if(r===0)return 0;r=this.fail[r]}}searchUTF16(r,e,t){let n=0;for(let s=e;s<t;s++)if(n=this.advance(n,r.charCodeAt(s)),this.match[n]===1)return!0;return!1}searchUTF8(r,e,t){let n=0;for(let s=e;s<t;s++)if(n=this.advance(n,r[s]),this.match[n]===1)return!0;return!1}},kt,he=(kt=class{constructor(e){this.type=e,this.subs=[],this.str="",this.bytes=null,this.cost=e===kt.Type.EXACT?1:0,this.allExact=!1,this.ac16=null,this.ac8=null}automaton16(){if(this.ac16===null){const e=this.subs.map(t=>{const n=new Array(t.str.length);for(let s=0;s<t.str.length;s++)n[s]=t.str.charCodeAt(s);return n});this.ac16=new ff(e,65536)}return this.ac16}automaton8(){return this.ac8===null&&(this.ac8=new ff(this.subs.map(e=>e.bytes),256)),this.ac8}eval(e,t){switch(this.type){case kt.Type.NONE:return!0;case kt.Type.EXACT:return e.hasString(this,t);case kt.Type.AND:for(let n=0;n<this.subs.length;n++)if(!this.subs[n].eval(e,t))return!1;return!0;case kt.Type.OR:if(this.allExact)return e.hasAnyString(this,t);for(let n=0;n<this.subs.length;n++)if(this.subs[n].eval(e,t))return!0;return!1;default:return!0}}},G(kt,"Type",{NONE:0,EXACT:1,AND:2,OR:3}),G(kt,"MAX_SCANS",32),G(kt,"MAX_AC_UNITS",1<<18),kt),Zt,Iy=(Zt=class{static build(e){return e?fl.walk(e,Zt.WALKER):new he(he.Type.NONE)}static leaf(e){if(e.op!==w.Op.LITERAL)return new he(he.Type.NONE);if(e.runes.length===0||e.flags&M.FOLD_CASE)return new he(he.Type.NONE);let t="";for(let s=0;s<e.runes.length;s++){if(Z.isUnsearchable(e.runes[s]))return new he(he.Type.NONE);t+=String.fromCodePoint(e.runes[s])}const n=new he(he.Type.EXACT);return n.str=t,n.bytes=$.stringToUtf8ByteArray(n.str),n}static enter(e){switch(e.op){case w.Op.CAPTURE:case w.Op.PLUS:return{sub:null};case w.Op.REPEAT:return e.min>=1?{sub:null}:{result:new he(he.Type.NONE)};case w.Op.CONCAT:return{pf:new he(he.Type.AND),subs:[]};case w.Op.ALTERNATE:return{pf:new he(he.Type.OR),subs:[]};default:return{result:new he(he.Type.NONE)}}}static child(e,t,n){if(t.subs===void 0){t.sub=n;return}if(t.pf.type===he.Type.AND){if(n.type===he.Type.NONE)return;if(n.type===he.Type.AND){for(let s=0;s<n.subs.length;s++)t.subs.push(n.subs[s]);return}t.subs.push(n);return}if(n.type===he.Type.NONE){t.result=new he(he.Type.NONE);return}if(n.type===he.Type.OR){for(let s=0;s<n.subs.length;s++)t.subs.push(n.subs[s]);return}t.subs.push(n)}static leave(e,t){if(t.subs===void 0)return t.sub;const n=t.pf,s=new Set,i=[];for(const B of t.subs){if(B.type===he.Type.EXACT){if(s.has(B.str))continue;s.add(B.str)}i.push(B)}if(n.type===he.Type.AND){const B=[];let l=0;for(const d of i)l+d.cost>he.MAX_SCANS||(B.push(d),l+=d.cost);return B.length===0?new he(he.Type.NONE):B.length===1?B[0]:(n.subs=B,n.cost=l,n)}if(i.length===0)return new he(he.Type.NONE);if(i.length===1)return i[0];n.subs=i;let o=!0,a=0,u=0;for(const B of i)B.type!==he.Type.EXACT?o=!1:u+=B.bytes.length,a+=B.cost;return o?u>he.MAX_AC_UNITS?new he(he.Type.NONE):(n.allExact=!0,n.cost=1,n):a>he.MAX_SCANS?new he(he.Type.NONE):(n.cost=a,n)}},G(Zt,"WALKER",{leaf:e=>Zt.leaf(e),enter:e=>Zt.enter(e),child:(e,t,n)=>Zt.child(e,t,n),leave:(e,t)=>Zt.leave(e,t)}),Zt),Ht=class{constructor(r=0,e=0){this.head=r,this.tail=e}},Dy=class{constructor(){this.inst=[],this.start=0,this.numCap=2,this.lbStarts=[],this.numLb=0,this.lbInst=null}getInst(r){return this.inst[r]}numInst(){return this.inst.length}addInst(r){this.inst.push(new L(r))}markLookbehindInsts(){const r=new Uint8Array(this.inst.length),e=this.lbStarts.slice();for(;e.length>0;){const t=e.pop();if(t===0||r[t]===1)continue;r[t]=1;const n=this.inst[t];switch(n.op){case L.ALT:case L.ALT_MATCH:e.push(n.out,n.arg);break;case L.MATCH:case L.FAIL:break;default:e.push(n.out)}}this.lbInst=r}skipNop(r){let e=this.inst[r];for(;e.op===L.NOP||e.op===L.CAPTURE;)e=this.inst[r],r=e.out;return e}prefix(){let r="",e=this.skipNop(this.start);if(!L.isRuneOp(e.op)||e.runes.length!==1)return[e.op===L.MATCH,r];for(;L.isRuneOp(e.op)&&e.runes.length===1&&!(e.arg&M.FOLD_CASE)&&!Z.isUnsearchable(e.runes[0]);)r+=String.fromCodePoint(e.runes[0]),e=this.skipNop(e.out);return[e.op===L.MATCH,r]}startCond(){let r=0,e=this.start;e:for(;;){const t=this.inst[e];switch(t.op){case L.EMPTY_WIDTH:r|=t.arg;break;case L.FAIL:return-1;case L.CAPTURE:case L.NOP:break;default:break e}e=t.out}return r}patch(r,e){let t=r.head;for(;t!==0;){const n=this.inst[t>>1];t&1?(t=n.arg,n.arg=e):(t=n.out,n.out=e)}}append(r,e){if(r.head===0)return e;if(e.head===0)return r;const t=this.inst[r.tail>>1];return r.tail&1?t.arg=e.head:t.out=e.head,new Ht(r.head,e.tail)}toString(){let r="";for(let e=0;e<this.inst.length;e++){const t=r.length;r+=e,e===this.start&&(r+="*"),r+="        ".substring(r.length-t),r+=this.inst[e],r+=`
`}return r}};const yy=new Int32Array([0,V.CODES[`
`]-1,V.CODES[`
`]+1,Z.MAX_RUNE]),Cf=new Int32Array([0,Z.MAX_RUNE]);var Va=class{constructor(r=0,e=new Ht,t=!1){this.i=r,this.out=e,this.nullable=t}},wy=class FB{static compileRegexp(e){const t=new FB,n=t.compile(e);return t.prog.patch(n.out,t.newInst(L.MATCH).i),t.prog.start=n.i,t.prog.markLookbehindInsts(),t.prog}static compileSet(e){const t=new FB;if(e.length===0)return t.prog.start=t.newInst(L.FAIL).i,t.prog.markLookbehindInsts(),t.prog;let n=[];for(let i=0;i<e.length;i++){t.lbOffset=t.prog.numLb;const o=t.compile(e[i]),a=t.newInst(L.MATCH);t.prog.getInst(a.i).arg=i,t.prog.patch(o.out,a.i),n.push(o.i)}let s=n[0];for(let i=1;i<n.length;i++){const o=t.newInst(L.ALT),a=t.prog.getInst(o.i);a.out=s,a.arg=n[i],s=o.i}return t.prog.start=s,t.prog.markLookbehindInsts(),t.prog}constructor(){this.prog=new Dy,this.newInst(L.FAIL),this.lbOffset=0,this.runeCache=new Map,this.walker={leaf:e=>this.leaf(e),enter:e=>this.enter(e),child:(e,t,n)=>this.child(e,t,n),leave:(e,t)=>this.leave(e,t)}}newInst(e){return this.prog.addInst(e),new Va(this.prog.numInst()-1,new Ht,!0)}nop(){const e=this.newInst(L.NOP);return e.out=new Ht(e.i<<1,e.i<<1),e}fail(){return new Va}cap(e){const t=this.newInst(L.CAPTURE);return t.out=new Ht(t.i<<1,t.i<<1),this.prog.getInst(t.i).arg=e,this.prog.numCap<e+1&&(this.prog.numCap=e+1),t}cat(e,t){return e.i===0||t.i===0?(this.prog.patch(e.out,0),this.prog.patch(t.out,0),this.fail()):(this.prog.patch(e.out,t.i),new Va(e.i,t.out,e.nullable&&t.nullable))}alt(e,t){if(e.i===0)return t;if(t.i===0)return e;const n=this.newInst(L.ALT),s=this.prog.getInst(n.i);return s.out=e.i,s.arg=t.i,n.out=this.prog.append(e.out,t.out),n.nullable=e.nullable||t.nullable,n}loop(e,t){const n=this.newInst(L.ALT),s=this.prog.getInst(n.i);return t?(s.arg=e.i,n.out=new Ht(n.i<<1,n.i<<1)):(s.out=e.i,n.out=new Ht(n.i<<1|1,n.i<<1|1)),this.prog.patch(e.out,n.i),n}quest(e,t){if(e.i===0)return this.nop();const n=this.newInst(L.ALT),s=this.prog.getInst(n.i);return t?(s.arg=e.i,n.out=new Ht(n.i<<1,n.i<<1)):(s.out=e.i,n.out=new Ht(n.i<<1|1,n.i<<1|1)),n.out=this.prog.append(n.out,e.out),n}star(e,t){return e.i===0?this.nop():e.nullable?this.quest(this.plus(e,t),t):this.loop(e,t)}plus(e,t){return e.i===0?this.fail():new Va(e.i,this.loop(e,t).out,e.nullable)}empty(e){const t=this.newInst(L.EMPTY_WIDTH);return this.prog.getInst(t.i).arg=e,t.out=new Ht(t.i<<1,t.i<<1),t}rune(e,t){const n=this.newInst(L.RUNE);n.nullable=!1;const s=this.prog.getInst(n.i);return s.runes=e,t&=M.FOLD_CASE,(e.length!==1||Z.simpleFold(e[0])===e[0])&&(t&=-2),s.arg=t,n.out=new Ht(n.i<<1,n.i<<1),!(t&M.FOLD_CASE)&&e.length===1||e.length===2&&e[0]===e[1]?s.op=L.RUNE1:e.length===2&&e[0]===0&&e[1]===Z.MAX_RUNE?s.op=L.RUNE_ANY:e.length===4&&e[0]===0&&e[1]===V.CODES[`
`]-1&&e[2]===V.CODES[`
`]+1&&e[3]===Z.MAX_RUNE&&(s.op=L.RUNE_ANY_NOT_NL),n}lookBehind(e,t){const n=Math.sign(t)*(Math.abs(t)+this.lbOffset),s=this.newInst(L.LB_WRITE);this.prog.getInst(s.i).arg=n;const i=this.rune(Cf,0),o=this.star(i,!0),a=this.cat(o,e);this.prog.patch(a.out,s.i);const u=this.newInst(L.LB_CHECK);return this.prog.getInst(u.i).arg=n,this.prog.lbStarts.push(a.i),Math.abs(n)>this.prog.numLb&&(this.prog.numLb=Math.abs(n)),u.out=new Ht(u.i<<1,u.i<<1),u}compile(e){return fl.walk(e,this.walker)}leaf(e){switch(e.op){case w.Op.NO_MATCH:return this.fail();case w.Op.EMPTY_MATCH:return this.nop();case w.Op.LITERAL:{if(e.runes.length===0)return this.nop();let t=null;for(let n of e.runes){let s=this.runeCache.get(n);s===void 0&&(s=new Int32Array([n]),this.runeCache.set(n,s));const i=this.rune(s,e.flags);t=t===null?i:this.cat(t,i)}return t}case w.Op.CHAR_CLASS:return this.rune(e.runes,e.flags);case w.Op.ANY_CHAR_NOT_NL:return this.rune(yy,0);case w.Op.ANY_CHAR:return this.rune(Cf,0);case w.Op.BEGIN_LINE:return this.empty($.EMPTY_BEGIN_LINE);case w.Op.END_LINE:return this.empty($.EMPTY_END_LINE);case w.Op.BEGIN_TEXT:return this.empty($.EMPTY_BEGIN_TEXT);case w.Op.END_TEXT:return this.empty($.EMPTY_END_TEXT);case w.Op.WORD_BOUNDARY:return this.empty($.EMPTY_WORD_BOUNDARY);case w.Op.NO_WORD_BOUNDARY:return this.empty($.EMPTY_NO_WORD_BOUNDARY);case w.Op.CONCAT:case w.Op.ALTERNATE:return this.nop();default:throw new aB("regexp: unhandled case in compile")}}enter(e){switch(e.op){case w.Op.PLB:case w.Op.NLB:case w.Op.STAR:case w.Op.PLUS:case w.Op.QUEST:return{sub:null};case w.Op.CAPTURE:return{bra:this.cap(e.cap<<1),sub:null};case w.Op.CONCAT:case w.Op.ALTERNATE:return{f:null};default:throw new aB("regexp: unhandled case in compile")}}child(e,t,n){e.op===w.Op.CONCAT?t.f=t.f===null?n:this.cat(t.f,n):e.op===w.Op.ALTERNATE?t.f=t.f===null?n:this.alt(t.f,n):t.sub=n}leave(e,t){switch(e.op){case w.Op.PLB:case w.Op.NLB:return this.lookBehind(t.sub,e.lb);case w.Op.CAPTURE:{const n=this.cap(e.cap<<1|1);return this.cat(this.cat(t.bra,t.sub),n)}case w.Op.STAR:return this.star(t.sub,(e.flags&M.NON_GREEDY)!==0);case w.Op.PLUS:return this.plus(t.sub,(e.flags&M.NON_GREEDY)!==0);case w.Op.QUEST:return this.quest(t.sub,(e.flags&M.NON_GREEDY)!==0);case w.Op.CONCAT:case w.Op.ALTERNATE:return t.f;default:throw new aB("regexp: unhandled case in compile")}}},Me,Ty=(Me=class{static simplify(e){return e===null?null:fl.walk(e,Me.WALKER)}static leaf(e){if(e.op===w.Op.CHAR_CLASS){if(e.runes===null)return e;if(e.runes.length===0)return new w(w.Op.NO_MATCH);if(e.runes.length===2&&e.runes[0]===0&&e.runes[1]===Z.MAX_RUNE)return new w(w.Op.ANY_CHAR);if(e.runes.length===4&&e.runes[0]===0&&e.runes[1]===V.CODES[`
`]-1&&e.runes[2]===V.CODES[`
`]+1&&e.runes[3]===Z.MAX_RUNE)return new w(w.Op.ANY_CHAR_NOT_NL)}return e}static enter(e){switch(e.op){case w.Op.PLB:case w.Op.NLB:case w.Op.CAPTURE:case w.Op.STAR:case w.Op.PLUS:case w.Op.QUEST:return{sub:null};case w.Op.CONCAT:case w.Op.ALTERNATE:return{subs:[],changed:!1};case w.Op.REPEAT:return e.min===0&&e.max===0?{result:new w(w.Op.EMPTY_MATCH)}:{sub:null};default:return{result:e}}}static child(e,t,n,s){if(t.subs===void 0){t.sub=n;return}if(n!==e.subs[s]&&(t.changed=!0),e.op===w.Op.CONCAT){if(n.op===w.Op.NO_MATCH){t.result=new w(w.Op.NO_MATCH);return}if(n.op===w.Op.EMPTY_MATCH){t.changed=!0;return}if(n.op===w.Op.CONCAT){t.changed=!0;for(let i=0;i<n.subs.length;i++)t.subs.push(n.subs[i]);return}}else{if(n.op===w.Op.NO_MATCH){t.changed=!0;return}if(n.op===w.Op.ALTERNATE){t.changed=!0;for(let i=0;i<n.subs.length;i++)t.subs.push(n.subs[i]);return}}t.subs.push(n)}static leave(e,t){switch(e.op){case w.Op.PLB:case w.Op.NLB:case w.Op.CAPTURE:{const n=t.sub;if(n!==e.subs[0]){const s=w.fromRegexp(e);return s.runes=new Int32Array(0),s.subs=[n],s}return e}case w.Op.CONCAT:case w.Op.ALTERNATE:if(t.changed){const n=t.subs;if(n.length===0)return new w(e.op===w.Op.CONCAT?w.Op.EMPTY_MATCH:w.Op.NO_MATCH);if(n.length===1)return n[0];const s=w.fromRegexp(e);return s.runes=new Int32Array(0),s.subs=n,s}return e;case w.Op.STAR:case w.Op.PLUS:case w.Op.QUEST:return Me.simplify1(e.op,e.flags,t.sub,e);case w.Op.REPEAT:return Me.simplifyRepeat(e,t.sub);default:return e}}static simplifyRepeat(e,t){if(e.max===-1){if(e.min===0)return Me.simplify1(w.Op.STAR,e.flags,t,null);if(e.min===1)return Me.simplify1(w.Op.PLUS,e.flags,t,null);const s=[];for(let i=0;i<e.min-1;i++)s.push(t);return s.push(Me.simplify1(w.Op.PLUS,e.flags,t,null)),Me.concat(s)}if(e.min===1&&e.max===1)return t;let n=null;if(e.min>0){n=[];for(let s=0;s<e.min;s++)n.push(t)}if(e.max>e.min){let s=Me.simplify1(w.Op.QUEST,e.flags,t,null);for(let i=e.min+1;i<e.max;i++)s=Me.simplify1(w.Op.QUEST,e.flags,Me.concat([t,s]),null);if(n===null)return s;n.push(s)}return n!==null?Me.concat(n):new w(w.Op.NO_MATCH)}static concat(e){const t=[];for(let s=0;s<e.length;s++){const i=e[s];if(i.op===w.Op.NO_MATCH)return new w(w.Op.NO_MATCH);if(i.op!==w.Op.EMPTY_MATCH){if(i.op===w.Op.CONCAT){for(let o=0;o<i.subs.length;o++)t.push(i.subs[o]);continue}t.push(i)}}if(t.length===0)return new w(w.Op.EMPTY_MATCH);if(t.length===1)return t[0];const n=new w(w.Op.CONCAT);return n.subs=t,n}static simplify1(e,t,n,s){if(n.op===w.Op.EMPTY_MATCH)return n;if(n.op===w.Op.NO_MATCH)return e===w.Op.PLUS?n:new w(w.Op.EMPTY_MATCH);if(e===n.op&&(t&M.NON_GREEDY)===(n.flags&M.NON_GREEDY))return n;if(s!==null&&s.op===e&&(s.flags&M.NON_GREEDY)===(t&M.NON_GREEDY)&&n===s.subs[0])return s;const i=new w(e);return i.flags=t,i.subs=[n],i}},G(Me,"WALKER",{leaf:e=>Me.leaf(e),enter:e=>Me.enter(e),child:(e,t,n,s)=>Me.child(e,t,n,s),leave:(e,t)=>Me.leave(e,t)}),Me),me=class{constructor(r,e){this.sign=r,this.cls=e}};const pf=[48,57],gf=[9,10,12,13,32,32],mf=[48,57,65,90,95,95,97,122],_f=new Map([["\\d",new me(1,pf)],["\\D",new me(-1,pf)],["\\s",new me(1,gf)],["\\S",new me(-1,gf)],["\\w",new me(1,mf)],["\\W",new me(-1,mf)]]),Ef=[48,57,65,90,97,122],If=[65,90,97,122],Df=[0,127],yf=[9,9,32,32],wf=[0,31,127,127],Tf=[48,57],Af=[33,126],Rf=[97,122],vf=[32,126],Pf=[33,47,58,64,91,96,123,126],bf=[9,13,32,32],Sf=[65,90],Of=[48,57,65,90,95,95,97,122],Nf=[48,57,65,70,97,102],Ff=new Map([["[:alnum:]",new me(1,Ef)],["[:^alnum:]",new me(-1,Ef)],["[:alpha:]",new me(1,If)],["[:^alpha:]",new me(-1,If)],["[:ascii:]",new me(1,Df)],["[:^ascii:]",new me(-1,Df)],["[:blank:]",new me(1,yf)],["[:^blank:]",new me(-1,yf)],["[:cntrl:]",new me(1,wf)],["[:^cntrl:]",new me(-1,wf)],["[:digit:]",new me(1,Tf)],["[:^digit:]",new me(-1,Tf)],["[:graph:]",new me(1,Af)],["[:^graph:]",new me(-1,Af)],["[:lower:]",new me(1,Rf)],["[:^lower:]",new me(-1,Rf)],["[:print:]",new me(1,vf)],["[:^print:]",new me(-1,vf)],["[:punct:]",new me(1,Pf)],["[:^punct:]",new me(-1,Pf)],["[:space:]",new me(1,bf)],["[:^space:]",new me(-1,bf)],["[:upper:]",new me(1,Sf)],["[:^upper:]",new me(-1,Sf)],["[:word:]",new me(1,Of)],["[:^word:]",new me(-1,Of)],["[:xdigit:]",new me(1,Nf)],["[:^xdigit:]",new me(-1,Nf)]]);var Vr=class Ya{static charClassToString(e,t){let n="[";for(let s=0;s<t;s+=2){s>0&&(n+=" ");const i=e[s],o=e[s+1];i===o?n+=`0x${i.toString(16)}`:n+=`0x${i.toString(16)}-0x${o.toString(16)}`}return n+="]",n}static sortRanges(e,t){const n=t>>1,s=new Array(n);for(let o=0;o<n;o++)s[o]=o;s.sort((o,a)=>e[2*o]-e[2*a]||e[2*a+1]-e[2*o+1]);const i=e.slice(0,t);for(let o=0;o<n;o++)e[2*o]=i[2*s[o]],e[2*o+1]=i[2*s[o]+1]}constructor(e=$.emptyInts()){this.r=e,this.len=e.length}toArray(){return this.r instanceof Int32Array?this.len===this.r.length?this.r:this.r.subarray(0,this.len):new Int32Array(this.len===this.r.length?this.r:this.r.slice(0,this.len))}toGrowableArray(){return Array.isArray(this.r)?(this.r.length=this.len,this.r):Array.from(this.r.subarray(0,this.len))}cleanClass(){if(this.len<4)return this;Ya.sortRanges(this.r,this.len);let e=2;for(let t=2;t<this.len;t+=2){const n=this.r[t],s=this.r[t+1];if(n<=this.r[e-1]+1){s>this.r[e-1]&&(this.r[e-1]=s);continue}this.r[e]=n,this.r[e+1]=s,e+=2}return this.len=e,this}appendLiteral(e,t){return t&M.FOLD_CASE?this.appendFoldedRange(e,e):this.appendRange(e,e)}appendRange(e,t){if(this.len>0){for(let n=2;n<=4;n+=2)if(this.len>=n){const s=this.r[this.len-n],i=this.r[this.len-n+1];if(e<=i+1&&s<=t+1)return e<s&&(this.r[this.len-n]=e),t>i&&(this.r[this.len-n+1]=t),this}}return this.r[this.len++]=e,this.r[this.len++]=t,this}appendFoldedRange(e,t){if(e<=Z.MIN_FOLD&&t>=Z.MAX_FOLD)return this.appendRange(e,t);if(t<Z.MIN_FOLD||e>Z.MAX_FOLD)return this.appendRange(e,t);e<Z.MIN_FOLD&&(this.appendRange(e,Z.MIN_FOLD-1),e=Z.MIN_FOLD),t>Z.MAX_FOLD&&(this.appendRange(Z.MAX_FOLD+1,t),t=Z.MAX_FOLD);for(let n=e;n<=t;n++){this.appendRange(n,n);for(let s=Z.simpleFold(n);s!==n;s=Z.simpleFold(s))this.appendRange(s,s)}return this}appendClass(e){for(let t=0;t<e.length;t+=2)this.appendRange(e[t],e[t+1]);return this}appendFoldedClass(e){for(let t=0;t<e.length;t+=2)this.appendFoldedRange(e[t],e[t+1]);return this}appendNegatedClass(e){let t=0;for(let n=0;n<e.length;n+=2){const s=e[n],i=e[n+1];t<=s-1&&this.appendRange(t,s-1),t=i+1}return t<=Z.MAX_RUNE&&this.appendRange(t,Z.MAX_RUNE),this}appendTable(e){for(let t=0;t<e.length;++t){const n=e.getLo(t),s=e.getHi(t),i=e.getStride(t);if(i===1){this.appendRange(n,s);continue}for(let o=n;o<=s;o+=i)this.appendRange(o,o)}return this}appendNegatedTable(e){let t=0;for(let n=0;n<e.length;++n){const s=e.getLo(n),i=e.getHi(n),o=e.getStride(n);if(o===1){t<=s-1&&this.appendRange(t,s-1),t=i+1;continue}for(let a=s;a<=i;a+=o)t<=a-1&&this.appendRange(t,a-1),t=a+1}return t<=Z.MAX_RUNE&&this.appendRange(t,Z.MAX_RUNE),this}appendTableWithSign(e,t){return t<0?this.appendNegatedTable(e):this.appendTable(e)}negateClass(){let e=0,t=0;for(let n=0;n<this.len;n+=2){const s=this.r[n],i=this.r[n+1];e<=s-1&&(this.r[t]=e,this.r[t+1]=s-1,t+=2),e=i+1}return this.len=t,e<=Z.MAX_RUNE&&(this.r[this.len++]=e,this.r[this.len++]=Z.MAX_RUNE),this}appendClassWithSign(e,t){return t<0?this.appendNegatedClass(e):this.appendClass(e)}appendGroup(e,t){let n=e.cls;return t&&(n=new Ya().appendFoldedClass(n).cleanClass().toArray()),this.appendClassWithSign(n,e.sign)}toString(){return Ya.charClassToString(this.r,this.len)}},Ay=class{constructor(r){this.str=r,this.position=0}pos(){return this.position}rewindTo(r){this.position=r}more(){return this.position<this.str.length}peek(){return this.str.codePointAt(this.position)}skip(r){this.position+=r}skipString(r){this.position+=r.length}pop(){const r=this.str.codePointAt(this.position);return this.position+=$.charCount(r),r}lookingAt(r){return this.str.startsWith(r,this.position)}rest(){return this.str.substring(this.position)}from(r){return this.str.substring(r,this.position)}toString(){return this.rest()}},z,Ry=(z=class{static unicodeTable(e){return e==="Any"?{tab:z.ANY_TABLE,fold:z.ANY_TABLE,sign:1}:e==="Ascii"?{tab:z.ASCII_TABLE,fold:z.ASCII_FOLD_TABLE,sign:1}:e==="Assigned"?{tab:Nt.CATEGORIES.get("Cn"),fold:Nt.CATEGORIES.get("Cn"),sign:-1}:e==="Lc"?{tab:Nt.CATEGORIES.get("LC"),fold:Nt.FOLD_CATEGORIES.get("LC"),sign:1}:Nt.CATEGORIES.has(e)?{tab:Nt.CATEGORIES.get(e),fold:Nt.FOLD_CATEGORIES.get(e),sign:1}:Nt.SCRIPTS.has(e)?{tab:Nt.SCRIPTS.get(e),fold:Nt.FOLD_SCRIPT.get(e),sign:1}:null}static minFoldRune(e){if(e<Z.MIN_FOLD||e>Z.MAX_FOLD)return e;let t=e;const n=e;for(e=Z.simpleFold(e);e!==n;e=Z.simpleFold(e))t>e&&(t=e);return t}static leadingRegexp(e){if(e.op===w.Op.EMPTY_MATCH)return null;if(e.op===w.Op.CONCAT&&e.subs.length>0){const t=e.subs[0];return t.op===w.Op.EMPTY_MATCH?null:t}return e}static literalRegexp(e,t){const n=new w(w.Op.LITERAL);return n.flags=t,n.runes=$.stringToRunes(e),n}static parse(e,t){return new z(e,t).parseInternal()}static parseRepeat(e){const t=e.pos();if(!e.more()||!e.lookingAt("{"))return-1;e.skip(1);const n=z.parseInt(e);if(n===-1||!e.more())return-1;let s;if(!e.lookingAt(","))s=n;else{if(e.skip(1),!e.more())return-1;if(e.lookingAt("}"))s=-1;else if((s=z.parseInt(e))===-1)return-1}if(!e.more()||!e.lookingAt("}"))return-1;if(e.skip(1),n<0||n>1e3||s===-2||s>1e3||s>=0&&n>s)throw new Ae(z.ERR_INVALID_REPEAT_SIZE,e.from(t));return n<<16|s&Z.MAX_BMP}static isValidCaptureName(e){if(e.length===0)return!1;for(let t=0;t<e.length;t++){const n=e.codePointAt(t);if(n!==V.CODES._&&!$.isalnum(n))return!1}return!0}static parseInt(e){const t=e.pos();for(;e.more()&&e.peek()>=V.CODES[0]&&e.peek()<=V.CODES[9];)e.skip(1);const n=e.from(t);return n.length===0||n.length>1&&n.codePointAt(0)===V.CODES[0]?-1:n.length>8?-2:parseInt(n,10)}static isCharClass(e){return e.op===w.Op.LITERAL&&e.runes.length===1||e.op===w.Op.CHAR_CLASS||e.op===w.Op.ANY_CHAR_NOT_NL||e.op===w.Op.ANY_CHAR}static matchRune(e,t){switch(e.op){case w.Op.LITERAL:return e.runes.length===1&&e.runes[0]===t;case w.Op.CHAR_CLASS:for(let n=0;n<e.runes.length;n+=2)if(e.runes[n]<=t&&t<=e.runes[n+1])return!0;return!1;case w.Op.ANY_CHAR_NOT_NL:return t!==V.CODES[`
`];case w.Op.ANY_CHAR:return!0}return!1}static mergeCharClass(e,t){switch(e.op){case w.Op.ANY_CHAR:break;case w.Op.ANY_CHAR_NOT_NL:z.matchRune(t,V.CODES[`
`])&&(e.op=w.Op.ANY_CHAR);break;case w.Op.CHAR_CLASS:{const n=new Vr(Array.isArray(e.runes)?e.runes:Array.from(e.runes));t.op===w.Op.LITERAL?n.appendLiteral(t.runes[0],t.flags):n.appendClass(t.runes),e.runes=n.toGrowableArray();break}case w.Op.LITERAL:if(t.runes[0]===e.runes[0]&&t.flags===e.flags)break;e.op=w.Op.CHAR_CLASS,e.runes=new Vr().appendLiteral(e.runes[0],e.flags).appendLiteral(t.runes[0],t.flags).toGrowableArray()}}static parseEscape(e){const t=e.pos();if(e.skip(1),!e.more())throw new Ae(z.ERR_TRAILING_BACKSLASH);let n=e.pop();e:switch(n){case V.CODES[1]:case V.CODES[2]:case V.CODES[3]:case V.CODES[4]:case V.CODES[5]:case V.CODES[6]:case V.CODES[7]:if(!e.more()||e.peek()<V.CODES[0]||e.peek()>V.CODES[7])break;case V.CODES[0]:{let s=n-V.CODES[0];for(let i=1;i<3&&!(!e.more()||e.peek()<V.CODES[0]||e.peek()>V.CODES[7]);i++)s=s*8+e.peek()-V.CODES[0],e.skip(1);return s}case V.CODES.x:{if(!e.more())break;if(n=e.pop(),n===V.CODES["{"]){let o=0,a=0;for(;;){if(!e.more())break e;if(n=e.pop(),n===V.CODES["}"])break;const u=$.unhex(n);if(u<0||(a=a*16+u,a>Z.MAX_RUNE))break e;o++}if(o===0)break e;return a}const s=$.unhex(n);if(!e.more())break;n=e.pop();const i=$.unhex(n);if(s<0||i<0)break;return s*16+i}case V.CODES.a:return V.CODES["\x07"];case V.CODES.f:return V.CODES["\f"];case V.CODES.n:return V.CODES[`
`];case V.CODES.r:return V.CODES["\r"];case V.CODES.t:return V.CODES["	"];case V.CODES.v:return V.CODES["\v"];default:if(n<=Z.MAX_ASCII&&!$.isalnum(n))return n}throw new Ae(z.ERR_INVALID_ESCAPE,e.from(t))}static parseClassChar(e,t){if(!e.more())throw new Ae(z.ERR_MISSING_BRACKET,e.from(t));return e.lookingAt("\\")?z.parseEscape(e):e.pop()}static hasCapture(e){if(e===null)return!1;if(e.op===w.Op.CAPTURE)return!0;if(e.subs){for(let t of e.subs)if(z.hasCapture(t))return!0}return!1}constructor(e,t=0){this.wholeRegexp=e,this.flags=t,this.numCap=0,this.namedGroups=Object.create(null),this.stack=[],this.free=null,this.numRegexp=0,this.numRunes=0,this.repeats=0,this.height=null,this.size=null,this.nlb=0}newRegexp(e){let t=this.free;return t!==null&&t.subs!==null&&t.subs.length>0?(this.free=t.subs[0],t.reinit(),t.op=e):(t=new w(e),this.numRegexp+=1),t}reuse(e){this.height!==null&&this.height.has(e)&&this.height.delete(e),e.subs!==null&&e.subs.length>0&&(e.subs[0]=this.free),this.free=e}checkLimits(e){if(this.numRunes>z.MAX_RUNES)throw new Ae(z.ERR_LARGE);this.checkSize(e),this.checkHeight(e)}checkSize(e){if(this.size===null){if(this.repeats===0&&(this.repeats=1),e.op===w.Op.REPEAT){let t=e.max;t===-1&&(t=e.min),t<=0&&(t=1),t>Math.floor(z.MAX_SIZE/this.repeats)?this.repeats=z.MAX_SIZE:this.repeats*=t}if(this.numRegexp<Math.floor(z.MAX_SIZE/this.repeats))return;this.size=new Map;for(let t of this.stack)this.checkSize(t)}if(this.calcSize(e,!0)>z.MAX_SIZE)throw new Ae(z.ERR_LARGE)}calcSize(e,t=!1){if(!t&&this.size!==null&&this.size.has(e))return this.size.get(e);let n=0;switch(e.op){case w.Op.LITERAL:n=e.runes.length;break;case w.Op.PLB:case w.Op.NLB:case w.Op.CAPTURE:case w.Op.STAR:n=2+this.calcSize(e.subs[0]);break;case w.Op.PLUS:case w.Op.QUEST:n=1+this.calcSize(e.subs[0]);break;case w.Op.CONCAT:for(let s of e.subs)n=n+this.calcSize(s);break;case w.Op.ALTERNATE:for(let s of e.subs)n=n+this.calcSize(s);e.subs.length>1&&(n=n+e.subs.length-1);break;case w.Op.REPEAT:{let s=this.calcSize(e.subs[0]);if(e.max===-1){e.min===0?n=2+s:n=1+e.min*s;break}n=e.max*s+(e.max-e.min);break}}return n=Math.max(1,n),this.size===null&&(this.size=new Map),this.size.set(e,n),n}checkHeight(e){if(!(this.numRegexp<z.MAX_HEIGHT)){if(this.height===null){this.height=new Map;for(let t of this.stack)this.checkHeight(t)}if(this.calcHeight(e,!0)>z.MAX_HEIGHT)throw new Ae(z.ERR_NESTING_DEPTH)}}calcHeight(e,t=!1){if(!t&&this.height!==null&&this.height.has(e))return this.height.get(e);let n=1;for(let s of e.subs){const i=this.calcHeight(s);n<1+i&&(n=1+i)}return this.height===null&&(this.height=new Map),this.height.set(e,n),n}pop(){return this.stack.pop()}popToPseudo(){const e=this.stack.length;let t=e;for(;t>0&&!w.isPseudoOp(this.stack[t-1].op);)t--;return this.stack.splice(t,e-t)}push(e){if(this.numRunes+=e.runes.length,e.op===w.Op.CHAR_CLASS&&e.runes.length===2&&e.runes[0]===e.runes[1]){if(this.maybeConcat(e.runes[0],this.flags&-2))return null;e.op=w.Op.LITERAL,e.runes=[e.runes[0]],e.flags=this.flags&-2}else if(e.op===w.Op.CHAR_CLASS&&e.runes.length===4&&e.runes[0]===e.runes[1]&&e.runes[2]===e.runes[3]&&Z.simpleFold(e.runes[0])===e.runes[2]&&Z.simpleFold(e.runes[2])===e.runes[0]||e.op===w.Op.CHAR_CLASS&&e.runes.length===2&&e.runes[0]+1===e.runes[1]&&Z.simpleFold(e.runes[0])===e.runes[1]&&Z.simpleFold(e.runes[1])===e.runes[0]){if(this.maybeConcat(e.runes[0],this.flags|M.FOLD_CASE))return null;e.op=w.Op.LITERAL,e.runes=[e.runes[0]],e.flags=this.flags|M.FOLD_CASE}else this.maybeConcat(-1,0);return this.stack.push(e),this.checkLimits(e),e}maybeConcat(e,t){const n=this.stack.length;if(n<2)return!1;const s=this.stack[n-1],i=this.stack[n-2];if(s.op!==w.Op.LITERAL||i.op!==w.Op.LITERAL||(s.flags&M.FOLD_CASE)!==(i.flags&M.FOLD_CASE))return!1;Array.isArray(i.runes)||(i.runes=Array.from(i.runes));for(let o=0;o<s.runes.length;o++)i.runes.push(s.runes[o]);return e>=0?(s.runes=[e],s.flags=t,!0):(this.pop(),this.reuse(s),!1)}newLiteral(e,t){const n=this.newRegexp(w.Op.LITERAL);return n.flags=t,t&M.FOLD_CASE&&(e=z.minFoldRune(e)),n.runes=[e],n}literal(e){this.push(this.newLiteral(e,this.flags))}op(e){const t=this.newRegexp(e);return t.flags=this.flags,this.push(t)}repeat(e,t,n,s,i,o){let a=this.flags;if(a&M.PERL_X&&(i.more()&&i.lookingAt("?")&&(i.skip(1),a^=M.NON_GREEDY),o!==-1))throw new Ae(z.ERR_INVALID_REPEAT_OP,i.from(o));const u=this.stack.length;if(u===0)throw new Ae(z.ERR_MISSING_REPEAT_ARGUMENT,i.from(s));const B=this.stack[u-1];if(w.isPseudoOp(B.op))throw new Ae(z.ERR_MISSING_REPEAT_ARGUMENT,i.from(s));const l=this.newRegexp(e);if(l.min=t,l.max=n,l.flags=a,l.subs=[B],this.stack[u-1]=l,this.checkLimits(l),e===w.Op.REPEAT&&(t>=2||n>=2)&&!this.repeatIsValid(l,1e3))throw new Ae(z.ERR_INVALID_REPEAT_SIZE,i.from(s))}repeatIsValid(e,t){if(e.op===w.Op.REPEAT){let n=e.max;if(n===0)return!0;if(n<0&&(n=e.min),n>t)return!1;n>0&&(t=Math.trunc(t/n))}for(let n of e.subs)if(!this.repeatIsValid(n,t))return!1;return!0}concat(){this.maybeConcat(-1,0);const e=this.popToPseudo();return e.length===0?this.push(this.newRegexp(w.Op.EMPTY_MATCH)):this.push(this.collapse(e,w.Op.CONCAT))}alternate(){const e=this.popToPseudo();return e.length>0&&this.cleanAlt(e[e.length-1]),e.length===0?this.push(this.newRegexp(w.Op.NO_MATCH)):this.push(this.collapse(e,w.Op.ALTERNATE))}cleanAlt(e){e.op===w.Op.CHAR_CLASS&&(e.runes=new Vr(Array.from(e.runes)).cleanClass().toArray(),e.runes.length===2&&e.runes[0]===0&&e.runes[1]===Z.MAX_RUNE?(e.runes=new Int32Array(0),e.op=w.Op.ANY_CHAR):e.runes.length===4&&e.runes[0]===0&&e.runes[1]===V.CODES[`
`]-1&&e.runes[2]===V.CODES[`
`]+1&&e.runes[3]===Z.MAX_RUNE&&(e.runes=new Int32Array(0),e.op=w.Op.ANY_CHAR_NOT_NL))}collapse(e,t){if(e.length===1)return e[0];let n=0;for(let a of e)n+=a.op===t?a.subs.length:1;let s=new Array(n).fill(null),i=0;for(let a of e)if(a.op===t){for(let u=0;u<a.subs.length;u++)s[i++]=a.subs[u];this.reuse(a)}else s[i++]=a;let o=this.newRegexp(t);if(o.subs=s,t===w.Op.ALTERNATE&&(o.subs=this.factor(o.subs),o.subs.length===1)){const a=o;o=o.subs[0],this.reuse(a)}return o}factor(e){if(e.length<2)return e;let t=0,n=e.length,s=0,i=null,o=0,a=0,u=0;for(let l=0;l<=n;l++){let d=null,C=0,g=0;if(l<n){let m=e[t+l];if(m.op===w.Op.CONCAT&&m.subs.length>0&&(m=m.subs[0]),m.op===w.Op.LITERAL&&(d=m.runes,C=m.runes.length,g=m.flags&M.FOLD_CASE),g===a){let v=0;for(;v<o&&v<C&&i[v]===d[v];)v++;if(v>0){o=v;continue}}}if(l!==u)if(l===u+1)e[s++]=e[t+u];else{const m=this.newRegexp(w.Op.LITERAL);m.flags=a,m.runes=i.slice(0,o);for(let q=u;q<l;q++)e[t+q]=this.removeLeadingString(e[t+q],o),this.checkLimits(e[t+q]);const v=this.collapse(e.slice(t+u,t+l),w.Op.ALTERNATE),N=this.newRegexp(w.Op.CONCAT);N.subs=[m,v],e[s++]=N}u=l,i=d,o=C,a=g}n=s,t=0,u=0,s=0;let B=null;for(let l=0;l<=n;l++){let d=null;if(!(l<n&&(d=z.leadingRegexp(e[t+l]),B!==null&&B.equals(d)&&(z.isCharClass(B)||B.op===w.Op.REPEAT&&B.min===B.max&&z.isCharClass(B.subs[0]))))){if(l!==u)if(l===u+1)e[s++]=e[t+u];else{const C=B;for(let v=u;v<l;v++){const N=v!==u;e[t+v]=this.removeLeadingRegexp(e[t+v],N),this.checkLimits(e[t+v])}const g=this.collapse(e.slice(t+u,t+l),w.Op.ALTERNATE),m=this.newRegexp(w.Op.CONCAT);m.subs=[C,g],e[s++]=m}u=l,B=d}}n=s,t=0,u=0,s=0;for(let l=0;l<=n;l++)if(!(l<n&&z.isCharClass(e[t+l]))){if(l!==u)if(l===u+1)e[s++]=e[t+u];else{let d=u;for(let g=u+1;g<l;g++){const m=e[t+d],v=e[t+g];(m.op<v.op||m.op===v.op&&(m.runes!==null?m.runes.length:0)<(v.runes!==null?v.runes.length:0))&&(d=g)}const C=e[t+u];e[t+u]=e[t+d],e[t+d]=C;for(let g=u+1;g<l;g++)z.mergeCharClass(e[t+u],e[t+g]),this.reuse(e[t+g]);this.cleanAlt(e[t+u]),e[s++]=e[t+u]}l<n&&(e[s++]=e[t+l]),u=l+1}n=s,t=0,u=0,s=0;for(let l=0;l<n;++l)l+1<n&&e[t+l].op===w.Op.EMPTY_MATCH&&e[t+l+1].op===w.Op.EMPTY_MATCH||(e[s++]=e[t+l]);return n=s,t=0,e.slice(t,n)}removeLeadingString(e,t){if(e.op===w.Op.CONCAT&&e.subs.length>0){const n=this.removeLeadingString(e.subs[0],t);if(e.subs[0]=n,n.op===w.Op.EMPTY_MATCH)switch(this.reuse(n),e.subs.length){case 0:case 1:e.op=w.Op.EMPTY_MATCH,e.subs=w.emptySubs();break;case 2:{const s=e;e=e.subs[1],this.reuse(s);break}default:e.subs=e.subs.slice(1,e.subs.length)}return e}return e.op===w.Op.LITERAL&&(e.runes=e.runes.slice(t,e.runes.length),e.runes.length===0&&(e.op=w.Op.EMPTY_MATCH)),e}removeLeadingRegexp(e,t){if(e.op===w.Op.CONCAT&&e.subs.length>0){switch(t&&this.reuse(e.subs[0]),e.subs=e.subs.slice(1,e.subs.length),e.subs.length){case 0:e.op=w.Op.EMPTY_MATCH,e.subs=w.emptySubs();break;case 1:{const n=e;e=e.subs[0],this.reuse(n);break}}return e}return t&&this.reuse(e),this.newRegexp(w.Op.EMPTY_MATCH)}parseInternal(){if(this.flags&M.LITERAL)return z.literalRegexp(this.wholeRegexp,this.flags);let e=-1,t=-1,n=-1;const s=new Ay(this.wholeRegexp);for(;s.more();){let i=-1;e:switch(s.peek()){case V.CODES["("]:if(this.flags&M.LOOKBEHIND){if(s.lookingAt("(?<=")){this.parsePosLookBehind(),s.skip(4);break}if(s.lookingAt("(?<!")){this.parseNegLookBehind(),s.skip(4);break}}if(this.flags&M.PERL_X&&s.lookingAt("(?")){this.parsePerlFlags(s);break}this.op(w.Op.LEFT_PAREN).cap=++this.numCap,s.skip(1);break;case V.CODES["|"]:this.parseVerticalBar(),s.skip(1);break;case V.CODES[")"]:this.parseRightParen(),s.skip(1);break;case V.CODES["^"]:this.flags&M.ONE_LINE?this.op(w.Op.BEGIN_TEXT):this.op(w.Op.BEGIN_LINE),s.skip(1);break;case V.CODES.$:this.flags&M.ONE_LINE?this.op(w.Op.END_TEXT).flags|=M.WAS_DOLLAR:this.op(w.Op.END_LINE),s.skip(1);break;case V.CODES["."]:this.flags&M.DOT_NL?this.op(w.Op.ANY_CHAR):this.op(w.Op.ANY_CHAR_NOT_NL),s.skip(1);break;case V.CODES["["]:this.parseClass(s);break;case V.CODES["*"]:case V.CODES["+"]:case V.CODES["?"]:{i=s.pos();let o=null;switch(s.pop()){case V.CODES["*"]:o=w.Op.STAR;break;case V.CODES["+"]:o=w.Op.PLUS;break;case V.CODES["?"]:o=w.Op.QUEST}this.repeat(o,t,n,i,s,e);break}case V.CODES["{"]:{const o=s.pos(),a=z.parseRepeat(s);if(a<0){s.rewindTo(o),this.literal(s.pop());break}i=o,t=a>>16,n=(a&Z.MAX_BMP)<<16>>16,this.repeat(w.Op.REPEAT,t,n,i,s,e);break}case V.CODES["\\"]:{const o=s.pos();if(s.skip(1),this.flags&M.PERL_X&&s.more())switch(s.pop()){case V.CODES.A:this.op(w.Op.BEGIN_TEXT);break e;case V.CODES.b:this.op(w.Op.WORD_BOUNDARY);break e;case V.CODES.B:this.op(w.Op.NO_WORD_BOUNDARY);break e;case V.CODES.C:throw new Ae(z.ERR_INVALID_ESCAPE,"\\C");case V.CODES.Q:{let B=s.rest();const l=B.indexOf("\\E");l>=0?(B=B.substring(0,l),s.skipString(B),s.skipString("\\E")):s.skipString(B);let d=0;for(;d<B.length;){const C=B.codePointAt(d);this.literal(C),d+=$.charCount(C)}break e}case V.CODES.z:this.op(w.Op.END_TEXT);break e;default:s.rewindTo(o)}else s.rewindTo(o);const a=this.newRegexp(w.Op.CHAR_CLASS);if(a.flags=this.flags,s.lookingAt("\\p")||s.lookingAt("\\P")){const B=new Vr;if(this.parseUnicodeClass(s,B)){a.runes=B.toArray(),this.push(a);break e}}const u=new Vr;if(this.parsePerlClassEscape(s,u)){a.runes=u.toArray(),this.push(a);break e}s.rewindTo(o),this.reuse(a),this.literal(z.parseEscape(s));break}default:this.literal(s.pop())}e=i}if(this.concat(),this.swapVerticalBar()&&this.pop(),this.alternate(),this.stack.length!==1)throw new Ae(z.ERR_MISSING_PAREN,this.wholeRegexp);return this.stack[0].namedGroups=this.namedGroups,this.stack[0]}parsePerlFlags(e){const t=e.pos(),n=e.rest();if(n.startsWith("(?P<")||n.startsWith("(?<")){const a=n.charAt(2)==="P"?4:3,u=n.indexOf(">");if(u<0)throw new Ae(z.ERR_INVALID_NAMED_CAPTURE,n);const B=n.substring(a,u);if(e.skipString(B),e.skip(a+1),!z.isValidCaptureName(B))throw new Ae(z.ERR_INVALID_NAMED_CAPTURE,n.substring(0,u+1));const l=this.op(w.Op.LEFT_PAREN);if(l.cap=++this.numCap,this.namedGroups[B])throw new Ae(z.ERR_DUPLICATE_NAMED_CAPTURE,B);this.namedGroups[B]=this.numCap,l.name=B;return}e.skip(2);let s=this.flags,i=1,o=!1;e:for(;e.more();){const a=e.pop();switch(a){case V.CODES.i:s|=M.FOLD_CASE,o=!0;break;case V.CODES.m:s&=-17,o=!0;break;case V.CODES.s:s|=M.DOT_NL,o=!0;break;case V.CODES.U:s|=M.NON_GREEDY,o=!0;break;case V.CODES["-"]:if(i<0)break e;i=-1,s=~s,o=!1;break;case V.CODES[":"]:case V.CODES[")"]:if(i<0){if(!o)break e;s=~s}a===V.CODES[":"]&&this.op(w.Op.LEFT_PAREN),this.flags=s;return;default:break e}}throw new Ae(z.ERR_INVALID_PERL_OP,e.from(t))}parsePosLookBehind(){const e=this.newRegexp(w.Op.LEFT_PAREN);return e.flags=this.flags,e.lb=++this.nlb,this.push(e)}parseNegLookBehind(){const e=this.newRegexp(w.Op.LEFT_PAREN);return e.flags=this.flags,e.lb=-++this.nlb,this.push(e)}parseVerticalBar(){this.concat(),this.swapVerticalBar()||this.op(w.Op.VERTICAL_BAR)}swapVerticalBar(){const e=this.stack.length;if(e>=3&&this.stack[e-2].op===w.Op.VERTICAL_BAR&&z.isCharClass(this.stack[e-1])&&z.isCharClass(this.stack[e-3])){let t=this.stack[e-1],n=this.stack[e-3];if(t.op>n.op){const s=n;n=t,t=s,this.stack[e-3]=n}return z.mergeCharClass(n,t),this.reuse(t),this.pop(),!0}if(e>=2){const t=this.stack[e-1],n=this.stack[e-2];if(n.op===w.Op.VERTICAL_BAR)return e>=3&&this.cleanAlt(this.stack[e-3]),this.stack[e-2]=t,this.stack[e-1]=n,!0}return!1}parseRightParen(){if(this.concat(),this.swapVerticalBar()&&this.pop(),this.alternate(),this.stack.length<2)throw new Ae(z.ERR_UNEXPECTED_PAREN,this.wholeRegexp);const e=this.pop(),t=this.pop();if(t.op!==w.Op.LEFT_PAREN)throw new Ae(z.ERR_UNEXPECTED_PAREN,this.wholeRegexp);if(this.flags=t.flags,t.lb!==0){if(z.hasCapture(e))throw new Ae(z.ERR_INVALID_CAPTURE_IN_LOOKBEHIND,this.wholeRegexp);t.lb>0?t.op=w.Op.PLB:t.op=w.Op.NLB,t.subs=[e],this.push(t);return}t.cap===0?this.push(e):(t.op=w.Op.CAPTURE,t.subs=[e],this.push(t))}parsePerlClassEscape(e,t){const n=e.pos();if(!(this.flags&M.PERL_X)||!e.more()||e.pop()!==V.CODES["\\"]||!e.more())return!1;e.pop();const s=e.from(n),i=_f.has(s)?_f.get(s):null;return i===null?!1:(t.appendGroup(i,(this.flags&M.FOLD_CASE)!==0),!0)}parseNamedClass(e,t){const n=e.rest(),s=n.indexOf(":]");if(s<0)return!1;const i=n.substring(0,s+2);e.skipString(i);const o=Ff.has(i)?Ff.get(i):null;if(o===null)throw new Ae(z.ERR_INVALID_CHAR_RANGE,i);return t.appendGroup(o,(this.flags&M.FOLD_CASE)!==0),!0}parseUnicodeClass(e,t){const n=e.pos();if(!(this.flags&M.UNICODE_GROUPS)||!e.lookingAt("\\p")&&!e.lookingAt("\\P"))return!1;e.skip(1);let s=1,i=e.pop();if(i===V.CODES.P&&(s=-1),!e.more())throw e.rewindTo(n),new Ae(z.ERR_INVALID_CHAR_RANGE,e.rest());i=e.pop();let o;if(i!==V.CODES["{"])o=$.runeToString(i);else{const l=e.rest(),d=l.indexOf("}");if(d<0)throw e.rewindTo(n),new Ae(z.ERR_INVALID_CHAR_RANGE,e.rest());o=l.substring(0,d),e.skipString(o),e.skip(1)}o.length!==0&&o.codePointAt(0)===V.CODES["^"]&&(s=0-s,o=o.substring(1));const a=z.unicodeTable(o);if(a===null)throw new Ae(z.ERR_INVALID_CHAR_RANGE,e.from(n));a.sign<0&&(s=0-s);const u=a.tab,B=a.fold;if(!(this.flags&M.FOLD_CASE)||B===null)t.appendTableWithSign(u,s);else{const l=new Vr().appendTable(u).appendTable(B).cleanClass().toArray();t.appendClassWithSign(Array.from(l),s)}return!0}parseClass(e){const t=e.pos();e.skip(1);const n=this.newRegexp(w.Op.CHAR_CLASS);n.flags=this.flags;const s=new Vr;let i=1;e.more()&&e.lookingAt("^")&&(i=-1,e.skip(1),this.flags&M.CLASS_NL||s.appendRange(V.CODES[`
`],V.CODES[`
`]));let o=!0;for(;!e.more()||e.peek()!==V.CODES["]"]||o;){if(e.more()&&e.lookingAt("-")&&!(this.flags&M.PERL_X)&&!o){const l=e.rest();if(l==="-"||!l.startsWith("-]"))throw e.rewindTo(t),new Ae(z.ERR_INVALID_CHAR_RANGE,e.rest())}o=!1;const a=e.pos();if(e.lookingAt("[:")){if(this.parseNamedClass(e,s))continue;e.rewindTo(a)}if(this.parseUnicodeClass(e,s)||this.parsePerlClassEscape(e,s))continue;e.rewindTo(a);const u=z.parseClassChar(e,t);let B=u;if(e.more()&&e.lookingAt("-")){if(e.skip(1),e.more()&&e.lookingAt("]"))e.skip(-1);else if(B=z.parseClassChar(e,t),B<u)throw new Ae(z.ERR_INVALID_CHAR_RANGE,e.from(a))}this.flags&M.FOLD_CASE?s.appendFoldedRange(u,B):s.appendRange(u,B)}e.skip(1),s.cleanClass(),i<0&&s.negateClass(),n.runes=s.toArray(),this.push(n)}},G(z,"ERR_INTERNAL_ERROR","regexp/syntax: internal error"),G(z,"ERR_INVALID_CHAR_RANGE","invalid character class range"),G(z,"ERR_INVALID_ESCAPE","invalid escape sequence"),G(z,"ERR_INVALID_NAMED_CAPTURE","invalid named capture"),G(z,"ERR_INVALID_PERL_OP","invalid or unsupported Perl syntax"),G(z,"ERR_INVALID_REPEAT_OP","invalid nested repetition operator"),G(z,"ERR_INVALID_REPEAT_SIZE","invalid repeat count"),G(z,"ERR_MISSING_BRACKET","missing closing ]"),G(z,"ERR_MISSING_PAREN","missing closing )"),G(z,"ERR_MISSING_REPEAT_ARGUMENT","missing argument to repetition operator"),G(z,"ERR_TRAILING_BACKSLASH","trailing backslash at end of expression"),G(z,"ERR_DUPLICATE_NAMED_CAPTURE","duplicate capture group name"),G(z,"ERR_UNEXPECTED_PAREN","unexpected )"),G(z,"ERR_NESTING_DEPTH","expression nests too deeply"),G(z,"ERR_LARGE","expression too large"),G(z,"ERR_INVALID_CAPTURE_IN_LOOKBEHIND","invalid capture in lookbehind"),G(z,"MAX_HEIGHT",1e3),G(z,"MAX_SIZE",1398101),G(z,"MAX_RUNES",33554432),G(z,"ANY_TABLE",new _(new Uint32Array([0,Z.MAX_RUNE,1]))),G(z,"ASCII_TABLE",new _(new Uint32Array([0,127,1]))),G(z,"ASCII_FOLD_TABLE",new _(new Uint32Array([0,127,1,383,383,1,8490,8490,1]))),z),vy=class Gr{static initTest(e){const t=Gr.compile(e),n=new Gr(t.expr,t.prog,t.numSubexp,t.longest);return n.cond=t.cond,n.prefix=t.prefix,n.prefixUTF8=t.prefixUTF8,n.prefixComplete=t.prefixComplete,n.prefixRune=t.prefixRune,n.prefilter=t.prefilter,n.namedGroups=t.namedGroups,n}static compile(e){return Gr.compileImpl(e,M.PERL,!1)}static compilePOSIX(e){return Gr.compileImpl(e,M.POSIX,!0)}static compileImpl(e,t,n){let s=Ry.parse(e,t);const i=s.maxCap(),o=s.namedGroups;s=Ty.simplify(s);const a=Iy.build(s),u=wy.compileRegexp(s),B=new Gr(e,u,i,n);B.prefilter=a.type===he.Type.NONE?null:a;const[l,d]=u.prefix();return B.prefixComplete=l,B.prefix=d,B.prefixUTF8=$.stringToUtf8ByteArray(B.prefix),B.prefix.length>0&&(B.prefixRune=B.prefix.codePointAt(0)),B.namedGroups=o,B}static match(e,t){return Gr.compile(e).match(t)}constructor(e,t,n=0,s=0){this.expr=e,this.prog=t,this.numSubexp=n,this.longest=s,this.cond=t.startCond(),this.prefix=null,this.prefixUTF8=null,this.prefixComplete=!1,this.prefixRune=0,this.namedGroups=Object.create(null),this.machinePool=[],this.lazyDFA=null,this.onepass=df.compile(this.prog),this.prefilter=null}get dfa(){return this.lazyDFA===null&&(this.lazyDFA=new og(this.prog)),this.lazyDFA}matchPrefixComplete(e,t,n,s){if((n===M.ANCHOR_START||n===M.ANCHOR_BOTH)&&t!==0)return null;let i=-1,o=-1;const a=e.prefixLength(this);if(n===M.UNANCHORED){const u=e.index(this,t);if(u<0)return null;i=t+u,o=i+a}else if(n===M.ANCHOR_BOTH){if(e.endPos()!==a||e.index(this,0)!==0)return null;i=0,o=a}else if(n===M.ANCHOR_START){if(e.index(this,0)!==0)return null;i=0,o=a}if(i<0)return null;if(s>0){const u=new Int32Array(s).fill(-1);return u[0]=i,u[1]=o,Array.from(u)}return[]}createLookbehindState(){return this.prog.numLb>0?new cy(this.prog):null}executeEngine(e,t,n,s,i=null){if(this.prefixComplete&&(s===0||this.numSubexp===0))return this.matchPrefixComplete(e,t,n,s);if(this.prefilter!==null&&n===M.UNANCHORED&&!this.prefilter.eval(e,t))return null;if(this.onepass!==null)return df.execute(this,e,t,n,s);if(s>0)return this.prog.numLb===0&&e.endPos()<=xa.maxBitStateLen(this.prog)?xa.execute(this,e,t,n,s):this.doExecuteNFA(e,t,n,s,i);if(this.prog.numLb===0){const o=this.dfa.match(e,t,n);if(o!==null)return o?[]:null;if(e.endPos()<=xa.maxBitStateLen(this.prog))return xa.execute(this,e,t,n,s)}return this.doExecuteNFA(e,t,n,s,i)}numberOfCapturingGroups(){return this.numSubexp}numberOfInstructions(){return this.prog.numInst()}get(){return this.machinePool.length>0?this.machinePool.pop():null}reset(){this.machinePool.length=0}put(e){this.machinePool.push(e)}toString(){return this.expr}doExecuteNFA(e,t,n,s,i=null){let o=this.get();o||(o=By.fromRE2(this)),o.init(s);const a=o.match(e,t,n,i)?o.submatches():null;return this.put(o),a}match(e){return this.executeEngine(be.fromUTF16(e),0,M.UNANCHORED,0)!==null}matchWithGroup(e,t,n,s,i,o=null){return e instanceof os||($.isByteArray(e)?e=zr.utf8(e):e=zr.utf16(e)),this.matchMachineInput(e,t,n,s,i,o)}matchMachineInput(e,t,n,s,i,o=null){if(t>n)return[!1,null];const a=e.isUTF16Encoding()?be.fromUTF16(e.asCharSequence(),0,n):be.fromUTF8(e.asBytes(),0,n),u=this.executeEngine(a,t,s,2*i,o);return u===null?[!1,null]:[!0,u]}matchUTF8(e){return this.executeEngine(be.fromUTF8(e),0,M.UNANCHORED,0)!==null}replaceAll(e,t){return this.replaceAllFunc(e,()=>t,2*e.length+1)}replaceFirst(e,t){return this.replaceAllFunc(e,()=>t,1)}replaceAllFunc(e,t,n){let s=0,i=0,o="";const a=be.fromUTF16(e),u=this.createLookbehindState();let B=0;for(;i<=e.length;){const l=this.executeEngine(a,i,M.UNANCHORED,2,u);if(l===null||l.length===0)break;o+=e.substring(s,l[0]),(l[1]>s||l[0]===0)&&(o+=t(e.substring(l[0],l[1])),B++),s=l[1];const d=a.step(i)&7;if(i+d>l[1]?i+=d:i+1>l[1]?i++:i=l[1],B>=n)break}return o+=e.substring(s),o}pad(e){if(e===null)return null;let t=(1+this.numSubexp)*2;if(e.length<t){let n=new Array(t).fill(-1);for(let s=0;s<e.length;s++)n[s]=e[s];e=n}return e}allMatches(e,t,n=s=>s){let s=[];const i=e.endPos();t<0&&(t=i+1);let o=0,a=0,u=-1;const B=this.createLookbehindState();for(;a<t&&o<=i;){const l=this.executeEngine(e,o,M.UNANCHORED,this.prog.numCap,B);if(l===null||l.length===0)break;let d=!0;if(l[1]===o){l[0]===u&&(d=!1);const C=e.step(o);C<0?o=i+1:o+=C&7}else o=l[1];u=l[1],d&&(s.push(n(this.pad(l))),a++)}return s}findUTF8(e){const t=this.executeEngine(be.fromUTF8(e),0,M.UNANCHORED,2);return t===null?null:e.slice(t[0],t[1])}findUTF8Index(e){const t=this.executeEngine(be.fromUTF8(e),0,M.UNANCHORED,2);return t===null?null:t.slice(0,2)}find(e){const t=this.executeEngine(be.fromUTF16(e),0,M.UNANCHORED,2);return t===null?"":e.substring(t[0],t[1])}findIndex(e){return this.executeEngine(be.fromUTF16(e),0,M.UNANCHORED,2)}findUTF8Submatch(e){const t=this.executeEngine(be.fromUTF8(e),0,M.UNANCHORED,this.prog.numCap);if(t===null)return null;const n=new Array(1+this.numSubexp).fill(null);for(let s=0;s<n.length;s++)2*s<t.length&&t[2*s]>=0&&(n[s]=e.slice(t[2*s],t[2*s+1]));return n}findUTF8SubmatchIndex(e){return this.pad(this.executeEngine(be.fromUTF8(e),0,M.UNANCHORED,this.prog.numCap))}findSubmatch(e){const t=this.executeEngine(be.fromUTF16(e),0,M.UNANCHORED,this.prog.numCap);if(t===null)return null;const n=new Array(1+this.numSubexp).fill(null);for(let s=0;s<n.length;s++)2*s<t.length&&t[2*s]>=0&&(n[s]=e.substring(t[2*s],t[2*s+1]));return n}findSubmatchIndex(e){return this.pad(this.executeEngine(be.fromUTF16(e),0,M.UNANCHORED,this.prog.numCap))}findAllUTF8(e,t){const n=this.allMatches(be.fromUTF8(e),t,s=>e.slice(s[0],s[1]));return n.length===0?null:n}findAllUTF8Index(e,t){const n=this.allMatches(be.fromUTF8(e),t,s=>s.slice(0,2));return n.length===0?null:n}findAll(e,t){const n=this.allMatches(be.fromUTF16(e),t,s=>e.substring(s[0],s[1]));return n.length===0?null:n}findAllIndex(e,t){const n=this.allMatches(be.fromUTF16(e),t,s=>s.slice(0,2));return n.length===0?null:n}findAllUTF8Submatch(e,t){const n=this.allMatches(be.fromUTF8(e),t,s=>{let i=new Array(s.length/2|0).fill(null);for(let o=0;o<i.length;o++)s[2*o]>=0&&(i[o]=e.slice(s[2*o],s[2*o+1]));return i});return n.length===0?null:n}findAllUTF8SubmatchIndex(e,t){const n=this.allMatches(be.fromUTF8(e),t);return n.length===0?null:n}findAllSubmatch(e,t){const n=this.allMatches(be.fromUTF16(e),t,s=>{let i=new Array(s.length/2|0).fill(null);for(let o=0;o<i.length;o++)s[2*o]>=0&&(i[o]=e.substring(s[2*o],s[2*o+1]));return i});return n.length===0?null:n}findAllSubmatchIndex(e,t){const n=this.allMatches(be.fromUTF16(e),t);return n.length===0?null:n}},Py=class Ms{static isHexadecimal(e){return"0"<=e&&e<="9"||"A"<=e&&e<="F"||"a"<=e&&e<="f"}static translate(e){let t="";if(e instanceof RegExp&&(e.ignoreCase&&(t+="i"),e.multiline&&(t+="m"),e.dotAll&&(t+="s"),e=e.source),typeof e!="string")return e;let n="",s=!1,i=e.length;i===0&&(n="(?:)",s=!0);let o=!1,a=0;for(;a<i;){let B=e[a];if(B==="\\"){if(a+1<i)switch(B=e[a+1],B){case"\\":n+="\\\\",a+=2;continue;case"c":if(a+2<i){let C=e[a+2].charCodeAt(0);if(C>=65&&C<=90||C>=97&&C<=122){let g=C%32;n+="\\x",n+=(g>>4).toString(16).toUpperCase(),n+=(g&15).toString(16).toUpperCase(),a+=3,s=!0;continue}}n+="c",a+=2,s=!0;continue;case"u":if(a+2<i){if(e[a+2]==="{"){let C=a+3,g=!1,m=!1;for(;C<i;){const v=e[C];if(v==="}"){m=!0;break}if(!Ms.isHexadecimal(v))break;g=!0,C++}if(m&&g){n+="\\x",a+=2,s=!0;continue}}else if(a+5<i){let C=!0;for(let g=0;g<4;g++)if(!Ms.isHexadecimal(e[a+2+g])){C=!1;break}if(C){n+="\\x{"+e.substring(a+2,a+6)+"}",a+=6,s=!0;continue}}}n+="u",a+=2,s=!0;continue;case"x":{let C=!1;if(a+2<i&&e[a+2]==="{"){let g=a+3,m=!1,v=!1;for(;g<i;){const N=e[g];if(N==="}"){v=!0;break}if(!Ms.isHexadecimal(N))break;m=!0,g++}v&&m&&(C=!0)}else a+3<i&&Ms.isHexadecimal(e[a+2])&&Ms.isHexadecimal(e[a+3])&&(C=!0);C?(n+="\\x",a+=2):(n+="x",a+=2,s=!0);continue}case"n":case"r":case"t":case"a":case"f":case"v":case"d":case"D":case"s":case"S":case"w":case"W":case"b":case"B":case"p":case"P":case"A":case"z":case"Q":case"E":case"0":case"1":case"2":case"3":case"4":case"5":case"6":case"7":n+="\\"+B,a+=2;continue;default:{let C=e.codePointAt(a+1);if(C>=48&&C<=57||C>=65&&C<=90||C>=97&&C<=122){let g=$.charCount(C);n+=e.substring(a+1,a+1+g),a+=g+1,s=!0}else{n+="\\";let g=$.charCount(C);n+=e.substring(a+1,a+1+g),a+=g+1}continue}}}else if(B==="/"){n+="\\/",a+=1,s=!0;continue}else if(B==="["){if(!o&&e[a+1]==="]"){n+="[^\\x00-\\x{10FFFF}]",a+=2,s=!0;continue}if(!o&&e[a+1]==="^"&&e[a+2]==="]"){n+="[\\x00-\\x{10FFFF}]",a+=3,s=!0;continue}o=!0}else if(B==="]")o=!1;else if(!o&&B==="("&&a+2<i&&e[a+1]==="?"&&e[a+2]==="<"&&a+3<i&&!"=!>)".includes(e[a+3])){n+="(?P<",a+=3,s=!0;continue}let l=e.codePointAt(a),d=$.charCount(l);n+=e.substring(a,a+d),a+=d}const u=s?n:e;return t.length>0?`(?${t})${u}`:u}};const Lf=(r,e)=>{const t=r.matchArray();return t.index=r.start(0),t.input=e,t.groups=r.namedGroupsObject(),t};var qe,Cl=(qe=class{static quote(e){return $.quoteMeta(e)}static quoteReplacement(e,t=!1){return uf.quoteReplacement(e,t)}static translateRegExp(e){return Py.translate(e)}static compile(e,t=0){let n=e;if(t&qe.CASE_INSENSITIVE&&(n=`(?i)${n}`),t&qe.DOTALL&&(n=`(?s)${n}`),t&qe.MULTILINE&&(n=`(?m)${n}`),t&-544)throw new uy("Flags should only be a combination of MULTILINE, DOTALL, CASE_INSENSITIVE, DISABLE_UNICODE_GROUPS, LONGEST_MATCH, LOOKBEHINDS");let s=M.PERL;t&qe.DISABLE_UNICODE_GROUPS&&(s&=-129),t&qe.LOOKBEHINDS&&(s|=M.LOOKBEHIND);const i=new qe(e,t);return i.re2Input=vy.compileImpl(n,s,(t&qe.LONGEST_MATCH)!==0),i}static matches(e,t){return qe.compile(e).testExact(t)}static initTest(e,t,n){if(e==null)throw new Error("pattern is null");if(n==null)throw new Error("re2 is null");const s=new qe(e,t);return s.re2Input=n,s}constructor(e,t){this.patternInput=e,this.flagsInput=t,this.re2Input=null}reset(){this.re2Input.reset()}flags(){return this.flagsInput}pattern(){return this.patternInput}re2(){return this.re2Input}matches(e){return this.testExact(e)}matcher(e){return $.isByteArray(e)&&(e=zr.utf8(e)),new uf(this,e)}test(e){return $.isByteArray(e)?this.re2Input.matchUTF8(e):this.re2Input.match(e)}testExact(e){const t=$.isByteArray(e)?be.fromUTF8(e):be.fromUTF16(e);return this.re2Input.executeEngine(t,0,M.ANCHOR_BOTH,0)!==null}exec(e){const t=this.matcher(e);return t.find()?Lf(t,e):null}split(e,t=0){const n=this.matcher(e),s=[];let i=0,o=0;for(;n.find();){if(o===0&&n.end()===0){o=n.end();continue}if(t>0&&s.length===t-1)break;if(o===n.start()){if(t===0){i+=1,o=n.end();continue}}else for(;i>0;)s.push(""),i-=1;s.push(n.substring(o,n.start())),o=n.end()}if(t===0&&o!==n.inputLength()){for(;i>0;)s.push(""),i-=1;s.push(n.substring(o,n.inputLength()))}return(t!==0||s.length===0&&!(o===n.inputLength()&&o>0))&&s.push(n.substring(o,n.inputLength())),s}*matchAll(e){const t=this.matcher(e);for(;t.find();)yield Lf(t,e)}toString(){return this.patternInput}programSize(){return this.re2Input.numberOfInstructions()}groupCount(){return this.re2Input.numberOfCapturingGroups()}namedGroups(){return this.re2Input.namedGroups}equals(e){return this===e?!0:e===null||this.constructor!==e.constructor?!1:this.flagsInput===e.flagsInput&&this.patternInput===e.patternInput}},G(qe,"CASE_INSENSITIVE",bs.CASE_INSENSITIVE),G(qe,"DOTALL",bs.DOTALL),G(qe,"MULTILINE",bs.MULTILINE),G(qe,"DISABLE_UNICODE_GROUPS",bs.DISABLE_UNICODE_GROUPS),G(qe,"LONGEST_MATCH",bs.LONGEST_MATCH),G(qe,"LOOKBEHINDS",bs.LOOKBEHINDS),qe);/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class by{constructor(e,t,n){this.alias=e,this.aggregateType=t,this.fieldPath=n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Bi="12.19.0";function Sy(r){Bi=r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const as=new Bl("@firebase/firestore");function Gs(){return as.logLevel}function U(r,...e){if(as.logLevel<=fe.DEBUG){const t=e.map(pl);as.debug(`Firestore (${Bi}): ${r}`,...t)}}function Dt(r,...e){if(as.logLevel<=fe.ERROR){const t=e.map(pl);as.error(`Firestore (${Bi}): ${r}`,...t)}}function tn(r,...e){if(as.logLevel<=fe.WARN){const t=e.map(pl);as.warn(`Firestore (${Bi}): ${r}`,...t)}}function pl(r){if(typeof r=="string")return r;try{return function(t){return JSON.stringify(t)}(r)}catch{return r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ee(r,e,t){let n="Unexpected state";typeof e=="string"?n=e:t=e,cg(r,n,t)}function cg(r,e,t){let n=`FIRESTORE (${Bi}) INTERNAL ASSERTION FAILED: ${e} (ID: ${r.toString(16)})`;if(t!==void 0)try{n+=" CONTEXT: "+JSON.stringify(t)}catch{n+=" CONTEXT: "+t}throw Dt(n),new Error(n)}function j(r,e,t,n){let s="Unexpected state";typeof t=="string"?s=t:n=t,r||cg(e,s,n)}function oe(r,e){return r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Oy(r){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(r);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let n=0;n<r;n++)t[n]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gl{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let n="";for(;n.length<20;){const s=Oy(40);for(let i=0;i<s.length;++i)n.length<20&&s[i]<t&&(n+=e.charAt(s[i]%62))}return n}}function ae(r,e){return r<e?-1:r>e?1:0}function LB(r,e){const t=Math.min(r.length,e.length);for(let n=0;n<t;n++){const s=r.charAt(n),i=e.charAt(n);if(s!==i)return BB(s)===BB(i)?ae(s,i):BB(s)?1:-1}return ae(r.length,e.length)}const Ny=55296,Fy=57343;function BB(r){const e=r.charCodeAt(0);return e>=Ny&&e<=Fy}function $s(r,e,t){return r.length===e.length&&r.every((n,s)=>t(n,e[s]))}function Bg(r){return r+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oe{constructor(e,t){this.comparator=e,this.root=t||at.EMPTY}insert(e,t){return new Oe(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,at.BLACK,null,null))}remove(e){return new Oe(this.comparator,this.root.remove(e,this.comparator).copy(null,null,at.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const n=this.comparator(e,t.key);if(n===0)return t.value;n<0?t=t.left:n>0&&(t=t.right)}return null}indexOf(e){let t=0,n=this.root;for(;!n.isEmpty();){const s=this.comparator(e,n.key);if(s===0)return t+n.left.size;s<0?n=n.left:(t+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal((t,n)=>(e(t,n),!1))}toString(){const e=[];return this.inorderTraversal((t,n)=>(e.push(`${t}:${n}`),!1)),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Ma(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Ma(this.root,e,this.comparator,!1)}getReverseIterator(){return new Ma(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Ma(this.root,e,this.comparator,!0)}}class Ma{constructor(e,t,n,s){this.isReverse=s,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?n(e.key,t):1,t&&s&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class at{constructor(e,t,n,s,i){this.key=e,this.value=t,this.color=n??at.RED,this.left=s??at.EMPTY,this.right=i??at.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,n,s,i){return new at(e??this.key,t??this.value,n??this.color,s??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let s=this;const i=n(e,s.key);return s=i<0?s.copy(null,null,null,s.left.insert(e,t,n),null):i===0?s.copy(null,t,null,null,null):s.copy(null,null,null,null,s.right.insert(e,t,n)),s.fixUp()}removeMin(){if(this.left.isEmpty())return at.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let n,s=this;if(t(e,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(e,t),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),t(e,s.key)===0){if(s.right.isEmpty())return at.EMPTY;n=s.right.min(),s=s.copy(n.key,n.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(e,t))}return s.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,at.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,at.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw ee(43730,{key:this.key,value:this.value});if(this.right.isRed())throw ee(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw ee(27949);return e+(this.isRed()?0:1)}}at.EMPTY=null,at.RED=!0,at.BLACK=!1;at.EMPTY=new class{constructor(){this.size=0}get key(){throw ee(57766)}get value(){throw ee(16141)}get color(){throw ee(16727)}get left(){throw ee(29726)}get right(){throw ee(36894)}copy(e,t,n,s,i){return this}insert(e,t,n){return new at(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class De{constructor(e){this.comparator=e,this.data=new Oe(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal((t,n)=>(e(t),!1))}forEachInRange(e,t){const n=this.data.getIteratorFrom(e[0]);for(;n.hasNext();){const s=n.getNext();if(this.comparator(s.key,e[1])>=0)return;t(s.key)}}forEachWhile(e,t){let n;for(n=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();n.hasNext();)if(!e(n.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new kf(this.data.getIterator())}getIteratorFrom(e){return new kf(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach(n=>{t=t.add(n)}),t}isEqual(e){if(!(e instanceof De)||this.size!==e.size)return!1;const t=this.data.getIterator(),n=e.data.getIterator();for(;t.hasNext();){const s=t.getNext().key,i=n.getNext().key;if(this.comparator(s,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach(t=>{e.push(t)}),e}toString(){const e=[];return this.forEach(t=>e.push(t)),"SortedSet("+e.toString()+")"}copy(e){const t=new De(this.comparator);return t.data=e,t}}class kf{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function Ss(r){return r.hasNext()?r.getNext():void 0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const k={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class H extends In{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const an="__name__";class sn{constructor(e,t,n){t===void 0?t=0:t>e.length&&ee(637,{offset:t,range:e.length}),n===void 0?n=e.length-t:n>e.length-t&&ee(1746,{length:n,range:e.length-t}),this.segments=e,this.offset=t,this.len=n}get length(){return this.len}isEqual(e){return sn.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof sn?e.forEach(n=>{t.push(n)}):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,n=this.limit();t<n;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const n=Math.min(e.length,t.length);for(let s=0;s<n;s++){const i=sn.compareSegments(e.get(s),t.get(s));if(i!==0)return i}return ae(e.length,t.length)}static compareSegments(e,t){const n=sn.isNumericId(e),s=sn.isNumericId(t);return n&&!s?-1:!n&&s?1:n&&s?sn.extractNumericId(e).compare(sn.extractNumericId(t)):LB(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return hr.fromString(e.substring(4,e.length-2))}}class de extends sn{construct(e,t,n){return new de(e,t,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toStringWithLeadingSlash(){return`/${this.canonicalString()}`}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const n of e){if(n.indexOf("//")>=0)throw new H(k.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);t.push(...n.split("/").filter(s=>s.length>0))}return new de(t)}static emptyPath(){return new de([])}}const Ly=/^[_a-zA-Z][_a-zA-Z0-9]*$/;let $e=class Us extends sn{construct(e,t,n){return new Us(e,t,n)}static isValidIdentifier(e){return Ly.test(e)}canonicalString(){return this.toArray().map(e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),Us.isValidIdentifier(e)||(e="`"+e+"`"),e)).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===an}static keyField(){return new Us([an])}static fromServerFormat(e){const t=[];let n="",s=0;const i=()=>{if(n.length===0)throw new H(k.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(n),n=""};let o=!1;for(;s<e.length;){const a=e[s];if(a==="\\"){if(s+1===e.length)throw new H(k.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const u=e[s+1];if(u!=="\\"&&u!=="."&&u!=="`")throw new H(k.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);n+=u,s+=2}else a==="`"?(o=!o,s++):a!=="."||o?(n+=a,s++):(i(),s++)}if(i(),o)throw new H(k.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new Us(t)}static emptyPath(){return new Us([])}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(e){this.fields=e,e.sort($e.comparator)}static empty(){return new vt([])}unionWith(e){let t=new De($e.comparator);for(const n of this.fields)t=t.add(n);for(const n of e)t=t.add(n);return new vt(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return $s(this.fields,e.fields,(t,n)=>t.isEqual(n))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gu(r){let e=0;for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e++;return e}function Pr(r,e){for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e(t,r[t])}function lg(r,e){const t=[];for(const n in r)Object.prototype.hasOwnProperty.call(r,n)&&t.push(e(r[n],n,r));return t}function hg(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W{constructor(e){this.path=e}static fromPath(e){return new W(de.fromString(e))}static fromName(e){return new W(de.fromString(e).popFirst(5))}static empty(){return new W(de.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&de.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return de.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new W(new de(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dg(r,e,t){if(!t)throw new H(k.INVALID_ARGUMENT,`Function ${r}() cannot be called with an empty ${e}.`)}function ky(r,e,t,n){if(e===!0&&n===!0)throw new H(k.INVALID_ARGUMENT,`${r} and ${t} cannot be used together.`)}function xf(r){if(!W.isDocumentKey(r))throw new H(k.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${r} has ${r.length}.`)}function Vf(r){if(W.isDocumentKey(r))throw new H(k.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${r} has ${r.length}.`)}function Ko(r){return typeof r=="object"&&r!==null&&(Object.getPrototypeOf(r)===Object.prototype||Object.getPrototypeOf(r)===null)}function Ju(r){if(r===void 0)return"undefined";if(r===null)return"null";if(typeof r=="string")return r.length>20&&(r=`${r.substring(0,20)}...`),JSON.stringify(r);if(typeof r=="number"||typeof r=="boolean")return""+r;if(typeof r=="object"){if(r instanceof Array)return"an array";{const e=function(n){return n.constructor?n.constructor.name:null}(r);return e?`a custom ${e} object`:"an object"}}return typeof r=="function"?"a function":ee(12329,{type:typeof r})}function Ye(r,e){if("_delegate"in r&&(r=r._delegate),!(r instanceof e)){if(e.name===r.constructor.name)throw new H(k.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=Ju(r);throw new H(k.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return r}function xy(r,e){if(e<=0)throw new H(k.INVALID_ARGUMENT,`Function ${r}() requires a positive number, but it was: ${e}.`)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Je(r,e){const t={typeString:r};return e&&(t.value=e),t}function zo(r,e){if(!Ko(r))throw new H(k.INVALID_ARGUMENT,"JSON must be an object");let t;for(const n in e)if(e[n]){const s=e[n].typeString,i="value"in e[n]?{value:e[n].value}:void 0;if(!(n in r)){t=`JSON missing required field: '${n}'`;break}const o=r[n];if(s&&typeof o!==s){t=`JSON field '${n}' must be a ${s}.`;break}if(i!==void 0&&o!==i.value){t=`Expected '${n}' field to equal '${i.value}'`;break}}if(t)throw new H(k.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mf=-62135596800,Gf=1e6;class _e{static now(){return _e.fromMillis(Date.now())}static fromDate(e){return _e.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),n=Math.floor((e-1e3*t)*Gf);return new _e(t,n)}static fromInstant(e){if(!e||typeof e.t!="bigint")throw new H(k.INVALID_ARGUMENT,"Invalid Temporal.Instant object provided.");return _e._fromEpochNanoseconds(e.t)}static _fromEpochNanoseconds(e){let t,n;if(e>=0n)t=Number(e/1000000000n),n=Number(e%1000000000n);else{const s=e%1000000000n;s===0n?(t=Number(e/1000000000n),n=0):(t=Number(e/1000000000n-1n),n=Number(s+1000000000n))}return new _e(t,n)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new H(k.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new H(k.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<Mf)throw new H(k.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new H(k.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Gf}toInstant(){if(typeof Temporal>"u"||!Temporal.Instant)throw new H(k.FAILED_PRECONDITION,"The Temporal object is not available in the current environment.");const e=1000000000n*BigInt(this.seconds)+BigInt(this.nanoseconds);return Temporal.Instant.__PRIVATE_fromEpochNanoseconds(e)}_compareTo(e){return this.seconds===e.seconds?ae(this.nanoseconds,e.nanoseconds):ae(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:_e._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(zo(e,_e._jsonSchema))return new _e(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-Mf;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}_e._jsonSchemaVersion="firestore/timestamp/1.0",_e._jsonSchema={type:Je("string",_e._jsonSchemaVersion),seconds:Je("number"),nanoseconds:Je("number")};/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fg extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xe{constructor(e){this.binaryString=e}static fromBase64String(e){const t=function(s){try{return atob(s)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new fg("Invalid base64 string: "+i):i}}(e);return new xe(t)}static fromUint8Array(e){const t=function(s){let i="";for(let o=0;o<s.length;++o)i+=String.fromCharCode(s[o]);return i}(e);return new xe(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return function(t){return btoa(t)}(this.binaryString)}toUint8Array(){return function(t){const n=new Uint8Array(t.length);for(let s=0;s<t.length;s++)n[s]=t.charCodeAt(s);return n}(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return ae(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}xe.EMPTY_BYTE_STRING=new xe("");const Vy=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function On(r){if(j(!!r,39018),typeof r=="string"){let e=0;const t=Vy.exec(r);if(j(!!t,46558,{timestamp:r}),t[1]){let s=t[1];s=(s+"000000000").substr(0,9),e=Number(s)}const n=new Date(r);return{seconds:Math.floor(n.getTime()/1e3),nanos:e}}return{seconds:Re(r.seconds),nanos:Re(r.nanos)}}function Re(r){return typeof r=="number"?r:typeof r=="string"?Number(r):0}function Nn(r){return typeof r=="string"?xe.fromBase64String(r):xe.fromUint8Array(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cg="server_timestamp",pg="__type__",gg="__previous_value__",mg="__local_write_time__";function Ku(r){var t,n;return((n=(((t=r==null?void 0:r.mapValue)==null?void 0:t.fields)||{})[pg])==null?void 0:n.stringValue)===Cg}function Wo(r){const e=r.mapValue.fields[gg];return Ku(e)?Wo(e):e}function Ys(r){const e=On(r.mapValue.fields[mg].timestampValue);return new _e(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class My{constructor(e,t,n,s,i,o,a,u,B,l,d,C,g){this.databaseId=e,this.appId=t,this.persistenceKey=n,this.host=s,this.ssl=i,this.forceLongPolling=o,this.autoDetectLongPolling=a,this.longPollingOptions=u,this.useFetchStreams=B,this.isUsingEmulator=l,this.apiKey=d,this._customHeaders=C,this.grpcFlowControlWindow=g}}const Io="(default)";class us{constructor(e,t){this.projectId=e,this.database=t||Io}static empty(){return new us("","")}get isDefaultDatabase(){return this.database===Io}isEqual(e){return e instanceof us&&e.projectId===this.projectId&&e.database===this.database}}function Gy(r,e){if(!Object.prototype.hasOwnProperty.apply(r.options,["projectId"]))throw new H(k.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new us(r.options.projectId,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xr=-1;function Qo(r){return r==null}function Xs(r){return r===0&&1/r==-1/0}function Uy(r){return typeof r=="number"&&Number.isInteger(r)&&!Xs(r)&&r<=Number.MAX_SAFE_INTEGER&&r>=Number.MIN_SAFE_INTEGER}function Hy(r){return typeof r=="string"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ml="__type__",_g="__max__",ur={mapValue:{fields:{__type__:{stringValue:_g}}}},_l="__vector__",cs="value",dn={nullValue:"NULL_VALUE"},bt={booleanValue:!0},st={booleanValue:!1};function Ke(r){return"nullValue"in r?0:"booleanValue"in r?1:"integerValue"in r||"doubleValue"in r?2:"timestampValue"in r?3:"stringValue"in r?5:"bytesValue"in r?6:"referenceValue"in r?7:"geoPointValue"in r?8:"arrayValue"in r?9:"mapValue"in r?Ku(r)?4:Eg(r)?9007199254740991:Bs(r)?10:11:ee(28295,{value:r})}function Wt(r,e,t){if(r===e)return!0;const n=Ke(r);if(n!==Ke(e))return!1;switch(n){case 0:case 9007199254740991:return!0;case 1:return r.booleanValue===e.booleanValue;case 4:return Ys(r).isEqual(Ys(e));case 3:return function(i,o){if(typeof i.timestampValue=="string"&&typeof o.timestampValue=="string"&&i.timestampValue.length===o.timestampValue.length)return i.timestampValue===o.timestampValue;const a=On(i.timestampValue),u=On(o.timestampValue);return a.seconds===u.seconds&&a.nanos===u.nanos}(r,e);case 5:return r.stringValue===e.stringValue;case 6:return function(i,o){return Nn(i.bytesValue).isEqual(Nn(o.bytesValue))}(r,e);case 7:return r.referenceValue===e.referenceValue;case 8:return function(i,o){return Re(i.geoPointValue.latitude)===Re(o.geoPointValue.latitude)&&Re(i.geoPointValue.longitude)===Re(o.geoPointValue.longitude)}(r,e);case 2:return function(i,o,a){if("integerValue"in i&&"integerValue"in o)return Re(i.integerValue)===Re(o.integerValue);let u,B;if("doubleValue"in i&&"doubleValue"in o)u=Re(i.doubleValue),B=Re(o.doubleValue);else{if(!(a!=null&&a.i))return!1;u=Re(i.integerValue??i.doubleValue),B=Re(o.integerValue??o.doubleValue)}return u===B?!!(a!=null&&a.o)||Xs(u)===Xs(B):!!(a===void 0||a.u)&&isNaN(u)&&isNaN(B)}(r,e,t);case 9:return $s(r.arrayValue.values||[],e.arrayValue.values||[],(s,i)=>Wt(s,i,t));case 10:case 11:return function(i,o,a){const u=i.mapValue.fields||{},B=o.mapValue.fields||{};if(gu(u)!==gu(B))return!1;for(const l in u)if(u.hasOwnProperty(l)&&(B[l]===void 0||!Wt(u[l],B[l],a)))return!1;return!0}(r,e,t);default:return ee(52216,{left:r})}}function Do(r,e){return(r.values||[]).find(t=>Wt(t,e))!==void 0}function pt(r,e){if(r===e)return 0;const t=Ke(r),n=Ke(e);if(t!==n)return ae(t,n);switch(t){case 0:case 9007199254740991:return 0;case 1:return ae(r.booleanValue,e.booleanValue);case 2:return function(i,o){const a=Re(i.integerValue||i.doubleValue),u=Re(o.integerValue||o.doubleValue);return a<u?-1:a>u?1:a===u?0:isNaN(a)?isNaN(u)?0:-1:1}(r,e);case 3:return Uf(r.timestampValue,e.timestampValue);case 4:return Uf(Ys(r),Ys(e));case 5:return LB(r.stringValue,e.stringValue);case 6:return function(i,o){const a=Nn(i),u=Nn(o);return a.compareTo(u)}(r.bytesValue,e.bytesValue);case 7:return function(i,o){const a=i.split("/"),u=o.split("/");for(let B=0;B<a.length&&B<u.length;B++){const l=ae(a[B],u[B]);if(l!==0)return l}return ae(a.length,u.length)}(r.referenceValue,e.referenceValue);case 8:return function(i,o){const a=ae(Re(i.latitude),Re(o.latitude));return a!==0?a:ae(Re(i.longitude),Re(o.longitude))}(r.geoPointValue,e.geoPointValue);case 9:return Hf(r.arrayValue,e.arrayValue);case 10:return function(i,o){var C,g,m,v;const a=i.fields||{},u=o.fields||{},B=(C=a[cs])==null?void 0:C.arrayValue,l=(g=u[cs])==null?void 0:g.arrayValue,d=ae(((m=B==null?void 0:B.values)==null?void 0:m.length)||0,((v=l==null?void 0:l.values)==null?void 0:v.length)||0);return d!==0?d:Hf(B,l)}(r.mapValue,e.mapValue);case 11:return function(i,o){if(i===ur.mapValue&&o===ur.mapValue)return 0;if(i===ur.mapValue)return 1;if(o===ur.mapValue)return-1;const a=i.fields||{},u=Object.keys(a),B=o.fields||{},l=Object.keys(B);u.sort(),l.sort();for(let d=0;d<u.length&&d<l.length;++d){const C=LB(u[d],l[d]);if(C!==0)return C;const g=pt(a[u[d]],B[l[d]]);if(g!==0)return g}return ae(u.length,l.length)}(r.mapValue,e.mapValue);default:throw ee(23264,{l:t})}}function Uf(r,e){if(typeof r=="string"&&typeof e=="string"&&r.length===e.length)return ae(r,e);const t=On(r),n=On(e),s=ae(t.seconds,n.seconds);return s!==0?s:ae(t.nanos,n.nanos)}function Hf(r,e){const t=r.values||[],n=e.values||[];for(let s=0;s<t.length&&s<n.length;++s){const i=pt(t[s],n[s]);if(i!==void 0&&i!==0)return i}return ae(t.length,n.length)}function Zs(r){return kB(r)}function kB(r){return"nullValue"in r?"null":"booleanValue"in r?""+r.booleanValue:"integerValue"in r?""+r.integerValue:"doubleValue"in r?""+r.doubleValue:"timestampValue"in r?function(t){const n=On(t);return`time(${n.seconds},${n.nanos})`}(r.timestampValue):"stringValue"in r?r.stringValue:"bytesValue"in r?function(t){return Nn(t).toBase64()}(r.bytesValue):"referenceValue"in r?function(t){return W.fromName(t).toString()}(r.referenceValue):"geoPointValue"in r?function(t){return`geo(${t.latitude},${t.longitude})`}(r.geoPointValue):"arrayValue"in r?function(t){let n="[",s=!0;for(const i of t.values||[])s?s=!1:n+=",",n+=kB(i);return n+"]"}(r.arrayValue):"mapValue"in r?function(t){const n=Object.keys(t.fields||{}).sort();let s="{",i=!0;for(const o of n)i?i=!1:s+=",",s+=`${o}:${kB(t.fields[o])}`;return s+"}"}(r.mapValue):ee(61005,{value:r})}function Xa(r){switch(Ke(r)){case 0:case 1:return 4;case 2:return 8;case 3:case 8:return 16;case 4:const e=Wo(r);return e?16+Xa(e):16;case 5:return 2*r.stringValue.length;case 6:return Nn(r.bytesValue).approximateByteSize();case 7:return r.referenceValue.length;case 9:return function(n){return(n.values||[]).reduce((s,i)=>s+Xa(i),0)}(r.arrayValue);case 10:case 11:return function(n){let s=0;return Pr(n.fields,(i,o)=>{s+=i.length+Xa(o)}),s}(r.mapValue);default:throw ee(13486,{value:r})}}function yo(r,e){return{referenceValue:`projects/${r.projectId}/databases/${r.database}/documents/${e.path.canonicalString()}`}}function un(r){return!!r&&"integerValue"in r}function Wr(r){return!!r&&"doubleValue"in r}function Ir(r){return un(r)||Wr(r)}function Dr(r){return!!r&&"arrayValue"in r}function Vt(r){return!!r&&"nullValue"in r}function St(r){return!!r&&"doubleValue"in r&&isNaN(Number(r.doubleValue))}function Zr(r){return!!r&&"mapValue"in r}function Bs(r){var t,n;return((n=(((t=r==null?void 0:r.mapValue)==null?void 0:t.fields)||{})[ml])==null?void 0:n.stringValue)===_l}function xB(r){var e,t;return(t=(((e=r==null?void 0:r.mapValue)==null?void 0:e.fields)||{})[cs])==null?void 0:t.arrayValue}function to(r){if(r.geoPointValue)return{geoPointValue:{...r.geoPointValue}};if(r.timestampValue&&typeof r.timestampValue=="object")return{timestampValue:{...r.timestampValue}};if(r.mapValue){const e={mapValue:{fields:{}}};return Pr(r.mapValue.fields,(t,n)=>e.mapValue.fields[t]=to(n)),e}if(r.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(r.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=to(r.arrayValue.values[t]);return e}return{...r}}function Eg(r){return(((r.mapValue||{}).fields||{}).__type__||{}).stringValue===_g}const Ig={mapValue:{fields:{[ml]:{stringValue:_l},[cs]:{arrayValue:{}}}}};function qy(r){return"nullValue"in r?dn:"booleanValue"in r?{booleanValue:!1}:"integerValue"in r||"doubleValue"in r?{doubleValue:NaN}:"timestampValue"in r?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in r?{stringValue:""}:"bytesValue"in r?{bytesValue:""}:"referenceValue"in r?yo(us.empty(),W.empty()):"geoPointValue"in r?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in r?{arrayValue:{}}:"mapValue"in r?Bs(r)?Ig:{mapValue:{}}:ee(35942,{value:r})}function jy(r){return"nullValue"in r?{booleanValue:!1}:"booleanValue"in r?{doubleValue:NaN}:"integerValue"in r||"doubleValue"in r?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in r?{stringValue:""}:"stringValue"in r?{bytesValue:""}:"bytesValue"in r?yo(us.empty(),W.empty()):"referenceValue"in r?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in r?{arrayValue:{}}:"arrayValue"in r?Ig:"mapValue"in r?Bs(r)?{mapValue:{}}:ur:ee(61959,{value:r})}function qf(r,e){const t=pt(r.value,e.value);return t!==0?t:r.inclusive&&!e.inclusive?-1:!r.inclusive&&e.inclusive?1:0}function jf(r,e){const t=pt(r.value,e.value);return t!==0?t:r.inclusive&&!e.inclusive?1:!r.inclusive&&e.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class We{constructor(e){this.value=e}static empty(){return new We({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let n=0;n<e.length-1;++n)if(t=(t.mapValue.fields||{})[e.get(n)],!Zr(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=to(t)}setAll(e){let t=$e.emptyPath(),n={},s=[];e.forEach((o,a)=>{if(!t.isImmediateParentOf(a)){const u=this.getFieldsMap(t);this.applyChanges(u,n,s),n={},s=[],t=a.popLast()}o?n[a.lastSegment()]=to(o):s.push(a.lastSegment())});const i=this.getFieldsMap(t);this.applyChanges(i,n,s)}delete(e){const t=this.field(e.popLast());Zr(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return Wt(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let n=0;n<e.length;++n){let s=t.mapValue.fields[e.get(n)];Zr(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},t.mapValue.fields[e.get(n)]=s),t=s}return t.mapValue.fields}applyChanges(e,t,n){Pr(t,(s,i)=>e[s]=i);for(const s of n)delete e[s]}clone(){return new We(to(this.value))}}function Dg(r){const e=[];return Pr(r.fields,(t,n)=>{const s=new $e([t]);if(Zr(n)){const i=Dg(n.mapValue).fields;if(i.length===0)e.push(s);else for(const o of i)e.push(s.child(o))}else e.push(s)}),new vt(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zu(r,e){if(r.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:Xs(e)?"-0":e}}function El(r){return{integerValue:""+r}}function Wu(r,e,t){return Uy(e)?El(e):zu(r,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qu{constructor(){this._=void 0}}function Jy(r,e,t){return r instanceof ei?function(s,i){const o={fields:{[pg]:{stringValue:Cg},[mg]:{timestampValue:{seconds:s.seconds,nanos:s.nanoseconds}}}};return i&&Ku(i)&&(i=Wo(i)),i&&(o.fields[gg]=i),{mapValue:o}}(t,e):r instanceof ls?wg(r,e):r instanceof hs?Tg(r,e):r instanceof ds?function(s,i){const o=yg(s,i),a=mu(o)+mu(s.h);return un(o)&&un(s.h)?El(a):zu(s.serializer,a)}(r,e):r instanceof wo?function(s,i){return Jf(s,i,Math.min)}(r,e):r instanceof To?function(s,i){return Jf(s,i,Math.max)}(r,e):void 0}function Ky(r,e,t){return r instanceof ls?wg(r,e):r instanceof hs?Tg(r,e):t}function yg(r,e){return r instanceof ds?Ir(e)?e:{integerValue:0}:null}class ei extends Qu{}class ls extends Qu{constructor(e){super(),this.elements=e}}function wg(r,e){const t=Ag(e);for(const n of r.elements)t.some(s=>Wt(s,n))||t.push(n);return{arrayValue:{values:t}}}class hs extends Qu{constructor(e){super(),this.elements=e}}function Tg(r,e){let t=Ag(e);for(const n of r.elements)t=t.filter(s=>!Wt(s,n));return{arrayValue:{values:t}}}class Il extends Qu{constructor(e,t){super(),this.serializer=e,this.h=t}}class ds extends Il{}class wo extends Il{}class To extends Il{}function Jf(r,e,t){if(!Ir(e))return r.h;const n=t(mu(e),mu(r.h));return un(e)&&un(r.h)?El(n):zu(r.serializer,n)}function mu(r){return Re(r.integerValue||r.doubleValue)}function Ag(r){return Dr(r)&&r.arrayValue.values?r.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $o{constructor(e,t){this.field=e,this.transform=t}}function zy(r,e){return r.field.isEqual(e.field)&&function(n,s){return n instanceof ls&&s instanceof ls||n instanceof hs&&s instanceof hs?$s(n.elements,s.elements,Wt):n instanceof ds&&s instanceof ds||n instanceof wo&&s instanceof wo||n instanceof To&&s instanceof To?Wt(n.h,s.h):n instanceof ei&&s instanceof ei}(r.transform,e.transform)}class Wy{constructor(e,t){this.version=e,this.transformResults=t}}class Fe{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new Fe}static exists(e){return new Fe(void 0,e)}static updateTime(e){return new Fe(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function Za(r,e){return r.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(r.updateTime):r.exists===void 0||r.exists===e.isFoundDocument()}class $u{}function Rg(r,e){if(!r.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return r.isNoDocument()?new hi(r.key,Fe.none()):new li(r.key,r.data,Fe.none());{const t=r.data,n=We.empty();let s=new De($e.comparator);for(let i of e.fields)if(!s.has(i)){let o=t.field(i);o===null&&i.length>1&&(i=i.popLast(),o=t.field(i)),o===null?n.delete(i):n.set(i,o),s=s.add(i)}return new Mn(r.key,n,new vt(s.toArray()),Fe.none())}}function Qy(r,e,t){r instanceof li?function(s,i,o){const a=s.value.clone(),u=zf(s.fieldTransforms,i,o.transformResults);a.setAll(u),i.convertToFoundDocument(o.version,a).setHasCommittedMutations()}(r,e,t):r instanceof Mn?function(s,i,o){if(!Za(s.precondition,i))return void i.convertToUnknownDocument(o.version);const a=zf(s.fieldTransforms,i,o.transformResults),u=i.data;u.setAll(vg(s)),u.setAll(a),i.convertToFoundDocument(o.version,u).setHasCommittedMutations()}(r,e,t):function(s,i,o){i.convertToNoDocument(o.version).setHasCommittedMutations()}(0,e,t)}function no(r,e,t,n){return r instanceof li?function(i,o,a,u){if(!Za(i.precondition,o))return a;const B=i.value.clone(),l=Wf(i.fieldTransforms,u,o);return B.setAll(l),o.convertToFoundDocument(o.version,B).setHasLocalMutations(),null}(r,e,t,n):r instanceof Mn?function(i,o,a,u){if(!Za(i.precondition,o))return a;const B=Wf(i.fieldTransforms,u,o),l=o.data;return l.setAll(vg(i)),l.setAll(B),o.convertToFoundDocument(o.version,l).setHasLocalMutations(),a===null?null:a.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map(d=>d.field))}(r,e,t,n):function(i,o,a){return Za(i.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):a}(r,e,t)}function $y(r,e){let t=null;for(const n of r.fieldTransforms){const s=e.data.field(n.field),i=yg(n.transform,s||null);i!=null&&(t===null&&(t=We.empty()),t.set(n.field,i))}return t||null}function Kf(r,e){return r.type===e.type&&!!r.key.isEqual(e.key)&&!!r.precondition.isEqual(e.precondition)&&!!function(n,s){return n===void 0&&s===void 0||!(!n||!s)&&$s(n,s,(i,o)=>zy(i,o))}(r.fieldTransforms,e.fieldTransforms)&&(r.type===0?r.value.isEqual(e.value):r.type!==1||r.data.isEqual(e.data)&&r.fieldMask.isEqual(e.fieldMask))}class li extends $u{constructor(e,t,n,s=[]){super(),this.key=e,this.value=t,this.precondition=n,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class Mn extends $u{constructor(e,t,n,s,i=[]){super(),this.key=e,this.data=t,this.fieldMask=n,this.precondition=s,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function vg(r){const e=new Map;return r.fieldMask.fields.forEach(t=>{if(!t.isEmpty()){const n=r.data.field(t);e.set(t,n)}}),e}function zf(r,e,t){const n=new Map;j(r.length===t.length,32656,{T:t.length,P:r.length});for(let s=0;s<t.length;s++){const i=r[s],o=i.transform,a=e.data.field(i.field);n.set(i.field,Ky(o,a,t[s]))}return n}function Wf(r,e,t){const n=new Map;for(const s of r){const i=s.transform,o=t.data.field(s.field);n.set(s.field,Jy(i,o,e))}return n}class hi extends $u{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class Dl extends $u{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ti{constructor(e,t){this.position=e,this.inclusive=t}}function Qf(r,e,t){let n=0;for(let s=0;s<r.position.length;s++){const i=e[s],o=r.position[s];if(i.field.isKeyField()?n=W.comparator(W.fromName(o.referenceValue),t.key):n=pt(o,t.data.field(i.field)),i.dir==="desc"&&(n*=-1),n!==0)break}return n}function $f(r,e){if(r===null)return e===null;if(e===null||r.inclusive!==e.inclusive||r.position.length!==e.position.length)return!1;for(let t=0;t<r.position.length;t++)if(!Wt(r.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pg{}class Ce extends Pg{constructor(e,t,n){super(),this.field=e,this.op=t,this.value=n}static create(e,t,n){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,n):new Yy(e,t,n):t==="array-contains"?new ew(e,n):t==="in"?new Lg(e,n):t==="not-in"?new tw(e,n):t==="array-contains-any"?new nw(e,n):new Ce(e,t,n)}static createKeyFieldInFilter(e,t,n){return t==="in"?new Xy(e,n):new Zy(e,n)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(pt(t,this.value)):t!==null&&Ke(this.value)===Ke(t)&&this.matchesComparison(pt(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return ee(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class ye extends Pg{constructor(e,t){super(),this.filters=e,this.op=t,this.I=null}static create(e,t){return new ye(e,t)}matches(e){return ni(this)?this.filters.find(t=>!t.matches(e))===void 0:this.filters.find(t=>t.matches(e))!==void 0}getFlattenedFilters(){return this.I!==null||(this.I=this.filters.reduce((e,t)=>e.concat(t.getFlattenedFilters()),[])),this.I}getFilters(){return Object.assign([],this.filters)}}function ni(r){return r.op==="and"}function VB(r){return r.op==="or"}function yl(r){return bg(r)&&ni(r)}function bg(r){for(const e of r.filters)if(e instanceof ye)return!1;return!0}function MB(r){if(r instanceof Ce)return r.field.canonicalString()+r.op.toString()+Zs(r.value);if(yl(r))return r.filters.map(e=>MB(e)).join(",");{const e=r.filters.map(t=>MB(t)).join(",");return`${r.op}(${e})`}}function Sg(r,e){return r instanceof Ce?function(n,s){return s instanceof Ce&&n.op===s.op&&n.field.isEqual(s.field)&&Wt(n.value,s.value)}(r,e):r instanceof ye?function(n,s){return s instanceof ye&&n.op===s.op&&n.filters.length===s.filters.length?n.filters.reduce((i,o,a)=>i&&Sg(o,s.filters[a]),!0):!1}(r,e):void ee(19439)}function Og(r,e){const t=r.filters.concat(e);return ye.create(t,r.op)}function Ng(r){return r instanceof Ce?function(t){return`${t.field.canonicalString()} ${t.op} ${Zs(t.value)}`}(r):r instanceof ye?function(t){return t.op.toString()+" {"+t.getFilters().map(Ng).join(" ,")+"}"}(r):"Filter"}class Yy extends Ce{constructor(e,t,n){super(e,t,n),this.key=W.fromName(n.referenceValue)}matches(e){const t=W.comparator(e.key,this.key);return this.matchesComparison(t)}}class Xy extends Ce{constructor(e,t){super(e,"in",t),this.keys=Fg("in",t)}matches(e){return this.keys.some(t=>t.isEqual(e.key))}}class Zy extends Ce{constructor(e,t){super(e,"not-in",t),this.keys=Fg("not-in",t)}matches(e){return!this.keys.some(t=>t.isEqual(e.key))}}function Fg(r,e){var t;return(((t=e.arrayValue)==null?void 0:t.values)||[]).map(n=>W.fromName(n.referenceValue))}class ew extends Ce{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return Dr(t)&&Do(t.arrayValue,this.value)}}class Lg extends Ce{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&Do(this.value.arrayValue,t)}}class tw extends Ce{constructor(e,t){super(e,"not-in",t)}matches(e){if(Do(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!Do(this.value.arrayValue,t)}}class nw extends Ce{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!Dr(t)||!t.arrayValue.values)&&t.arrayValue.values.some(n=>Do(this.value.arrayValue,n))}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ao{constructor(e,t="asc"){this.field=e,this.dir=t}}function rw(r,e){return r.dir===e.dir&&r.field.isEqual(e.field)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class te{static fromTimestamp(e){return new te(e)}static min(){return new te(new _e(0,0))}static max(){return new te(new _e(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ne{constructor(e,t,n,s,i,o,a){this.key=e,this.documentType=t,this.version=n,this.readTime=s,this.createTime=i,this.data=o,this.documentState=a}static newInvalidDocument(e){return new Ne(e,0,te.min(),te.min(),te.min(),We.empty(),0)}static newFoundDocument(e,t,n,s){return new Ne(e,1,t,te.min(),n,s,0)}static newNoDocument(e,t){return new Ne(e,2,t,te.min(),te.min(),We.empty(),0)}static newUnknownDocument(e,t){return new Ne(e,3,t,te.min(),te.min(),We.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(te.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=We.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=We.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=te.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof Ne&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new Ne(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ro=-1;class _u{constructor(e,t,n,s){this.indexId=e,this.collectionGroup=t,this.fields=n,this.indexState=s}}function GB(r){return r.fields.find(e=>e.kind===2)}function Ur(r){return r.fields.filter(e=>e.kind!==2)}_u.UNKNOWN_ID=-1;class eu{constructor(e,t){this.fieldPath=e,this.kind=t}}class vo{constructor(e,t){this.sequenceNumber=e,this.offset=t}static empty(){return new vo(0,Mt.min())}}function sw(r,e){const t=r.toTimestamp().seconds,n=r.toTimestamp().nanoseconds+1,s=te.fromTimestamp(n===1e9?new _e(t+1,0):new _e(t,n));return new Mt(s,W.empty(),e)}function kg(r){return new Mt(r.readTime,r.key,Ro)}class Mt{constructor(e,t,n){this.readTime=e,this.documentKey=t,this.largestBatchId=n}static min(){return new Mt(te.min(),W.empty(),Ro)}static max(){return new Mt(te.max(),W.empty(),Ro)}}function wl(r,e){let t=r.readTime.compareTo(e.readTime);return t!==0?t:(t=W.comparator(r.documentKey,e.documentKey),t!==0?t:ae(r.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class iw{constructor(e,t=null,n=[],s=[],i=null,o=null,a=null){this.path=e,this.collectionGroup=t,this.orderBy=n,this.filters=s,this.limit=i,this.startAt=o,this.endAt=a,this.R=null}}function UB(r,e=null,t=[],n=[],s=null,i=null,o=null){return new iw(r,e,t,n,s,i,o)}function Eu(r){const e=oe(r);if(e.R===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map(n=>MB(n)).join(","),t+="|ob:",t+=e.orderBy.map(n=>function(i){return i.field.canonicalString()+i.dir}(n)).join(","),Qo(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map(n=>Zs(n)).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map(n=>Zs(n)).join(",")),e.R=t}return e.R}function Tl(r,e){if(r.limit!==e.limit||r.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<r.orderBy.length;t++)if(!rw(r.orderBy[t],e.orderBy[t]))return!1;if(r.filters.length!==e.filters.length)return!1;for(let t=0;t<r.filters.length;t++)if(!Sg(r.filters[t],e.filters[t]))return!1;return r.collectionGroup===e.collectionGroup&&!!r.path.isEqual(e.path)&&!!$f(r.startAt,e.startAt)&&$f(r.endAt,e.endAt)}function tr(r){return!!r.isCorePipeline}function Al(r){return!!r.path&&W.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}function Iu(r,e){return r.filters.filter(t=>t instanceof Ce&&t.field.isEqual(e))}function Yf(r,e,t){let n=dn,s=!0;for(const i of Iu(r,e)){let o=dn,a=!0;switch(i.op){case"<":case"<=":o=qy(i.value);break;case"==":case"in":case">=":o=i.value;break;case">":o=i.value,a=!1;break;case"!=":case"not-in":o=dn}qf({value:n,inclusive:s},{value:o,inclusive:a})<0&&(n=o,s=a)}if(t!==null){for(let i=0;i<r.orderBy.length;++i)if(r.orderBy[i].field.isEqual(e)){const o=t.position[i];qf({value:n,inclusive:s},{value:o,inclusive:t.inclusive})<0&&(n=o,s=t.inclusive);break}}return{value:n,inclusive:s}}function Xf(r,e,t){let n=ur,s=!0;for(const i of Iu(r,e)){let o=ur,a=!0;switch(i.op){case">=":case">":o=jy(i.value),a=!1;break;case"==":case"in":case"<=":o=i.value;break;case"<":o=i.value,a=!1;break;case"!=":case"not-in":o=ur}jf({value:n,inclusive:s},{value:o,inclusive:a})>0&&(n=o,s=a)}if(t!==null){for(let i=0;i<r.orderBy.length;++i)if(r.orderBy[i].field.isEqual(e)){const o=t.position[i];jf({value:n,inclusive:s},{value:o,inclusive:t.inclusive})>0&&(n=o,s=t.inclusive);break}}return{value:n,inclusive:s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class di{constructor(e,t=null,n=[],s=[],i=null,o="F",a=null,u=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=n,this.filters=s,this.limit=i,this.limitType=o,this.startAt=a,this.endAt=u,this.A=null,this.V=null,this.m=null,this.startAt,this.endAt}}function ow(r,e,t,n,s,i,o,a){return new di(r,e,t,n,s,i,o,a)}function Yo(r){return new di(r)}function Zf(r){return r.filters.length===0&&r.limit===null&&r.startAt==null&&r.endAt==null&&(r.explicitOrderBy.length===0||r.explicitOrderBy.length===1&&r.explicitOrderBy[0].field.isKeyField())}function aw(r){return W.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}function xg(r){return r.collectionGroup!==null}function ro(r){const e=oe(r);if(e.A===null){e.A=[];const t=new Set;for(const i of e.explicitOrderBy)e.A.push(i),t.add(i.field.canonicalString());const n=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let a=new De($e.comparator);return o.filters.forEach(u=>{u.getFlattenedFilters().forEach(B=>{B.isInequality()&&(a=a.add(B.field))})}),a})(e).forEach(i=>{t.has(i.canonicalString())||i.isKeyField()||e.A.push(new Ao(i,n))}),t.has($e.keyField().canonicalString())||e.A.push(new Ao($e.keyField(),n))}return e.A}function Kt(r){const e=oe(r);return e.V||(e.V=Vg(e,ro(r))),e.V}function uw(r){const e=oe(r);return e.m||(e.m=Vg(e,r.explicitOrderBy)),e.m}function Vg(r,e){if(r.limitType==="F")return UB(r.path,r.collectionGroup,e,r.filters,r.limit,r.startAt,r.endAt);{e=e.map(s=>{const i=s.dir==="desc"?"asc":"desc";return new Ao(s.field,i)});const t=r.endAt?new ti(r.endAt.position,r.endAt.inclusive):null,n=r.startAt?new ti(r.startAt.position,r.startAt.inclusive):null;return UB(r.path,r.collectionGroup,e,r.filters,r.limit,t,n)}}function HB(r,e){const t=r.filters.concat([e]);return new di(r.path,r.collectionGroup,r.explicitOrderBy.slice(),t,r.limit,r.limitType,r.startAt,r.endAt)}function cw(r,e){const t=r.explicitOrderBy.concat([e]);return new di(r.path,r.collectionGroup,t,r.filters.slice(),r.limit,r.limitType,r.startAt,r.endAt)}function Du(r,e,t){return new di(r.path,r.collectionGroup,r.explicitOrderBy.slice(),r.filters.slice(),e,t,r.startAt,r.endAt)}function Bw(r,e){return Tl(Kt(r),Kt(e))&&r.limitType===e.limitType}function so(r){return`Query(target=${function(t){let n=t.path.canonicalString();return t.collectionGroup!==null&&(n+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(n+=`, filters: [${t.filters.map(s=>Ng(s)).join(", ")}]`),Qo(t.limit)||(n+=", limit: "+t.limit),t.orderBy.length>0&&(n+=`, orderBy: [${t.orderBy.map(s=>function(o){return`${o.field.canonicalString()} (${o.dir})`}(s)).join(", ")}]`),t.startAt&&(n+=", startAt: ",n+=t.startAt.inclusive?"b:":"a:",n+=t.startAt.position.map(s=>Zs(s)).join(",")),t.endAt&&(n+=", endAt: ",n+=t.endAt.inclusive?"a:":"b:",n+=t.endAt.position.map(s=>Zs(s)).join(",")),`Target(${n})`}(Kt(r))}; limitType=${r.limitType})`}function Yu(r,e){return e.isFoundDocument()&&function(n,s){const i=s.key.path;return n.collectionGroup!==null?s.key.hasCollectionId(n.collectionGroup)&&n.path.isPrefixOf(i):W.isDocumentKey(n.path)?n.path.isEqual(i):n.path.isImmediateParentOf(i)}(r,e)&&function(n,s){for(const i of ro(n))if(!i.field.isKeyField()&&s.data.field(i.field)===null)return!1;return!0}(r,e)&&function(n,s){for(const i of n.filters)if(!i.matches(s))return!1;return!0}(r,e)&&function(n,s){return!(n.startAt&&!function(o,a,u){const B=Qf(o,a,u);return o.inclusive?B<=0:B<0}(n.startAt,ro(n),s)||n.endAt&&!function(o,a,u){const B=Qf(o,a,u);return o.inclusive?B>=0:B>0}(n.endAt,ro(n),s))}(r,e)}function Rl(r){return(e,t)=>{let n=!1;for(const s of ro(r)){const i=lw(s,e,t);if(i!==0)return i;n=n||s.field.isKeyField()}return 0}}function lw(r,e,t){const n=r.field.isKeyField()?W.comparator(e.key,t.key):function(i,o,a){const u=o.data.field(i),B=a.data.field(i);return u!==null&&B!==null?pt(u,B):ee(42886)}(r.field,e,t);switch(r.dir){case"asc":return n;case"desc":return-1*n;default:return ee(19790,{direction:r.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hw{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Ue,ge;function Mg(r){switch(r){case k.OK:return ee(64938);case k.CANCELLED:case k.UNKNOWN:case k.DEADLINE_EXCEEDED:case k.RESOURCE_EXHAUSTED:case k.INTERNAL:case k.UNAVAILABLE:case k.UNAUTHENTICATED:return!1;case k.INVALID_ARGUMENT:case k.NOT_FOUND:case k.ALREADY_EXISTS:case k.PERMISSION_DENIED:case k.FAILED_PRECONDITION:case k.ABORTED:case k.OUT_OF_RANGE:case k.UNIMPLEMENTED:case k.DATA_LOSS:return!0;default:return ee(15467,{code:r})}}function Gg(r){if(r===void 0)return Dt("GRPC error has no .code"),k.UNKNOWN;switch(r){case Ue.OK:return k.OK;case Ue.CANCELLED:return k.CANCELLED;case Ue.UNKNOWN:return k.UNKNOWN;case Ue.DEADLINE_EXCEEDED:return k.DEADLINE_EXCEEDED;case Ue.RESOURCE_EXHAUSTED:return k.RESOURCE_EXHAUSTED;case Ue.INTERNAL:return k.INTERNAL;case Ue.UNAVAILABLE:return k.UNAVAILABLE;case Ue.UNAUTHENTICATED:return k.UNAUTHENTICATED;case Ue.INVALID_ARGUMENT:return k.INVALID_ARGUMENT;case Ue.NOT_FOUND:return k.NOT_FOUND;case Ue.ALREADY_EXISTS:return k.ALREADY_EXISTS;case Ue.PERMISSION_DENIED:return k.PERMISSION_DENIED;case Ue.FAILED_PRECONDITION:return k.FAILED_PRECONDITION;case Ue.ABORTED:return k.ABORTED;case Ue.OUT_OF_RANGE:return k.OUT_OF_RANGE;case Ue.UNIMPLEMENTED:return k.UNIMPLEMENTED;case Ue.DATA_LOSS:return k.DATA_LOSS;default:return ee(39323,{code:r})}}(ge=Ue||(Ue={}))[ge.OK=0]="OK",ge[ge.CANCELLED=1]="CANCELLED",ge[ge.UNKNOWN=2]="UNKNOWN",ge[ge.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",ge[ge.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",ge[ge.NOT_FOUND=5]="NOT_FOUND",ge[ge.ALREADY_EXISTS=6]="ALREADY_EXISTS",ge[ge.PERMISSION_DENIED=7]="PERMISSION_DENIED",ge[ge.UNAUTHENTICATED=16]="UNAUTHENTICATED",ge[ge.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",ge[ge.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",ge[ge.ABORTED=10]="ABORTED",ge[ge.OUT_OF_RANGE=11]="OUT_OF_RANGE",ge[ge.UNIMPLEMENTED=12]="UNIMPLEMENTED",ge[ge.INTERNAL=13]="INTERNAL",ge[ge.UNAVAILABLE=14]="UNAVAILABLE",ge[ge.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gn{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n!==void 0){for(const[s,i]of n)if(this.equalsFn(s,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const n=this.mapKeyFn(e),s=this.inner[n];if(s===void 0)return this.inner[n]=[[e,t]],void this.innerSize++;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],e))return void(s[i]=[e,t]);s.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n===void 0)return!1;for(let s=0;s<n.length;s++)if(this.equalsFn(n[s][0],e))return n.length===1?delete this.inner[t]:n.splice(s,1),this.innerSize--,!0;return!1}forEach(e){Pr(this.inner,(t,n)=>{for(const[s,i]of n)e(s,i)})}isEmpty(){return hg(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dw=new Oe(W.comparator);function Qe(){return dw}const Ug=new Oe(W.comparator);function Hs(...r){let e=Ug;for(const t of r)e=e.insert(t.key,t);return e}function Hg(r){let e=Ug;return r.forEach((t,n)=>e=e.insert(t,n.overlayedDocument)),e}function qt(){return io()}function qg(){return io()}function io(){return new Gn(r=>r.toString(),(r,e)=>r.isEqual(e))}const fw=new Oe(W.comparator),Cw=new De(W.comparator);function Be(...r){let e=Cw;for(const t of r)e=e.add(t);return e}const pw=new De(ae);function gw(){return pw}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mw(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _w=new hr([4294967295,4294967295],0);function eC(r){const e=mw().encode(r),t=new Qp;return t.update(e),new Uint8Array(t.digest())}function tC(r){const e=new DataView(r.buffer),t=e.getUint32(0,!0),n=e.getUint32(4,!0),s=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new hr([t,n],0),new hr([s,i],0)]}class vl{constructor(e,t,n){if(this.bitmap=e,this.padding=t,this.hashCount=n,t<0||t>=8)throw new Yi(`Invalid padding: ${t}`);if(n<0)throw new Yi(`Invalid hash count: ${n}`);if(e.length>0&&this.hashCount===0)throw new Yi(`Invalid hash count: ${n}`);if(e.length===0&&t!==0)throw new Yi(`Invalid padding when bitmap length is 0: ${t}`);this.p=8*e.length-t,this.S=hr.fromNumber(this.p)}v(e,t,n){let s=e.add(t.multiply(hr.fromNumber(n)));return s.compare(_w)===1&&(s=new hr([s.getBits(0),s.getBits(1)],0)),s.modulo(this.S).toNumber()}D(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.p===0)return!1;const t=eC(e),[n,s]=tC(t);for(let i=0;i<this.hashCount;i++){const o=this.v(n,s,i);if(!this.D(o))return!1}return!0}static create(e,t,n){const s=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new vl(i,s,t);return n.forEach(a=>o.insert(a)),o}insert(e){if(this.p===0)return;const t=eC(e),[n,s]=tC(t);for(let i=0;i<this.hashCount;i++){const o=this.v(n,s,i);this.C(o)}}C(e){const t=Math.floor(e/8),n=e%8;this.bitmap[t]|=1<<n}}class Yi extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xo{constructor(e,t,n,s,i,o){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=n,this.documentUpdates=s,this.augmentedDocumentUpdates=i,this.resolvedLimboDocuments=o}static createSynthesizedRemoteEventForCurrentChange(e,t,n){const s=new Map;return s.set(e,Zo.createSynthesizedTargetChangeForCurrentChange(e,t,n)),new Xo(te.min(),s,new Oe(ae),Qe(),Qe(),Be())}}class Zo{constructor(e,t,n,s,i){this.resumeToken=e,this.current=t,this.addedDocuments=n,this.modifiedDocuments=s,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,n){return new Zo(n,t,Be(),Be(),Be())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class tu{constructor(e,t,n,s){this.F=e,this.removedTargetIds=t,this.key=n,this.O=s}}class jg{constructor(e,t){this.targetId=e,this.M=t}}class Jg{constructor(e,t,n=xe.EMPTY_BYTE_STRING,s=null){this.state=e,this.targetIds=t,this.resumeToken=n,this.cause=s}}class nC{constructor(e){this.targetId=e,this.N=0,this.L=rC(),this.B=xe.EMPTY_BYTE_STRING,this.U=!1,this.k=!0}get current(){return this.U}get resumeToken(){return this.B}get q(){return this.N!==0}get $(){return this.k}K(e){e.approximateByteSize()>0&&(this.k=!0,this.B=e)}W(){let e=Be(),t=Be(),n=Be();return this.L.forEach((s,i)=>{switch(i){case 0:e=e.add(s);break;case 2:t=t.add(s);break;case 1:n=n.add(s);break;default:ee(38017,{changeType:i})}}),new Zo(this.B,this.U,e,t,n)}G(){this.k=!1,this.L=rC()}j(e,t){this.k=!0,this.L=this.L.insert(e,t)}H(e){this.k=!0,this.L=this.L.remove(e)}J(){this.N+=1}Y(){this.N-=1,j(this.N>=0,3241,{N:this.N,targetId:this.targetId})}Z(){this.k=!0,this.U=!0}}const Gi="WatchChangeAggregator";class Ew{constructor(e){this.X=e,this.ee=new Map,this.te=Qe(),this.ne=Ga(),this.re=Qe(),this.ie=Ga(),this.se=new Oe(ae)}_e(e){for(const t of e.F)e.O&&e.O.isFoundDocument()?this.oe(t,e.O):this.ae(t,e.key,e.O);for(const t of e.removedTargetIds)this.ae(t,e.key,e.O)}ue(e){this.forEachTarget(e,t=>{const n=this.ee.get(t);if(n)switch(e.state){case 0:this.ce(t)&&n.K(e.resumeToken);break;case 1:n.Y(),n.q||n.G(),n.K(e.resumeToken);break;case 2:n.Y(),n.q||this.removeTarget(t);break;case 3:this.ce(t)&&(n.Z(),n.K(e.resumeToken));break;case 4:this.ce(t)&&(this.le(t),n.K(e.resumeToken));break;default:ee(56790,{state:e.state})}else U(Gi,`handleTargetChange received targetChange for untracked target ID (${t}) with state (${e.state})`)})}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ee.forEach((n,s)=>{this.ce(s)&&t(s)})}Ee(e){var t;return tr(e)?e.getPipelineSourceType()==="documents"&&((t=e.getPipelineDocuments())==null?void 0:t.length)===1:Al(e)}he(e){const t=e.targetId,n=e.M.count,s=this.Te(t);if(s){const i=s.target;if(this.Ee(i))if(n===0){const o=new W(tr(i)?de.fromString(i.getPipelineDocuments()[0]):i.path);this.ae(t,o,Ne.newNoDocument(o,te.min()))}else j(n===1,20013,"Single document existence filter with count: "+n);else{const o=this.Pe(t);if(o!==n){const a=this.Ie(e),u=a?this.Re(a,e,o):1;if(u!==0){this.le(t);const B=u===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.se=this.se.insert(t,B)}}}}}Ie(e){const t=e.M.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:n="",padding:s=0},hashCount:i=0}=t;let o,a;try{o=Nn(n).toUint8Array()}catch(u){if(u instanceof fg)return tn("Decoding the base64 bloom filter in existence filter failed ("+u.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw u}try{a=new vl(o,s,i)}catch(u){return tn(u instanceof Yi?"BloomFilter error: ":"Applying bloom filter failed: ",u),null}return a.p===0?null:a}Re(e,t,n){return t.M.count===n-this.de(e,t.targetId)?0:2}de(e,t){const n=this.X.getRemoteKeysForTarget(t);let s=0;return n.forEach(i=>{const o=this.X.Ve(),a=`projects/${o.projectId}/databases/${o.database}/documents/${i.path.canonicalString()}`;e.mightContain(a)||(this.ae(t,i,null),s++)}),s}fe(e){const t=new Map;this.ee.forEach((i,o)=>{const a=this.Te(o);if(a){if(i.current&&this.Ee(a.target)){const u=tr(a.target)?de.fromString(a.target.getPipelineDocuments()[0]):a.target.path,B=new W(u);this.me(B).has(o)||this.pe(o,B)||this.ae(o,B,Ne.newNoDocument(B,e))}i.$&&(t.set(o,i.W()),i.G())}});let n=Be();this.ie.forEach((i,o)=>{let a=!0;o.forEachWhile(u=>{const B=this.Te(u);return!B||B.purpose==="TargetPurposeLimboResolution"||(a=!1,!1)}),a&&(n=n.add(i))}),this.te.forEach((i,o)=>o.setReadTime(e)),this.re.forEach((i,o)=>o.setReadTime(e));const s=new Xo(e,t,this.se,this.te,this.re,n);return this.te=Qe(),this.ne=Ga(),this.re=Qe(),this.ie=Ga(),this.se=new Oe(ae),s}oe(e,t){const n=this.ee.get(e);if(!n||!this.ce(e))return void U(Gi,`addDocumentToTarget received document for unknown inactive target (${e})`);const s=this.pe(e,t.key)?2:0;n.j(t.key,s),tr(this.Te(e).target)&&this.Te(e).target.getPipelineFlavor()!=="exact"?this.re=this.re.insert(t.key,t):this.te=this.te.insert(t.key,t),this.ne=this.ne.insert(t.key,this.me(t.key).add(e)),this.ie=this.ie.insert(t.key,this.ge(t.key).add(e))}ae(e,t,n){const s=this.ee.get(e);s&&this.ce(e)?(this.pe(e,t)?s.j(t,1):s.H(t),this.ie=this.ie.insert(t,this.ge(t).delete(e)),this.ie=this.ie.insert(t,this.ge(t).add(e)),n&&(tr(this.Te(e).target)&&this.Te(e).target.getPipelineFlavor()!=="exact"?this.re=this.re.insert(t,n):this.te=this.te.insert(t,n))):U(Gi,`removeDocumentFromTarget received document for unknown or inactive target (${e})`)}removeTarget(e){this.ee.delete(e)}Pe(e){const t=this.ee.get(e);if(!t)return 0;const n=t.W();return this.X.getRemoteKeysForTarget(e).size+n.addedDocuments.size-n.removedDocuments.size}J(e){let t=this.ee.get(e);t||(U(Gi,`recordPendingTargetRequest set up tracking for target ID ${e}`),t=new nC(e),this.ee.set(e,t)),t.J()}ge(e){let t=this.ie.get(e);return t||(t=new De(ae),this.ie=this.ie.insert(e,t)),t}me(e){let t=this.ne.get(e);return t||(t=new De(ae),this.ne=this.ne.insert(e,t)),t}ce(e){const t=this.Te(e)!==null;return t||U(Gi,"Detected inactive target",e),t}Te(e){const t=this.ee.get(e);return t===void 0||t.q?null:this.X.ye(e)}le(e){this.ee.set(e,new nC(e)),this.X.getRemoteKeysForTarget(e).forEach(t=>{this.ae(e,t,null)})}pe(e,t){return this.X.getRemoteKeysForTarget(e).has(t)}}function Ga(){return new Oe(W.comparator)}function rC(){return new Oe(W.comparator)}const Iw={asc:"ASCENDING",desc:"DESCENDING"},Dw={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},yw={and:"AND",or:"OR"};class ww{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function qB(r,e){return r.useProto3Json||Qo(e)?e:{value:e}}function es(r,e){return r.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Pl(r){const e=On(r);return new _e(e.seconds,e.nanos)}function Kg(r,e){return r.useProto3Json?e.toBase64():e.toUint8Array()}function nu(r,e){return es(r,e.toTimestamp())}function it(r){return j(!!r,49232),te.fromTimestamp(Pl(r))}function bl(r,e){return jB(r,e).canonicalString()}function jB(r,e){const t=function(s){return new de(["projects",s.projectId,"databases",s.database])}(r).child("documents");return e===void 0?t:t.child(e)}function zg(r){const e=de.fromString(r);return j(nm(e),10190,{key:e.toString()}),e}function ri(r,e){return bl(r.databaseId,e.path)}function Pn(r,e){const t=zg(e);if(t.get(1)!==r.databaseId.projectId)throw new H(k.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+r.databaseId.projectId);if(t.get(3)!==r.databaseId.database)throw new H(k.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+r.databaseId.database);return new W($g(t))}function Wg(r,e){return bl(r.databaseId,e)}function Qg(r){const e=zg(r);return e.length===4?de.emptyPath():$g(e)}function JB(r){return new de(["projects",r.databaseId.projectId,"databases",r.databaseId.database]).canonicalString()}function $g(r){return j(r.length>4&&r.get(4)==="documents",29091,{key:r.toString()}),r.popFirst(5)}function sC(r,e,t){return{name:ri(r,e),fields:t.value.mapValue.fields}}function Tw(r,e,t){const n=Pn(r,e.name),s=it(e.updateTime),i=e.createTime?it(e.createTime):te.min(),o=new We({mapValue:{fields:e.fields}}),a=Ne.newFoundDocument(n,s,i,o);return t&&a.setHasCommittedMutations(),t?a.setHasCommittedMutations():a}function Aw(r,e){return"found"in e?function(n,s){j(!!s.found,43571),s.found.name,s.found.updateTime;const i=Pn(n,s.found.name),o=it(s.found.updateTime),a=s.found.createTime?it(s.found.createTime):te.min(),u=new We({mapValue:{fields:s.found.fields}});return Ne.newFoundDocument(i,o,a,u)}(r,e):"missing"in e?function(n,s){j(!!s.missing,3894),j(!!s.readTime,22933);const i=Pn(n,s.missing),o=it(s.readTime);return Ne.newNoDocument(i,o)}(r,e):ee(7234,{result:e})}function Rw(r,e){let t;if("targetChange"in e){e.targetChange;const n=function(B){return B==="NO_CHANGE"?0:B==="ADD"?1:B==="REMOVE"?2:B==="CURRENT"?3:B==="RESET"?4:ee(39313,{state:B})}(e.targetChange.targetChangeType||"NO_CHANGE"),s=e.targetChange.targetIds||[],i=function(B,l){return B.useProto3Json?(j(l===void 0||typeof l=="string",58123),xe.fromBase64String(l||"")):(j(l===void 0||l instanceof Buffer||l instanceof Uint8Array,16193),xe.fromUint8Array(l||new Uint8Array))}(r,e.targetChange.resumeToken),o=e.targetChange.cause,a=o&&function(B){const l=B.code===void 0?k.UNKNOWN:Gg(B.code);return new H(l,B.message||"")}(o);t=new Jg(n,s,i,a||null)}else if("documentChange"in e){e.documentChange;const n=e.documentChange;n.document,n.document.name,n.document.updateTime;const s=Pn(r,n.document.name),i=it(n.document.updateTime),o=n.document.createTime?it(n.document.createTime):te.min(),a=new We({mapValue:{fields:n.document.fields}}),u=Ne.newFoundDocument(s,i,o,a),B=n.targetIds||[],l=n.removedTargetIds||[];t=new tu(B,l,u.key,u)}else if("documentDelete"in e){e.documentDelete;const n=e.documentDelete;n.document;const s=Pn(r,n.document),i=n.readTime?it(n.readTime):te.min(),o=Ne.newNoDocument(s,i),a=n.removedTargetIds||[];t=new tu([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;const n=e.documentRemove;n.document;const s=Pn(r,n.document),i=n.removedTargetIds||[];t=new tu([],i,s,null)}else{if(!("filter"in e))return ee(11601,{we:e});{e.filter;const n=e.filter;n.targetId;const{count:s=0,unchangedNames:i}=n,o=new hw(s,i),a=n.targetId;t=new jg(a,o)}}return t}function Po(r,e){let t;if(e instanceof li)t={update:sC(r,e.key,e.value)};else if(e instanceof hi)t={delete:ri(r,e.key)};else if(e instanceof Mn)t={update:sC(r,e.key,e.data),updateMask:Fw(e.fieldMask)};else{if(!(e instanceof Dl))return ee(16599,{be:e.type});t={verify:ri(r,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map(n=>function(i,o){const a=o.transform;if(a instanceof ei)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(a instanceof ls)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:a.elements}};if(a instanceof hs)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:a.elements}};if(a instanceof ds)return{fieldPath:o.field.canonicalString(),increment:a.h};if(a instanceof wo)return{fieldPath:o.field.canonicalString(),minimum:a.h};if(a instanceof To)return{fieldPath:o.field.canonicalString(),maximum:a.h};throw ee(20930,{transform:o.transform})}(0,n))),e.precondition.isNone||(t.currentDocument=function(s,i){return i.updateTime!==void 0?{updateTime:nu(s,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:ee(27497)}(r,e.precondition)),t}function KB(r,e){const t=e.currentDocument?function(i){return i.updateTime!==void 0?Fe.updateTime(it(i.updateTime)):i.exists!==void 0?Fe.exists(i.exists):Fe.none()}(e.currentDocument):Fe.none(),n=e.updateTransforms?e.updateTransforms.map(s=>function(o,a){let u=null;if("setToServerValue"in a)j(a.setToServerValue==="REQUEST_TIME",16630,{proto:a}),u=new ei;else if("appendMissingElements"in a){const l=a.appendMissingElements.values||[];u=new ls(l)}else if("removeAllFromArray"in a){const l=a.removeAllFromArray.values||[];u=new hs(l)}else"increment"in a?u=new ds(o,a.increment):"minimum"in a?u=new wo(o,a.minimum):"maximum"in a?u=new To(o,a.maximum):ee(16584,{proto:a});const B=$e.fromServerFormat(a.fieldPath);return new $o(B,u)}(r,s)):[];if(e.update){e.update.name;const s=Pn(r,e.update.name),i=new We({mapValue:{fields:e.update.fields}});if(e.updateMask){const o=function(u){const B=u.fieldPaths||[];return new vt(B.map(l=>$e.fromServerFormat(l)))}(e.updateMask);return new Mn(s,i,o,t,n)}return new li(s,i,t,n)}if(e.delete){const s=Pn(r,e.delete);return new hi(s,t)}if(e.verify){const s=Pn(r,e.verify);return new Dl(s,t)}return ee(1463,{proto:e})}function vw(r,e){return r&&r.length>0?(j(e!==void 0,14353),r.map(t=>function(s,i){let o=s.updateTime?it(s.updateTime):it(i);return o.isEqual(te.min())&&(o=it(i)),new Wy(o,s.transformResults||[])}(t,e))):[]}function Yg(r,e){return{documents:[Wg(r,e.path)]}}function Sl(r,e){const t={structuredQuery:{}},n=e.path;let s;e.collectionGroup!==null?(s=n,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(s=n.popLast(),t.structuredQuery.from=[{collectionId:n.lastSegment()}]),t.parent=Wg(r,s);const i=function(B){if(B.length!==0)return tm(ye.create(B,"and"))}(e.filters);i&&(t.structuredQuery.where=i);const o=function(B){if(B.length!==0)return B.map(l=>function(C){return{field:nr(C.field),direction:Sw(C.dir)}}(l))}(e.orderBy);o&&(t.structuredQuery.orderBy=o);const a=qB(r,e.limit);return a!==null&&(t.structuredQuery.limit=a),e.startAt&&(t.structuredQuery.startAt=function(B){return{before:B.inclusive,values:B.position}}(e.startAt)),e.endAt&&(t.structuredQuery.endAt=function(B){return{before:!B.inclusive,values:B.position}}(e.endAt)),{Se:t,parent:s}}function Pw(r,e,t,n){const{Se:s,parent:i}=Sl(r,e),o={},a=[];let u=0;return t.forEach(B=>{const l="aggregate_"+u++;o[l]=B.alias,B.aggregateType==="count"?a.push({alias:l,count:{}}):B.aggregateType==="avg"?a.push({alias:l,avg:{field:nr(B.fieldPath)}}):B.aggregateType==="sum"&&a.push({alias:l,sum:{field:nr(B.fieldPath)}})}),{request:{structuredAggregationQuery:{aggregations:a,structuredQuery:s.structuredQuery},parent:s.parent},ve:o,parent:i}}function Xg(r){let e=Qg(r.parent);const t=r.structuredQuery,n=t.from?t.from.length:0;let s=null;if(n>0){j(n===1,65062);const l=t.from[0];l.allDescendants?s=l.collectionId:e=e.child(l.collectionId)}let i=[];t.where&&(i=function(d){const C=em(d);return C instanceof ye&&yl(C)?C.getFilters():[C]}(t.where));let o=[];t.orderBy&&(o=function(d){return d.map(C=>function(m){return new Ao(qs(m.field),function(N){switch(N){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}}(m.direction))}(C))}(t.orderBy));let a=null;t.limit&&(a=function(d){let C;return C=typeof d=="object"?d.value:d,Qo(C)?null:C}(t.limit));let u=null;t.startAt&&(u=function(d){const C=!!d.before,g=d.values||[];return new ti(g,C)}(t.startAt));let B=null;return t.endAt&&(B=function(d){const C=!d.before,g=d.values||[];return new ti(g,C)}(t.endAt)),ow(e,s,o,i,a,"F",u,B)}function bw(r,e){const t=function(s){switch(s){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return ee(28987,{purpose:s})}}(e.purpose);return t==null?null:{"goog-listen-tags":t}}function Zg(r,e){return{structuredPipeline:{pipeline:{stages:e.stages.map(t=>t._toProto(r))}}}}function em(r){return r.unaryFilter!==void 0?function(t){switch(t.unaryFilter.op){case"IS_NAN":const n=qs(t.unaryFilter.field);return Ce.create(n,"==",{doubleValue:NaN});case"IS_NULL":const s=qs(t.unaryFilter.field);return Ce.create(s,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=qs(t.unaryFilter.field);return Ce.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=qs(t.unaryFilter.field);return Ce.create(o,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return ee(61313);default:return ee(60726)}}(r):r.fieldFilter!==void 0?function(t){return Ce.create(qs(t.fieldFilter.field),function(s){switch(s){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return ee(58110);default:return ee(50506)}}(t.fieldFilter.op),t.fieldFilter.value)}(r):r.compositeFilter!==void 0?function(t){return ye.create(t.compositeFilter.filters.map(n=>em(n)),function(s){switch(s){case"AND":return"and";case"OR":return"or";default:return ee(1026)}}(t.compositeFilter.op))}(r):ee(30097,{filter:r})}function Sw(r){return Iw[r]}function Ow(r){return Dw[r]}function Nw(r){return yw[r]}function nr(r){return{fieldPath:r.canonicalString()}}function qs(r){return $e.fromServerFormat(r.fieldPath)}function tm(r){return r instanceof Ce?function(t){if(t.op==="=="){if(St(t.value))return{unaryFilter:{field:nr(t.field),op:"IS_NAN"}};if(Vt(t.value))return{unaryFilter:{field:nr(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(St(t.value))return{unaryFilter:{field:nr(t.field),op:"IS_NOT_NAN"}};if(Vt(t.value))return{unaryFilter:{field:nr(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:nr(t.field),op:Ow(t.op),value:t.value}}}(r):r instanceof ye?function(t){const n=t.getFilters().map(s=>tm(s));return n.length===1?n[0]:{compositeFilter:{op:Nw(t.op),filters:n}}}(r):ee(54877,{filter:r})}function Fw(r){const e=[];return r.fields.forEach(t=>e.push(t.canonicalString())),{fieldPaths:e}}function nm(r){return r.length>=4&&r.get(0)==="projects"&&r.get(2)==="databases"}function rm(r){return!!r&&typeof r._toProto=="function"&&r._protoValueType==="ProtoValue"}function bo(r,e){const t={fields:{}};return e.forEach((n,s)=>{if(typeof s!="string")throw new Error(`Cannot encode map with non-string key: ${s}`);t.fields[s]=n._toProto(r)}),{mapValue:t}}function sm(r){return{stringValue:r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xu(r){return new ww(r,!0)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xt{constructor(e){this._byteString=e}static fromBase64String(e){try{return new xt(xe.fromBase64String(e))}catch(t){throw new H(k.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new xt(xe.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:xt._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(zo(e,xt._jsonSchema))return xt.fromBase64String(e.bytes)}}xt._jsonSchemaVersion="firestore/bytes/1.0",xt._jsonSchema={type:Je("string",xt._jsonSchemaVersion),bytes:Je("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fi{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new H(k.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new $e(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}function Lw(){return new fi(an)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _s{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fn{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new H(k.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new H(k.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return ae(this._lat,e._lat)||ae(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:fn._jsonSchemaVersion}}static fromJSON(e){if(zo(e,fn._jsonSchema))return new fn(e.latitude,e.longitude)}}fn._jsonSchemaVersion="firestore/geoPoint/1.0",fn._jsonSchema={type:Je("string",fn._jsonSchemaVersion),latitude:Je("number"),longitude:Je("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ut{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}ut.UNAUTHENTICATED=new ut(null),ut.GOOGLE_CREDENTIALS=new ut("google-credentials-uid"),ut.FIRST_PARTY=new ut("first-party-uid"),ut.MOCK_USER=new ut("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zt{constructor(){this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class im{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class kw{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable(()=>t(ut.UNAUTHENTICATED))}shutdown(){}}class xw{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable(()=>t(this.token.user))}shutdown(){this.changeListener=null}}class Vw{constructor(e){this.De=e,this.currentUser=ut.UNAUTHENTICATED,this.xe=0,this.forceRefresh=!1,this.auth=null}start(e,t){j(this.Ce===void 0,42304);let n=this.xe;const s=u=>this.xe!==n?(n=this.xe,t(u)):Promise.resolve();let i=new zt;this.Ce=()=>{this.xe++,this.currentUser=this.Fe(),i.resolve(),i=new zt,e.enqueueRetryable(()=>s(this.currentUser))};const o=()=>{const u=i;e.enqueueRetryable(async()=>{await u.promise,await s(this.currentUser)})},a=u=>{U("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=u,this.Ce&&(this.auth.addAuthTokenListener(this.Ce),o())};this.De.onInit(u=>a(u)),setTimeout(()=>{if(!this.auth){const u=this.De.getImmediate({optional:!0});u?a(u):(U("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new zt)}},0),o()}getToken(){const e=this.xe,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then(n=>this.xe!==e?(U("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):n?(j(typeof n.accessToken=="string",31837,{Oe:n}),new im(n.accessToken,this.currentUser)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.Ce&&this.auth.removeAuthTokenListener(this.Ce),this.Ce=void 0}Fe(){const e=this.auth&&this.auth.getUid();return j(e===null||typeof e=="string",2055,{Me:e}),new ut(e)}}class Mw{constructor(e,t,n){this.Ne=e,this.Le=t,this.Be=n,this.type="FirstParty",this.user=ut.FIRST_PARTY,this.Ue=new Map}ke(){return this.Be?this.Be():null}get headers(){this.Ue.set("X-Goog-AuthUser",this.Ne);const e=this.ke();return e&&this.Ue.set("Authorization",e),this.Le&&this.Ue.set("X-Goog-Iam-Authorization-Token",this.Le),this.Ue}}class Gw{constructor(e,t,n){this.Ne=e,this.Le=t,this.Be=n}getToken(){return Promise.resolve(new Mw(this.Ne,this.Le,this.Be))}start(e,t){e.enqueueRetryable(()=>t(ut.FIRST_PARTY))}shutdown(){}invalidateToken(){}}class iC{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class Uw{constructor(e,t){this.qe=t,this.forceRefresh=!1,this.appCheck=null,this.$e=null,this.Ke=null,Ge(e)&&e.settings.appCheckToken&&(this.Ke=e.settings.appCheckToken)}start(e,t){j(this.Ce===void 0,3512);const n=i=>{i.error!=null&&U("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const o=i.token!==this.$e;return this.$e=i.token,U("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?t(i.token):Promise.resolve()};this.Ce=i=>{e.enqueueRetryable(()=>n(i))};const s=i=>{U("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.Ce&&this.appCheck.addTokenListener(this.Ce)};this.qe.onInit(i=>s(i)),setTimeout(()=>{if(!this.appCheck){const i=this.qe.getImmediate({optional:!0});i?s(i):U("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}},0)}getToken(){if(this.Ke)return Promise.resolve(new iC(this.Ke));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then(t=>t?(j(typeof t.token=="string",44558,{tokenResult:t}),this.$e=t.token,new iC(t.token)):null):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.Ce&&this.appCheck.removeTokenListener(this.Ce),this.Ce=void 0}}function om(r){const e={};return r.timeoutSeconds!==void 0&&(e.timeoutSeconds=r.timeoutSeconds),e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hw{Qe(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oC="ConnectivityMonitor";class aC{constructor(){this.We=()=>this.Ge(),this.ze=()=>this.je(),this.He=[],this.Je()}Qe(e){this.He.push(e)}shutdown(){window.removeEventListener("online",this.We),window.removeEventListener("offline",this.ze)}Je(){window.addEventListener("online",this.We),window.addEventListener("offline",this.ze)}Ge(){U(oC,"Network connectivity changed: AVAILABLE");for(const e of this.He)e(0)}je(){U(oC,"Network connectivity changed: UNAVAILABLE");for(const e of this.He)e(1)}static Ye(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ua=null;function zB(){return Ua===null?Ua=function(){return 268435456+Math.round(2147483648*Math.random())}():Ua++,"0x"+Ua.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lB="RestConnection",qw={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class jw{get Ze(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",n=encodeURIComponent(this.databaseId.projectId),s=encodeURIComponent(this.databaseId.database);this.Xe=t+"://"+e.host,this.et=`projects/${n}/databases/${s}`,this.tt=this.databaseId.database===Io?`project_id=${n}`:`project_id=${n}&database_id=${s}`}nt(e,t,n,s,i){const o=zB(),a=this.rt(e,t.toUriEncodedString());U(lB,`Sending RPC '${e}' ${o}:`,a,n);const u={"google-cloud-resource-prefix":this.et,"x-goog-request-params":this.tt};this.it(u,s,i);const{host:B}=new URL(a),l=vr(B);return this.st(e,a,u,n,l).then(d=>(U(lB,`Received RPC '${e}' ${o}: `,d),d),d=>{throw tn(lB,`RPC '${e}' ${o} failed with error: `,d,"url: ",a,"request:",n),d})}_t(e,t,n,s,i,o){return this.nt(e,t,n,s,i)}it(e,t,n){if(e["X-Goog-Api-Client"]=function(){return"gl-js/ fire/"+Bi}(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach((s,i)=>e[i]=s),n&&n.headers.forEach((s,i)=>e[i]=s),this.databaseInfo._customHeaders)for(const s of Object.keys(this.databaseInfo._customHeaders))e[s]=this.databaseInfo._customHeaders[s]}rt(e,t){const n=qw[e];let s=`${this.Xe}/v1/${t}:${n}`;return this.databaseInfo.apiKey&&(s=`${s}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),s}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jw{constructor(e){this.ot=e.ot,this.ut=e.ut}ct(e){this.lt=e}Et(e){this.ht=e}Tt(e){this.Pt=e}onMessage(e){this.It=e}close(){this.ut()}send(e){this.ot(e)}Rt(){this.lt()}At(){this.ht()}Vt(e){this.Pt(e)}dt(e){this.It(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lt="WebChannelConnection",Ui=(r,e,t)=>{r.listen(e,n=>{try{t(n)}catch(s){setTimeout(()=>{throw s},0)}})};class Ks extends jw{constructor(e){super(e),this.ft=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static gt(){if(!Ks.yt){const e=Zp();Ui(e,Xp.STAT_EVENT,t=>{t.stat===SB.PROXY?U(lt,"STAT_EVENT: detected buffering proxy"):t.stat===SB.NOPROXY&&U(lt,"STAT_EVENT: detected no buffering proxy")}),Ks.yt=!0}}st(e,t,n,s,i){const o=zB();return new Promise((a,u)=>{const B=new $p;B.setWithCredentials(!0),B.listenOnce(Yp.COMPLETE,()=>{try{switch(B.getLastErrorCode()){case $a.NO_ERROR:const d=B.getResponseJson();U(lt,`XHR for RPC '${e}' ${o} received:`,JSON.stringify(d)),a(d);break;case $a.TIMEOUT:U(lt,`RPC '${e}' ${o} timed out`),u(new H(k.DEADLINE_EXCEEDED,"Request time out"));break;case $a.HTTP_ERROR:const C=B.getStatus();if(U(lt,`RPC '${e}' ${o} failed with status:`,C,"response text:",B.getResponseText()),C>0){let g=B.getResponseJson();Array.isArray(g)&&(g=g[0]);const m=g==null?void 0:g.error;if(m&&m.status&&m.message){const v=function(q){const J=q.toLowerCase().replace(/_/g,"-");return Object.values(k).indexOf(J)>=0?J:k.UNKNOWN}(m.status);u(new H(v,m.message))}else u(new H(k.UNKNOWN,"Server responded with status "+B.getStatus()))}else u(new H(k.UNAVAILABLE,"Connection failed."));break;default:ee(9055,{wt:e,streamId:o,bt:B.getLastErrorCode(),St:B.getLastError()})}}finally{U(lt,`RPC '${e}' ${o} completed.`)}});const l=JSON.stringify(s);U(lt,`RPC '${e}' ${o} sending request:`,s),B.send(t,"POST",l,n,15)})}vt(e,t,n){const s=zB(),i=[this.Xe,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=this.createWebChannelTransport(),a={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(a.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(a.useFetchStreams=!0),this.it(a.initMessageHeaders,t,n),a.encodeInitMessageHeaders=!0;const B=i.join("");U(lt,`Creating RPC '${e}' stream ${s}: ${B}`,a);const l=o.createWebChannel(B,a);this.Dt(l);let d=!1,C=!1;const g=new Jw({ot:m=>{C?U(lt,`Not sending because RPC '${e}' stream ${s} is closed:`,m):(d||(U(lt,`Opening RPC '${e}' stream ${s} transport.`),l.open(),d=!0),U(lt,`RPC '${e}' stream ${s} sending:`,m),l.send(m))},ut:()=>l.close()});return Ui(l,$i.EventType.OPEN,()=>{C||(U(lt,`RPC '${e}' stream ${s} transport opened.`),g.Rt())}),Ui(l,$i.EventType.CLOSE,()=>{C||(C=!0,U(lt,`RPC '${e}' stream ${s} transport closed`),g.Vt(),this.xt(l))}),Ui(l,$i.EventType.ERROR,m=>{C||(C=!0,tn(lt,`RPC '${e}' stream ${s} transport errored. Name:`,m.name,"Message:",m.message),g.Vt(new H(k.UNAVAILABLE,"The operation could not be completed")))}),Ui(l,$i.EventType.MESSAGE,m=>{var v;if(!C){const N=m.data[0];j(!!N,16349);const q=N,J=(q==null?void 0:q.error)||((v=q[0])==null?void 0:v.error);if(J){U(lt,`RPC '${e}' stream ${s} received error:`,J);const X=J.status;let se=function(T){const I=Ue[T];if(I!==void 0)return Gg(I)}(X),ue=J.message;X==="NOT_FOUND"&&ue.includes("database")&&ue.includes("does not exist")&&ue.includes(this.databaseId.database)&&tn(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),se===void 0&&(se=k.INTERNAL,ue="Unknown error status: "+X+" with message "+J.message),C=!0,g.Vt(new H(se,ue)),l.close()}else U(lt,`RPC '${e}' stream ${s} received:`,N),g.dt(N)}}),Ks.gt(),setTimeout(()=>{g.At()},0),g}terminate(){this.ft.forEach(e=>e.close()),this.ft=[]}Dt(e){this.ft.push(e)}xt(e){this.ft=this.ft.filter(t=>t===e)}it(e,t,n){super.it(e,t,n),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return eg()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Kw(r){return new Ks(r)}Ks.yt=!1;class Ol{constructor(e,t,n=1e3,s=1.5,i=6e4){this.Ct=e,this.timerId=t,this.Ft=n,this.Ot=s,this.Mt=i,this.Nt=0,this.Lt=null,this.Bt=Date.now(),this.reset()}reset(){this.Nt=0}Ut(){this.Nt=this.Mt}kt(e){this.cancel();const t=Math.floor(this.Nt+this.qt()),n=Math.max(0,Date.now()-this.Bt),s=Math.max(0,t-n);s>0&&U("ExponentialBackoff",`Backing off for ${s} ms (base delay: ${this.Nt} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`),this.Lt=this.Ct.enqueueAfterDelay(this.timerId,s,()=>(this.Bt=Date.now(),e())),this.Nt*=this.Ot,this.Nt<this.Ft&&(this.Nt=this.Ft),this.Nt>this.Mt&&(this.Nt=this.Mt)}$t(){this.Lt!==null&&(this.Lt.skipDelay(),this.Lt=null)}cancel(){this.Lt!==null&&(this.Lt.cancel(),this.Lt=null)}qt(){return(Math.random()-.5)*this.Nt}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uC="PersistentStream";class am{constructor(e,t,n,s,i,o,a,u){this.Ct=e,this.Kt=n,this.Qt=s,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=a,this.listener=u,this.state=0,this.Wt=0,this.Gt=null,this.zt=null,this.stream=null,this.jt=0,this.Ht=new Ol(e,t)}Jt(){return this.state===1||this.state===5||this.Yt()}Yt(){return this.state===2||this.state===3}start(){this.jt=0,this.state!==4?this.auth():this.Zt()}async stop(){this.Jt()&&await this.close(0)}Xt(){this.state=0,this.Ht.reset()}en(){this.Yt()&&this.Gt===null&&(this.Gt=this.Ct.enqueueAfterDelay(this.Kt,6e4,()=>this.tn()))}nn(e){this.rn(),this.stream.send(e)}async tn(){if(this.Yt())return this.close(0)}rn(){this.Gt&&(this.Gt.cancel(),this.Gt=null)}sn(){this.zt&&(this.zt.cancel(),this.zt=null)}async close(e,t){this.rn(),this.sn(),this.Ht.cancel(),this.Wt++,e!==4?this.Ht.reset():t&&t.code===k.RESOURCE_EXHAUSTED?(Dt(t.toString()),Dt("Using maximum backoff delay to prevent overloading the backend."),this.Ht.Ut()):t&&t.code===k.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this._n(),this.stream.close(),this.stream=null),this.state=e,await this.listener.Tt(t)}_n(){}auth(){this.state=1;const e=this.an(this.Wt),t=this.Wt;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then(([n,s])=>{this.Wt===t&&this.un(n,s)},n=>{e(()=>{const s=new H(k.UNKNOWN,"Fetching auth token failed: "+n.message);return this.cn(s)})})}un(e,t){const n=this.an(this.Wt);this.stream=this.En(e,t),this.stream.ct(()=>{n(()=>this.listener.ct())}),this.stream.Et(()=>{n(()=>(this.state=2,this.zt=this.Ct.enqueueAfterDelay(this.Qt,1e4,()=>(this.Yt()&&(this.state=3),Promise.resolve())),this.listener.Et()))}),this.stream.Tt(s=>{n(()=>this.cn(s))}),this.stream.onMessage(s=>{n(()=>++this.jt==1?this.hn(s):this.onNext(s))})}Zt(){this.state=5,this.Ht.kt(async()=>{this.state=0,this.start()})}cn(e){return U(uC,`close with error: ${e}`),this.stream=null,this.close(4,e)}an(e){return t=>{this.Ct.enqueueAndForget(()=>this.Wt===e?t():(U(uC,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve()))}}}class zw extends am{constructor(e,t,n,s,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,n,s,o),this.serializer=i}En(e,t){return this.connection.vt("Listen",e,t)}hn(e){return this.onNext(e)}onNext(e){this.Ht.reset();const t=Rw(this.serializer,e),n=function(i){if(!("targetChange"in i))return te.min();const o=i.targetChange;return o.targetIds&&o.targetIds.length?te.min():o.readTime?it(o.readTime):te.min()}(e);return this.listener.Tn(t,n)}Pn(e){const t={};t.database=JB(this.serializer),t.addTarget=function(i,o){let a;const u=o.target;if(a=tr(u)?{pipelineQuery:Zg(i,u)}:Al(u)?{documents:Yg(i,u)}:{query:Sl(i,u).Se},a.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){a.resumeToken=Kg(i,o.resumeToken);const B=qB(i,o.expectedCount);B!==null&&(a.expectedCount=B)}else if(o.snapshotVersion.compareTo(te.min())>0){a.readTime=es(i,o.snapshotVersion.toTimestamp());const B=qB(i,o.expectedCount);B!==null&&(a.expectedCount=B)}return a}(this.serializer,e);const n=bw(this.serializer,e);n&&(t.labels=n),this.nn(t)}In(e){const t={};t.database=JB(this.serializer),t.removeTarget=e,this.nn(t)}}class Ww extends am{constructor(e,t,n,s,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,n,s,o),this.serializer=i}get Rn(){return this.jt>0}start(){this.lastStreamToken=void 0,super.start()}_n(){this.Rn&&this.An([])}En(e,t){return this.connection.vt("Write",e,t)}hn(e){return j(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,j(!e.writeResults||e.writeResults.length===0,55816),this.listener.Vn()}onNext(e){j(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.Ht.reset();const t=vw(e.writeResults,e.commitTime),n=it(e.commitTime);return this.listener.dn(n,t)}fn(){const e={};e.database=JB(this.serializer),this.nn(e)}An(e){const t={streamToken:this.lastStreamToken,writes:e.map(n=>Po(this.serializer,n))};this.nn(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qw{}class $w extends Qw{constructor(e,t,n,s){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=n,this.serializer=s,this.mn=!1}pn(){if(this.mn)throw new H(k.FAILED_PRECONDITION,"The client has already been terminated.")}nt(e,t,n,s){return this.pn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([i,o])=>this.connection.nt(e,jB(t,n),s,i,o)).catch(i=>{throw i.name==="FirebaseError"?(i.code===k.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new H(k.UNKNOWN,i.toString())})}_t(e,t,n,s,i){return this.pn(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then(([o,a])=>this.connection._t(e,jB(t,n),s,o,a,i)).catch(o=>{throw o.name==="FirebaseError"?(o.code===k.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new H(k.UNKNOWN,o.toString())})}terminate(){this.mn=!0,this.connection.terminate()}}function Yw(r,e,t,n){return new $w(r,e,t,n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xw="ComponentProvider",cC=new Map;function Zw(r,e,t,n,s){return new My(r,e,t,s.host,s.ssl,s.experimentalForceLongPolling,s.experimentalAutoDetectLongPolling,om(s.experimentalLongPollingOptions),s.useFetchStreams,s.isUsingEmulator,n,s._customHeaders,s.grpcFlowControlWindow)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const BC={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},um=41943040;class ht{static withCacheSize(e){return new ht(e,ht.DEFAULT_COLLECTION_PERCENTILE,ht.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,n){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=n}}ht.DEFAULT_COLLECTION_PERCENTILE=10,ht.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,ht.DEFAULT=new ht(um,ht.DEFAULT_COLLECTION_PERCENTILE,ht.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),ht.DISABLED=new ht(-1,0,0);/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class jt{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=n=>this.gn(n),this.yn=n=>t.writeSequenceNumber(n))}gn(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.yn&&this.yn(e),e}}jt.wn=-1;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cm="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class Bm{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Es(r){if(r.code!==k.FAILED_PRECONDITION||r.message!==cm)throw r;U("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class b{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e(t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)},t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)})}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&ee(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new b((n,s)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(n,s)},this.catchCallback=i=>{this.wrapFailure(t,i).next(n,s)}})}toPromise(){return new Promise((e,t)=>{this.next(e,t)})}wrapUserFunction(e){try{const t=e();return t instanceof b?t:b.resolve(t)}catch(t){return b.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction(()=>e(t)):b.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction(()=>e(t)):b.reject(t)}static resolve(e){return new b((t,n)=>{t(e)})}static reject(e){return new b((t,n)=>{n(e)})}static waitFor(e){return new b((t,n)=>{let s=0,i=0,o=!1;e.forEach(a=>{++s,a.next(()=>{++i,o&&i===s&&t()},u=>n(u))}),o=!0,i===s&&t()})}static or(e){let t=b.resolve(!1);for(const n of e)t=t.next(s=>s?b.resolve(s):n());return t}static forEach(e,t){const n=[];return e.forEach((s,i)=>{n.push(t.call(this,s,i))}),this.waitFor(n)}static mapArray(e,t){return new b((n,s)=>{const i=e.length,o=new Array(i);let a=0;for(let u=0;u<i;u++){const B=u;t(e[B]).next(l=>{o[B]=l,++a,a===i&&n(o)},l=>s(l))}})}static doWhile(e,t){return new b((n,s)=>{const i=()=>{e()===!0?t().next(()=>{i()},s):n()};i()})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lt="SimpleDb";class Zu{static open(e,t,n,s){try{return new Zu(t,e.transaction(s,n))}catch(i){throw new oo(t,i)}}constructor(e,t){this.action=e,this.transaction=t,this.aborted=!1,this.bn=new zt,this.transaction.oncomplete=()=>{this.bn.resolve()},this.transaction.onabort=()=>{t.error?this.bn.reject(new oo(e,t.error)):this.bn.resolve()},this.transaction.onerror=n=>{const s=Nl(n.target.error);this.bn.reject(new oo(e,s))}}get Sn(){return this.bn.promise}abort(e){e&&this.bn.reject(e),this.aborted||(U(Lt,"Aborting transaction:",e?e.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}vn(){const e=this.transaction;this.aborted||typeof e.commit!="function"||e.commit()}store(e){const t=this.transaction.objectStore(e);return new tT(t)}}class dr{static delete(e){return U(Lt,"Removing database:",e),qr(Fp().indexedDB.deleteDatabase(e)).toPromise()}static Ye(){if(!jp())return!1;if(dr.Dn())return!0;const e=Xe(),t=dr.xn(e),n=0<t&&t<10,s=lm(e),i=0<s&&s<4.5;return!(e.indexOf("MSIE ")>0||e.indexOf("Trident/")>0||e.indexOf("Edge/")>0||n||i)}static Dn(){var e;return typeof process<"u"&&((e=process.__PRIVATE_env)==null?void 0:e.__PRIVATE_USE_MOCK_PERSISTENCE)==="YES"}static Cn(e,t){return e.store(t)}static xn(e){const t=e.match(/i(?:phone|pad|pod) os ([\d_]+)/i),n=t?t[1].split("_").slice(0,2).join("."):"-1";return Number(n)}constructor(e,t,n){this.name=e,this.version=t,this.Fn=n,this.On=null,dr.xn(Xe())===12.2&&Dt("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}async Mn(e){return this.db||(U(Lt,"Opening database:",this.name),this.db=await new Promise((t,n)=>{const s=indexedDB.open(this.name,this.version);s.onsuccess=i=>{const o=i.target.result;t(o)},s.onblocked=()=>{n(new oo(e,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},s.onerror=i=>{const o=i.target.error;o.name==="VersionError"?n(new H(k.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):o.name==="InvalidStateError"?n(new H(k.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+o)):n(new oo(e,o))},s.onupgradeneeded=i=>{U(Lt,'Database "'+this.name+'" requires upgrade from version:',i.oldVersion);const o=i.target.result;this.Fn.Nn(o,s.transaction,i.oldVersion,this.version).next(()=>{U(Lt,"Database upgrade to version "+this.version+" complete")})}})),this.Ln&&(this.db.onversionchange=t=>this.Ln(t)),this.db}Bn(e){this.Ln=e,this.db&&(this.db.onversionchange=t=>e(t))}async runTransaction(e,t,n,s){const i=t==="readonly";let o=0;for(;;){++o;try{this.db=await this.Mn(e);const a=Zu.open(this.db,e,i?"readonly":"readwrite",n),u=s(a).next(B=>(a.vn(),B)).catch(B=>(a.abort(B),b.reject(B))).toPromise();return u.catch(()=>{}),await a.Sn,u}catch(a){const u=a,B=u.name!=="FirebaseError"&&o<3;if(U(Lt,"Transaction failed with error:",u.message,"Retrying:",B),this.close(),!B)return Promise.reject(u)}}}close(){this.db&&this.db.close(),this.db=void 0}}function lm(r){const e=r.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}class eT{constructor(e){this.Un=e,this.kn=!1,this.qn=null}get isDone(){return this.kn}get $n(){return this.qn}set cursor(e){this.Un=e}done(){this.kn=!0}Kn(e){this.qn=e}delete(){return qr(this.Un.delete())}}class oo extends H{constructor(e,t){super(k.UNAVAILABLE,`IndexedDB transaction '${e}' failed: ${t}`),this.name="IndexedDbTransactionError"}}function br(r){return r.name==="IndexedDbTransactionError"}class tT{constructor(e){this.store=e}put(e,t){let n;return t!==void 0?(U(Lt,"PUT",this.store.name,e,t),n=this.store.put(t,e)):(U(Lt,"PUT",this.store.name,"<auto-key>",e),n=this.store.put(e)),qr(n)}add(e){return U(Lt,"ADD",this.store.name,e,e),qr(this.store.add(e))}get(e){return qr(this.store.get(e)).next(t=>(t===void 0&&(t=null),U(Lt,"GET",this.store.name,e,t),t))}delete(e){return U(Lt,"DELETE",this.store.name,e),qr(this.store.delete(e))}count(){return U(Lt,"COUNT",this.store.name),qr(this.store.count())}Qn(e,t){const n=this.options(e,t),s=n.index?this.store.index(n.index):this.store;if(typeof s.getAll=="function"){const i=s.getAll(n.range);return new b((o,a)=>{i.onerror=u=>{a(u.target.error)},i.onsuccess=u=>{o(u.target.result)}})}{const i=this.cursor(n),o=[];return this.Wn(i,(a,u)=>{o.push(u)}).next(()=>o)}}Gn(e,t){const n=this.store.getAll(e,t===null?void 0:t);return new b((s,i)=>{n.onerror=o=>{i(o.target.error)},n.onsuccess=o=>{s(o.target.result)}})}zn(e,t){U(Lt,"DELETE ALL",this.store.name);const n=this.options(e,t);n.jn=!1;const s=this.cursor(n);return this.Wn(s,(i,o,a)=>a.delete())}Hn(e,t){let n;t?n=e:(n={},t=e);const s=this.cursor(n);return this.Wn(s,t)}Jn(e){const t=this.cursor({});return new b((n,s)=>{t.onerror=i=>{const o=Nl(i.target.error);s(o)},t.onsuccess=i=>{const o=i.target.result;o?e(o.primaryKey,o.value).next(a=>{a?o.continue():n()}):n()}})}Wn(e,t){const n=[];return new b((s,i)=>{e.onerror=o=>{i(o.target.error)},e.onsuccess=o=>{const a=o.target.result;if(!a)return void s();const u=new eT(a),B=t(a.primaryKey,a.value,u);if(B instanceof b){const l=B.catch(d=>(u.done(),b.reject(d)));n.push(l)}u.isDone?s():u.$n===null?a.continue():a.continue(u.$n)}}).next(()=>b.waitFor(n))}options(e,t){let n;return e!==void 0&&(typeof e=="string"?n=e:t=e),{index:n,range:t}}cursor(e){let t="next";if(e.reverse&&(t="prev"),e.index){const n=this.store.index(e.index);return e.jn?n.openKeyCursor(e.range,t):n.openCursor(e.range,t)}return this.store.openCursor(e.range,t)}}function qr(r){return new b((e,t)=>{r.onsuccess=n=>{const s=n.target.result;e(s)},r.onerror=n=>{const s=Nl(n.target.error);t(s)}})}let lC=!1;function Nl(r){const e=dr.xn(Xe());if(e>=12.2&&e<13){const t="An internal error was encountered in the Indexed Database server";if(r.message.indexOf(t)>=0){const n=new H("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${t}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return lC||(lC=!0,setTimeout(()=>{throw n},0)),n}}return r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hC="LruGarbageCollector",hm=1048576;function dC([r,e],[t,n]){const s=ae(r,t);return s===0?ae(e,n):s}class nT{constructor(e){this.Yn=e,this.buffer=new De(dC),this.Zn=0}Xn(){return++this.Zn}er(e){const t=[e,this.Xn()];if(this.buffer.size<this.Yn)this.buffer=this.buffer.add(t);else{const n=this.buffer.last();dC(t,n)<0&&(this.buffer=this.buffer.delete(n).add(t))}}get maxValue(){return this.buffer.last()[0]}}class dm{constructor(e,t,n){this.garbageCollector=e,this.asyncQueue=t,this.localStore=n,this.tr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.nr(6e4)}stop(){this.tr&&(this.tr.cancel(),this.tr=null)}get started(){return this.tr!==null}nr(e){U(hC,`Garbage collection scheduled in ${e}ms`),this.tr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,async()=>{this.tr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){br(t)?U(hC,"Ignoring IndexedDB error during garbage collection: ",t):await Es(t)}await this.nr(3e5)})}}class rT{constructor(e,t){this.rr=e,this.params=t}calculateTargetCount(e,t){return this.rr.ir(e).next(n=>Math.floor(t/100*n))}nthSequenceNumber(e,t){if(t===0)return b.resolve(jt.wn);const n=new nT(t);return this.rr.forEachTarget(e,s=>n.er(s.sequenceNumber)).next(()=>this.rr.sr(e,s=>n.er(s))).next(()=>n.maxValue)}removeTargets(e,t,n){return this.rr.removeTargets(e,t,n)}removeOrphanedDocuments(e,t){return this.rr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(U("LruGarbageCollector","Garbage collection skipped; disabled"),b.resolve(BC)):this.getCacheSize(e).next(n=>n<this.params.cacheSizeCollectionThreshold?(U("LruGarbageCollector",`Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),BC):this._r(e,t))}getCacheSize(e){return this.rr.getCacheSize(e)}_r(e,t){let n,s,i,o,a,u,B;const l=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next(d=>(d>this.params.maximumSequenceNumbersToCollect?(U("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${d}`),s=this.params.maximumSequenceNumbersToCollect):s=d,o=Date.now(),this.nthSequenceNumber(e,s))).next(d=>(n=d,a=Date.now(),this.removeTargets(e,n,t))).next(d=>(i=d,u=Date.now(),this.removeOrphanedDocuments(e,n))).next(d=>(B=Date.now(),Gs()<=fe.DEBUG&&U("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-l}ms
	Determined least recently used ${s} in `+(a-o)+`ms
	Removed ${i} targets in `+(u-a)+`ms
	Removed ${d} documents in `+(B-u)+`ms
Total Duration: ${B-l}ms`),b.resolve({didRun:!0,sequenceNumbersCollected:s,targetsRemoved:i,documentsRemoved:d})))}}function fm(r,e){return new rT(r,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cm="firestore.googleapis.com",fC=!0;class CC{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new H(k.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=Cm,this.ssl=fC}else this.host=e.host,this.ssl=e.ssl??fC;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e._customHeaders&&(this._customHeaders={...e._customHeaders}),e.cacheSizeBytes===void 0)this.cacheSizeBytes=um;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<hm)throw new H(k.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}if(ky("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=om(e.experimentalLongPollingOptions??{}),function(n){if(n.timeoutSeconds!==void 0){if(isNaN(n.timeoutSeconds))throw new H(k.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (must not be NaN)`);if(n.timeoutSeconds<5)throw new H(k.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (minimum allowed value is 5)`);if(n.timeoutSeconds>30)throw new H(k.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (maximum allowed value is 30)`)}}(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams,e.grpcFlowControlWindow!==void 0){if(typeof e.grpcFlowControlWindow!="number"||e.grpcFlowControlWindow<=0||e.grpcFlowControlWindow>2147483647||!Number.isInteger(e.grpcFlowControlWindow))throw new H(k.INVALID_ARGUMENT,"grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");this.grpcFlowControlWindow=e.grpcFlowControlWindow}}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&function(n,s){return n.timeoutSeconds===s.timeoutSeconds}(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams&&this.grpcFlowControlWindow===e.grpcFlowControlWindow&&function(n,s){if(n===s)return!0;if(!n||!s)return!1;const i=Object.keys(n),o=Object.keys(s);if(i.length!==o.length)return!1;for(const a of i)if(n[a]!==s[a])return!1;return!0}(this._customHeaders,e._customHeaders)}}let ec=class{constructor(e,t,n,s){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=n,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new CC({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new H(k.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new H(k.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new CC(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=function(n){if(!n)return new kw;switch(n.type){case"firstParty":return new Gw(n.sessionIndex||"0",n.iamToken||null,n.authTokenFactory||null);case"provider":return n.client;default:throw new H(k.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}}(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return function(t){const n=cC.get(t);n&&(U(Xw,"Removing Datastore"),cC.delete(t),n.terminate())}(this),Promise.resolve()}};function sT(r,e,t,n={}){var B;r=Ye(r,ec);const s=vr(e),i=r._getSettings(),o={...i,emulatorOptions:r._getEmulatorOptions()},a=`${e}:${t}`;s&&ju(`https://${a}`),i.host!==Cm&&i.host!==a&&tn("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const u={...i,host:a,ssl:s,emulatorOptions:n};if(!pn(u,o)&&(r._setSettings(u),n.mockUserToken)){let l,d;if(typeof n.mockUserToken=="string")l=n.mockUserToken,d=ut.MOCK_USER;else{l=Gp(n.mockUserToken,(B=r._app)==null?void 0:B.options.projectId);const C=n.mockUserToken.sub||n.mockUserToken.user_id;if(!C)throw new H(k.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");d=new ut(C)}r._authCredentials=new xw(new im(l,d))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dn{constructor(e,t,n){this.converter=t,this._query=n,this.type="query",this.firestore=e}withConverter(e){return new Dn(this.firestore,e,this._query)}}class Le{constructor(e,t,n){this.converter=t,this._key=n,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new fr(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new Le(this.firestore,e,this._key)}toJSON(){return{type:Le._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,n){if(zo(t,Le._jsonSchema))return new Le(e,n||null,new W(de.fromString(t.referencePath)))}}Le._jsonSchemaVersion="firestore/documentReference/1.0",Le._jsonSchema={type:Je("string",Le._jsonSchemaVersion),referencePath:Je("string")};class fr extends Dn{constructor(e,t,n){super(e,t,Yo(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new Le(this.firestore,null,new W(e))}withConverter(e){return new fr(this.firestore,e,this._path)}}function TO(r,e,...t){if(r=re(r),dg("collection","path",e),r instanceof ec){const n=de.fromString(e,...t);return Vf(n),new fr(r,null,n)}{if(!(r instanceof Le||r instanceof fr))throw new H(k.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=r._path.child(de.fromString(e,...t));return Vf(n),new fr(r.firestore,null,n)}}function iT(r,e,...t){if(r=re(r),arguments.length===1&&(e=gl.newId()),dg("doc","path",e),r instanceof ec){const n=de.fromString(e,...t);return xf(n),new Le(r,null,new W(n))}{if(!(r instanceof Le||r instanceof fr))throw new H(k.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=r._path.child(de.fromString(e,...t));return xf(n),new Le(r.firestore,r instanceof fr?r.converter:null,new W(n))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pt{constructor(e){this._values=(e||[]).map(t=>t)}toArray(){return this._values.map(e=>e)}isEqual(e){return function(n,s){if(n.length!==s.length)return!1;for(let i=0;i<n.length;++i)if(n[i]!==s[i])return!1;return!0}(this._values,e._values)}toJSON(){return{type:Pt._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(zo(e,Pt._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every(t=>typeof t=="number"))return new Pt(e.vectorValues);throw new H(k.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}Pt._jsonSchemaVersion="firestore/vectorValue/1.0",Pt._jsonSchema={type:Je("string",Pt._jsonSchemaVersion),vectorValues:Je("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oT=/^__.*__$/;class aT{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return this.fieldMask!==null?new Mn(e,this.data,this.fieldMask,t,this.fieldTransforms):new li(e,this.data,t,this.fieldTransforms)}}class pm{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return new Mn(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function gm(r){switch(r){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw ee(40011,{dataSource:r})}}class tc{constructor(e,t,n,s,i,o){this.settings=e,this.databaseId=t,this.serializer=n,this.ignoreUndefinedProperties=s,i===void 0&&this.validatePath(),this.fieldTransforms=i||[],this.fieldMask=o||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}contextWith(e){return new tc({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}childContextForField(e){var s;const t=(s=this.path)==null?void 0:s.child(e),n=this.contextWith({path:t,arrayElement:!1});return n.validatePathSegment(e),n}childContextForFieldPath(e){var s;const t=(s=this.path)==null?void 0:s.child(e),n=this.contextWith({path:t,arrayElement:!1});return n.validatePath(),n}childContextForArray(e){return this.contextWith({path:void 0,arrayElement:!0})}createError(e){return yu(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find(t=>e.isPrefixOf(t))!==void 0||this.fieldTransforms.find(t=>e.isPrefixOf(t.field))!==void 0}validatePath(){if(this.path)for(let e=0;e<this.path.length;e++)this.validatePathSegment(this.path.get(e))}validatePathSegment(e){if(e.length===0)throw this.createError("Document fields must not be empty");if(gm(this.dataSource)&&oT.test(e))throw this.createError('Document fields cannot begin and end with "__"')}}class uT{constructor(e,t,n){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=n||Xu(e)}createContext(e,t,n,s=!1){return new tc({dataSource:e,methodName:t,targetDoc:n,path:$e.emptyPath(),arrayElement:!1,hasConverter:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function Ci(r){const e=r._freezeSettings(),t=Xu(r._databaseId);return new uT(r._databaseId,!!e.ignoreUndefinedProperties,t)}function nc(r,e,t,n,s,i={}){const o=r.createContext(i.merge||i.mergeFields?2:0,e,t,s);Gl("Data must be an object, but it was:",o,n);const a=_m(n,o);let u,B;if(i.merge)u=new vt(o.fieldMask),B=o.fieldTransforms;else if(i.mergeFields){const l=[];for(const d of i.mergeFields){const C=Fn(e,d,t);if(!o.contains(C))throw new H(k.INVALID_ARGUMENT,`Field '${C}' is specified in your field mask but missing from your input data.`);ym(l,C)||l.push(C)}u=new vt(l),B=o.fieldTransforms.filter(d=>u.covers(d.field))}else u=null,B=o.fieldTransforms;return new aT(new We(a),u,B)}class ea extends _s{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.createError(`${this._methodName}() can only appear at the top level of your update data`):e.createError(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof ea}}function mm(r,e,t){return new tc({dataSource:3,targetDoc:e.settings.targetDoc,methodName:r._methodName,arrayElement:t},e.databaseId,e.serializer,e.ignoreUndefinedProperties)}class Fl extends _s{_toFieldTransform(e){return new $o(e.path,new ei)}isEqual(e){return e instanceof Fl}}class Ll extends _s{constructor(e,t){super(e),this.ar=t}_toFieldTransform(e){const t=mm(this,e,!0),n=this.ar.map(i=>gn(i,t)),s=new ls(n);return new $o(e.path,s)}isEqual(e){return e instanceof Ll&&pn(this.ar,e.ar)}}class kl extends _s{constructor(e,t){super(e),this.ar=t}_toFieldTransform(e){const t=mm(this,e,!0),n=this.ar.map(i=>gn(i,t)),s=new hs(n);return new $o(e.path,s)}isEqual(e){return e instanceof kl&&pn(this.ar,e.ar)}}class xl extends _s{constructor(e,t){super(e),this.ur=t}_toFieldTransform(e){const t=new ds(e.serializer,Wu(e.serializer,this.ur));return new $o(e.path,t)}isEqual(e){return e instanceof xl&&(this.ur===e.ur||Number.isNaN(this.ur)&&Number.isNaN(e.ur))}}function Vl(r,e,t,n){const s=r.createContext(1,e,t);Gl("Data must be an object, but it was:",s,n);const i=[],o=We.empty();Pr(n,(u,B)=>{const l=Dm(e,u,t);B=re(B);const d=s.childContextForFieldPath(l);if(B instanceof ea)i.push(l);else{const C=gn(B,d);C!=null&&(i.push(l),o.set(l,C))}});const a=new vt(i);return new pm(o,a,s.fieldTransforms)}function Ml(r,e,t,n,s,i){const o=r.createContext(1,e,t),a=[Fn(e,n,t)],u=[s];if(i.length%2!=0)throw new H(k.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let C=0;C<i.length;C+=2)a.push(Fn(e,i[C])),u.push(i[C+1]);const B=[],l=We.empty();for(let C=a.length-1;C>=0;--C)if(!ym(B,a[C])){const g=a[C];let m=u[C];m=re(m);const v=o.childContextForFieldPath(g);if(m instanceof ea)B.push(g);else{const N=gn(m,v);N!=null&&(B.push(g),l.set(g,N))}}const d=new vt(B);return new pm(l,d,o.fieldTransforms)}function cT(r,e,t,n=!1){return gn(t,r.createContext(n?4:3,e))}function gn(r,e,t){if(Im(r=re(r)))return Gl("Unsupported field value:",e,r),_m(r,e);if(r instanceof _s)return function(s,i){if(!gm(i.dataSource))throw i.createError(`${s._methodName}() can only be used with update() and set()`);if(!i.path)throw i.createError(`${s._methodName}() is not currently supported inside arrays`);const o=s._toFieldTransform(i);o&&i.fieldTransforms.push(o)}(r,e),null;if(r===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),r instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.createError("Nested arrays are not supported");return function(s,i){const o=[];let a=0;for(const u of s){let B=gn(u,i.childContextForArray(a));B==null&&(B={nullValue:"NULL_VALUE"}),o.push(B),a++}return{arrayValue:{values:o}}}(r,e)}return function(s,i,o){if((s=re(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return Wu(i.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const a=_e.fromDate(s);return{timestampValue:es(i.serializer,a)}}if(s instanceof _e){const a=new _e(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:es(i.serializer,a)}}if(Em(s)){const a=_e.fromInstant(s),u=new _e(a.seconds,1e3*Math.floor(a.nanoseconds/1e3));return{timestampValue:es(i.serializer,u)}}if(s instanceof fn)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof xt)return{bytesValue:Kg(i.serializer,s._byteString)};if(s instanceof Le){const a=i.databaseId,u=s.firestore._databaseId;if(!u.isEqual(a))throw i.createError(`Document reference is for database ${u.projectId}/${u.database} but should be for database ${a.projectId}/${a.database}`);return{referenceValue:bl(s.firestore._databaseId||i.databaseId,s._key.path)}}if(s instanceof Pt)return function(u,B){const l=u instanceof Pt?u.toArray():u;return{mapValue:{fields:{[ml]:{stringValue:_l},[cs]:{arrayValue:{values:l.map(C=>{if(typeof C!="number")throw B.createError("VectorValues must only contain numeric values.");return zu(B.serializer,C)})}}}}}}(s,i);if(rm(s))return s._toProto(i.serializer);throw i.createError(`Unsupported field value: ${Ju(s)}`)}(r,e)}function _m(r,e){const t={};return hg(r)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):Pr(r,(n,s)=>{const i=gn(s,e.childContextForField(n));i!=null&&(t[n]=i)}),{mapValue:{fields:t}}}function Em(r){if(typeof r!="object"||r===null)return!1;if(typeof Temporal<"u"&&typeof Temporal.Instant=="function"&&r instanceof Temporal.Instant)return!0;const e=r;return e[Symbol.toStringTag]==="Temporal.Instant"&&typeof e.t=="bigint"}function Im(r){return!(typeof r!="object"||r===null||r instanceof Array||r instanceof Date||r instanceof _e||r instanceof fn||r instanceof xt||r instanceof Le||r instanceof _s||r instanceof Pt||Em(r)||rm(r))}function Gl(r,e,t){if(!Im(t)||!Ko(t)){const n=Ju(t);throw n==="an object"?e.createError(r+" a custom object"):e.createError(r+" "+n)}}function Fn(r,e,t){if((e=re(e))instanceof fi)return e._internalPath;if(typeof e=="string")return Dm(r,e);throw yu("Field path arguments must be of type string or ",r,!1,void 0,t)}const BT=new RegExp("[~\\*/\\[\\]]");function Dm(r,e,t){if(e.search(BT)>=0)throw yu(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,r,!1,void 0,t);try{return new fi(...e.split("."))._internalPath}catch{throw yu(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,r,!1,void 0,t)}}function yu(r,e,t,n,s){const i=n&&!n.isEmpty(),o=s!==void 0;let a=`Function ${e}() called with invalid data`;t&&(a+=" (via `toFirestore()`)"),a+=". ";let u="";return(i||o)&&(u+=" (found",i&&(u+=` in field ${n}`),o&&(u+=` in document ${s}`),u+=")"),new H(k.INVALID_ARGUMENT,a+r+u)}function ym(r,e){return r.some(t=>t.isEqual(e))}function wm(r){return typeof r._readUserData=="function"}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gt{constructor(e){this.optionDefinitions=e}_getKnownOptions(e,t){const n=We.empty();for(const s in this.optionDefinitions)if(this.optionDefinitions.hasOwnProperty(s)){const i=this.optionDefinitions[s];if(s in e){const o=e[s];let a;i.nestedOptions&&Ko(o)?a={mapValue:{fields:new gt(i.nestedOptions).getOptionsProto(t,o)}}:o&&(a=gn(o,t)??void 0),a&&n.set($e.fromServerFormat(i.serverName),a)}}return n}getOptionsProto(e,t,n){const s=this._getKnownOptions(t,e);if(n){const i=new Map(lg(n,(o,a)=>[$e.fromServerFormat(a),o!==void 0?gn(o,e):null]));s.setAll(i)}return s.value.mapValue.fields??{}}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function lT(r){return typeof r=="object"&&r!==null&&!!("nullValue"in r&&(r.nullValue===null||r.nullValue==="NULL_VALUE")||"booleanValue"in r&&(r.booleanValue===null||typeof r.booleanValue=="boolean")||"integerValue"in r&&(r.integerValue===null||typeof r.integerValue=="number"||typeof r.integerValue=="string")||"doubleValue"in r&&(r.doubleValue===null||typeof r.doubleValue=="number")||"timestampValue"in r&&(r.timestampValue===null||function(t){return typeof t=="object"&&t!==null&&"seconds"in t&&(t.seconds===null||typeof t.seconds=="number"||typeof t.seconds=="string")&&"nanos"in t&&(t.nanos===null||typeof t.nanos=="number")}(r.timestampValue))||"stringValue"in r&&(r.stringValue===null||typeof r.stringValue=="string")||"bytesValue"in r&&(r.bytesValue===null||r.bytesValue instanceof Uint8Array)||"referenceValue"in r&&(r.referenceValue===null||typeof r.referenceValue=="string")||"geoPointValue"in r&&(r.geoPointValue===null||function(t){return typeof t=="object"&&t!==null&&"latitude"in t&&(t.latitude===null||typeof t.latitude=="number")&&"longitude"in t&&(t.longitude===null||typeof t.longitude=="number")}(r.geoPointValue))||"arrayValue"in r&&(r.arrayValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("values"in t)||t.values!==null&&!Array.isArray(t.values))}(r.arrayValue))||"mapValue"in r&&(r.mapValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("fields"in t)||t.fields!==null&&!Ko(t.fields))}(r.mapValue))||"fieldReferenceValue"in r&&(r.fieldReferenceValue===null||typeof r.fieldReferenceValue=="string")||"functionValue"in r&&(r.functionValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("name"in t)||t.name!==null&&typeof t.name!="string"||!("args"in t)||t.args!==null&&!Array.isArray(t.args))}(r.functionValue))||"pipelineValue"in r&&(r.pipelineValue===null||function(t){return typeof t=="object"&&t!==null&&!(!("stages"in t)||t.stages!==null&&!Array.isArray(t.stages))}(r.pipelineValue)))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function AO(){return new ea("deleteField")}function RO(){return new Fl("serverTimestamp")}function vO(...r){return new Ll("arrayUnion",r)}function PO(...r){return new kl("arrayRemove",r)}function bO(r){return new xl("increment",r)}function hT(r){return new Pt(r)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function K(r){let e;return r instanceof Is?r:(e=Ko(r)?gT(r):r instanceof Array?mT(r):Tm(r,void 0),e)}function hB(r){if(r instanceof Is)return r;if(r instanceof Pt)return So(r);if(Array.isArray(r))return So(hT(r));throw new Error("Unsupported value: "+typeof r)}function Ul(r){return Hy(r)?ru(r):K(r)}class Is{constructor(){this._protoValueType="ProtoValue"}add(e){return new x("add",[this,K(e)],"add")}asBoolean(){if(this instanceof yr)return this;if(this instanceof ys)return new Rm(this);if(this instanceof Ds)return new pT(this);if(this instanceof x)return new Am(this);throw new H("invalid-argument",`Conversion of type ${typeof this} to BooleanExpression not supported.`)}subtract(e){return new x("subtract",[this,K(e)],"subtract")}multiply(e){return new x("multiply",[this,K(e)],"multiply")}divide(e){return new x("divide",[this,K(e)],"divide")}mod(e){return new x("mod",[this,K(e)],"mod")}equal(e){return new x("equal",[this,K(e)],"equal").asBoolean()}notEqual(e){return new x("not_equal",[this,K(e)],"notEqual").asBoolean()}lessThan(e){return new x("less_than",[this,K(e)],"lessThan").asBoolean()}lessThanOrEqual(e){return new x("less_than_or_equal",[this,K(e)],"lessThanOrEqual").asBoolean()}greaterThan(e){return new x("greater_than",[this,K(e)],"greaterThan").asBoolean()}greaterThanOrEqual(e){return new x("greater_than_or_equal",[this,K(e)],"greaterThanOrEqual").asBoolean()}arrayConcat(e,...t){const n=[e,...t].map(s=>K(s));return new x("array_concat",[this,...n],"arrayConcat")}arrayContains(e){return new x("array_contains",[this,K(e)],"arrayContains").asBoolean()}arrayContainsAll(e){const t=Array.isArray(e)?new Xi(e.map(K),"arrayContainsAll"):e;return new x("array_contains_all",[this,t],"arrayContainsAll").asBoolean()}arrayContainsAny(e){const t=Array.isArray(e)?new Xi(e.map(K),"arrayContainsAny"):e;return new x("array_contains_any",[this,t],"arrayContainsAny").asBoolean()}arrayReverse(){return new x("array_reverse",[this])}arrayLength(){return new x("array_length",[this],"arrayLength")}equalAny(e){const t=Array.isArray(e)?new Xi(e.map(K),"equalAny"):e;return new x("equal_any",[this,t],"equalAny").asBoolean()}notEqualAny(e){const t=Array.isArray(e)?new Xi(e.map(K),"notEqualAny"):e;return new x("not_equal_any",[this,t],"notEqualAny").asBoolean()}exists(){return new x("exists",[this],"exists").asBoolean()}charLength(){return new x("char_length",[this],"charLength")}like(e){return new x("like",[this,K(e)],"like").asBoolean()}regexContains(e){return new x("regex_contains",[this,K(e)],"regexContains").asBoolean()}regexFind(e){return new x("regex_find",[this,K(e)],"regexFind")}regexFindAll(e){return new x("regex_find_all",[this,K(e)],"regexFindAll")}regexMatch(e){return new x("regex_match",[this,K(e)],"regexMatch").asBoolean()}stringContains(e){return new x("string_contains",[this,K(e)],"stringContains").asBoolean()}startsWith(e){return new x("starts_with",[this,K(e)],"startsWith").asBoolean()}endsWith(e){return new x("ends_with",[this,K(e)],"endsWith").asBoolean()}toLower(){return new x("to_lower",[this],"toLower")}toUpper(){return new x("to_upper",[this],"toUpper")}trim(e){const t=[this];return e&&t.push(K(e)),new x("trim",t,"trim")}ltrim(e){const t=[this];return e&&t.push(K(e)),new x("ltrim",t,"ltrim")}rtrim(e){const t=[this];return e&&t.push(K(e)),new x("rtrim",t,"rtrim")}type(){return new x("type",[this])}isType(e){return new x("is_type",[this,So(e)],"isType").asBoolean()}stringConcat(e,...t){const n=[e,...t].map(K);return new x("string_concat",[this,...n],"stringConcat")}stringIndexOf(e){return new x("string_index_of",[this,K(e)],"stringIndexOf")}stringRepeat(e){return new x("string_repeat",[this,K(e)],"stringRepeat")}stringReplaceAll(e,t){return new x("string_replace_all",[this,K(e),K(t)],"stringReplaceAll")}stringReplaceOne(e,t){return new x("string_replace_one",[this,K(e),K(t)],"stringReplaceOne")}concat(e,...t){const n=[e,...t].map(K);return new x("concat",[this,...n],"concat")}reverse(){return new x("reverse",[this],"reverse")}arrayFilter(e,t){return new x("array_filter",[this,K(e),t],"arrayFilter")}arrayTransform(e,t){return new x("array_transform",[this,K(e),t],"arrayTransform")}arrayTransformWithIndex(e,t,n){return new x("array_transform",[this,K(e),K(t),n],"arrayTransformWithIndex")}arraySlice(e,t){const n=[this,K(e)];return t!==void 0&&n.push(K(t)),new x("array_slice",n,"arraySlice")}arrayFirst(){return new x("array_first",[this],"arrayFirst")}arrayFirstN(e){return new x("array_first_n",[this,K(e)],"arrayFirstN")}arrayLast(){return new x("array_last",[this],"arrayLast")}arrayLastN(e){return new x("array_last_n",[this,K(e)],"arrayLastN")}arrayMaximum(){return new x("maximum",[this],"arrayMaximum")}arrayMaximumN(e){return new x("maximum_n",[this,K(e)],"arrayMaximumN")}arrayMinimum(){return new x("minimum",[this],"arrayMinimum")}arrayMinimumN(e){return new x("minimum_n",[this,K(e)],"arrayMinimumN")}arrayIndexOf(e){return new x("array_index_of",[this,K(e),K("first")],"arrayIndexOf")}arrayLastIndexOf(e){return new x("array_index_of",[this,K(e),K("last")],"arrayLastIndexOf")}arrayIndexOfAll(e){return new x("array_index_of_all",[this,K(e)],"arrayIndexOfAll")}byteLength(){return new x("byte_length",[this],"byteLength")}ceil(){return new x("ceil",[this])}floor(){return new x("floor",[this])}abs(){return new x("abs",[this])}exp(){return new x("exp",[this])}mapGet(e){return new x("map_get",[this,So(e)],"mapGet")}mapSet(e,t,...n){const s=[this,K(e),K(t),...n.map(K)];return new x("map_set",s,"mapSet")}mapKeys(){return new x("map_keys",[this],"mapKeys")}mapValues(){return new x("map_values",[this],"mapValues")}mapEntries(){return new x("map_entries",[this],"mapEntries")}getField(e){return new x("get_field",[this,K(e)],"get_field")}count(){return Ft._create("count",[this],"count")}sum(){return Ft._create("sum",[this],"sum")}average(){return Ft._create("average",[this],"average")}minimum(){return Ft._create("minimum",[this],"minimum")}maximum(){return Ft._create("maximum",[this],"maximum")}first(){return Ft._create("first",[this],"first")}last(){return Ft._create("last",[this],"last")}arrayAgg(){return Ft._create("array_agg",[this],"arrayAgg")}arrayAggDistinct(){return Ft._create("array_agg_distinct",[this],"arrayAggDistinct")}countDistinct(){return Ft._create("count_distinct",[this],"countDistinct")}logicalMaximum(e,...t){const n=[e,...t];return new x("maximum",[this,...n.map(K)],"logicalMaximum")}logicalMinimum(e,...t){const n=[e,...t];return new x("minimum",[this,...n.map(K)],"minimum")}vectorLength(){return new x("vector_length",[this],"vectorLength")}cosineDistance(e){return new x("cosine_distance",[this,hB(e)],"cosineDistance")}dotProduct(e){return new x("dot_product",[this,hB(e)],"dotProduct")}euclideanDistance(e){return new x("euclidean_distance",[this,hB(e)],"euclideanDistance")}unixMicrosToTimestamp(){return new x("unix_micros_to_timestamp",[this],"unixMicrosToTimestamp")}timestampToUnixMicros(){return new x("timestamp_to_unix_micros",[this],"timestampToUnixMicros")}unixMillisToTimestamp(){return new x("unix_millis_to_timestamp",[this],"unixMillisToTimestamp")}timestampToUnixMillis(){return new x("timestamp_to_unix_millis",[this],"timestampToUnixMillis")}unixSecondsToTimestamp(){return new x("unix_seconds_to_timestamp",[this],"unixSecondsToTimestamp")}timestampToUnixSeconds(){return new x("timestamp_to_unix_seconds",[this],"timestampToUnixSeconds")}timestampAdd(e,t){return new x("timestamp_add",[this,K(e),K(t)],"timestampAdd")}timestampSubtract(e,t){return new x("timestamp_subtract",[this,K(e),K(t)],"timestampSubtract")}timestampDiff(e,t){return new x("timestamp_diff",[this,Ul(e),K(t)],"timestampDiff")}timestampExtract(e,t){const n=[this,K(e)];return t&&n.push(K(t)),new x("timestamp_extract",n,"timestampExtract")}documentId(){return new x("document_id",[this],"documentId")}parent(){return new x("parent",[this],"parent")}substring(e,t){const n=K(e);return new x("substring",t===void 0?[this,n]:[this,n,K(t)],"substring")}arrayGet(e){return new x("array_get",[this,K(e)],"arrayGet")}isError(){return new x("is_error",[this],"isError").asBoolean()}ifError(e){const t=new x("if_error",[this,K(e)],"ifError");return e instanceof yr?t.asBoolean():t}isAbsent(){return new x("is_absent",[this],"isAbsent").asBoolean()}mapRemove(e){return new x("map_remove",[this,K(e)],"mapRemove")}mapMerge(e,...t){const n=K(e),s=t.map(K);return new x("map_merge",[this,n,...s],"mapMerge")}pow(e){return new x("pow",[this,K(e)])}trunc(e){return e===void 0?new x("trunc",[this]):new x("trunc",[this,K(e)],"trunc")}round(e){return e===void 0?new x("round",[this]):new x("round",[this,K(e)],"round")}collectionId(){return new x("collection_id",[this])}length(){return new x("length",[this])}ln(){return new x("ln",[this])}sqrt(){return new x("sqrt",[this])}stringReverse(){return new x("string_reverse",[this])}ifAbsent(e){return new x("if_absent",[this,K(e)],"ifAbsent")}ifNull(e){return new x("if_null",[this,K(e)],"ifNull")}coalesce(e,...t){return new x("coalesce",[this,K(e),...t.map(K)],"coalesce")}join(e){return new x("join",[this,K(e)],"join")}log10(){return new x("log10",[this])}arraySum(){return new x("sum",[this])}split(e){return new x("split",[this,K(e)])}timestampTruncate(e,t){const n=[this,K(e)];return t&&n.push(K(t)),new x("timestamp_trunc",n)}ascending(){return _T(this)}descending(){return ET(this)}as(e){return new fT(this,e,"as")}}class Ft{constructor(e,t){this.name=e,this.params=t,this.exprType="AggregateFunction",this._protoValueType="ProtoValue"}static _create(e,t,n){const s=new Ft(e,t);return s._methodName=n,s}as(e){return new dT(this,e,"as")}_toProto(e){return{functionValue:{name:this.name,args:this.params.map(t=>t._toProto(e))}}}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach(t=>t._readUserData(e))}}class dT{constructor(e,t,n){this.aggregate=e,this.alias=t,this._methodName=n}_readUserData(e){this.aggregate._readUserData(e)}}class fT{constructor(e,t,n){this.expr=e,this.alias=t,this._methodName=n,this.exprType="AliasedExpression",this.selectable=!0}_readUserData(e){this.expr._readUserData(e)}}class Xi extends Is{constructor(e,t){super(),this.cr=e,this._methodName=t,this.expressionType="ListOfExpressions"}_toProto(e){return{arrayValue:{values:this.cr.map(t=>t._toProto(e))}}}_readUserData(e){this.cr.forEach(t=>t._readUserData(e))}}class Ds extends Is{constructor(e,t){super(),this.fieldPath=e,this._methodName=t,this.expressionType="Field",this.selectable=!0}get _fieldPath(){return this.fieldPath}get fieldName(){return this.fieldPath.canonicalString()}get alias(){return this.fieldName}get expr(){return this}geoDistance(e){return new x("geo_distance",[this,K(e)],"geoDistance")}_toProto(e){return{fieldReferenceValue:this.fieldPath.canonicalString()}}_readUserData(e){}}function ru(r){return CT(r,"field")}function CT(r,e){return new Ds(typeof r=="string"?an===r?Lw()._internalPath:Fn("field",r):r._internalPath,e)}class ys extends Is{constructor(e,t){super(),this.value=e,this._methodName=t,this.expressionType="Constant"}static _fromProto(e){const t=new ys(e,void 0);return t._protoValue=e,t}_toProto(e){return j(this._protoValue!==void 0,237),this._protoValue}_getValue(){return this._protoValue}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,lT(this._protoValue)||(this._protoValue=gn(this.value,e))}}function So(r,e){return Tm(r,"constant")}function Tm(r,e){const t=new ys(r,e);return typeof r=="boolean"?new Rm(t):t}class x extends Is{constructor(e,t,n,s){super(),this.name=e,this.params=t,this.expressionType="Function",this._optionsProto=void 0,n!==void 0&&(this._methodName=n),s!==void 0&&(this._options=s)}get _optionsUtil(){return new gt({})}_toProto(e){const t={functionValue:{name:this.name,args:this.params.map(n=>n._toProto(e))}};return this._optionsProto&&(t.functionValue.options=this._optionsProto),t}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach(t=>t._readUserData(e)),this._options&&(this._optionsProto=this._optionsUtil.getOptionsProto(e,this._options))}}class yr extends Is{get _methodName(){return this._expr._methodName}countIf(){return Ft._create("count_if",[this],"countIf")}not(){return new x("not",[this],"not").asBoolean()}conditional(e,t){return new x("conditional",[this,e,t],"conditional")}ifError(e){const t=K(e),n=new x("if_error",[this,t],"ifError");return t instanceof yr?n.asBoolean():n}_toProto(e){return this._expr._toProto(e)}_readUserData(e){this._expr._readUserData(e)}}class Am extends yr{constructor(e){super(),this._expr=e,this.expressionType="Function"}}class Rm extends yr{constructor(e){super(),this._expr=e,this.expressionType="Constant"}_getValue(){return this._expr._getValue()}}class pT extends yr{constructor(e){super(),this._expr=e,this.expressionType="Field"}}function gT(r,e){const t=[];for(const n in r)if(Object.prototype.hasOwnProperty.call(r,n)){const s=r[n];t.push(So(n)),t.push(K(s))}return new x("map",t,"map")}function mT(r){return function(t,n){return new x("array",t.map(s=>K(s)),n)}(r,"array")}function _T(r){return new Hl(Ul(r),"ascending","ascending")}function ET(r){return new Hl(Ul(r),"descending","descending")}class Hl{constructor(e,t,n){this.expr=e,this.direction=t,this._methodName=n,this._protoValueType="ProtoValue"}_toProto(e){return{mapValue:{fields:{direction:sm(this.direction),expression:this.expr._toProto(e)}}}}_readUserData(e){this.expr._readUserData(e)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ut{constructor(e){this.optionsProto=void 0,{rawOptions:this.rawOptions,...this.knownOptions}=e}_readUserData(e){this.optionsProto=this._optionsUtil.getOptionsProto(e,this.knownOptions,this.rawOptions)}_toProto(e){return{name:this._name,options:this.optionsProto}}}class vm extends Ut{get _name(){return"add_fields"}get _optionsUtil(){return new gt({})}constructor(e,t){super(t),this.fields=e}_toProto(e){return{...super._toProto(e),args:[bo(e,this.fields)]}}_readUserData(e){super._readUserData(e),Tr(this.fields,e)}}class Pm extends Ut{get _name(){return"aggregate"}get _optionsUtil(){return new gt({})}constructor(e,t,n){super(n),this.groups=e,this.accumulators=t}_toProto(e){return{...super._toProto(e),args:[bo(e,this.accumulators),bo(e,this.groups)]}}_readUserData(e){super._readUserData(e),Tr(this.groups,e),Tr(this.accumulators,e)}}class bm extends Ut{get _name(){return"distinct"}get _optionsUtil(){return new gt({})}constructor(e,t){super(t),this.groups=e}_toProto(e){return{...super._toProto(e),args:[bo(e,this.groups)]}}_readUserData(e){super._readUserData(e),Tr(this.groups,e)}}class ta extends Ut{get _name(){return"collection"}get _optionsUtil(){return new gt({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.hr=e.startsWith("/")?e:"/"+e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:this.hr}]}}_readUserData(e){super._readUserData(e)}}class na extends Ut{get _name(){return"collection_group"}get _optionsUtil(){return new gt({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.collectionId=e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:""},{stringValue:this.collectionId}]}}_readUserData(e){super._readUserData(e)}}class rc extends Ut{get _name(){return"database"}get _optionsUtil(){return new gt({})}_toProto(e){return{...super._toProto(e)}}_readUserData(e){super._readUserData(e)}}class sc extends Ut{get _name(){return"documents"}get _optionsUtil(){return new gt({})}constructor(e,t){if(super(t),!e||e.length===0)throw new H(k.INVALID_ARGUMENT,"Empty document paths are not allowed in DocumentsSource");const n=e.map(i=>i.startsWith("/")?i:"/"+i),s=new Set(n);if(s.size!==n.length)throw new H(k.INVALID_ARGUMENT,"Duplicate document paths are not allowed in DocumentsSource");this.Tr=n,this.Pr=s}_toProto(e){return{...super._toProto(e),args:this.Tr.map(t=>({referenceValue:t}))}}_readUserData(e){super._readUserData(e)}}class ra extends Ut{get _name(){return"where"}get _optionsUtil(){return new gt({})}constructor(e,t){super(t),this.condition=e}_toProto(e){return{...super._toProto(e),args:[this.condition._toProto(e)]}}_readUserData(e){super._readUserData(e),Tr(this.condition,e)}}class wr extends Ut{get _name(){return"limit"}get _optionsUtil(){return new gt({})}constructor(e,t){j(!isNaN(e)&&e!==1/0&&e!==-1/0,34860),super(t),this.limit=e}_toProto(e){return{...super._toProto(e),args:[Wu(e,this.limit)]}}}class pC extends Ut{get _name(){return"offset"}get _optionsUtil(){return new gt({})}constructor(e,t){super(t),this.offset=e}_toProto(e){return{...super._toProto(e),args:[Wu(e,this.offset)]}}}class IT extends Ut{get _name(){return"select"}get _optionsUtil(){return new gt({})}constructor(e,t){super(t),this.selections=e}_toProto(e){return{...super._toProto(e),args:[bo(e,this.selections)]}}_readUserData(e){super._readUserData(e),Tr(this.selections,e)}}class cn extends Ut{get _name(){return"sort"}get _optionsUtil(){return new gt({})}constructor(e,t){super(t),this.orderings=e}_toProto(e){return{...super._toProto(e),args:this.orderings.map(t=>t._toProto(e))}}_readUserData(e){super._readUserData(e),Tr(this.orderings,e)}}class ql extends Ut{get _name(){return"replace_with"}get _optionsUtil(){return new gt({})}constructor(e,t){super(t),this.map=e}_toProto(e){return{...super._toProto(e),args:[this.map._toProto(e),sm(ql.Ir)]}}_readUserData(e){super._readUserData(e),Tr(this.map,e)}}ql.Ir="full_replace";function Tr(r,e){return wm(r)?r._readUserData(e):Array.isArray(r)?r.forEach(t=>t._readUserData(e)):r instanceof Map?r.forEach(t=>t._readUserData(e)):Object.values(r).forEach(t=>t._readUserData(e)),r}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ao{constructor(e,t,n,s){this._db=e,this.userDataReader=t,this._userDataWriter=n,this.stages=s}Vr(e,t){const n=this.userDataReader.createContext(3,e);return wm(t)?t._readUserData(n):Array.isArray(t)?t.forEach(s=>s._readUserData(n)):t.forEach(s=>s._readUserData(n)),t}where(e){const t=this.stages.map(n=>n);return this.Vr("where",e),t.push(new ra(e,{})),new ao(this._db,this.userDataReader,this._userDataWriter,t)}limit(e){const t=this.stages.map(n=>n);return t.push(new wr(e,{})),new ao(this._db,this.userDataReader,this._userDataWriter,t)}sort(e,...t){const n=this.stages.map(s=>s);return"orderings"in e?n.push(new cn(this.Vr("sort",e.orderings),{})):n.push(new cn(this.Vr("sort",[e,...t]),{})),new ao(this._db,this.userDataReader,this._userDataWriter,n)}dr(e){return{pipeline:{stages:this.stages.map(t=>t._toProto(e))}}}}// Copyright 2024 Google LLC* @license
class dt{constructor(e,t,n){this.serializer=e,this.stages=t,this.listenOptions=n,this.isCorePipeline=!0}getPipelineCollection(){return sa(this)}getPipelineCollectionGroup(){return jl(this)}getPipelineCollectionId(){return DT(this)}getPipelineDocuments(){return WB(this)}getPipelineFlavor(){return function(t){let n="exact";return t.stages.forEach((s,i)=>{s._name!==bm.name&&s._name!==Pm.name||(n="keyless"),s._name===IT.name&&n==="exact"&&(n="augmented"),s._name===vm.name&&i<t.stages.length-1&&n==="exact"&&(n="augmented")}),n}(this)}getPipelineSourceType(){return Cr(this)}}function Cr(r){const e=r.stages[0];return e instanceof ta||e instanceof na||e instanceof rc||e instanceof sc?e._name:"unknown"}function sa(r){if(Cr(r)==="collection")return r.stages[0].hr}function jl(r){if(Cr(r)==="collection_group")return r.stages[0].collectionId}function DT(r){switch(Cr(r)){case"collection":return de.fromString(sa(r)).lastSegment();case"collection_group":return jl(r);default:return}}function WB(r){if(Cr(r)==="documents")return r.stages[0].Tr}class A{constructor(e,t){this.type=e,this.value=t}static mr(){return new A("ERROR",void 0)}static pr(){return new A("UNSET",void 0)}static gr(){return new A("NULL",dn)}static newValue(e){return Vt(e)?new A("NULL",dn):function(n){return!!n&&"booleanValue"in n}(e)?new A("BOOLEAN",e):un(e)?new A("INT",e):Wr(e)?new A("DOUBLE",e):function(n){return!!n&&"timestampValue"in n&&!!n.timestampValue}(e)?new A("TIMESTAMP",e):function(n){return!!n&&"stringValue"in n}(e)?new A("STRING",e):function(n){return!!n&&"bytesValue"in n}(e)?new A("BYTES",e):e.referenceValue?new A("REFERENCE",e):e.geoPointValue?new A("GEO_POINT",e):Dr(e)?new A("ARRAY",e):Bs(e)?new A("VECTOR",e):Zr(e)?new A("MAP",e):new A("ERROR",void 0)}yr(){return this.type==="ERROR"||this.type==="UNSET"}wr(){return this.type==="NULL"}}function uo(r){if(!r.yr())return r.value}function Sm(r){return r instanceof yr?r._expr:r}function ie(r){if((r=Sm(r))instanceof Ds)return new yT(r);if(r instanceof ys)return new wT(r);if(r instanceof Xi)return new TT(r);if(r instanceof x){if(r.name==="add")return new vT(r);if(r.name==="subtract")return new PT(r);if(r.name==="multiply")return new bT(r);if(r.name==="divide")return new ST(r);if(r.name==="mod")return new OT(r);if(r.name==="and")return new NT(r);if(r.name==="equal")return new JT(r);if(r.name==="not_equal")return new KT(r);if(r.name==="less_than")return new zT(r);if(r.name==="less_than_or_equal")return new WT(r);if(r.name==="greater_than")return new QT(r);if(r.name==="greater_than_or_equal")return new $T(r);if(r.name==="array_concat")return new YT(r);if(r.name==="array_reverse")return new XT(r);if(r.name==="array_contains")return new ZT(r);if(r.name==="array_contains_all")return new eA(r);if(r.name==="array_contains_any")return new tA(r);if(r.name==="array_length")return new nA(r);if(r.name==="array_element")return new rA(r);if(r.name==="equal_any")return new Om(r);if(r.name==="not_equal_any")return new LT(r);if(r.name==="is_nan")return new kT(r);if(r.name==="is_not_nan")return new xT(r);if(r.name==="is_null")return new VT(r);if(r.name==="is_not_null")return new MT(r);if(r.name==="is_error")return new GT(r);if(r.name==="exists")return new UT(r);if(r.name==="not")return new ic(r);if(r.name==="or")return new FT(r);if(r.name==="xor")return new Jl(r);if(r.name==="conditional")return new HT(r);if(r.name==="maximum")return new qT(r);if(r.name==="minimum")return new jT(r);if(r.name==="reverse")return new sA(r);if(r.name==="replace_first")return new iA(r);if(r.name==="replace_all")return new oA(r);if(r.name==="char_length")return new aA(r);if(r.name==="byte_length")return new uA(r);if(r.name==="like")return new cA(r);if(r.name==="regex_contains")return new BA(r);if(r.name==="regex_match")return new lA(r);if(r.name==="string_contains")return new hA(r);if(r.name==="starts_with")return new dA(r);if(r.name==="ends_with")return new fA(r);if(r.name==="to_lower")return new CA(r);if(r.name==="to_upper")return new pA(r);if(r.name==="trim")return new gA(r);if(r.name==="string_concat")return new mA(r);if(r.name==="map_get")return new _A(r);if(r.name==="cosine_distance")return new EA(r);if(r.name==="dot_product")return new IA(r);if(r.name==="euclidean_distance")return new DA(r);if(r.name==="vector_length")return new yA(r);if(r.name==="unix_micros_to_timestamp")return new vA(r);if(r.name==="timestamp_to_unix_micros")return new SA(r);if(r.name==="unix_millis_to_timestamp")return new PA(r);if(r.name==="timestamp_to_unix_millis")return new OA(r);if(r.name==="unix_seconds_to_timestamp")return new bA(r);if(r.name==="timestamp_to_unix_seconds")return new NA(r);if(r.name==="timestamp_add")return new FA(r);if(r.name==="timestamp_subtract")return new LA(r)}throw new Error(`Unknown Expr : ${r}`)}class yT{constructor(e){this.expr=e}evaluate(e,t){if(this.expr.fieldName===an)return A.newValue({referenceValue:ri(e.serializer,t.key)});if(this.expr.fieldName==="__update_time__")return A.newValue({timestampValue:nu(e.serializer,t.version)});if(this.expr.fieldName==="__create_time__")return A.newValue({timestampValue:nu(e.serializer,t.createTime)});const n=t.data.field(this.expr._fieldPath);return n?Ku(n)?A.newValue(function(i,o){if(i.serverTimestampBehavior==="estimate")return{timestampValue:nu(i.serializer,te.fromTimestamp(Ys(o)))};if(i.serverTimestampBehavior==="previous"){const a=Wo(o);if(a)return a}return{nullValue:"NULL_VALUE"}}(e,n)):A.newValue(n):A.pr()}}class wT{constructor(e){this.expr=e}evaluate(e,t){return A.newValue(this.expr._getValue())}}class TT{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.cr.map(s=>ie(s).evaluate(e,t));return n.some(s=>s.yr())?A.mr():A.newValue({arrayValue:{values:n.map(s=>s.value)}})}}function ct(r){return Wr(r)?Number(r.doubleValue):Number(r.integerValue)}function mn(r){return BigInt(r.integerValue)}const AT=BigInt("0x7fffffffffffffff"),RT=-BigInt("0x8000000000000000");class ia{constructor(e){this.expr=e}evaluate(e,t){j(this.expr.params.length>=2,24778);const n=ie(this.expr.params[0]).evaluate(e,t),s=ie(this.expr.params[1]).evaluate(e,t);let i=this.br(n,s);for(const o of this.expr.params.slice(2)){const a=ie(o).evaluate(e,t);i=this.br(i,a)}return i}br(e,t){if(e.yr()||t.yr())return A.mr();if(e.wr()||t.wr())return A.gr();const n=e.value,s=t.value;if(!Wr(n)&&!un(n)||!Wr(s)&&!un(s))return A.mr();if(Wr(n)||Wr(s)){const i=this.Sr(n,s);return i?A.newValue(i):A.mr()}if(un(n)&&un(s)){const i=this.vr(n,s);return i===void 0?A.mr():typeof i=="number"?A.newValue({doubleValue:i}):i<RT||i>AT?A.mr():A.newValue({integerValue:`${i}`})}return A.mr()}}function Ln(r,e){return Ke(r)!==Ke(e)?"TYPE_MISMATCH":St(r)||St(e)?"NOT_EQ":Vt(r)&&Vt(e)?"EQ":Vt(r)||Vt(e)?"NULL":Dr(r)&&Dr(e)?function(n,s){var o,a,u;if(((o=n.values)==null?void 0:o.length)!==((a=s.values)==null?void 0:a.length))return"NOT_EQ";let i=!1;for(let B=0;B<(((u=n.values)==null?void 0:u.length)??0);B++){const l=n.values[B],d=s.values[B];switch(Ln(l,d)){case"EQ":break;case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":i=!0;break;default:ee(44609,{Dr:l,Cr:d})}}return i?"NULL":"EQ"}(r.arrayValue,e.arrayValue):Bs(r)&&Bs(e)||Zr(r)&&Zr(e)?function(n,s){const i=n.fields||{},o=s.fields||{};if(gu(i)!==gu(o))return"NOT_EQ";let a=!1;for(const u in i)if(i.hasOwnProperty(u)){if(o[u]===void 0)return"NOT_EQ";switch(Ln(i[u],o[u])){case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":a=!0}}return a?"NULL":"EQ"}(r.mapValue,e.mapValue):function(n,s){return Wt(n,s,{u:!1,i:!0,o:!0})}(r,e)?"EQ":"NOT_EQ"}class vT extends ia{vr(e,t){return mn(e)+mn(t)}Sr(e,t){return{doubleValue:ct(e)+ct(t)}}}class PT extends ia{constructor(e){super(e),this.expr=e}vr(e,t){return mn(e)-mn(t)}Sr(e,t){return{doubleValue:ct(e)-ct(t)}}}class bT extends ia{constructor(e){super(e),this.expr=e}vr(e,t){return mn(e)*mn(t)}Sr(e,t){return{doubleValue:ct(e)*ct(t)}}}class ST extends ia{constructor(e){super(e),this.expr=e}vr(e,t){const n=mn(t);if(n!==BigInt(0))return mn(e)/n}Sr(e,t){const n=ct(t);return n===0?{doubleValue:Xs(n)?Number.NEGATIVE_INFINITY:Number.POSITIVE_INFINITY}:{doubleValue:ct(e)/n}}}class OT extends ia{constructor(e){super(e),this.expr=e}vr(e,t){const n=mn(t);if(n!==BigInt(0))return mn(e)%n}Sr(e,t){const n=ct(t);if(n!==0)return{doubleValue:ct(e)%n}}}class NT{constructor(e){this.expr=e}evaluate(e,t){var i;let n=!1,s=!1;for(const o of this.expr.params){const a=ie(o).evaluate(e,t);switch(a.type){case"BOOLEAN":if(!((i=a.value)!=null&&i.booleanValue))return A.newValue(st);break;case"NULL":s=!0;break;default:n=!0}}return n?A.mr():s?A.gr():A.newValue(bt)}}class ic{constructor(e){this.expr=e}evaluate(e,t){var s;j(this.expr.params.length===1,9634);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BOOLEAN":return A.newValue({booleanValue:!((s=n.value)!=null&&s.booleanValue)});case"NULL":return A.gr();default:return A.mr()}}}class FT{constructor(e){this.expr=e}evaluate(e,t){var i;let n=!1,s=!1;for(const o of this.expr.params){const a=ie(o).evaluate(e,t);switch(a.type){case"BOOLEAN":if((i=a.value)!=null&&i.booleanValue)return A.newValue(bt);break;case"NULL":s=!0;break;default:n=!0}}return n?A.mr():s?A.gr():A.newValue(st)}}class Jl{constructor(e){this.expr=e}evaluate(e,t){var i;let n=!1,s=!1;for(const o of this.expr.params){const a=ie(o).evaluate(e,t);switch(a.type){case"BOOLEAN":n=Jl.xor(n,!!((i=a.value)!=null&&i.booleanValue));break;case"NULL":s=!0;break;default:return A.mr()}}return s?A.gr():A.newValue({booleanValue:n})}static xor(e,t){return(e||t)&&!(e&&t)}}class Om{constructor(e){this.expr=e}evaluate(e,t){var o,a;j(this.expr.params.length===2,55094);let n=!1;const s=ie(this.expr.params[0]).evaluate(e,t);switch(s.type){case"NULL":n=!0;break;case"ERROR":case"UNSET":return A.mr()}const i=ie(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return A.mr()}if(n)return A.gr();for(const u of((a=(o=i.value)==null?void 0:o.arrayValue)==null?void 0:a.values)??[])switch(Vt(s.value)&&Vt(u)?"EQ":Ln(s.value,u)){case"EQ":return A.newValue(bt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:ee(44608,{value:s.value,candidate:u})}return n?A.gr():A.newValue(st)}}class LT{constructor(e){this.expr=e}evaluate(e,t){return new ic(new x("not",[new x("equal_any",this.expr.params)])).evaluate(e,t)}}class kT{constructor(e){this.expr=e}evaluate(e,t){j(this.expr.params.length===1,23322);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"INT":return A.newValue(st);case"DOUBLE":return A.newValue({booleanValue:isNaN(ct(n.value))});case"NULL":return A.gr();default:return A.mr()}}}class xT{constructor(e){this.expr=e}evaluate(e,t){return j(this.expr.params.length===1,50406),new ic(new x("not",[new x("is_nan",this.expr.params)])).evaluate(e,t)}}class VT{constructor(e){this.expr=e}evaluate(e,t){switch(j(this.expr.params.length===1,23123),ie(this.expr.params[0]).evaluate(e,t).type){case"NULL":return A.newValue(bt);case"UNSET":case"ERROR":return A.mr();default:return A.newValue(st)}}}class MT{constructor(e){this.expr=e}evaluate(e,t){return j(this.expr.params.length===1,23167),new ic(new x("not",[new x("is_null",this.expr.params)])).evaluate(e,t)}}class GT{constructor(e){this.expr=e}evaluate(e,t){return j(this.expr.params.length===1,5228),ie(this.expr.params[0]).evaluate(e,t).type==="ERROR"?A.newValue(bt):A.newValue(st)}}class UT{constructor(e){this.expr=e}evaluate(e,t){switch(j(this.expr.params.length===1,6877),ie(this.expr.params[0]).evaluate(e,t).type){case"ERROR":return A.mr();case"UNSET":return A.newValue(st);default:return A.newValue(bt)}}}class HT{constructor(e){this.expr=e}evaluate(e,t){var s;j(this.expr.params.length===3,11706);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BOOLEAN":return(s=n.value)!=null&&s.booleanValue?ie(this.expr.params[1]).evaluate(e,t):ie(this.expr.params[2]).evaluate(e,t);case"NULL":return ie(this.expr.params[2]).evaluate(e,t);default:return A.mr()}}}class qT{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map(i=>ie(i).evaluate(e,t));let s;for(const i of n)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:s=s===void 0||pt(i.value,s.value)>0?i:s}return s===void 0?A.gr():s}}class jT{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map(i=>ie(i).evaluate(e,t));let s;for(const i of n)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:s=s===void 0||pt(i.value,s.value)<0?i:s}return s===void 0?A.gr():s}}class pi{constructor(e){this.expr=e}evaluate(e,t){j(this.expr.params.length===2,31033,`${this.expr.name}() function should have exactly 2 params`);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"ERROR":case"UNSET":return A.mr()}const s=ie(this.expr.params[1]).evaluate(e,t);switch(s.type){case"ERROR":case"UNSET":return A.mr()}return this.Fr(n,s)}}class JT extends pi{constructor(e){super(e),this.expr=e}Fr(e,t){if(e.wr()&&t.wr())return A.newValue(bt);if(e.wr()||t.wr()||St(e.value)||St(t.value)||Ke(e.value)!==Ke(t.value))return A.newValue(st);switch(Ln(e.value,t.value)){case"EQ":return A.newValue(bt);case"NOT_EQ":return A.newValue(st);case"NULL":return A.gr();default:ee(44615,{left:e,right:t})}}}class KT extends pi{constructor(e){super(e),this.expr=e}Fr(e,t){switch(Ln(e.value,t.value)){case"EQ":return A.newValue(st);case"NOT_EQ":case"TYPE_MISMATCH":return A.newValue(bt);case"NULL":return A.gr();default:ee(44614,{left:e,right:t})}}}class zT extends pi{constructor(e){super(e),this.expr=e}Fr(e,t){return Ke(e.value)!==Ke(t.value)||St(e.value)||St(t.value)?A.newValue(st):A.newValue({booleanValue:pt(e.value,t.value)<0})}}class WT extends pi{constructor(e){super(e),this.expr=e}Fr(e,t){return Ke(e.value)!==Ke(t.value)||St(e.value)||St(t.value)?A.newValue(st):Ln(e.value,t.value)==="EQ"?A.newValue(bt):A.newValue({booleanValue:pt(e.value,t.value)<0})}}class QT extends pi{constructor(e){super(e),this.expr=e}Fr(e,t){return Ke(e.value)!==Ke(t.value)||St(e.value)||St(t.value)?A.newValue(st):A.newValue({booleanValue:pt(e.value,t.value)>0})}}class $T extends pi{constructor(e){super(e),this.expr=e}Fr(e,t){return Ke(e.value)!==Ke(t.value)||St(e.value)||St(t.value)?A.newValue(st):Ln(e.value,t.value)==="EQ"?A.newValue(bt):A.newValue({booleanValue:pt(e.value,t.value)>0})}}class YT{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class XT{constructor(e){this.expr=e}evaluate(e,t){var s;j(this.expr.params.length===1,216);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return A.gr();case"ARRAY":{const i=((s=n.value.arrayValue)==null?void 0:s.values)??[];return A.newValue({arrayValue:{values:[...i].reverse()}})}default:return A.mr()}}}class ZT{constructor(e){this.expr=e}evaluate(e,t){return j(this.expr.params.length===2,52884),new Om(new x("eq_any",[this.expr.params[1],this.expr.params[0]])).evaluate(e,t)}}class eA{constructor(e){this.expr=e}evaluate(e,t){var u,B,l,d;j(this.expr.params.length===2,1392);let n=!1;const s=ie(this.expr.params[0]).evaluate(e,t);switch(s.type){case"ARRAY":break;case"NULL":n=!0;break;default:return A.mr()}const i=ie(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return A.mr()}if(n)return A.gr();const o=((B=(u=i.value)==null?void 0:u.arrayValue)==null?void 0:B.values)??[],a=((d=(l=s.value)==null?void 0:l.arrayValue)==null?void 0:d.values)??[];for(const C of o){let g=!1;n=!1;for(const m of a){switch(Vt(C)&&Vt(m)?"EQ":Ln(C,m)){case"EQ":g=!0;break;case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:ee(44613,{value:m,search:C})}if(g)break}if(!g)return A.newValue(st)}return A.newValue(bt)}}class tA{constructor(e){this.expr=e}evaluate(e,t){var u,B,l,d;j(this.expr.params.length===2,2680);let n=!1;const s=ie(this.expr.params[0]).evaluate(e,t);switch(s.type){case"ARRAY":break;case"NULL":n=!0;break;default:return A.mr()}const i=ie(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return A.mr()}if(n)return A.gr();const o=((B=(u=i.value)==null?void 0:u.arrayValue)==null?void 0:B.values)??[],a=((d=(l=s.value)==null?void 0:l.arrayValue)==null?void 0:d.values)??[];for(const C of a)for(const g of o)switch(Vt(C)&&Vt(g)?"EQ":Ln(C,g)){case"EQ":return A.newValue(bt);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:ee(60403,{value:C,search:g})}return n?A.gr():A.newValue(st)}}class nA{constructor(e){this.expr=e}evaluate(e,t){var s,i,o;j(this.expr.params.length===1,38605);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return A.gr();case"ARRAY":return A.newValue({integerValue:`${((o=(i=(s=n.value)==null?void 0:s.arrayValue)==null?void 0:i.values)==null?void 0:o.length)??0}`});default:return A.mr()}}}class rA{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class sA{constructor(e){this.expr=e}evaluate(e,t){var s,i;j(this.expr.params.length===1,1508);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return A.gr();case"BYTES":{const o=(s=n.value)==null?void 0:s.bytesValue;if(typeof o=="string"){const a=xe.fromBase64String(o).toUint8Array();return a.reverse(),A.newValue({bytesValue:xe.fromUint8Array(a).toBase64()})}return A.newValue({bytesValue:new Uint8Array(o).reverse()})}case"STRING":{const o=(i=n.value)==null?void 0:i.stringValue,a=new Intl.__PRIVATE_Segmenter(void 0,{granularity:"grapheme"}).segment(o),u=Array.from(a,B=>B.segment).reverse();return A.newValue({stringValue:u.join("")})}default:return A.mr()}}}class iA{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class oA{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class aA{constructor(e){this.expr=e}evaluate(e,t){j(this.expr.params.length===1,19400);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return A.gr();case"STRING":{const s=function(o){let a=0;for(let u=0;u<o.length;u++){const B=o.codePointAt(u);if(B===void 0)return;if(B<=65535)if(B>=55296&&B<=57343)if(B<=56319){const l=o.codePointAt(u+1);l!==void 0&&l>=56320&&l<=57343?(a+=1,u++):a+=1}else a+=1;else a+=1;else{if(!(B<=1114111))return;a+=1,u++}}return a}(n.value.stringValue);return s===void 0?A.mr():A.newValue({integerValue:s})}default:return A.mr()}}}class uA{constructor(e){this.expr=e}evaluate(e,t){var s,i;j(this.expr.params.length===1,8486);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BYTES":{const o=(s=n.value)==null?void 0:s.bytesValue;return typeof o=="string"?A.newValue({integerValue:xe.fromBase64String(o).toUint8Array().length}):A.newValue({integerValue:new Uint8Array(o).length})}case"STRING":{const o=function(u){let B=0;for(let l=0;l<u.length;l++){const d=u.codePointAt(l);if(d===void 0)return;if(d>=55296&&d<=57343){if(!(d<=56319))return;{const C=u.codePointAt(l+1);if(C===void 0||!(C>=56320&&C<=57343))return;B+=4,l++}}else if(d<=127)B+=1;else if(d<=2047)B+=2;else if(d<=65535)B+=3;else{if(!(d<=1114111))return;B+=4,l++}}return B}((i=n.value)==null?void 0:i.stringValue);return o===void 0?A.mr():A.newValue({integerValue:o})}case"NULL":return A.gr();default:return A.mr()}}}class gi{constructor(e){this.expr=e}evaluate(e,t){var o,a;j(this.expr.params.length===2,39773,`${this.expr.name}() function should have exactly two parameters`);let n=!1;const s=ie(this.expr.params[0]).evaluate(e,t);switch(s.type){case"STRING":break;case"NULL":n=!0;break;default:return A.mr()}const i=ie(this.expr.params[1]).evaluate(e,t);switch(i.type){case"STRING":break;case"NULL":n=!0;break;default:return A.mr()}return n?A.gr():this.Or((o=s.value)==null?void 0:o.stringValue,(a=i.value)==null?void 0:a.stringValue)}}class cA extends gi{Or(e,t){try{const n=function(o){let a="";for(let u=0;u<o.length;u++){const B=o.charAt(u);switch(B){case"_":a+=".";break;case"%":a+=".*";break;case"\\":case".":case"*":case"?":case"+":case"^":case"$":case"|":case"(":case")":case"[":case"]":case"{":case"}":a+="\\"+B;break;default:a+=B}}return"^"+a+"$"}(t),s=Cl.compile(n);return A.newValue({booleanValue:s.matches(e)})}catch(n){return tn(`Invalid LIKE pattern converted to regex: ${t}, returning error. Error: ${n}`),A.mr()}}}class BA extends gi{Or(e,t){try{const n=Cl.compile(t);return A.newValue({booleanValue:n.test(e)})}catch{return tn(`Invalid regex pattern found in regex_contains: ${t}, returning error`),A.mr()}}}class lA extends gi{Or(e,t){try{return A.newValue({booleanValue:Cl.compile(t).matches(e)})}catch{return tn(`Invalid regex pattern found in regex_match: ${t}, returning error`),A.mr()}}}class hA extends gi{Or(e,t){return A.newValue({booleanValue:e.includes(t)})}}class dA extends gi{Or(e,t){return A.newValue({booleanValue:e.startsWith(t)})}}class fA extends gi{Or(e,t){return A.newValue({booleanValue:e.endsWith(t)})}}class CA{constructor(e){this.expr=e}evaluate(e,t){var s,i;j(this.expr.params.length===1,29079);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return A.newValue({stringValue:(i=(s=n.value)==null?void 0:s.stringValue)==null?void 0:i.toLowerCase()});case"NULL":return A.gr();default:return A.mr()}}}class pA{constructor(e){this.expr=e}evaluate(e,t){var s,i;j(this.expr.params.length===1,60487);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return A.newValue({stringValue:(i=(s=n.value)==null?void 0:s.stringValue)==null?void 0:i.toUpperCase()});case"NULL":return A.gr();default:return A.mr()}}}class gA{constructor(e){this.expr=e}evaluate(e,t){var s,i;j(this.expr.params.length===1,28544);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return A.newValue({stringValue:(i=(s=n.value)==null?void 0:s.stringValue)==null?void 0:i.trim()});case"NULL":return A.gr();default:return A.mr()}}}class mA{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map(o=>ie(o).evaluate(e,t));let s="",i=!1;for(const o of n)switch(o.type){case"STRING":s+=o.value.stringValue;break;case"NULL":i=!0;break;default:return A.mr()}return i?A.gr():A.newValue({stringValue:s})}}class _A{constructor(e){this.expr=e}evaluate(e,t){var o,a,u,B;j(this.expr.params.length===2,4483);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"UNSET":return A.pr();case"MAP":break;default:return A.mr()}const s=ie(this.expr.params[1]).evaluate(e,t);if(s.type!=="STRING")return A.mr();const i=(B=(a=(o=n.value)==null?void 0:o.mapValue)==null?void 0:a.fields)==null?void 0:B[(u=s.value)==null?void 0:u.stringValue];return i===void 0?A.pr():A.newValue(i)}}class Kl{constructor(e){this.expr=e}evaluate(e,t){var B,l;j(this.expr.params.length===2,25231,`${this.expr.name}() function should have exactly 2 params`);let n=!1;const s=ie(this.expr.params[0]).evaluate(e,t);switch(s.type){case"VECTOR":break;case"NULL":n=!0;break;default:return A.mr()}const i=ie(this.expr.params[1]).evaluate(e,t);switch(i.type){case"VECTOR":break;case"NULL":n=!0;break;default:return A.mr()}if(n)return A.gr();const o=xB(s.value),a=xB(i.value);if(o===void 0||a===void 0||((B=o.values)==null?void 0:B.length)!==((l=a.values)==null?void 0:l.length))return A.mr();const u=this.Mr(o,a);return u===void 0||isNaN(u)?A.mr():A.newValue({doubleValue:u})}}class EA extends Kl{Mr(e,t){const n=(e==null?void 0:e.values)??[],s=(t==null?void 0:t.values)??[];if(n.length===0)return;let i=0,o=0,a=0;for(let B=0;B<n.length;B++){if(!Ir(n[B])||!Ir(s[B]))return;const l=ct(n[B]),d=ct(s[B]);i+=l*d,o+=l*l,a+=d*d}const u=Math.sqrt(o)*Math.sqrt(a);if(u!==0)return 1-Math.max(-1,Math.min(1,i/u))}}class IA extends Kl{Mr(e,t){const n=(e==null?void 0:e.values)??[],s=(t==null?void 0:t.values)??[];if(n.length===0)return 0;let i=0;for(let o=0;o<n.length;o++){if(!Ir(n[o])||!Ir(s[o]))return;i+=ct(n[o])*ct(s[o])}return i}}class DA extends Kl{Mr(e,t){const n=(e==null?void 0:e.values)??[],s=(t==null?void 0:t.values)??[];if(n.length===0)return 0;let i=0;for(let o=0;o<n.length;o++){if(!Ir(n[o])||!Ir(s[o]))return;const a=ct(n[o]),u=ct(s[o]);i+=Math.pow(a-u,2)}return Math.sqrt(i)}}class yA{constructor(e){this.expr=e}evaluate(e,t){var s;j(this.expr.params.length===1,39044);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"VECTOR":{const i=xB(n.value);return A.newValue({integerValue:((s=i==null?void 0:i.values)==null?void 0:s.length)??0})}case"NULL":return A.gr();default:return A.mr()}}}const Oo=BigInt(-62135596800),No=BigInt(253402300799),wu=BigInt(1e3),pr=BigInt(1e6),wA=Oo*wu,TA=No*wu+BigInt(999),AA=Oo*pr,RA=No*pr+BigInt(999999);function zl(r){return r>=AA&&r<=RA}function Nm(r){return r>=Oo&&r<=No}function Fo(r,e){const t=BigInt(r);return!(t<Oo||t>No)&&!(e<0||e>=1e9)&&(t!==Oo||e===0)&&!(t===No&&e>999999999)}function Fm(r,e){return e<0?{seconds:r-1,nanos:e+1e9}:{seconds:r,nanos:e}}function Wl(r){return BigInt(r.seconds)*pr+BigInt(Math.trunc(r.nanoseconds/1e3))}class Ql{constructor(e){this.expr=e}evaluate(e,t){j(this.expr.params.length===1,49262,`${this.expr.name}() function should have exactly one parameter`);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"INT":return this.toTimestamp(BigInt(n.value.integerValue));case"NULL":return A.gr();default:return A.mr()}}}class vA extends Ql{toTimestamp(e){if(!zl(e))return A.mr();let t=Number(e/pr),n=Number(e%pr*BigInt(1e3));const s=Fm(t,n);return t=s.seconds,n=s.nanos,Fo(t,n)?A.newValue({timestampValue:{seconds:t,nanos:n}}):A.mr()}}class PA extends Ql{toTimestamp(e){if(!function(o){return o>=wA&&o<=TA}(e))return A.mr();let t=Number(e/wu),n=Number(e%wu*BigInt(1e6));const s=Fm(t,n);return t=s.seconds,n=s.nanos,Fo(t,n)?A.newValue({timestampValue:{seconds:t,nanos:n}}):A.mr()}}class bA extends Ql{toTimestamp(e){if(!Nm(e))return A.mr();const t=Number(e);return A.newValue({timestampValue:{seconds:t,nanos:0}})}}class $l{constructor(e){this.expr=e}evaluate(e,t){j(this.expr.params.length===1,1265,`${this.expr.name}() function should have exactly one parameter`);const n=ie(this.expr.params[0]).evaluate(e,t);switch(n.type){case"TIMESTAMP":break;case"NULL":return A.gr();default:return A.mr()}const s=Pl(n.value.timestampValue);return Fo(s.seconds,s.nanoseconds)?this.Nr(s):A.mr()}}class SA extends $l{Nr(e){const t=Wl(e);return zl(t)?A.newValue({integerValue:`${t.toString()}`}):A.mr()}}class OA extends $l{Nr(e){const t=Wl(e),n=t/BigInt(1e3),s=t%BigInt(1e3);return n>BigInt(0)||s===BigInt(0)?A.newValue({integerValue:n.toString()}):A.newValue({integerValue:(n-BigInt(1)).toString()})}}class NA extends $l{Nr(e){const t=BigInt(e.seconds);return Nm(t)?A.newValue({integerValue:t.toString()}):A.mr()}}class Lm{constructor(e){this.expr=e}evaluate(e,t){j(this.expr.params.length===3,2775,`${this.expr.name}() function should have exactly 3 parameters`);let n=!1;const s=ie(this.expr.params[0]).evaluate(e,t);switch(s.type){case"TIMESTAMP":break;case"NULL":n=!0;break;default:return A.mr()}const i=ie(this.expr.params[1]).evaluate(e,t);let o;switch(i.type){case"STRING":if(o=function(J){switch(J){case"microsecond":return"microsecond";case"millisecond":return"millisecond";case"second":return"second";case"minute":return"minute";case"hour":return"hour";case"day":return"day";default:return}}(i.value.stringValue),o===void 0)return A.mr();break;case"NULL":n=!0;break;default:return A.mr()}const a=ie(this.expr.params[2]).evaluate(e,t);switch(a.type){case"INT":break;case"NULL":n=!0;break;default:return A.mr()}if(n)return A.gr();const u=BigInt(a.value.integerValue);let B;try{switch(o){case"microsecond":B=u;break;case"millisecond":B=u*BigInt(1e3);break;case"second":B=u*BigInt(1e6);break;case"minute":B=u*BigInt(6e7);break;case"hour":B=u*BigInt(36e8);break;case"day":B=u*BigInt(864e8);break;default:return A.mr()}if(o!=="microsecond"&&u!==BigInt(0)&&B/u!==BigInt(this.Lr(o)))return A.mr()}catch(q){return tn(`Error during timestamp arithmetic: ${q}`),A.mr()}const l=Pl(s.value.timestampValue);if(!Fo(l.seconds,l.nanoseconds))return A.mr();const d=Wl(l),C=this.Br(d,B);if(!zl(C))return A.mr();const g=Number(C/pr),m=C%pr,v=Number((m<0?m+pr:m)*BigInt(1e3)),N=m<0?g-1:g;return Fo(N,v)?A.newValue({timestampValue:{seconds:N,nanos:v}}):A.mr()}Lr(e){switch(e){case"millisecond":return 1e3;case"second":return 1e6;case"minute":return 6e7;case"hour":return 36e8;case"day":return 864e8;default:return 1}}}class FA extends Lm{Br(e,t){return e+t}}class LA extends Lm{Br(e,t){return e-t}}function Lo(r){if((r=Sm(r))instanceof Ds)return`fld(${r.fieldName})`;if(r instanceof ys)return`cst(${function(t){return t===null?"null":typeof t=="number"?t.toString():typeof t=="string"?`"${t}"`:t instanceof Le?`ref(${t.path})`:t instanceof Pt?`vec(${JSON.stringify(t)})`:JSON.stringify(t)}(r.value)})`;if(r instanceof x)return`fn(${r.name},[${r.params.map(Lo).join(",")}])`;if(r.expressionType==="ListOfExpressions")return`list([${r.cr.map(Lo).join(",")}])`;throw new Error(`Unrecognized expr ${JSON.stringify(r,null,2)}`)}function kA(r){if(r instanceof vm)return`${r._name}(${Ha(r.fields)})`;if(r instanceof Pm){let e=`${r._name}(${Ha(r.accumulators)})`;return r.groups.size>0&&(e+=`grouping(${Ha(r.groups)})`),e}if(r instanceof bm)return`${r._name}(${Ha(r.groups)})`;if(r instanceof ta)return`${r._name}(${r.hr})`;if(r instanceof na)return`${r._name}(${r.collectionId})`;if(r instanceof rc)return`${r._name}()`;if(r instanceof sc)return`${r._name}(${r.Tr.sort()})`;if(r instanceof ra)return`${r._name}(${Lo(r.condition)})`;if(r instanceof wr)return`${r._name}(${r.limit})`;if(r instanceof cn)return`${r._name}(${function(t){return t.map(n=>`${Lo(n.expr)}${n.direction}`).join(",")}(r.orderings)})`;throw new Error(`Unrecognized stage ${r._name}`)}function Ha(r){return`${Array.from(r.entries()).sort().map(([e,t])=>`${e}=${Lo(t)}`).join(",")}`}function bn(r){return r.stages.map(e=>kA(e)).join("|")}function km(r,e){return bn(r)===bn(e)}function je(r){return r instanceof dt}function gC(r){return je(r)?bn(r):so(r)}function xm(r){return je(r)?bn(r):function(t){return`${Eu(Kt(t))}|lt:${t.limitType}`}(r)}function oc(r,e){return r instanceof dt&&e instanceof dt?km(r,e):!(r instanceof dt&&!(e instanceof dt)||!(r instanceof dt)&&e instanceof dt)&&Bw(r,e)}function ac(r){return tr(r)?bn(r):Eu(r)}function Yl(r,e){return r instanceof dt&&e instanceof dt?km(r,e):!(r instanceof dt&&!(e instanceof dt)||!(r instanceof dt)&&e instanceof dt)&&Tl(r,e)}function xA(r,e){const t=function(s){let i=!1;const o=[];for(const a of s)if(a instanceof cn)if(i=!0,a.orderings.some(u=>u.expr instanceof Ds&&u.expr.fieldName===an))o.push(a);else{const u=a.orderings.map(B=>B);u.push(ru(an).ascending()),o.push(new cn(u,{}))}else a instanceof wr&&(i||(o.push(new cn([ru(an).ascending()],{})),i=!0)),o.push(a);return i||o.push(new cn([ru(an).ascending()],{})),o}(r.stages);if(r.userDataReader){const n=r.userDataReader.createContext(3,"toCorePipeline");t.forEach(s=>s._readUserData(n))}return new dt(r.userDataReader.serializer,t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xl{constructor(e,t,n,s){this.batchId=e,this.localWriteTime=t,this.baseMutations=n,this.mutations=s}applyToRemoteDocument(e,t){const n=t.mutationResults;for(let s=0;s<this.mutations.length;s++){const i=this.mutations[s];i.key.isEqual(e.key)&&Qy(i,e,n[s])}}applyToLocalView(e,t){for(const n of this.baseMutations)n.key.isEqual(e.key)&&(t=no(n,e,t,this.localWriteTime));for(const n of this.mutations)n.key.isEqual(e.key)&&(t=no(n,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const n=qg();return this.mutations.forEach(s=>{const i=e.get(s.key),o=i.overlayedDocument;let a=this.applyToLocalView(o,i.mutatedFields);a=t.has(s.key)?null:a;const u=Rg(o,a);u!==null&&n.set(s.key,u),o.isValidDocument()||o.convertToNoDocument(te.min())}),n}keys(){return this.mutations.reduce((e,t)=>e.add(t.key),Be())}isEqual(e){return this.batchId===e.batchId&&$s(this.mutations,e.mutations,(t,n)=>Kf(t,n))&&$s(this.baseMutations,e.baseMutations,(t,n)=>Kf(t,n))}}class Zl{constructor(e,t,n,s){this.batch=e,this.commitVersion=t,this.mutationResults=n,this.docVersions=s}static from(e,t,n){j(e.mutations.length===n.length,58842,{Ur:e.mutations.length,kr:n.length});let s=function(){return fw}();const i=e.mutations;for(let o=0;o<i.length;o++)s=s.insert(i[o].key,n[o].version);return new Zl(e,t,n,s)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tu="";function Ct(r){let e="";for(let t=0;t<r.length;t++)e.length>0&&(e=mC(e)),e=VA(r.get(t),e);return mC(e)}function VA(r,e){let t=e;const n=r.length;for(let s=0;s<n;s++){const i=r.charAt(s);switch(i){case"\0":t+="";break;case Tu:t+="";break;default:t+=i}}return t}function mC(r){return r+Tu+""}function Bn(r){const e=r.length;if(j(e>=2,64408,{path:r}),e===2)return j(r.charAt(0)===Tu&&r.charAt(1)==="",56145,{path:r}),de.emptyPath();const t=e-2,n=[];let s="";for(let i=0;i<e;){const o=r.indexOf(Tu,i);switch((o<0||o>t)&&ee(50515,{path:r}),r.charAt(o+1)){case"":const a=r.substring(i,o);let u;s.length===0?u=a:(s+=a,u=s,s=""),n.push(u);break;case"":s+=r.substring(i,o),s+="\0";break;case"":s+=r.substring(i,o+1);break;default:ee(61167,{path:r})}i=o+2}return new de(n)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hr="remoteDocuments",oa="owner",Os="owner",ko="mutationQueues",MA="userId",$t="mutations",_C="batchId",Qr="userMutationsIndex",EC=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function su(r,e){return[r,Ct(e)]}function Vm(r,e,t){return[r,Ct(e),t]}const GA={},si="documentMutations",Au="remoteDocumentsV14",UA=["prefixPath","collectionGroup","readTime","documentId"],iu="documentKeyIndex",HA=["prefixPath","collectionGroup","documentId"],Mm="collectionGroupIndex",qA=["collectionGroup","readTime","prefixPath","documentId"],xo="remoteDocumentGlobal",QB="remoteDocumentGlobalKey",ii="targets",Gm="queryTargetsIndex",jA=["canonicalId","targetId"],oi="targetDocuments",JA=["targetId","path"],eh="documentTargetsIndex",KA=["path","targetId"],Ru="targetGlobalKey",ts="targetGlobal",Vo="collectionParents",zA=["collectionId","parent"],ai="clientMetadata",WA="clientId",uc="bundles",QA="bundleId",cc="namedQueries",$A="name",th="indexConfiguration",YA="indexId",$B="collectionGroupIndex",XA="collectionGroup",co="indexState",ZA=["indexId","uid"],Um="sequenceNumberIndex",eR=["uid","sequenceNumber"],Bo="indexEntries",tR=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],Hm="documentKeyIndex",nR=["indexId","uid","orderedDocumentKey"],Bc="documentOverlays",rR=["userId","collectionPath","documentId"],YB="collectionPathOverlayIndex",sR=["userId","collectionPath","largestBatchId"],qm="collectionGroupOverlayIndex",iR=["userId","collectionGroup","largestBatchId"],nh="globals",oR="name",jm=[ko,$t,si,Hr,ii,oa,ts,oi,ai,xo,Vo,uc,cc],aR=[...jm,Bc],Jm=[ko,$t,si,Au,ii,oa,ts,oi,ai,xo,Vo,uc,cc,Bc],Km=Jm,rh=[...Km,th,co,Bo],uR=rh,zm=[...rh,nh],cR=zm;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wm(r,e,t){const n=r.store($t),s=r.store(si),i=[],o=IDBKeyRange.only(t.batchId);let a=0;const u=n.Hn({range:o},(l,d,C)=>(a++,C.delete()));i.push(u.next(()=>{j(a===1,47070,{batchId:t.batchId})}));const B=[];for(const l of t.mutations){const d=Vm(e,l.key.path,t.batchId);i.push(s.delete(d)),B.push(l.key)}return b.waitFor(i).next(()=>B)}function vu(r){if(!r)return 0;let e;if(r.document)e=r.document;else if(r.unknownDocument)e=r.unknownDocument;else{if(!r.noDocument)throw ee(14731);e=r.noDocument}return JSON.stringify(e).length}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class XB extends Bm{constructor(e,t){super(),this.qr=e,this.currentSequenceNumber=t}}function Ze(r,e){const t=oe(r);return dr.Cn(t.qr,e)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sh{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ln{constructor(e,t,n,s,i=te.min(),o=te.min(),a=xe.EMPTY_BYTE_STRING,u=null){this.target=e,this.targetId=t,this.purpose=n,this.sequenceNumber=s,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=a,this.expectedCount=u}withSequenceNumber(e){return new ln(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new ln(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new ln(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new ln(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qm{constructor(e){this.$r=e}}function BR(r,e){let t;if(e.document)t=Tw(r.$r,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const n=W.fromSegments(e.noDocument.path),s=Cs(e.noDocument.readTime);t=Ne.newNoDocument(n,s),e.hasCommittedMutations&&t.setHasCommittedMutations()}else{if(!e.unknownDocument)return ee(56709);{const n=W.fromSegments(e.unknownDocument.path),s=Cs(e.unknownDocument.version);t=Ne.newUnknownDocument(n,s)}}return e.readTime&&t.setReadTime(function(s){const i=new _e(s[0],s[1]);return te.fromTimestamp(i)}(e.readTime)),t}function IC(r,e){const t=e.key,n={prefixPath:t.getCollectionPath().popLast().toArray(),collectionGroup:t.collectionGroup,documentId:t.path.lastSegment(),readTime:Pu(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())n.document=function(i,o){return{name:ri(i,o.key),fields:o.data.value.mapValue.fields,updateTime:es(i,o.version.toTimestamp()),createTime:es(i,o.createTime.toTimestamp())}}(r.$r,e);else if(e.isNoDocument())n.noDocument={path:t.path.toArray(),readTime:fs(e.version)};else{if(!e.isUnknownDocument())return ee(57904,{document:e});n.unknownDocument={path:t.path.toArray(),version:fs(e.version)}}return n}function Pu(r){const e=r.toTimestamp();return[e.seconds,e.nanoseconds]}function fs(r){const e=r.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function Cs(r){const e=new _e(r.seconds,r.nanoseconds);return te.fromTimestamp(e)}function jr(r,e){const t=(e.baseMutations||[]).map(i=>KB(r.$r,i));for(let i=0;i<e.mutations.length-1;++i){const o=e.mutations[i];if(i+1<e.mutations.length&&e.mutations[i+1].transform!==void 0){const a=e.mutations[i+1];o.updateTransforms=a.transform.fieldTransforms,e.mutations.splice(i+1,1),++i}}const n=e.mutations.map(i=>KB(r.$r,i)),s=_e.fromMillis(e.localWriteTimeMs);return new Xl(e.batchId,s,t,n)}function Zi(r,e){const t=Cs(e.readTime),n=e.lastLimboFreeSnapshotVersion!==void 0?Cs(e.lastLimboFreeSnapshotVersion):te.min();let s;return s=function(o){return o.structuredPipeline!==void 0}(e.query)?function(o,a){var l,d;const u=o.structuredPipeline;j((((l=u==null?void 0:u.pipeline)==null?void 0:l.stages)??[]).length>0,1845);const B=(d=u==null?void 0:u.pipeline)==null?void 0:d.stages.map(lR);return new dt(a,B)}(e.query,r.$r):function(o){return o.documents!==void 0}(e.query)?function(o){const a=o.documents.length;return j(a===1,1966,{count:a}),Kt(Yo(Qg(o.documents[0])))}(e.query):function(o){return Kt(Xg(o))}(e.query),new ln(s,e.targetId,"TargetPurposeListen",e.lastListenSequenceNumber,t,n,xe.fromBase64String(e.resumeToken))}function $m(r,e){const t=fs(e.snapshotVersion),n=fs(e.lastLimboFreeSnapshotVersion);let s;s=tr(e.target)?Zg(r.$r,e.target):Al(e.target)?Yg(r.$r,e.target):Sl(r.$r,e.target).Se;const i=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:ac(e.target),readTime:t,resumeToken:i,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:n,query:s}}function Ym(r){const e=Xg({parent:r.parent,structuredQuery:r.structuredQuery});return r.limitType==="LAST"?Du(e,e.limit,"L"):e}function qa(r,e){return new sh(e.largestBatchId,KB(r.$r,e.overlayMutation))}function DC(r,e){const t=e.path.lastSegment();return[r,Ct(e.path.popLast()),t]}function yC(r,e,t,n){return{indexId:r,uid:e,sequenceNumber:t,readTime:fs(n.readTime),documentKey:Ct(n.documentKey.path),largestBatchId:n.largestBatchId}}function lR(r){switch(r.name){case"collection":return new ta(r.args[0].referenceValue,{});case"collection_group":return new na(r.args[1].stringValue,{});case"database":return new rc({});case"documents":return new sc(r.args.map(e=>e.referenceValue),{});case"where":return new ra(ZB(r.args[0]),{});case"limit":{const e=r.args[0].integerValue??r.args[0].doubleValue;return new wr(typeof e=="number"?e:Number(e),{})}case"sort":return new cn(r.args.map(e=>function(n){var i,o;const s=(i=n.mapValue)==null?void 0:i.fields;return new Hl(ZB(s.expression),(o=s.direction)==null?void 0:o.stringValue,"orderingFromProto")}(e)),{});default:throw new Error(`Stage type: ${r.name} not supported.`)}}function ZB(r){return r.fieldReferenceValue?new Ds(Fn("_exprFromProto",r.fieldReferenceValue),"_exprFromProto"):r.functionValue?function(t){var n;return new x(t.functionValue.name,((n=t.functionValue.args)==null?void 0:n.map(ZB))||[])}(r):ys._fromProto(r)}class lc{constructor(e,t,n,s){this.userId=e,this.serializer=t,this.indexManager=n,this.referenceDelegate=s,this.Kr={}}static Qr(e,t,n,s){j(e.uid!=="",64387);const i=e.isAuthenticated()?e.uid:"";return new lc(i,t,n,s)}checkEmpty(e){let t=!0;const n=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Qn(e).Hn({index:Qr,range:n},(s,i,o)=>{t=!1,o.done()}).next(()=>t)}addMutationBatch(e,t,n,s){const i=js(e),o=Qn(e);return o.add({}).next(a=>{j(typeof a=="number",49019);const u=new Xl(a,t,n,s),B=function(g,m,v){const N=v.baseMutations.map(J=>Po(g.$r,J)),q=v.mutations.map(J=>Po(g.$r,J));return{userId:m,batchId:v.batchId,localWriteTimeMs:v.localWriteTime.toMillis(),baseMutations:N,mutations:q}}(this.serializer,this.userId,u),l=[];let d=new De((C,g)=>ae(C.canonicalString(),g.canonicalString()));for(const C of s){const g=Vm(this.userId,C.key.path,a);d=d.add(C.key.path.popLast()),l.push(o.put(B)),l.push(i.put(g,GA))}return d.forEach(C=>{l.push(this.indexManager.addToCollectionParentIndex(e,C))}),e.addOnCommittedListener(()=>{this.Kr[a]=u.keys()}),b.waitFor(l).next(()=>u)})}lookupMutationBatch(e,t){return Qn(e).get(t).next(n=>n?(j(n.userId===this.userId,48,"Unexpected user for mutation batch",{userId:n.userId,batchId:t}),jr(this.serializer,n)):null)}Wr(e,t){return this.Kr[t]?b.resolve(this.Kr[t]):this.lookupMutationBatch(e,t).next(n=>{if(n){const s=n.keys();return this.Kr[t]=s,s}return null})}getNextMutationBatchAfterBatchId(e,t){const n=t+1,s=IDBKeyRange.lowerBound([this.userId,n]);let i=null;return Qn(e).Hn({index:Qr,range:s},(o,a,u)=>{a.userId===this.userId&&(j(a.batchId>=n,47524,{Gr:n}),i=jr(this.serializer,a)),u.done()}).next(()=>i)}getHighestUnacknowledgedBatchId(e){const t=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let n=Xr;return Qn(e).Hn({index:Qr,range:t,reverse:!0},(s,i,o)=>{n=i.batchId,o.done()}).next(()=>n)}getAllMutationBatches(e){const t=IDBKeyRange.bound([this.userId,Xr],[this.userId,Number.POSITIVE_INFINITY]);return Qn(e).Qn(Qr,t).next(n=>n.map(s=>jr(this.serializer,s)))}getAllMutationBatchesAffectingDocumentKey(e,t){const n=su(this.userId,t.path),s=IDBKeyRange.lowerBound(n),i=[];return js(e).Hn({range:s},(o,a,u)=>{const[B,l,d]=o,C=Bn(l);if(B===this.userId&&t.path.isEqual(C))return Qn(e).get(d).next(g=>{if(!g)throw ee(61480,{zr:o,batchId:d});j(g.userId===this.userId,10503,"Unexpected user for mutation batch",{userId:g.userId,batchId:d}),i.push(jr(this.serializer,g))});u.done()}).next(()=>i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new De(ae);const s=[];return t.forEach(i=>{const o=su(this.userId,i.path),a=IDBKeyRange.lowerBound(o),u=js(e).Hn({range:a},(B,l,d)=>{const[C,g,m]=B,v=Bn(g);C===this.userId&&i.path.isEqual(v)?n=n.add(m):d.done()});s.push(u)}),b.waitFor(s).next(()=>this.jr(e,n))}getAllMutationBatchesAffectingQuery(e,t){const n=t.path,s=n.length+1,i=su(this.userId,n),o=IDBKeyRange.lowerBound(i);let a=new De(ae);return js(e).Hn({range:o},(u,B,l)=>{const[d,C,g]=u,m=Bn(C);d===this.userId&&n.isPrefixOf(m)?m.length===s&&(a=a.add(g)):l.done()}).next(()=>this.jr(e,a))}jr(e,t){const n=[],s=[];return t.forEach(i=>{s.push(Qn(e).get(i).next(o=>{if(o===null)throw ee(35274,{batchId:i});j(o.userId===this.userId,9748,"Unexpected user for mutation batch",{userId:o.userId,batchId:i}),n.push(jr(this.serializer,o))}))}),b.waitFor(s).next(()=>n)}removeMutationBatch(e,t){return Wm(e.qr,this.userId,t).next(n=>(e.addOnCommittedListener(()=>{this.Hr(t.batchId)}),b.forEach(n,s=>this.referenceDelegate.markPotentiallyOrphaned(e,s))))}Hr(e){delete this.Kr[e]}performConsistencyCheck(e){return this.checkEmpty(e).next(t=>{if(!t)return b.resolve();const n=IDBKeyRange.lowerBound(function(o){return[o]}(this.userId)),s=[];return js(e).Hn({range:n},(i,o,a)=>{if(i[0]===this.userId){const u=Bn(i[1]);s.push(u)}else a.done()}).next(()=>{j(s.length===0,56720,{Jr:s.map(i=>i.canonicalString())})})})}containsKey(e,t){return Xm(e,this.userId,t)}Yr(e){return Zm(e).get(this.userId).next(t=>t||{userId:this.userId,lastAcknowledgedBatchId:Xr,lastStreamToken:""})}}function Xm(r,e,t){const n=su(e,t.path),s=n[1],i=IDBKeyRange.lowerBound(n);let o=!1;return js(r).Hn({range:i,jn:!0},(a,u,B)=>{const[l,d,C]=a;l===e&&d===s&&(o=!0),B.done()}).next(()=>o)}function Qn(r){return Ze(r,$t)}function js(r){return Ze(r,si)}function Zm(r){return Ze(r,ko)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hR{getBundleMetadata(e,t){return wC(e).get(t).next(n=>{if(n)return function(i){return{id:i.bundleId,createTime:Cs(i.createTime),version:i.version}}(n)})}saveBundleMetadata(e,t){return wC(e).put(function(s){return{bundleId:s.id,createTime:fs(it(s.createTime)),version:s.version}}(t))}getNamedQuery(e,t){return TC(e).get(t).next(n=>{if(n)return function(i){return{name:i.name,query:Ym(i.bundledQuery),readTime:Cs(i.readTime)}}(n)})}saveNamedQuery(e,t){return TC(e).put(function(s){return{name:s.name,readTime:fs(it(s.readTime)),bundledQuery:s.bundledQuery}}(t))}}function wC(r){return Ze(r,uc)}function TC(r){return Ze(r,cc)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hc{constructor(e,t){this.serializer=e,this.userId=t}static Qr(e,t){const n=t.uid||"";return new hc(e,n)}getOverlay(e,t){return Ns(e).get(DC(this.userId,t)).next(n=>n?qa(this.serializer,n):null)}getOverlays(e,t){const n=qt();return b.forEach(t,s=>this.getOverlay(e,s).next(i=>{i!==null&&n.set(s,i)})).next(()=>n)}getAllOverlays(e,t){const n=qt();return Ns(e).Hn((s,i)=>{const o=qa(this.serializer,i);o.largestBatchId>t&&n.set(o.getKey(),o)}).next(()=>n)}saveOverlays(e,t,n){const s=[];return n.forEach((i,o)=>{const a=new sh(t,o);s.push(this.Zr(e,a))}),b.waitFor(s)}removeOverlaysForBatchId(e,t,n){const s=new Set;t.forEach(o=>s.add(Ct(o.getCollectionPath())));const i=[];return s.forEach(o=>{const a=IDBKeyRange.bound([this.userId,o,n],[this.userId,o,n+1],!1,!0);i.push(Ns(e).zn(YB,a))}),b.waitFor(i)}getOverlaysForCollection(e,t,n){const s=qt(),i=Ct(t),o=IDBKeyRange.bound([this.userId,i,n],[this.userId,i,Number.POSITIVE_INFINITY],!0);return Ns(e).Qn(YB,o).next(a=>{for(const u of a){const B=qa(this.serializer,u);s.set(B.getKey(),B)}return s})}getOverlaysForCollectionGroup(e,t,n,s){const i=qt();let o;const a=IDBKeyRange.bound([this.userId,t,n],[this.userId,t,Number.POSITIVE_INFINITY],!0);return Ns(e).Hn({index:qm,range:a},(u,B,l)=>{const d=qa(this.serializer,B);i.size()<s||d.largestBatchId===o?(i.set(d.getKey(),d),o=d.largestBatchId):l.done()}).next(()=>i)}Zr(e,t){return Ns(e).put(function(s,i,o){const[a,u,B]=DC(i,o.mutation.key);return{userId:i,collectionPath:u,documentId:B,collectionGroup:o.mutation.key.getCollectionGroup(),largestBatchId:o.largestBatchId,overlayMutation:Po(s.$r,o.mutation)}}(this.serializer,this.userId,t))}}function Ns(r){return Ze(r,Bc)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dR{Xr(e){return Ze(e,nh)}getSessionToken(e){return this.Xr(e).get("sessionToken").next(t=>{const n=t==null?void 0:t.value;return n?xe.fromUint8Array(n):xe.EMPTY_BYTE_STRING})}setSessionToken(e,t){return this.Xr(e).put({name:"sessionToken",value:t.toUint8Array()})}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Jr{constructor(){}ei(e,t){this.ti(e,t),t.ni()}ti(e,t){if("nullValue"in e)this.ri(t,5);else if("booleanValue"in e)this.ri(t,10),t.ii(e.booleanValue?1:0);else if("integerValue"in e)this.ri(t,15),t.ii(Re(e.integerValue));else if("doubleValue"in e){const n=Re(e.doubleValue);isNaN(n)?this.ri(t,13):(this.ri(t,15),Xs(n)?t.ii(0):t.ii(n))}else if("timestampValue"in e){let n=e.timestampValue;this.ri(t,20),typeof n=="string"&&(n=On(n)),t.si(`${n.seconds||""}`),t.ii(n.nanos||0)}else if("stringValue"in e)this._i(e.stringValue,t),this.oi(t);else if("bytesValue"in e)this.ri(t,30),t.ai(Nn(e.bytesValue)),this.oi(t);else if("referenceValue"in e)this.ui(e.referenceValue,t);else if("geoPointValue"in e){const n=e.geoPointValue;this.ri(t,45),t.ii(n.latitude||0),t.ii(n.longitude||0)}else"mapValue"in e?Eg(e)?this.ri(t,Number.MAX_SAFE_INTEGER):Bs(e)?this.ci(e.mapValue,t):(this.li(e.mapValue,t),this.oi(t)):"arrayValue"in e?(this.Ei(e.arrayValue,t),this.oi(t)):ee(19022,{hi:e})}_i(e,t){this.ri(t,25),this.Ti(e,t)}Ti(e,t){t.si(e)}li(e,t){const n=e.fields||{};this.ri(t,55);for(const s of Object.keys(n))this._i(s,t),this.ti(n[s],t)}ci(e,t){var o,a;const n=e.fields||{};this.ri(t,53);const s=cs,i=((a=(o=n[s].arrayValue)==null?void 0:o.values)==null?void 0:a.length)||0;this.ri(t,15),t.ii(Re(i)),this._i(s,t),this.ti(n[s],t)}Ei(e,t){const n=e.values||[];this.ri(t,50);for(const s of n)this.ti(s,t)}ui(e,t){this.ri(t,37),W.fromName(e).path.forEach(n=>{this.ri(t,60),this.Ti(n,t)})}ri(e,t){e.ii(t)}oi(e){e.ii(2)}}Jr.Pi=new Jr;/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law | agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES | CONDITIONS OF ANY KIND, either express | implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Fs=255;function fR(r){if(r===0)return 8;let e=0;return r>>4||(e+=4,r<<=4),r>>6||(e+=2,r<<=2),r>>7||(e+=1),e}function AC(r){const e=64-function(n){let s=0;for(let i=0;i<8;++i){const o=fR(255&n[i]);if(s+=o,o!==8)break}return s}(r);return Math.ceil(e/8)}class CR{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Ii(e){const t=e[Symbol.iterator]();let n=t.next();for(;!n.done;)this.Ri(n.value),n=t.next();this.Ai()}Vi(e){const t=e[Symbol.iterator]();let n=t.next();for(;!n.done;)this.di(n.value),n=t.next();this.fi()}mi(e){for(const t of e){const n=t.charCodeAt(0);if(n<128)this.Ri(n);else if(n<2048)this.Ri(960|n>>>6),this.Ri(128|63&n);else if(t<"\uD800"||"\uDBFF"<t)this.Ri(480|n>>>12),this.Ri(128|63&n>>>6),this.Ri(128|63&n);else{const s=t.codePointAt(0);this.Ri(240|s>>>18),this.Ri(128|63&s>>>12),this.Ri(128|63&s>>>6),this.Ri(128|63&s)}}this.Ai()}pi(e){for(const t of e){const n=t.charCodeAt(0);if(n<128)this.di(n);else if(n<2048)this.di(960|n>>>6),this.di(128|63&n);else if(t<"\uD800"||"\uDBFF"<t)this.di(480|n>>>12),this.di(128|63&n>>>6),this.di(128|63&n);else{const s=t.codePointAt(0);this.di(240|s>>>18),this.di(128|63&s>>>12),this.di(128|63&s>>>6),this.di(128|63&s)}}this.fi()}gi(e){const t=this.yi(e),n=AC(t);this.wi(1+n),this.buffer[this.position++]=255&n;for(let s=t.length-n;s<t.length;++s)this.buffer[this.position++]=255&t[s]}bi(e){const t=this.yi(e),n=AC(t);this.wi(1+n),this.buffer[this.position++]=~(255&n);for(let s=t.length-n;s<t.length;++s)this.buffer[this.position++]=~(255&t[s])}Si(){this.Di(Fs),this.Di(255)}xi(){this.Ci(Fs),this.Ci(255)}reset(){this.position=0}seed(e){this.wi(e.length),this.buffer.set(e,this.position),this.position+=e.length}Fi(){return this.buffer.slice(0,this.position)}yi(e){const t=function(i){const o=new DataView(new ArrayBuffer(8));return o.setFloat64(0,i,!1),new Uint8Array(o.buffer)}(e),n=!!(128&t[0]);t[0]^=n?255:128;for(let s=1;s<t.length;++s)t[s]^=n?255:0;return t}Ri(e){const t=255&e;t===0?(this.Di(0),this.Di(255)):t===Fs?(this.Di(Fs),this.Di(0)):this.Di(t)}di(e){const t=255&e;t===0?(this.Ci(0),this.Ci(255)):t===Fs?(this.Ci(Fs),this.Ci(0)):this.Ci(e)}Ai(){this.Di(0),this.Di(1)}fi(){this.Ci(0),this.Ci(1)}Di(e){this.wi(1),this.buffer[this.position++]=e}Ci(e){this.wi(1),this.buffer[this.position++]=~e}wi(e){const t=e+this.position;if(t<=this.buffer.length)return;let n=2*this.buffer.length;n<t&&(n=t);const s=new Uint8Array(n);s.set(this.buffer),this.buffer=s}}class pR{constructor(e){this.Oi=e}ai(e){this.Oi.Ii(e)}si(e){this.Oi.mi(e)}ii(e){this.Oi.gi(e)}ni(){this.Oi.Si()}}class gR{constructor(e){this.Oi=e}ai(e){this.Oi.Vi(e)}si(e){this.Oi.pi(e)}ii(e){this.Oi.bi(e)}ni(){this.Oi.xi()}}class Hi{constructor(){this.Oi=new CR,this.ascending=new pR(this.Oi),this.descending=new gR(this.Oi)}seed(e){this.Oi.seed(e)}Mi(e){return e===0?this.ascending:this.descending}Fi(){return this.Oi.Fi()}reset(){this.Oi.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kr{constructor(e,t,n,s){this.Ni=e,this.Li=t,this.Bi=n,this.Ui=s}ki(){const e=this.Ui.length,t=e===0||this.Ui[e-1]===255?e+1:e,n=new Uint8Array(t);return n.set(this.Ui,0),t!==e?n.set([0],this.Ui.length):++n[n.length-1],new Kr(this.Ni,this.Li,this.Bi,n)}qi(e,t,n){return{indexId:this.Ni,uid:e,arrayValue:ou(this.Bi),directionalValue:ou(this.Ui),orderedDocumentKey:ou(t),documentKey:n.path.toArray()}}$i(e,t,n){const s=this.qi(e,t,n);return[s.indexId,s.uid,s.arrayValue,s.directionalValue,s.orderedDocumentKey,s.documentKey]}}function $n(r,e){let t=r.Ni-e.Ni;return t!==0?t:(t=RC(r.Bi,e.Bi),t!==0?t:(t=RC(r.Ui,e.Ui),t!==0?t:W.comparator(r.Li,e.Li)))}function RC(r,e){for(let t=0;t<r.length&&t<e.length;++t){const n=r[t]-e[t];if(n!==0)return n}return r.length-e.length}function ou(r){return qp()?function(t){let n="";for(let s=0;s<t.length;s++)n+=String.fromCharCode(t[s]);return n}(r):r}function vC(r){return typeof r!="string"?r:function(t){const n=new Uint8Array(t.length);for(let s=0;s<t.length;s++)n[s]=t.charCodeAt(s);return n}(r)}class PC{constructor(e){this.Ki=new De((t,n)=>$e.comparator(t.field,n.field)),this.collectionId=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment(),this.Qi=e.orderBy,this.Wi=[];for(const t of e.filters){const n=t;n.isInequality()?this.Ki=this.Ki.add(n):this.Wi.push(n)}}get Gi(){return this.Ki.size>1}zi(e){if(j(e.collectionGroup===this.collectionId,49279),this.Gi)return!1;const t=GB(e);if(t!==void 0&&!this.ji(t))return!1;const n=Ur(e);let s=new Set,i=0,o=0;for(;i<n.length&&this.ji(n[i]);++i)s=s.add(n[i].fieldPath.canonicalString());if(i===n.length)return!0;if(this.Ki.size>0){const a=this.Ki.getIterator().getNext();if(!s.has(a.field.canonicalString())){const u=n[i];if(!this.Hi(a,u)||!this.Ji(this.Qi[o++],u))return!1}++i}for(;i<n.length;++i){const a=n[i];if(o>=this.Qi.length||!this.Ji(this.Qi[o++],a))return!1}return!0}Yi(){if(this.Gi)return null;let e=new De($e.comparator);const t=[];for(const n of this.Wi)if(!n.field.isKeyField())if(n.op==="array-contains"||n.op==="array-contains-any")t.push(new eu(n.field,2));else{if(e.has(n.field))continue;e=e.add(n.field),t.push(new eu(n.field,0))}for(const n of this.Qi)n.field.isKeyField()||e.has(n.field)||(e=e.add(n.field),t.push(new eu(n.field,n.dir==="asc"?0:1)));return new _u(_u.UNKNOWN_ID,this.collectionId,t,vo.empty())}ji(e){for(const t of this.Wi)if(this.Hi(t,e))return!0;return!1}Hi(e,t){if(e===void 0||!e.field.isEqual(t.fieldPath))return!1;const n=e.op==="array-contains"||e.op==="array-contains-any";return t.kind===2===n}Ji(e,t){return!!e.field.isEqual(t.fieldPath)&&(t.kind===0&&e.dir==="asc"||t.kind===1&&e.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function e_(r){var t,n;if(j(r instanceof Ce||r instanceof ye,20012),r instanceof Ce){if(r instanceof Lg){const s=((n=(t=r.value.arrayValue)==null?void 0:t.values)==null?void 0:n.map(i=>Ce.create(r.field,"==",i)))||[];return ye.create(s,"or")}return r}const e=r.filters.map(s=>e_(s));return ye.create(e,r.op)}function mR(r){if(r.getFilters().length===0)return[];const e=nl(e_(r));return j(t_(e),7391),el(e)||tl(e)?[e]:e.getFilters()}function el(r){return r instanceof Ce}function tl(r){return r instanceof ye&&yl(r)}function t_(r){return el(r)||tl(r)||function(t){if(t instanceof ye&&VB(t)){for(const n of t.getFilters())if(!el(n)&&!tl(n))return!1;return!0}return!1}(r)}function nl(r){if(j(r instanceof Ce||r instanceof ye,34018),r instanceof Ce)return r;if(r.filters.length===1)return nl(r.filters[0]);const e=r.filters.map(n=>nl(n));let t=ye.create(e,r.op);return t=bu(t),t_(t)?t:(j(t instanceof ye,64498),j(ni(t),40251),j(t.filters.length>1,57927),t.filters.reduce((n,s)=>ih(n,s)))}function ih(r,e){let t;return j(r instanceof Ce||r instanceof ye,38388),j(e instanceof Ce||e instanceof ye,25473),t=r instanceof Ce?e instanceof Ce?function(s,i){return ye.create([s,i],"and")}(r,e):bC(r,e):e instanceof Ce?bC(e,r):function(s,i){if(j(s.filters.length>0&&i.filters.length>0,48005),ni(s)&&ni(i))return Og(s,i.getFilters());const o=VB(s)?s:i,a=VB(s)?i:s,u=o.filters.map(B=>ih(B,a));return ye.create(u,"or")}(r,e),bu(t)}function bC(r,e){if(ni(e))return Og(e,r.getFilters());{const t=e.filters.map(n=>ih(r,n));return ye.create(t,"or")}}function bu(r){if(j(r instanceof Ce||r instanceof ye,11850),r instanceof Ce)return r;const e=r.getFilters();if(e.length===1)return bu(e[0]);if(bg(r))return r;const t=e.map(s=>bu(s)),n=[];return t.forEach(s=>{s instanceof Ce?n.push(s):s instanceof ye&&(s.op===r.op?n.push(...s.filters):n.push(s))}),n.length===1?n[0]:ye.create(n,r.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _R{constructor(){this.Zi=new oh}addToCollectionParentIndex(e,t){return this.Zi.add(t),b.resolve()}getCollectionParents(e,t){return b.resolve(this.Zi.getEntries(t))}addFieldIndex(e,t){return b.resolve()}deleteFieldIndex(e,t){return b.resolve()}deleteAllFieldIndexes(e){return b.resolve()}createTargetIndexes(e,t){return b.resolve()}getDocumentsMatchingTarget(e,t){return b.resolve(null)}getIndexType(e,t){return b.resolve(0)}getFieldIndexes(e,t){return b.resolve([])}getNextCollectionGroupToUpdate(e){return b.resolve(null)}getMinOffset(e,t){return b.resolve(Mt.min())}getMinOffsetFromCollectionGroup(e,t){return b.resolve(Mt.min())}updateCollectionGroup(e,t,n){return b.resolve()}updateIndexEntries(e,t){return b.resolve()}}class oh{constructor(){this.index={}}add(e){const t=e.lastSegment(),n=e.popLast(),s=this.index[t]||new De(de.comparator),i=!s.has(n);return this.index[t]=s.add(n),i}has(e){const t=e.lastSegment(),n=e.popLast(),s=this.index[t];return s&&s.has(n)}getEntries(e){return(this.index[e]||new De(de.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const SC="IndexedDbIndexManager",ja=new Uint8Array(0);class ER{constructor(e,t){this.databaseId=t,this.Xi=new oh,this.es=new Gn(n=>Eu(n),(n,s)=>Tl(n,s)),this.uid=e.uid||""}addToCollectionParentIndex(e,t){if(!this.Xi.has(t)){const n=t.lastSegment(),s=t.popLast();e.addOnCommittedListener(()=>{this.Xi.add(t)});const i={collectionId:n,parent:Ct(s)};return OC(e).put(i)}return b.resolve()}getCollectionParents(e,t){const n=[],s=IDBKeyRange.bound([t,""],[Bg(t),""],!1,!0);return OC(e).Qn(s).next(i=>{for(const o of i){if(o.collectionId!==t)break;n.push(Bn(o.parent))}return n})}addFieldIndex(e,t){const n=qi(e),s=function(a){return{indexId:a.indexId,collectionGroup:a.collectionGroup,fields:a.fields.map(u=>[u.fieldPath.canonicalString(),u.kind])}}(t);delete s.indexId;const i=n.add(s);if(t.indexState){const o=ks(e);return i.next(a=>{o.put(yC(a,this.uid,t.indexState.sequenceNumber,t.indexState.offset))})}return i.next()}deleteFieldIndex(e,t){const n=qi(e),s=ks(e),i=Ls(e);return n.delete(t.indexId).next(()=>s.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0))).next(()=>i.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0)))}deleteAllFieldIndexes(e){const t=qi(e),n=Ls(e),s=ks(e);return t.zn().next(()=>n.zn()).next(()=>s.zn())}createTargetIndexes(e,t){return b.forEach(this.ts(t),n=>this.getIndexType(e,n).next(s=>{if(s===0||s===1){const i=new PC(n).Yi();if(i!=null)return this.addFieldIndex(e,i)}}))}getDocumentsMatchingTarget(e,t){const n=Ls(e);let s=!0;const i=new Map;return b.forEach(this.ts(t),o=>this.ns(e,o).next(a=>{s&&(s=!!a),i.set(o,a)})).next(()=>{if(s){let o=Be();const a=[];return b.forEach(i,(u,B)=>{U(SC,`Using index ${function(X){return`id=${X.indexId}|cg=${X.collectionGroup}|f=${X.fields.map(se=>`${se.fieldPath}:${se.kind}`).join(",")}`}(u)} to execute ${Eu(t)}`);const l=function(X,se){const ue=GB(se);if(ue===void 0)return null;for(const ce of Iu(X,ue.fieldPath))switch(ce.op){case"array-contains-any":return ce.value.arrayValue.values||[];case"array-contains":return[ce.value]}return null}(B,u),d=function(X,se){const ue=new Map;for(const ce of Ur(se))for(const T of Iu(X,ce.fieldPath))switch(T.op){case"==":case"in":ue.set(ce.fieldPath.canonicalString(),T.value);break;case"not-in":case"!=":return ue.set(ce.fieldPath.canonicalString(),T.value),Array.from(ue.values())}return null}(B,u),C=function(X,se){const ue=[];let ce=!0;for(const T of Ur(se)){const I=T.kind===0?Yf(X,T.fieldPath,X.startAt):Xf(X,T.fieldPath,X.startAt);ue.push(I.value),ce&&(ce=I.inclusive)}return new ti(ue,ce)}(B,u),g=function(X,se){const ue=[];let ce=!0;for(const T of Ur(se)){const I=T.kind===0?Xf(X,T.fieldPath,X.endAt):Yf(X,T.fieldPath,X.endAt);ue.push(I.value),ce&&(ce=I.inclusive)}return new ti(ue,ce)}(B,u),m=this.rs(u,B,C),v=this.rs(u,B,g),N=this.ss(u,B,d),q=this._s(u.indexId,l,m,C.inclusive,v,g.inclusive,N);return b.forEach(q,J=>n.Gn(J,t.limit).next(X=>{X.forEach(se=>{const ue=W.fromSegments(se.documentKey);o.has(ue)||(o=o.add(ue),a.push(ue))})}))}).next(()=>a)}return b.resolve(null)})}ts(e){let t=this.es.get(e);return t||(e.filters.length===0?t=[e]:t=mR(ye.create(e.filters,"and")).map(n=>UB(e.path,e.collectionGroup,e.orderBy,n.getFilters(),e.limit,e.startAt,e.endAt)),this.es.set(e,t),t)}_s(e,t,n,s,i,o,a){const u=(t!=null?t.length:1)*Math.max(n.length,i.length),B=u/(t!=null?t.length:1),l=[];for(let d=0;d<u;++d){const C=t?this.us(t[d/B]):ja,g=this.cs(e,C,n[d%B],s),m=this.ls(e,C,i[d%B],o),v=a.map(N=>this.cs(e,C,N,!0));l.push(...this.createRange(g,m,v))}return l}cs(e,t,n,s){const i=new Kr(e,W.empty(),t,n);return s?i:i.ki()}ls(e,t,n,s){const i=new Kr(e,W.empty(),t,n);return s?i.ki():i}ns(e,t){const n=new PC(t),s=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment();return this.getFieldIndexes(e,s).next(i=>{let o=null;for(const a of i)n.zi(a)&&(!o||a.fields.length>o.fields.length)&&(o=a);return o})}getIndexType(e,t){let n=2;const s=this.ts(t);return b.forEach(s,i=>this.ns(e,i).next(o=>{o?n!==0&&o.fields.length<function(u){let B=new De($e.comparator),l=!1;for(const d of u.filters)for(const C of d.getFlattenedFilters())C.field.isKeyField()||(C.op==="array-contains"||C.op==="array-contains-any"?l=!0:B=B.add(C.field));for(const d of u.orderBy)d.field.isKeyField()||(B=B.add(d.field));return B.size+(l?1:0)}(i)&&(n=1):n=0})).next(()=>function(o){return o.limit!==null}(t)&&s.length>1&&n===2?1:n)}Es(e,t){const n=new Hi;for(const s of Ur(e)){const i=t.data.field(s.fieldPath);if(i==null)return null;const o=n.Mi(s.kind);Jr.Pi.ei(i,o)}return n.Fi()}us(e){const t=new Hi;return Jr.Pi.ei(e,t.Mi(0)),t.Fi()}hs(e,t){const n=new Hi;return Jr.Pi.ei(yo(this.databaseId,t),n.Mi(function(i){const o=Ur(i);return o.length===0?0:o[o.length-1].kind}(e))),n.Fi()}ss(e,t,n){if(n===null)return[];let s=[];s.push(new Hi);let i=0;for(const o of Ur(e)){const a=n[i++];for(const u of s)if(this.Ts(t,o.fieldPath)&&Dr(a))s=this.Ps(s,o,a);else{const B=u.Mi(o.kind);Jr.Pi.ei(a,B)}}return this.Is(s)}rs(e,t,n){return this.ss(e,t,n.position)}Is(e){const t=[];for(let n=0;n<e.length;++n)t[n]=e[n].Fi();return t}Ps(e,t,n){const s=[...e],i=[];for(const o of n.arrayValue.values||[])for(const a of s){const u=new Hi;u.seed(a.Fi()),Jr.Pi.ei(o,u.Mi(t.kind)),i.push(u)}return i}Ts(e,t){return!!e.filters.find(n=>n instanceof Ce&&n.field.isEqual(t)&&(n.op==="in"||n.op==="not-in"))}getFieldIndexes(e,t){const n=qi(e),s=ks(e);return(t?n.Qn($B,IDBKeyRange.bound(t,t)):n.Qn()).next(i=>{const o=[];return b.forEach(i,a=>s.get([a.indexId,this.uid]).next(u=>{o.push(function(l,d){const C=d?new vo(d.sequenceNumber,new Mt(Cs(d.readTime),new W(Bn(d.documentKey)),d.largestBatchId)):vo.empty(),g=l.fields.map(([m,v])=>new eu($e.fromServerFormat(m),v));return new _u(l.indexId,l.collectionGroup,g,C)}(a,u))})).next(()=>o)})}getNextCollectionGroupToUpdate(e){return this.getFieldIndexes(e).next(t=>t.length===0?null:(t.sort((n,s)=>{const i=n.indexState.sequenceNumber-s.indexState.sequenceNumber;return i!==0?i:ae(n.collectionGroup,s.collectionGroup)}),t[0].collectionGroup))}updateCollectionGroup(e,t,n){const s=qi(e),i=ks(e);return this.Rs(e).next(o=>s.Qn($B,IDBKeyRange.bound(t,t)).next(a=>b.forEach(a,u=>i.put(yC(u.indexId,this.uid,o,n)))))}updateIndexEntries(e,t){const n=new Map;return b.forEach(t,(s,i)=>{const o=n.get(s.collectionGroup);return(o?b.resolve(o):this.getFieldIndexes(e,s.collectionGroup)).next(a=>(n.set(s.collectionGroup,a),b.forEach(a,u=>this.As(e,s,u).next(B=>{const l=this.Vs(i,u);return B.isEqual(l)?b.resolve():this.ds(e,i,u,B,l)}))))})}fs(e,t,n,s){return Ls(e).put(s.qi(this.uid,this.hs(n,t.key),t.key))}ps(e,t,n,s){return Ls(e).delete(s.$i(this.uid,this.hs(n,t.key),t.key))}As(e,t,n){const s=Ls(e);let i=new De($n);return s.Hn({index:Hm,range:IDBKeyRange.only([n.indexId,this.uid,ou(this.hs(n,t))])},(o,a)=>{i=i.add(new Kr(n.indexId,t,vC(a.arrayValue),vC(a.directionalValue)))}).next(()=>i)}Vs(e,t){let n=new De($n);const s=this.Es(t,e);if(s==null)return n;const i=GB(t);if(i!=null){const o=e.data.field(i.fieldPath);if(Dr(o))for(const a of o.arrayValue.values||[])n=n.add(new Kr(t.indexId,e.key,this.us(a),s))}else n=n.add(new Kr(t.indexId,e.key,ja,s));return n}ds(e,t,n,s,i){U(SC,"Updating index entries for document '%s'",t.key);const o=[];return function(u,B,l,d,C){const g=u.getIterator(),m=B.getIterator();let v=Ss(g),N=Ss(m);for(;v||N;){let q=!1,J=!1;if(v&&N){const X=l(v,N);X<0?J=!0:X>0&&(q=!0)}else v!=null?J=!0:q=!0;q?(d(N),N=Ss(m)):J?(C(v),v=Ss(g)):(v=Ss(g),N=Ss(m))}}(s,i,$n,a=>{o.push(this.fs(e,t,n,a))},a=>{o.push(this.ps(e,t,n,a))}),b.waitFor(o)}Rs(e){let t=1;return ks(e).Hn({index:Um,reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},(n,s,i)=>{i.done(),t=s.sequenceNumber+1}).next(()=>t)}createRange(e,t,n){n=n.sort((o,a)=>$n(o,a)).filter((o,a,u)=>!a||$n(o,u[a-1])!==0);const s=[];s.push(e);for(const o of n){const a=$n(o,e),u=$n(o,t);if(a===0)s[0]=e.ki();else if(a>0&&u<0)s.push(o),s.push(o.ki());else if(u>0)break}s.push(t);const i=[];for(let o=0;o<s.length;o+=2){if(this.gs(s[o],s[o+1]))return[];const a=s[o].$i(this.uid,ja,W.empty()),u=s[o+1].$i(this.uid,ja,W.empty());i.push(IDBKeyRange.bound(a,u))}return i}gs(e,t){return $n(e,t)>0}getMinOffsetFromCollectionGroup(e,t){return this.getFieldIndexes(e,t).next(NC)}getMinOffset(e,t){return b.mapArray(this.ts(t),n=>this.ns(e,n).next(s=>s||ee(44426))).next(NC)}}function OC(r){return Ze(r,Vo)}function Ls(r){return Ze(r,Bo)}function qi(r){return Ze(r,th)}function ks(r){return Ze(r,co)}function NC(r){j(r.length!==0,28825);let e=r[0].indexState.offset,t=e.largestBatchId;for(let n=1;n<r.length;n++){const s=r[n].indexState.offset;wl(s,e)<0&&(e=s),t<s.largestBatchId&&(t=s.largestBatchId)}return new Mt(e.readTime,e.documentKey,t)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kn{constructor(e){this.ys=e}next(){return this.ys+=2,this.ys}static ws(){return new kn(0)}static bs(){return new kn(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class IR{constructor(e,t){this.referenceDelegate=e,this.serializer=t}allocateTargetId(e){return this.Ss(e).next(t=>{const n=new kn(t.highestTargetId);return t.highestTargetId=n.next(),this.vs(e,t).next(()=>t.highestTargetId)})}getLastRemoteSnapshotVersion(e){return this.Ss(e).next(t=>te.fromTimestamp(new _e(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds)))}getHighestSequenceNumber(e){return this.Ss(e).next(t=>t.highestListenSequenceNumber)}setTargetsMetadata(e,t,n){return this.Ss(e).next(s=>(s.highestListenSequenceNumber=t,n&&(s.lastRemoteSnapshotVersion=n.toTimestamp()),t>s.highestListenSequenceNumber&&(s.highestListenSequenceNumber=t),this.vs(e,s)))}addTargetData(e,t){return this.Ds(e,t).next(()=>this.Ss(e).next(n=>(n.targetCount+=1,this.xs(t,n),this.vs(e,n))))}updateTargetData(e,t){return this.Ds(e,t)}removeTargetData(e,t){return this.removeMatchingKeysForTargetId(e,t.targetId).next(()=>xs(e).delete(t.targetId)).next(()=>this.Ss(e)).next(n=>(j(n.targetCount>0,8065),n.targetCount-=1,this.vs(e,n)))}removeTargets(e,t,n){let s=0;const i=[];return xs(e).Hn((o,a)=>{const u=Zi(this.serializer,a);u.sequenceNumber<=t&&n.get(u.targetId)===null&&(s++,i.push(this.removeTargetData(e,u)))}).next(()=>b.waitFor(i)).next(()=>s)}forEachTarget(e,t){return xs(e).Hn((n,s)=>{const i=Zi(this.serializer,s);t(i)})}Ss(e){return FC(e).get(Ru).next(t=>(j(t!==null,2888),t))}vs(e,t){return FC(e).put(Ru,t)}Ds(e,t){return xs(e).put($m(this.serializer,t))}xs(e,t){let n=!1;return e.targetId>t.highestTargetId&&(t.highestTargetId=e.targetId,n=!0),e.sequenceNumber>t.highestListenSequenceNumber&&(t.highestListenSequenceNumber=e.sequenceNumber,n=!0),n}getTargetCount(e){return this.Ss(e).next(t=>t.targetCount)}getTargetData(e,t){const n=ac(t),s=IDBKeyRange.bound([n,Number.NEGATIVE_INFINITY],[n,Number.POSITIVE_INFINITY]);let i=null;return xs(e).Hn({range:s,index:Gm},(o,a,u)=>{const B=Zi(this.serializer,a);Yl(t,B.target)&&(i=B,u.done())}).next(()=>i)}addMatchingKeys(e,t,n){const s=[],i=rr(e);return t.forEach(o=>{const a=Ct(o.path);s.push(i.put({targetId:n,path:a})),s.push(this.referenceDelegate.addReference(e,n,o))}),b.waitFor(s)}removeMatchingKeys(e,t,n){const s=rr(e);return b.forEach(t,i=>{const o=Ct(i.path);return b.waitFor([s.delete([n,o]),this.referenceDelegate.removeReference(e,n,i)])})}removeMatchingKeysForTargetId(e,t){const n=rr(e),s=IDBKeyRange.bound([t],[t+1],!1,!0);return n.delete(s)}getMatchingKeysForTargetId(e,t){const n=IDBKeyRange.bound([t],[t+1],!1,!0),s=rr(e);let i=Be();return s.Hn({range:n,jn:!0},(o,a,u)=>{const B=Bn(o[1]),l=new W(B);i=i.add(l)}).next(()=>i)}containsKey(e,t){const n=Ct(t.path),s=IDBKeyRange.bound([n],[Bg(n)],!1,!0);let i=0;return rr(e).Hn({index:eh,jn:!0,range:s},([o,a],u,B)=>{o!==0&&(i++,B.done())}).next(()=>i>0)}ye(e,t){return xs(e).get(t).next(n=>n?Zi(this.serializer,n):null)}}function xs(r){return Ze(r,ii)}function FC(r){return Ze(r,ts)}function rr(r){return Ze(r,oi)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class DR{constructor(e,t){this.db=e,this.garbageCollector=fm(this,t)}ir(e){const t=this.Cs(e);return this.db.getTargetCache().getTargetCount(e).next(n=>t.next(s=>n+s))}Cs(e){let t=0;return this.sr(e,n=>{t++}).next(()=>t)}forEachTarget(e,t){return this.db.getTargetCache().forEachTarget(e,t)}sr(e,t){return this.Fs(e,(n,s)=>t(s))}addReference(e,t,n){return Ja(e,n)}removeReference(e,t,n){return Ja(e,n)}removeTargets(e,t,n){return this.db.getTargetCache().removeTargets(e,t,n)}markPotentiallyOrphaned(e,t){return Ja(e,t)}Os(e,t){return function(s,i){let o=!1;return Zm(s).Jn(a=>Xm(s,a,i).next(u=>(u&&(o=!0),b.resolve(!u)))).next(()=>o)}(e,t)}removeOrphanedDocuments(e,t){const n=this.db.getRemoteDocumentCache().newChangeBuffer(),s=[];let i=0;return this.Fs(e,(o,a)=>{if(a<=t){const u=this.Os(e,o).next(B=>{if(!B)return i++,n.getEntry(e,o).next(()=>(n.removeEntry(o,te.min()),rr(e).delete(function(d){return[0,Ct(d.path)]}(o))))});s.push(u)}}).next(()=>b.waitFor(s)).next(()=>n.apply(e)).next(()=>i)}removeTarget(e,t){const n=t.withSequenceNumber(e.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(e,n)}updateLimboDocument(e,t){return Ja(e,t)}Fs(e,t){const n=rr(e);let s,i=jt.wn;return n.Hn({index:eh},([o,a],{path:u,sequenceNumber:B})=>{o===0?(i!==jt.wn&&t(new W(Bn(s)),i),i=B,s=u):i=jt.wn}).next(()=>{i!==jt.wn&&t(new W(Bn(s)),i)})}getCacheSize(e){return this.db.getRemoteDocumentCache().getSize(e)}}function Ja(r,e){return rr(r).put(function(n,s){return{targetId:0,path:Ct(n.path),sequenceNumber:s}}(e,r.currentSequenceNumber))}// Copyright 2024 Google LLC* @license
function n_(r,e){var n;let t=e;for(const s of r.stages)t=yR({serializer:r.serializer,serverTimestampBehavior:(n=r.listenOptions)==null?void 0:n.serverTimestampBehavior},s,t);return t}function dc(r,e){return n_(r,[e]).length>0}function r_(r,e){return je(r)?dc(r,e):Yu(r,e)}function yR(r,e,t){if(e instanceof ta)return function(s,i,o){return o.filter(a=>a.isFoundDocument()&&`/${a.key.getCollectionPath().canonicalString()}`===i.hr)}(0,e,t);if(e instanceof ra)return function(s,i,o){return o.filter(a=>{const u=uo(ie(i.condition).evaluate(s,a));return u!==void 0&&Wt(u,bt)})}(r,e,t);if(e instanceof na)return function(s,i,o){return o.filter(a=>a.isFoundDocument()&&a.key.getCollectionPath().lastSegment()===i.collectionId)}(0,e,t);if(e instanceof rc)return function(s,i,o){return o.filter(a=>a.isFoundDocument())}(0,0,t);if(e instanceof sc)return function(s,i,o){return o.filter(a=>a.isFoundDocument()&&i.Pr.has(a.key.path.toStringWithLeadingSlash()))}(0,e,t);if(e instanceof wr)return function(s,i,o){return o.slice(0,i.limit)}(0,e,t);if(e instanceof cn)return function(s,i,o){const a=i.orderings.map(u=>({Ms:ie(u.expr),direction:u.direction}));return[...o].sort((u,B)=>{for(const{Ms:l,direction:d}of a){const C=uo(l.evaluate(s,u)),g=uo(l.evaluate(s,B)),m=pt(C??dn,g??dn);if(m!==0)return d==="ascending"?m:-m}return 0})}(r,e,t);throw new Error(`Unknown stage: ${e._name}`)}function rl(r){const e=function(n){for(let s=n.stages.length-1;s>=0;s--){const i=n.stages[s];if(i instanceof cn)return i.orderings}throw new Error("Pipeline must contain at least one Sort stage")}(r);return(t,n)=>{for(const s of e){const i=uo(ie(s.expr).evaluate({serializer:r.serializer},t)),o=uo(ie(s.expr).evaluate({serializer:r.serializer},n)),a=pt(i||dn,o||dn);if(a!==0)return s.direction==="ascending"?a:-a}return 0}}function dB(r){for(let e=r.stages.length-1;e>=0;e--){const t=r.stages[e];if(t instanceof wr)return{limit:t.limit}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class s_{constructor(){this.changes=new Gn(e=>e.toString(),(e,t)=>e.isEqual(t)),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,Ne.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const n=this.changes.get(t);return n!==void 0?b.resolve(n):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wR{constructor(e){this.serializer=e}setIndexManager(e){this.indexManager=e}addEntry(e,t,n){return Yn(e).put(n)}removeEntry(e,t,n){return Yn(e).delete(function(i,o){const a=i.path.toArray();return[a.slice(0,a.length-2),a[a.length-2],Pu(o),a[a.length-1]]}(t,n))}updateMetadata(e,t){return this.getMetadata(e).next(n=>(n.byteSize+=t,this.Ns(e,n)))}getEntry(e,t){let n=Ne.newInvalidDocument(t);return Yn(e).Hn({index:iu,range:IDBKeyRange.only(ji(t))},(s,i)=>{n=this.Ls(t,i)}).next(()=>n)}Bs(e,t){let n={size:0,document:Ne.newInvalidDocument(t)};return Yn(e).Hn({index:iu,range:IDBKeyRange.only(ji(t))},(s,i)=>{n={document:this.Ls(t,i),size:vu(i)}}).next(()=>n)}getEntries(e,t){let n=Qe();return this.Us(e,t,(s,i)=>{const o=this.Ls(s,i);n=n.insert(s,o)}).next(()=>n)}getAllEntries(e){let t=Qe();return Yn(e).Hn((n,s)=>{const i=this.Ls(W.fromSegments(s.prefixPath.concat(s.collectionGroup,s.documentId)),s);t=t.insert(i.key,i)}).next(()=>t)}ks(e,t){let n=Qe(),s=new Oe(W.comparator);return this.Us(e,t,(i,o)=>{const a=this.Ls(i,o);n=n.insert(i,a),s=s.insert(i,vu(o))}).next(()=>({documents:n,qs:s}))}Us(e,t,n){if(t.isEmpty())return b.resolve();let s=new De(xC);t.forEach(u=>s=s.add(u));const i=IDBKeyRange.bound(ji(s.first()),ji(s.last())),o=s.getIterator();let a=o.getNext();return Yn(e).Hn({index:iu,range:i},(u,B,l)=>{const d=W.fromSegments([...B.prefixPath,B.collectionGroup,B.documentId]);for(;a&&xC(a,d)<0;)n(a,null),a=o.getNext();a&&a.isEqual(d)&&(n(a,B),a=o.hasNext()?o.getNext():null),a?l.Kn(ji(a)):l.done()}).next(()=>{for(;a;)n(a,null),a=o.hasNext()?o.getNext():null})}getDocumentsMatchingQuery(e,t,n,s,i){const o=je(t)?de.fromString(sa(t)):t.path,a=[o.popLast().toArray(),o.lastSegment(),Pu(n.readTime),n.documentKey.path.isEmpty()?"":n.documentKey.path.lastSegment()],u=[o.popLast().toArray(),o.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return Yn(e).Qn(IDBKeyRange.bound(a,u,!0)).next(B=>{i==null||i.incrementDocumentReadCount(B.length);let l=Qe();for(const d of B){const C=this.Ls(W.fromSegments(d.prefixPath.concat(d.collectionGroup,d.documentId)),d);C.isFoundDocument()&&(r_(t,C)||s.has(C.key))&&(l=l.insert(C.key,C))}return l})}getAllFromCollectionGroup(e,t,n,s){let i=Qe();const o=kC(t,n),a=kC(t,Mt.max());return Yn(e).Hn({index:Mm,range:IDBKeyRange.bound(o,a,!0)},(u,B,l)=>{const d=this.Ls(W.fromSegments(B.prefixPath.concat(B.collectionGroup,B.documentId)),B);i=i.insert(d.key,d),i.size===s&&l.done()}).next(()=>i)}newChangeBuffer(e){return new TR(this,!!e&&e.trackRemovals)}getSize(e){return this.getMetadata(e).next(t=>t.byteSize)}getMetadata(e){return LC(e).get(QB).next(t=>(j(!!t,20021),t))}Ns(e,t){return LC(e).put(QB,t)}Ls(e,t){if(t){const n=BR(this.serializer,t);if(!(n.isNoDocument()&&n.version.isEqual(te.min())))return n}return Ne.newInvalidDocument(e)}}function i_(r){return new wR(r)}class TR extends s_{constructor(e,t){super(),this.$s=e,this.trackRemovals=t,this.Ks=new Gn(n=>n.toString(),(n,s)=>n.isEqual(s))}applyChanges(e){const t=[];let n=0,s=new De((i,o)=>ae(i.canonicalString(),o.canonicalString()));return this.changes.forEach((i,o)=>{const a=this.Ks.get(i);if(t.push(this.$s.removeEntry(e,i,a.readTime)),o.isValidDocument()){const u=IC(this.$s.serializer,o);s=s.add(i.path.popLast());const B=vu(u);n+=B-a.size,t.push(this.$s.addEntry(e,i,u))}else if(n-=a.size,this.trackRemovals){const u=IC(this.$s.serializer,o.convertToNoDocument(te.min()));t.push(this.$s.addEntry(e,i,u))}}),s.forEach(i=>{t.push(this.$s.indexManager.addToCollectionParentIndex(e,i))}),t.push(this.$s.updateMetadata(e,n)),b.waitFor(t)}getFromCache(e,t){return this.$s.Bs(e,t).next(n=>(this.Ks.set(t,{size:n.size,readTime:n.document.readTime}),n.document))}getAllFromCache(e,t){return this.$s.ks(e,t).next(({documents:n,qs:s})=>(s.forEach((i,o)=>{this.Ks.set(i,{size:o,readTime:n.get(i).readTime})}),n))}}function LC(r){return Ze(r,xo)}function Yn(r){return Ze(r,Au)}function ji(r){const e=r.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function kC(r,e){const t=e.documentKey.path.toArray();return[r,Pu(e.readTime),t.slice(0,t.length-2),t.length>0?t[t.length-1]:""]}function xC(r,e){const t=r.path.toArray(),n=e.path.toArray();let s=0;for(let i=0;i<t.length-2&&i<n.length-2;++i)if(s=ae(t[i],n[i]),s)return s;return s=ae(t.length,n.length),s||(s=ae(t[t.length-2],n[n.length-2]),s||ae(t[t.length-1],n[n.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class AR{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class o_{constructor(e,t,n,s){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=n,this.indexManager=s}getDocument(e,t){let n=null;return this.documentOverlayCache.getOverlay(e,t).next(s=>(n=s,this.remoteDocumentCache.getEntry(e,t))).next(s=>(n!==null&&no(n.mutation,s,vt.empty(),_e.now()),s))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next(n=>this.getLocalViewOfDocuments(e,n,Be()).next(()=>n))}getLocalViewOfDocuments(e,t,n=Be()){const s=qt();return this.populateOverlays(e,s,t).next(()=>this.computeViews(e,t,s,n).next(i=>{let o=Hs();return i.forEach((a,u)=>{o=o.insert(a,u.overlayedDocument)}),o}))}getOverlayedDocuments(e,t){const n=qt();return this.populateOverlays(e,n,t).next(()=>this.computeViews(e,t,n,Be()))}populateOverlays(e,t,n){const s=[];return n.forEach(i=>{t.has(i)||s.push(i)}),this.documentOverlayCache.getOverlays(e,s).next(i=>{i.forEach((o,a)=>{t.set(o,a)})})}computeViews(e,t,n,s){let i=Qe();const o=io(),a=function(){return io()}();return t.forEach((u,B)=>{const l=n.get(B.key);s.has(B.key)&&(l===void 0||l.mutation instanceof Mn)?i=i.insert(B.key,B):l!==void 0?(o.set(B.key,l.mutation.getFieldMask()),no(l.mutation,B,l.mutation.getFieldMask(),_e.now())):o.set(B.key,vt.empty())}),this.recalculateAndSaveOverlays(e,i).next(u=>(u.forEach((B,l)=>o.set(B,l)),t.forEach((B,l)=>a.set(B,new AR(l,o.get(B)??null))),a))}recalculateAndSaveOverlays(e,t){const n=io();let s=new Oe((o,a)=>o-a),i=Be();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next(o=>{for(const a of o)a.keys().forEach(u=>{const B=t.get(u);if(B===null)return;let l=n.get(u)||vt.empty();l=a.applyToLocalView(B,l),n.set(u,l);const d=(s.get(a.batchId)||Be()).add(u);s=s.insert(a.batchId,d)})}).next(()=>{const o=[],a=s.getReverseIterator();for(;a.hasNext();){const u=a.getNext(),B=u.key,l=u.value,d=qg();l.forEach(C=>{if(!i.has(C)){const g=Rg(t.get(C),n.get(C));g!==null&&d.set(C,g),i=i.add(C)}}),o.push(this.documentOverlayCache.saveOverlays(e,B,d))}return b.waitFor(o)}).next(()=>n)}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next(n=>this.recalculateAndSaveOverlays(e,n))}getDocumentsMatchingQuery(e,t,n,s){return je(t)?this.getDocumentsMatchingPipeline(e,t,n,s):aw(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):xg(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,n,s):this.getDocumentsMatchingCollectionQuery(e,t,n,s)}getNextDocuments(e,t,n,s){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,n,s).next(i=>{const o=s-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,n.largestBatchId,s-i.size):b.resolve(qt());let a=Ro,u=i;return o.next(B=>b.forEach(B,(l,d)=>(a<d.largestBatchId&&(a=d.largestBatchId),i.get(l)?b.resolve():this.remoteDocumentCache.getEntry(e,l).next(C=>{u=u.insert(l,C)}))).next(()=>this.populateOverlays(e,B,i)).next(()=>this.computeViews(e,u,B,Be())).next(l=>({batchId:a,changes:Hg(l)})))})}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new W(t)).next(n=>{let s=Hs();return n.isFoundDocument()&&(s=s.insert(n.key,n)),s})}getDocumentsMatchingCollectionGroupQuery(e,t,n,s){const i=t.collectionGroup;let o=Hs();return this.indexManager.getCollectionParents(e,i).next(a=>b.forEach(a,u=>{const B=function(d,C){return new di(C,null,d.explicitOrderBy.slice(),d.filters.slice(),d.limit,d.limitType,d.startAt,d.endAt)}(t,u.child(i));return this.getDocumentsMatchingCollectionQuery(e,B,n,s).next(l=>{l.forEach((d,C)=>{o=o.insert(d,C)})})}).next(()=>o))}getDocumentsMatchingCollectionQuery(e,t,n,s){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,n.largestBatchId).next(o=>(i=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,i,s))).next(o=>this.retrieveMatchingLocalDocuments(i,o,a=>Yu(t,a)))}getDocumentsMatchingPipeline(e,t,n,s){if(Cr(t)==="collection_group"){const i=jl(t);let o=Hs();return this.indexManager.getCollectionParents(e,i).next(a=>b.forEach(a,u=>{const B=function(d,C){const g=d.stages.map(m=>m instanceof na?new ta(C.canonicalString(),{}):m);return new dt(d.serializer,g)}(t,u.child(i));return this.getDocumentsMatchingPipeline(e,B,n,s).next(l=>{l.forEach((d,C)=>{o=o.insert(d,C)})})}).next(()=>o))}{let i;return this.getOverlaysForPipeline(e,t,n.largestBatchId).next(o=>{switch(i=o,Cr(t)){case"collection":return this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,i,s);case"documents":let a=Be();for(const u of WB(t))a=a.add(W.fromPath(u));return this.remoteDocumentCache.getEntries(e,a);case"database":return this.remoteDocumentCache.getAllEntries(e);default:throw new H("invalid-argument",`Invalid pipeline source to execute offline: ${bn(t)}`)}}).next(o=>this.retrieveMatchingLocalDocuments(i,o,a=>dc(t,a)))}}retrieveMatchingLocalDocuments(e,t,n){e.forEach((i,o)=>{const a=o.getKey();t.get(a)===null&&(t=t.insert(a,Ne.newInvalidDocument(a)))});let s=Hs();return t.forEach((i,o)=>{const a=e.get(i);a!==void 0&&no(a.mutation,o,vt.empty(),_e.now()),n(o)&&(s=s.insert(i,o))}),s}getOverlaysForPipeline(e,t,n){switch(Cr(t)){case"collection":return this.documentOverlayCache.getOverlaysForCollection(e,de.fromString(sa(t)),n);case"collection_group":throw new H("invalid-argument",`Unexpected collection group pipeline: ${bn(t)}`);case"documents":return this.documentOverlayCache.getOverlays(e,WB(t).map(s=>W.fromPath(s)));case"database":return this.documentOverlayCache.getAllOverlays(e,n);default:throw new H("invalid-argument",`Failed to get overlays for pipeline: ${bn(t)}`)}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class RR{constructor(e){this.serializer=e,this.Qs=new Map,this.Ws=new Map}getBundleMetadata(e,t){return b.resolve(this.Qs.get(t))}saveBundleMetadata(e,t){return this.Qs.set(t.id,function(s){return{id:s.id,version:s.version,createTime:it(s.createTime)}}(t)),b.resolve()}getNamedQuery(e,t){return b.resolve(this.Ws.get(t))}saveNamedQuery(e,t){return this.Ws.set(t.name,function(s){return{name:s.name,query:Ym(s.bundledQuery),readTime:it(s.readTime)}}(t)),b.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vR{constructor(){this.overlays=new Oe(W.comparator),this.Gs=new Map}getOverlay(e,t){return b.resolve(this.overlays.get(t))}getOverlays(e,t){const n=qt();return b.forEach(t,s=>this.getOverlay(e,s).next(i=>{i!==null&&n.set(s,i)})).next(()=>n)}getAllOverlays(e,t){const n=qt();return this.overlays.forEach((s,i)=>{i.largestBatchId>t&&n.set(s,i)}),b.resolve(n)}saveOverlays(e,t,n){return n.forEach((s,i)=>{this.Zr(e,t,i)}),b.resolve()}removeOverlaysForBatchId(e,t,n){const s=this.Gs.get(n);return s!==void 0&&(s.forEach(i=>this.overlays=this.overlays.remove(i)),this.Gs.delete(n)),b.resolve()}getOverlaysForCollection(e,t,n){const s=qt(),i=t.length+1,o=new W(t.child("")),a=this.overlays.getIteratorFrom(o);for(;a.hasNext();){const u=a.getNext().value,B=u.getKey();if(!t.isPrefixOf(B.path))break;B.path.length===i&&u.largestBatchId>n&&s.set(u.getKey(),u)}return b.resolve(s)}getOverlaysForCollectionGroup(e,t,n,s){let i=new Oe((B,l)=>B-l);const o=this.overlays.getIterator();for(;o.hasNext();){const B=o.getNext().value;if(B.getKey().getCollectionGroup()===t&&B.largestBatchId>n){let l=i.get(B.largestBatchId);l===null&&(l=qt(),i=i.insert(B.largestBatchId,l)),l.set(B.getKey(),B)}}const a=qt(),u=i.getIterator();for(;u.hasNext()&&(u.getNext().value.forEach((B,l)=>a.set(B,l)),!(a.size()>=s)););return b.resolve(a)}Zr(e,t,n){const s=this.overlays.get(n.key);if(s!==null){const o=this.Gs.get(s.largestBatchId).delete(n.key);this.Gs.set(s.largestBatchId,o)}this.overlays=this.overlays.insert(n.key,new sh(t,n));let i=this.Gs.get(t);i===void 0&&(i=Be(),this.Gs.set(t,i)),this.Gs.set(t,i.add(n.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PR{constructor(){this.sessionToken=xe.EMPTY_BYTE_STRING}getSessionToken(e){return b.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,b.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ah{constructor(){this.zs=new De(rt.js),this.Hs=new De(rt.Js)}isEmpty(){return this.zs.isEmpty()}addReference(e,t){const n=new rt(e,t);this.zs=this.zs.add(n),this.Hs=this.Hs.add(n)}Ys(e,t){e.forEach(n=>this.addReference(n,t))}removeReference(e,t){this.Zs(new rt(e,t))}Xs(e,t){e.forEach(n=>this.removeReference(n,t))}e_(e){const t=new W(new de([])),n=new rt(t,e),s=new rt(t,e+1),i=[];return this.Hs.forEachInRange([n,s],o=>{this.Zs(o),i.push(o.key)}),i}t_(){this.zs.forEach(e=>this.Zs(e))}Zs(e){this.zs=this.zs.delete(e),this.Hs=this.Hs.delete(e)}n_(e){const t=new W(new de([])),n=new rt(t,e),s=new rt(t,e+1);let i=Be();return this.Hs.forEachInRange([n,s],o=>{i=i.add(o.key)}),i}containsKey(e){const t=new rt(e,0),n=this.zs.firstAfterOrEqual(t);return n!==null&&e.isEqual(n.key)}}class rt{constructor(e,t){this.key=e,this.r_=t}static js(e,t){return W.comparator(e.key,t.key)||ae(e.r_,t.r_)}static Js(e,t){return ae(e.r_,t.r_)||W.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bR{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Gr=1,this.i_=new De(rt.js)}checkEmpty(e){return b.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,n,s){const i=this.Gr;this.Gr++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new Xl(i,t,n,s);this.mutationQueue.push(o);for(const a of s)this.i_=this.i_.add(new rt(a.key,i)),this.indexManager.addToCollectionParentIndex(e,a.key.path.popLast());return b.resolve(o)}lookupMutationBatch(e,t){return b.resolve(this.s_(t))}getNextMutationBatchAfterBatchId(e,t){const n=t+1,s=this.__(n),i=s<0?0:s;return b.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return b.resolve(this.mutationQueue.length===0?Xr:this.Gr-1)}getAllMutationBatches(e){return b.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const n=new rt(t,0),s=new rt(t,Number.POSITIVE_INFINITY),i=[];return this.i_.forEachInRange([n,s],o=>{const a=this.s_(o.r_);i.push(a)}),b.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new De(ae);return t.forEach(s=>{const i=new rt(s,0),o=new rt(s,Number.POSITIVE_INFINITY);this.i_.forEachInRange([i,o],a=>{n=n.add(a.r_)})}),b.resolve(this.o_(n))}getAllMutationBatchesAffectingQuery(e,t){const n=t.path,s=n.length+1;let i=n;W.isDocumentKey(i)||(i=i.child(""));const o=new rt(new W(i),0);let a=new De(ae);return this.i_.forEachWhile(u=>{const B=u.key.path;return!!n.isPrefixOf(B)&&(B.length===s&&(a=a.add(u.r_)),!0)},o),b.resolve(this.o_(a))}o_(e){const t=[];return e.forEach(n=>{const s=this.s_(n);s!==null&&t.push(s)}),t}removeMutationBatch(e,t){j(this.a_(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let n=this.i_;return b.forEach(t.mutations,s=>{const i=new rt(s.key,t.batchId);return n=n.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,s.key)}).next(()=>{this.i_=n})}Hr(e){}containsKey(e,t){const n=new rt(t,0),s=this.i_.firstAfterOrEqual(n);return b.resolve(t.isEqual(s&&s.key))}performConsistencyCheck(e){return this.mutationQueue.length,b.resolve()}a_(e,t){return this.__(e)}__(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}s_(e){const t=this.__(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class SR{constructor(e){this.u_=e,this.docs=function(){return new Oe(W.comparator)}(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const n=t.key,s=this.docs.get(n),i=s?s.size:0,o=this.u_(t);return this.docs=this.docs.insert(n,{document:t.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,n.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const n=this.docs.get(t);return b.resolve(n?n.document.mutableCopy():Ne.newInvalidDocument(t))}getEntries(e,t){let n=Qe();return t.forEach(s=>{const i=this.docs.get(s);n=n.insert(s,i?i.document.mutableCopy():Ne.newInvalidDocument(s))}),b.resolve(n)}getAllEntries(e){let t=Qe();return this.docs.forEach((n,s)=>{t=t.insert(n,s.document)}),b.resolve(t)}getDocumentsMatchingQuery(e,t,n,s){let i,o;je(t)?(i=de.fromString(sa(t)),o=l=>dc(t,l)):(i=t.path,o=l=>Yu(t,l));let a=Qe();const u=new W(i.child("__id-9223372036854775808__")),B=this.docs.getIteratorFrom(u);for(;B.hasNext();){const{key:l,value:{document:d}}=B.getNext();if(!i.isPrefixOf(l.path))break;l.path.length>i.length+1||wl(kg(d),n)<=0||(s.has(d.key)||o(d))&&(a=a.insert(d.key,d.mutableCopy()))}return b.resolve(a)}getAllFromCollectionGroup(e,t,n,s){ee(9500)}c_(e,t){return b.forEach(this.docs,n=>t(n))}newChangeBuffer(e){return new OR(this)}getSize(e){return b.resolve(this.size)}}class OR extends s_{constructor(e){super(),this.$s=e}applyChanges(e){const t=[];return this.changes.forEach((n,s)=>{s.isValidDocument()?t.push(this.$s.addEntry(e,s)):this.$s.removeEntry(n)}),b.waitFor(t)}getFromCache(e,t){return this.$s.getEntry(e,t)}getAllFromCache(e,t){return this.$s.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class NR{constructor(e){this.persistence=e,this.l_=new Gn(t=>ac(t),Yl),this.lastRemoteSnapshotVersion=te.min(),this.highestTargetId=0,this.E_=0,this.h_=new ah,this.targetCount=0,this.T_=kn.ws()}forEachTarget(e,t){return this.l_.forEach((n,s)=>t(s)),b.resolve()}getLastRemoteSnapshotVersion(e){return b.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return b.resolve(this.E_)}allocateTargetId(e){return this.highestTargetId=this.T_.next(),b.resolve(this.highestTargetId)}setTargetsMetadata(e,t,n){return n&&(this.lastRemoteSnapshotVersion=n),t>this.E_&&(this.E_=t),b.resolve()}Ds(e){this.l_.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.T_=new kn(t),this.highestTargetId=t),e.sequenceNumber>this.E_&&(this.E_=e.sequenceNumber)}addTargetData(e,t){return this.Ds(t),this.targetCount+=1,b.resolve()}updateTargetData(e,t){return this.Ds(t),b.resolve()}removeTargetData(e,t){return this.l_.delete(t.target),this.h_.e_(t.targetId),this.targetCount-=1,b.resolve()}removeTargets(e,t,n){let s=0;const i=[];return this.l_.forEach((o,a)=>{a.sequenceNumber<=t&&n.get(a.targetId)===null&&(this.l_.delete(o),i.push(this.removeMatchingKeysForTargetId(e,a.targetId)),s++)}),b.waitFor(i).next(()=>s)}getTargetCount(e){return b.resolve(this.targetCount)}getTargetData(e,t){const n=this.l_.get(t)||null;return b.resolve(n)}addMatchingKeys(e,t,n){return this.h_.Ys(t,n),b.resolve()}removeMatchingKeys(e,t,n){this.h_.Xs(t,n);const s=this.persistence.referenceDelegate,i=[];return s&&t.forEach(o=>{i.push(s.markPotentiallyOrphaned(e,o))}),b.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.h_.e_(t),b.resolve()}getMatchingKeysForTargetId(e,t){const n=this.h_.n_(t);return b.resolve(n)}containsKey(e,t){return b.resolve(this.h_.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uh{constructor(e,t){this.P_={},this.overlays={},this.I_=new jt(0),this.R_=!1,this.R_=!0,this.A_=new PR,this.referenceDelegate=e(this),this.V_=new NR(this),this.indexManager=new _R,this.remoteDocumentCache=function(s){return new SR(s)}(n=>this.referenceDelegate.d_(n)),this.serializer=new Qm(t),this.f_=new RR(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.R_=!1,Promise.resolve()}get started(){return this.R_}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new vR,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let n=this.P_[e.toKey()];return n||(n=new bR(t,this.referenceDelegate),this.P_[e.toKey()]=n),n}getGlobalsCache(){return this.A_}getTargetCache(){return this.V_}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.f_}runTransaction(e,t,n){U("MemoryPersistence","Starting transaction:",e);const s=new FR(this.I_.next());return this.referenceDelegate.m_(),n(s).next(i=>this.referenceDelegate.p_(s).next(()=>i)).toPromise().then(i=>(s.raiseOnCommittedEvent(),i))}g_(e,t){return b.or(Object.values(this.P_).map(n=>()=>n.containsKey(e,t)))}}class FR extends Bm{constructor(e){super(),this.currentSequenceNumber=e}}class fc{constructor(e){this.persistence=e,this.y_=new ah,this.w_=null}static b_(e){return new fc(e)}get S_(){if(this.w_)return this.w_;throw ee(60996)}addReference(e,t,n){return this.y_.addReference(n,t),this.S_.delete(n.toString()),b.resolve()}removeReference(e,t,n){return this.y_.removeReference(n,t),this.S_.add(n.toString()),b.resolve()}markPotentiallyOrphaned(e,t){return this.S_.add(t.toString()),b.resolve()}removeTarget(e,t){this.y_.e_(t.targetId).forEach(s=>this.S_.add(s.toString()));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(e,t.targetId).next(s=>{s.forEach(i=>this.S_.add(i.toString()))}).next(()=>n.removeTargetData(e,t))}m_(){this.w_=new Set}p_(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return b.forEach(this.S_,n=>{const s=W.fromPath(n);return this.v_(e,s).next(i=>{i||t.removeEntry(s,te.min())})}).next(()=>(this.w_=null,t.apply(e)))}updateLimboDocument(e,t){return this.v_(e,t).next(n=>{n?this.S_.delete(t.toString()):this.S_.add(t.toString())})}d_(e){return 0}v_(e,t){return b.or([()=>b.resolve(this.y_.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.g_(e,t)])}}class Su{constructor(e,t){this.persistence=e,this.D_=new Gn(n=>Ct(n.path),(n,s)=>n.isEqual(s)),this.garbageCollector=fm(this,t)}static b_(e,t){return new Su(e,t)}m_(){}p_(e){return b.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}ir(e){const t=this.Cs(e);return this.persistence.getTargetCache().getTargetCount(e).next(n=>t.next(s=>n+s))}Cs(e){let t=0;return this.sr(e,n=>{t++}).next(()=>t)}sr(e,t){return b.forEach(this.D_,(n,s)=>this.Os(e,n,s).next(i=>i?b.resolve():t(s)))}removeTargets(e,t,n){return this.persistence.getTargetCache().removeTargets(e,t,n)}removeOrphanedDocuments(e,t){let n=0;const s=this.persistence.getRemoteDocumentCache(),i=s.newChangeBuffer();return s.c_(e,o=>this.Os(e,o,t).next(a=>{a||(n++,i.removeEntry(o,te.min()))})).next(()=>i.apply(e)).next(()=>n)}markPotentiallyOrphaned(e,t){return this.D_.set(t,e.currentSequenceNumber),b.resolve()}removeTarget(e,t){const n=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,n)}addReference(e,t,n){return this.D_.set(n,e.currentSequenceNumber),b.resolve()}removeReference(e,t,n){return this.D_.set(n,e.currentSequenceNumber),b.resolve()}updateLimboDocument(e,t){return this.D_.set(t,e.currentSequenceNumber),b.resolve()}d_(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=Xa(e.data.value)),t}Os(e,t,n){return b.or([()=>this.persistence.g_(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const s=this.D_.get(t);return b.resolve(s!==void 0&&s>n)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class LR{constructor(e){this.serializer=e}Nn(e,t,n,s){const i=new Zu("createOrUpgrade",t);n<1&&s>=1&&(function(u){u.createObjectStore(oa)}(e),function(u){u.createObjectStore(ko,{keyPath:MA}),u.createObjectStore($t,{keyPath:_C,autoIncrement:!0}).createIndex(Qr,EC,{unique:!0}),u.createObjectStore(si)}(e),VC(e),function(u){u.createObjectStore(Hr)}(e));let o=b.resolve();return n<3&&s>=3&&(n!==0&&(function(u){u.deleteObjectStore(oi),u.deleteObjectStore(ii),u.deleteObjectStore(ts)}(e),VC(e)),o=o.next(()=>function(u){const B=u.store(ts),l={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:te.min().toTimestamp(),targetCount:0};return B.put(Ru,l)}(i))),n<4&&s>=4&&(n!==0&&(o=o.next(()=>function(u,B){return B.store($t).Qn().next(d=>{u.deleteObjectStore($t),u.createObjectStore($t,{keyPath:_C,autoIncrement:!0}).createIndex(Qr,EC,{unique:!0});const C=B.store($t),g=d.map(m=>C.put(m));return b.waitFor(g)})}(e,i))),o=o.next(()=>{(function(u){u.createObjectStore(ai,{keyPath:WA})})(e)})),n<5&&s>=5&&(o=o.next(()=>this.x_(i))),n<6&&s>=6&&(o=o.next(()=>(function(u){u.createObjectStore(xo)}(e),this.C_(i)))),n<7&&s>=7&&(o=o.next(()=>this.F_(i))),n<8&&s>=8&&(o=o.next(()=>this.O_(e,i))),n<9&&s>=9&&(o=o.next(()=>{(function(u){u.objectStoreNames.contains("remoteDocumentChanges")&&u.deleteObjectStore("remoteDocumentChanges")})(e)})),n<10&&s>=10&&(o=o.next(()=>this.M_(i))),n<11&&s>=11&&(o=o.next(()=>{(function(u){u.createObjectStore(uc,{keyPath:QA})})(e),function(u){u.createObjectStore(cc,{keyPath:$A})}(e)})),n<12&&s>=12&&(o=o.next(()=>{(function(u){const B=u.createObjectStore(Bc,{keyPath:rR});B.createIndex(YB,sR,{unique:!1}),B.createIndex(qm,iR,{unique:!1})})(e)})),n<13&&s>=13&&(o=o.next(()=>function(u){const B=u.createObjectStore(Au,{keyPath:UA});B.createIndex(iu,HA),B.createIndex(Mm,qA)}(e)).next(()=>this.N_(e,i)).next(()=>e.deleteObjectStore(Hr))),n<14&&s>=14&&(o=o.next(()=>this.L_(e,i))),n<15&&s>=15&&(o=o.next(()=>function(u){u.createObjectStore(th,{keyPath:YA,autoIncrement:!0}).createIndex($B,XA,{unique:!1}),u.createObjectStore(co,{keyPath:ZA}).createIndex(Um,eR,{unique:!1}),u.createObjectStore(Bo,{keyPath:tR}).createIndex(Hm,nR,{unique:!1})}(e))),n<16&&s>=16&&(o=o.next(()=>{t.objectStore(co).clear()}).next(()=>{t.objectStore(Bo).clear()})),n<17&&s>=17&&(o=o.next(()=>{(function(u){u.createObjectStore(nh,{keyPath:oR})})(e)})),n<18&&s>=18&&qp()&&(o=o.next(()=>{t.objectStore(co).clear()}).next(()=>{t.objectStore(Bo).clear()})),o}C_(e){let t=0;return e.store(Hr).Hn((n,s)=>{t+=vu(s)}).next(()=>{const n={byteSize:t};return e.store(xo).put(QB,n)})}x_(e){const t=e.store(ko),n=e.store($t);return t.Qn().next(s=>b.forEach(s,i=>{const o=IDBKeyRange.bound([i.userId,Xr],[i.userId,i.lastAcknowledgedBatchId]);return n.Qn(Qr,o).next(a=>b.forEach(a,u=>{j(u.userId===i.userId,18650,"Cannot process batch from unexpected user",{batchId:u.batchId});const B=jr(this.serializer,u);return Wm(e,i.userId,B).next(()=>{})}))}))}F_(e){const t=e.store(oi),n=e.store(Hr);return e.store(ts).get(Ru).next(s=>{const i=[];return n.Hn((o,a)=>{const u=new de(o),B=function(d){return[0,Ct(d)]}(u);i.push(t.get(B).next(l=>l?b.resolve():(d=>t.put({targetId:0,path:Ct(d),sequenceNumber:s.highestListenSequenceNumber}))(u)))}).next(()=>b.waitFor(i))})}O_(e,t){e.createObjectStore(Vo,{keyPath:zA});const n=t.store(Vo),s=new oh,i=o=>{if(s.add(o)){const a=o.lastSegment(),u=o.popLast();return n.put({collectionId:a,parent:Ct(u)})}};return t.store(Hr).Hn({jn:!0},(o,a)=>{const u=new de(o);return i(u.popLast())}).next(()=>t.store(si).Hn({jn:!0},([o,a,u],B)=>{const l=Bn(a);return i(l.popLast())}))}M_(e){const t=e.store(ii);return t.Hn((n,s)=>{const i=Zi(this.serializer,s),o=$m(this.serializer,i);return t.put(o)})}N_(e,t){const n=t.store(Hr),s=[];return n.Hn((i,o)=>{const a=t.store(Au),u=function(d){return d.document?new W(de.fromString(d.document.name).popFirst(5)):d.noDocument?W.fromSegments(d.noDocument.path):d.unknownDocument?W.fromSegments(d.unknownDocument.path):ee(36783)}(o).path.toArray(),B={prefixPath:u.slice(0,u.length-2),collectionGroup:u[u.length-2],documentId:u[u.length-1],readTime:o.readTime||[0,0],unknownDocument:o.unknownDocument,noDocument:o.noDocument,document:o.document,hasCommittedMutations:!!o.hasCommittedMutations};s.push(a.put(B))}).next(()=>b.waitFor(s))}L_(e,t){const n=t.store($t),s=i_(this.serializer),i=new uh(fc.b_,this.serializer.$r);return n.Qn().next(o=>{const a=new Map;return o.forEach(u=>{let B=a.get(u.userId)??Be();jr(this.serializer,u).keys().forEach(l=>B=B.add(l)),a.set(u.userId,B)}),b.forEach(a,(u,B)=>{const l=new ut(B),d=hc.Qr(this.serializer,l),C=i.getIndexManager(l),g=lc.Qr(l,this.serializer,C,i.referenceDelegate);return new o_(s,g,d,C).recalculateAndSaveOverlaysForDocumentKeys(new XB(t,jt.wn),u).next()})})}}function VC(r){r.createObjectStore(oi,{keyPath:JA}).createIndex(eh,KA,{unique:!0}),r.createObjectStore(ii,{keyPath:"targetId"}).createIndex(Gm,jA,{unique:!0}),r.createObjectStore(ts)}const Xn="IndexedDbPersistence",fB=18e5,CB=5e3,pB="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.",kR="main";class ch{constructor(e,t,n,s,i,o,a,u,B,l,d=18){if(this.allowTabSynchronization=e,this.persistenceKey=t,this.clientId=n,this.Ct=i,this.window=o,this.document=a,this.B_=B,this.U_=l,this.k_=d,this.I_=null,this.R_=!1,this.isPrimary=!1,this.networkEnabled=!0,this.q_=null,this.inForeground=!1,this.K_=null,this.Q_=null,this.W_=Number.NEGATIVE_INFINITY,this.G_=C=>Promise.resolve(),!ch.Ye())throw new H(k.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new DR(this,s),this.z_=t+kR,this.serializer=new Qm(u),this.j_=new dr(this.z_,this.k_,new LR(this.serializer)),this.A_=new dR,this.V_=new IR(this.referenceDelegate,this.serializer),this.remoteDocumentCache=i_(this.serializer),this.f_=new hR,this.window&&this.window.localStorage?this.H_=this.window.localStorage:(this.H_=null,l===!1&&Dt(Xn,"LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.J_().then(()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new H(k.FAILED_PRECONDITION,pB);return this.Y_(),this.Z_(),this.X_(),this.runTransaction("getHighestListenSequenceNumber","readonly",e=>this.V_.getHighestSequenceNumber(e))}).then(e=>{this.I_=new jt(e,this.B_)}).then(()=>{this.R_=!0}).catch(e=>(this.j_&&this.j_.close(),Promise.reject(e)))}eo(e){return this.G_=async t=>{if(this.started)return e(t)},e(this.isPrimary)}setDatabaseDeletedListener(e){this.j_.Bn(async t=>{t.newVersion===null&&await e()})}setNetworkEnabled(e){this.networkEnabled!==e&&(this.networkEnabled=e,this.Ct.enqueueAndForget(async()=>{this.started&&await this.J_()}))}J_(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",e=>Ka(e).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next(()=>{if(this.isPrimary)return this.no(e).next(t=>{t||(this.isPrimary=!1,this.Ct.enqueueRetryable(()=>this.G_(!1)))})}).next(()=>this.ro(e)).next(t=>this.isPrimary&&!t?this.io(e).next(()=>!1):!!t&&this.so(e).next(()=>!0))).catch(e=>{if(br(e))return U(Xn,"Failed to extend owner lease: ",e),this.isPrimary;if(!this.allowTabSynchronization)throw e;return U(Xn,"Releasing owner lease after error during lease refresh",e),!1}).then(e=>{this.isPrimary!==e&&this.Ct.enqueueRetryable(()=>this.G_(e)),this.isPrimary=e})}no(e){return Ji(e).get(Os).next(t=>b.resolve(this._o(t)))}oo(e){return Ka(e).delete(this.clientId)}async ao(){if(this.isPrimary&&!this.uo(this.W_,fB)){this.W_=Date.now();const e=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",t=>{const n=Ze(t,ai);return n.Qn().next(s=>{const i=this.co(s,fB),o=s.filter(a=>i.indexOf(a)===-1);return b.forEach(o,a=>n.delete(a.clientId)).next(()=>o)})}).catch(()=>[]);if(this.H_)for(const t of e)this.H_.removeItem(this.lo(t.clientId))}}X_(){this.Q_=this.Ct.enqueueAfterDelay("client_metadata_refresh",4e3,()=>this.J_().then(()=>this.ao()).then(()=>this.X_()))}_o(e){return!!e&&e.ownerId===this.clientId}ro(e){return this.U_?b.resolve(!0):Ji(e).get(Os).next(t=>{if(t!==null&&this.uo(t.leaseTimestampMs,CB)&&!this.Eo(t.ownerId)){if(this._o(t)&&this.networkEnabled)return!0;if(!this._o(t)){if(!t.allowTabSynchronization)throw new H(k.FAILED_PRECONDITION,pB);return!1}}return!(!this.networkEnabled||!this.inForeground)||Ka(e).Qn().next(n=>this.co(n,CB).find(s=>{if(this.clientId!==s.clientId){const i=!this.networkEnabled&&s.networkEnabled,o=!this.inForeground&&s.inForeground,a=this.networkEnabled===s.networkEnabled;if(i||o&&a)return!0}return!1})===void 0)}).next(t=>(this.isPrimary!==t&&U(Xn,`Client ${t?"is":"is not"} eligible for a primary lease.`),t))}async shutdown(){this.R_=!1,this.ho(),this.Q_&&(this.Q_.cancel(),this.Q_=null),this.To(),this.Po(),await this.j_.runTransaction("shutdown","readwrite",[oa,ai],e=>{const t=new XB(e,jt.wn);return this.io(t).next(()=>this.oo(t))}),this.j_.close(),this.Io()}co(e,t){return e.filter(n=>this.uo(n.updateTimeMs,t)&&!this.Eo(n.clientId))}Ro(){return this.runTransaction("getActiveClients","readonly",e=>Ka(e).Qn().next(t=>this.co(t,fB).map(n=>n.clientId)))}get started(){return this.R_}getGlobalsCache(){return this.A_}getMutationQueue(e,t){return lc.Qr(e,this.serializer,t,this.referenceDelegate)}getTargetCache(){return this.V_}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(e){return new ER(e,this.serializer.$r.databaseId)}getDocumentOverlayCache(e){return hc.Qr(this.serializer,e)}getBundleCache(){return this.f_}runTransaction(e,t,n){U(Xn,"Starting transaction:",e);const s=t==="readonly"?"readonly":"readwrite",i=function(u){return u===18?cR:u===17?zm:u===16?uR:u===15?rh:u===14?Km:u===13?Jm:u===12?aR:u===11?jm:void ee(60245)}(this.k_);let o;return this.j_.runTransaction(e,s,i,a=>(o=new XB(a,this.I_?this.I_.next():jt.wn),t==="readwrite-primary"?this.no(o).next(u=>!!u||this.ro(o)).next(u=>{if(!u)throw Dt(`Failed to obtain primary lease for action '${e}'.`),this.isPrimary=!1,this.Ct.enqueueRetryable(()=>this.G_(!1)),new H(k.FAILED_PRECONDITION,cm);return n(o)}).next(u=>this.so(o).next(()=>u)):this.Ao(o).next(()=>n(o)))).then(a=>(o.raiseOnCommittedEvent(),a))}Ao(e){return Ji(e).get(Os).next(t=>{if(t!==null&&this.uo(t.leaseTimestampMs,CB)&&!this.Eo(t.ownerId)&&!this._o(t)&&!(this.U_||this.allowTabSynchronization&&t.allowTabSynchronization))throw new H(k.FAILED_PRECONDITION,pB)})}so(e){const t={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return Ji(e).put(Os,t)}static Ye(){return dr.Ye()}io(e){const t=Ji(e);return t.get(Os).next(n=>this._o(n)?(U(Xn,"Releasing primary lease."),t.delete(Os)):b.resolve())}uo(e,t){const n=Date.now();return!(e<n-t)&&(!(e>n)||(Dt(`Detected an update time that is in the future: ${e} > ${n}`),!1))}Y_(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.K_=()=>{this.Ct.enqueueAndForget(()=>(this.inForeground=this.document.visibilityState==="visible",this.J_()))},this.document.addEventListener("visibilitychange",this.K_),this.inForeground=this.document.visibilityState==="visible")}To(){this.K_&&(this.document.removeEventListener("visibilitychange",this.K_),this.K_=null)}Z_(){var e;typeof((e=this.window)==null?void 0:e.addEventListener)=="function"&&(this.q_=()=>{this.ho();const t=/(?:Version|Mobile)\/1[456]/;Hp()&&(navigator.appVersion.match(t)||navigator.userAgent.match(t))&&this.Ct.enterRestrictedMode(!0),this.Ct.enqueueAndForget(()=>this.shutdown())},this.window.addEventListener("pagehide",this.q_))}Po(){this.q_&&(this.window.removeEventListener("pagehide",this.q_),this.q_=null)}Eo(e){var t;try{const n=((t=this.H_)==null?void 0:t.getItem(this.lo(e)))!==null;return U(Xn,`Client '${e}' ${n?"is":"is not"} zombied in LocalStorage`),n}catch(n){return Dt(Xn,"Failed to get zombied client id.",n),!1}}ho(){if(this.H_)try{this.H_.setItem(this.lo(this.clientId),String(Date.now()))}catch(e){Dt("Failed to set zombie client id.",e)}}Io(){if(this.H_)try{this.H_.removeItem(this.lo(this.clientId))}catch{}}lo(e){return`firestore_zombie_${this.persistenceKey}_${e}`}}function Ji(r){return Ze(r,oa)}function Ka(r){return Ze(r,ai)}function xR(r,e){let t=r.projectId;return r.isDefaultDatabase||(t+="."+r.database),"firestore/"+e+"/"+t+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bh{constructor(e,t,n,s){this.targetId=e,this.fromCache=t,this.Vo=n,this.fo=s}static mo(e,t){let n=Be(),s=Be();for(const i of t.docChanges)switch(i.type){case 0:n=n.add(i.doc.key);break;case 1:s=s.add(i.doc.key)}return new Bh(e,t.fromCache,n,s)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function VR(r,e){return W.comparator(r.key,e.key)}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class MR{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class a_{constructor(){this.po=!1,this.yo=!1,this.wo=100,this.bo=function(){return Hp()?8:lm(Xe())>0?6:4}()}initialize(e,t){this.So=e,this.indexManager=t,this.po=!0}getDocumentsMatchingQuery(e,t,n,s){const i={result:null};return this.vo(e,t).next(o=>{i.result=o}).next(()=>{if(!i.result)return this.Do(e,t,s,n).next(o=>{i.result=o})}).next(()=>{if(i.result)return;const o=new MR;return this.xo(e,t,o).next(a=>{if(i.result=a,this.yo)return this.Co(e,t,o,a.size)})}).next(()=>i.result)}Co(e,t,n,s){return je(t)?b.resolve():n.documentReadCount<this.wo?(Gs()<=fe.DEBUG&&U("QueryEngine","SDK will not create cache indexes for query:",so(t),"since it only creates cache indexes for collection contains","more than or equal to",this.wo,"documents"),b.resolve()):(Gs()<=fe.DEBUG&&U("QueryEngine","Query:",so(t),"scans",n.documentReadCount,"local documents and returns",s,"documents as results."),n.documentReadCount>this.bo*s?(Gs()<=fe.DEBUG&&U("QueryEngine","The SDK decides to create cache indexes for query:",so(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,Kt(t))):b.resolve())}vo(e,t){if(je(t))return b.resolve(null);let n=t;if(Zf(n))return b.resolve(null);let s=Kt(n);return this.indexManager.getIndexType(e,s).next(i=>i===0?null:(n.limit!==null&&i===1&&(n=Du(n,null,"F"),s=Kt(n)),this.indexManager.getDocumentsMatchingTarget(e,s).next(o=>{const a=Be(...o);return this.So.getDocuments(e,a).next(u=>this.indexManager.getMinOffset(e,s).next(B=>{const l=this.Fo(n,u);return this.Oo(n,l,a,B.readTime)?this.vo(e,Du(n,null,"F")):this.Mo(e,l,n,B)}))})))}Do(e,t,n,s){return(je(t)?function(o){for(const a of o.stages){if(a instanceof wr||a instanceof pC)return!1;if(a instanceof ra){if(a.condition instanceof Am&&a.condition._expr.name==="exists"&&a.condition._expr.params[0]instanceof Ds&&a.condition._expr.params[0].fieldName===an)continue;return!1}}return!0}(t):Zf(t))||s.isEqual(te.min())?b.resolve(null):this.So.getDocuments(e,n).next(i=>{const o=this.Fo(t,i);return this.Oo(t,o,n,s)?b.resolve(null):(Gs()<=fe.DEBUG&&U("QueryEngine","Re-using previous result from %s to execute query: %s",s.toString(),gC(t)),this.Mo(e,o,t,sw(s,Ro)).next(a=>a))})}Fo(e,t){let n,s;return je(e)?(n=new De(VR),s=i=>dc(e,i)):(n=new De(Rl(e)),s=i=>Yu(e,i)),t.forEach((i,o)=>{s(o)&&(n=n.add(o))}),n}Oo(e,t,n,s){if(je(e))return function(a){return a.stages.some(u=>u instanceof wr||u instanceof pC)}(e);if(e.limit===null)return!1;if(n.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(s)>0)}xo(e,t,n){return Gs()<=fe.DEBUG&&U("QueryEngine","Using full collection scan to execute query:",gC(t)),this.So.getDocumentsMatchingQuery(e,t,Mt.min(),n)}Mo(e,t,n,s){return this.So.getDocumentsMatchingQuery(e,n,s).next(i=>(t.forEach(o=>{i=i.insert(o.key,o)}),i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lh="LocalStore",GR=3e8;class UR{constructor(e,t,n,s){this.persistence=e,this.No=t,this.serializer=s,this.Lo=new Oe(ae),this.Bo=new Gn(i=>ac(i),Yl),this.Uo=new Map,this.ko=e.getRemoteDocumentCache(),this.V_=e.getTargetCache(),this.f_=e.getBundleCache(),this.qo(n)}qo(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new o_(this.ko,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.ko.setIndexManager(this.indexManager),this.No.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",t=>e.collect(t,this.Lo))}}function u_(r,e,t,n){return new UR(r,e,t,n)}async function c_(r,e){const t=oe(r);return await t.persistence.runTransaction("Handle user change","readonly",n=>{let s;return t.mutationQueue.getAllMutationBatches(n).next(i=>(s=i,t.qo(e),t.mutationQueue.getAllMutationBatches(n))).next(i=>{const o=[],a=[];let u=Be();for(const B of s){o.push(B.batchId);for(const l of B.mutations)u=u.add(l.key)}for(const B of i){a.push(B.batchId);for(const l of B.mutations)u=u.add(l.key)}return t.localDocuments.getDocuments(n,u).next(B=>({$o:B,removedBatchIds:o,addedBatchIds:a}))})})}function HR(r,e){const t=oe(r);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",n=>{const s=e.batch.keys(),i=t.ko.newChangeBuffer({trackRemovals:!0});return function(a,u,B,l){const d=B.batch,C=d.keys();let g=b.resolve();return C.forEach(m=>{g=g.next(()=>l.getEntry(u,m)).next(v=>{const N=B.docVersions.get(m);j(N!==null,48541),v.version.compareTo(N)<0&&(d.applyToRemoteDocument(v,B),v.isValidDocument()&&(v.setReadTime(B.commitVersion),l.addEntry(v)))})}),g.next(()=>a.mutationQueue.removeMutationBatch(u,d))}(t,n,e,i).next(()=>i.apply(n)).next(()=>t.mutationQueue.performConsistencyCheck(n)).next(()=>t.documentOverlayCache.removeOverlaysForBatchId(n,s,e.batch.batchId)).next(()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(n,function(a){let u=Be();for(let B=0;B<a.mutationResults.length;++B)a.mutationResults[B].transformResults.length>0&&(u=u.add(a.batch.mutations[B].key));return u}(e))).next(()=>t.localDocuments.getDocuments(n,s))})}function B_(r){const e=oe(r);return e.persistence.runTransaction("Get last remote snapshot version","readonly",t=>e.V_.getLastRemoteSnapshotVersion(t))}function qR(r,e){const t=oe(r),n=e.snapshotVersion;let s=t.Lo;return t.persistence.runTransaction("Apply remote event","readwrite-primary",i=>{const o=t.ko.newChangeBuffer({trackRemovals:!0});s=t.Lo;const a=[];e.targetChanges.forEach((l,d)=>{const C=s.get(d);if(!C)return;a.push(t.V_.removeMatchingKeys(i,l.removedDocuments,d).next(()=>t.V_.addMatchingKeys(i,l.addedDocuments,d)));let g=C.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(d)!==null?g=g.withResumeToken(xe.EMPTY_BYTE_STRING,te.min()).withLastLimboFreeSnapshotVersion(te.min()):l.resumeToken.approximateByteSize()>0&&(g=g.withResumeToken(l.resumeToken,n)),s=s.insert(d,g),function(v,N,q){return v.resumeToken.approximateByteSize()===0||N.snapshotVersion.toMicroseconds()-v.snapshotVersion.toMicroseconds()>=GR?!0:q.addedDocuments.size+q.modifiedDocuments.size+q.removedDocuments.size>0}(C,g,l)&&a.push(t.V_.updateTargetData(i,g))});let u=Qe(),B=Be();if(e.documentUpdates.forEach(l=>{e.resolvedLimboDocuments.has(l)&&a.push(t.persistence.referenceDelegate.updateLimboDocument(i,l))}),a.push(jR(i,o,e.documentUpdates).next(l=>{u=l.Ko,B=l.Qo})),!n.isEqual(te.min())){const l=t.V_.getLastRemoteSnapshotVersion(i).next(d=>t.V_.setTargetsMetadata(i,i.currentSequenceNumber,n));a.push(l)}return b.waitFor(a).next(()=>o.apply(i)).next(()=>t.localDocuments.getLocalViewOfDocuments(i,u,B)).next(()=>u)}).then(i=>(t.Lo=s,i))}function jR(r,e,t){let n=Be(),s=Be();return t.forEach(i=>n=n.add(i)),e.getEntries(r,n).next(i=>{let o=Qe();return t.forEach((a,u)=>{const B=i.get(a);u.isFoundDocument()!==B.isFoundDocument()&&(s=s.add(a)),u.isNoDocument()&&u.version.isEqual(te.min())?(e.removeEntry(a,u.readTime),o=o.insert(a,u)):!B.isValidDocument()||u.version.compareTo(B.version)>0||u.version.compareTo(B.version)===0&&B.hasPendingWrites?(e.addEntry(u),o=o.insert(a,u)):U(lh,"Ignoring outdated watch update for ",a,". Current version:",B.version," Watch version:",u.version)}),{Ko:o,Qo:s}})}function JR(r,e){const t=oe(r);return t.persistence.runTransaction("Get next mutation batch","readonly",n=>(e===void 0&&(e=Xr),t.mutationQueue.getNextMutationBatchAfterBatchId(n,e)))}function KR(r,e){const t=oe(r);return t.persistence.runTransaction("Allocate target","readwrite",n=>{let s;return t.V_.getTargetData(n,e).next(i=>i?(s=i,b.resolve(s)):t.V_.allocateTargetId(n).next(o=>(s=new ln(e,o,"TargetPurposeListen",n.currentSequenceNumber),t.V_.addTargetData(n,s).next(()=>s))))}).then(n=>{const s=t.Lo.get(n.targetId);return(s===null||n.snapshotVersion.compareTo(s.snapshotVersion)>0)&&(t.Lo=t.Lo.insert(n.targetId,n),t.Bo.set(e,n.targetId)),n})}async function sl(r,e,t){const n=oe(r),s=n.Lo.get(e),i=t?"readwrite":"readwrite-primary";try{t||await n.persistence.runTransaction("Release target",i,o=>n.persistence.referenceDelegate.removeTarget(o,s))}catch(o){if(!br(o))throw o;U(lh,`Failed to update sequence numbers for target ${e}: ${o}`)}n.Lo=n.Lo.remove(e),n.Bo.delete(s.target)}function MC(r,e,t){const n=oe(r);let s=te.min(),i=Be();return n.persistence.runTransaction("Execute query","readwrite",o=>function(u,B,l){const d=oe(u),C=d.Bo.get(l);return C!==void 0?b.resolve(d.Lo.get(C)):d.V_.getTargetData(B,l)}(n,o,je(e)?e:Kt(e)).next(a=>{if(a)return s=a.lastLimboFreeSnapshotVersion,n.V_.getMatchingKeysForTargetId(o,a.targetId).next(u=>{i=u})}).next(()=>n.No.getDocumentsMatchingQuery(o,e,t?s:te.min(),t?i:Be())).next(a=>(zR(n,a),{documents:a,Wo:i})))}function zR(r,e){e.forEach((t,n)=>{const s=n.key.getCollectionGroup(),i=r.Uo.get(s)||te.min();n.readTime.compareTo(i)>0&&r.Uo.set(s,n.readTime)})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class WR{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.Yo=0,this.Zo=null,this.Xo=!0}ea(){this.Yo===0&&(this.ta("Unknown"),this.Zo=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,()=>(this.Zo=null,this.na("Backend didn't respond within 10 seconds."),this.ta("Offline"),Promise.resolve())))}ra(e){this.state==="Online"?this.ta("Unknown"):(this.Yo++,this.Yo>=1&&(this.ia(),this.na(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ta("Offline")))}set(e){this.ia(),this.Yo=0,e==="Online"&&(this.Xo=!1),this.ta(e)}ta(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}na(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.Xo?(Dt(t),this.Xo=!1):U("OnlineStateTracker",t)}ia(){this.Zo!==null&&(this.Zo.cancel(),this.Zo=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _n="RemoteStore";class QR{constructor(e,t,n,s,i){this.localStore=e,this.datastore=t,this.asyncQueue=n,this.remoteSyncer={},this.sa=[],this._a=new Map,this.oa=new Map,this.aa=new Map,this.ua=new kn(1e3),this.ca=new kn(1001),this.la=new Set,this.Ea=[],this.ha=i,this.ha.Qe(o=>{n.enqueueAndForget(async()=>{ws(this)&&(U(_n,"Restarting streams for network reachability change."),await async function(u){const B=oe(u);B.la.add(4),await aa(B),B.Ta.set("Unknown"),B.la.delete(4),await Cc(B)}(this))})}),this.Ta=new WR(n,s)}}async function Cc(r){if(ws(r))for(const e of r.Ea)await e(!0)}async function aa(r){for(const e of r.Ea)await e(!1)}function il(r,e){return r.oa.get(e)||void 0}function l_(r,e){const t=oe(r),n=il(t,e.targetId);if(n!==void 0&&t._a.has(n))return;const s=function(a,u){const B=il(a,u);B!==void 0&&a.aa.delete(B);const l=function(C,g){return g%2!=0?C.ca.next():C.ua.next()}(a,u);return a.oa.set(u,l),a.aa.set(l,u),l}(t,e.targetId);U(_n,"remoteStoreListen mapping SDK target ID to remote",e.targetId,s);const i=new ln(e.target,s,e.purpose,e.sequenceNumber,e.snapshotVersion,e.lastLimboFreeSnapshotVersion,e.resumeToken);t._a.set(s,i),Ch(t)?fh(t):mi(t).Yt()&&dh(t,i)}function hh(r,e){const t=oe(r),n=mi(t),s=il(t,e);U(_n,"remoteStoreUnlisten removing mapping of SDK target ID to remote",e,s),t._a.delete(s),t.oa.delete(e),t.aa.delete(s),n.Yt()&&h_(t,s),t._a.size===0&&(n.Yt()?n.en():ws(t)&&t.Ta.set("Unknown"))}function dh(r,e){if(r.Pa.J(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(te.min())>0){const t=r.aa.get(e.targetId);if(t===void 0)return void U(_n,"SDK target ID not found for remote ID: "+e.targetId);const n=r.remoteSyncer.getRemoteKeysForTarget(t).size;e=e.withExpectedCount(n)}mi(r).Pn(e)}function h_(r,e){r.Pa.J(e),mi(r).In(e)}function fh(r){r.Pa=new Ew({getRemoteKeysForTarget:e=>{const t=r.aa.get(e);return t!==void 0?r.remoteSyncer.getRemoteKeysForTarget(t):Be()},ye:e=>r._a.get(e)||null,Ve:()=>r.datastore.serializer.databaseId}),mi(r).start(),r.Ta.ea()}function Ch(r){return ws(r)&&!mi(r).Jt()&&r._a.size>0}function ws(r){return oe(r).la.size===0}function d_(r){r.Pa=void 0}async function $R(r){r.Ta.set("Online")}async function YR(r){r._a.forEach((e,t)=>{dh(r,e)})}async function XR(r,e){d_(r),Ch(r)?(r.Ta.ra(e),fh(r)):r.Ta.set("Unknown")}async function ZR(r,e,t){if(r.Ta.set("Online"),e instanceof Jg&&e.state===2&&e.cause)try{await async function(s,i){const o=i.cause;for(const a of i.targetIds){if(s._a.has(a)){const u=s.aa.get(a);u!==void 0&&(await s.remoteSyncer.rejectListen(u,o),s.oa.delete(u),s.aa.delete(a)),s._a.delete(a)}s.Pa.removeTarget(a)}}(r,e)}catch(n){U(_n,"Failed to remove targets %s: %s ",e.targetIds.join(","),n),await Ou(r,n)}else if(e instanceof tu?r.Pa._e(e):e instanceof jg?r.Pa.he(e):r.Pa.ue(e),!t.isEqual(te.min()))try{const n=await B_(r.localStore);t.compareTo(n)>=0&&await function(i,o){const a=i.Pa.fe(o);a.targetChanges.forEach((B,l)=>{if(B.resumeToken.approximateByteSize()>0){const d=i._a.get(l);d&&i._a.set(l,d.withResumeToken(B.resumeToken,o))}}),a.targetMismatches.forEach((B,l)=>{const d=i._a.get(B);if(!d)return;i._a.set(B,d.withResumeToken(xe.EMPTY_BYTE_STRING,d.snapshotVersion)),h_(i,B);const C=new ln(d.target,B,l,d.sequenceNumber);dh(i,C)});const u=function(l,d){const C=new Map;d.targetChanges.forEach((m,v)=>{const N=l.aa.get(v);N!==void 0&&C.set(N,m)});let g=new Oe(ae);return d.targetMismatches.forEach((m,v)=>{const N=l.aa.get(m);N!==void 0&&(g=g.insert(N,v))}),new Xo(d.snapshotVersion,C,g,d.documentUpdates,d.augmentedDocumentUpdates,d.resolvedLimboDocuments)}(i,a);return i.remoteSyncer.applyRemoteEvent(u)}(r,t)}catch(n){U(_n,"Failed to raise snapshot:",n),await Ou(r,n)}}async function Ou(r,e,t){if(!br(e))throw e;r.la.add(1),await aa(r),r.Ta.set("Offline"),t||(t=()=>B_(r.localStore)),r.asyncQueue.enqueueRetryable(async()=>{U(_n,"Retrying IndexedDB access"),await t(),r.la.delete(1),await Cc(r)})}function f_(r,e){return e().catch(t=>Ou(r,t,e))}async function ua(r){const e=oe(r),t=Ar(e);let n=e.sa.length>0?e.sa[e.sa.length-1].batchId:Xr;for(;ev(e);)try{const s=await JR(e.localStore,n);if(s===null){e.sa.length===0&&t.en();break}n=s.batchId,tv(e,s)}catch(s){await Ou(e,s)}C_(e)&&p_(e)}function ev(r){return ws(r)&&r.sa.length<10}function tv(r,e){r.sa.push(e);const t=Ar(r);t.Yt()&&t.Rn&&t.An(e.mutations)}function C_(r){return ws(r)&&!Ar(r).Jt()&&r.sa.length>0}function p_(r){Ar(r).start()}async function nv(r){Ar(r).fn()}async function rv(r){const e=Ar(r);for(const t of r.sa)e.An(t.mutations)}async function sv(r,e,t){const n=r.sa.shift(),s=Zl.from(n,e,t);await f_(r,()=>r.remoteSyncer.applySuccessfulWrite(s)),await ua(r)}async function iv(r,e){e&&Ar(r).Rn&&await async function(n,s){if(function(o){return Mg(o)&&o!==k.ABORTED}(s.code)){const i=n.sa.shift();Ar(n).Xt(),await f_(n,()=>n.remoteSyncer.rejectFailedWrite(i.batchId,s)),await ua(n)}}(r,e),C_(r)&&p_(r)}async function GC(r,e){const t=oe(r);t.asyncQueue.verifyOperationInProgress(),U(_n,"RemoteStore received new credentials");const n=ws(t);t.la.add(3),await aa(t),n&&t.Ta.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.la.delete(3),await Cc(t)}async function ov(r,e){const t=oe(r);e?(t.la.delete(2),await Cc(t)):e||(t.la.add(2),await aa(t),t.Ta.set("Unknown"))}function mi(r){return r.Ia||(r.Ia=function(t,n,s){const i=oe(t);return i.pn(),new zw(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)}(r.datastore,r.asyncQueue,{ct:$R.bind(null,r),Et:YR.bind(null,r),Tt:XR.bind(null,r),Tn:ZR.bind(null,r)}),r.Ea.push(async e=>{e?(r.Ia.Xt(),Ch(r)?fh(r):r.Ta.set("Unknown")):(await r.Ia.stop(),d_(r))})),r.Ia}function Ar(r){return r.Ra||(r.Ra=function(t,n,s){const i=oe(t);return i.pn(),new Ww(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)}(r.datastore,r.asyncQueue,{ct:()=>Promise.resolve(),Et:nv.bind(null,r),Tt:iv.bind(null,r),Vn:rv.bind(null,r),dn:sv.bind(null,r)}),r.Ea.push(async e=>{e?(r.Ra.Xt(),await ua(r)):(await r.Ra.stop(),r.sa.length>0&&(U(_n,`Stopping write stream with ${r.sa.length} pending writes`),r.sa=[]))})),r.Ra}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ph{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Aa(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Aa(this.observer.error,e):Dt("Uncaught Error in snapshot listener:",e.toString()))}Va(){this.muted=!0}Aa(e,t){setTimeout(()=>{this.muted||e(t)},0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gh{constructor(e,t,n,s,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=n,this.op=s,this.removalCallback=i,this.deferred=new zt,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch(o=>{})}get promise(){return this.deferred.promise}static createAndSchedule(e,t,n,s,i){const o=Date.now()+n,a=new gh(e,t,o,s,i);return a.start(n),a}start(e){this.timerHandle=setTimeout(()=>this.handleDelayElapsed(),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new H(k.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget(()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then(e=>this.deferred.resolve(e))):Promise.resolve())}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function mh(r,e){if(Dt("AsyncQueue",`${e}: ${r}`),br(r))return new H(k.UNAVAILABLE,`${e}: ${r}`);throw r}const lo="IndexBackfiller";class av{constructor(e,t){this.asyncQueue=e,this.Da=t,this.task=null}start(){this.xa(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}xa(e){U(lo,`Scheduled in ${e}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",e,async()=>{this.task=null;try{const t=await this.Da.Ca();U(lo,`Documents written: ${t}`)}catch(t){br(t)?U(lo,"Ignoring IndexedDB error during index backfill: ",t):await Es(t)}await this.xa(6e4)})}}class uv{constructor(e,t){this.localStore=e,this.persistence=t}async Ca(e=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",t=>this.Fa(t,e))}Fa(e,t){const n=new Set;let s=t,i=!0;return b.doWhile(()=>i===!0&&s>0,()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(e).next(o=>{if(o!==null&&!n.has(o))return U(lo,`Processing collection: ${o}`),this.Oa(e,o,s).next(a=>{s-=a,n.add(o)});i=!1})).next(()=>t-s)}Oa(e,t,n){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(e,t).next(s=>this.localStore.localDocuments.getNextDocuments(e,t,s,n).next(i=>{const o=i.changes;return this.localStore.indexManager.updateIndexEntries(e,o).next(()=>this.Ma(s,i)).next(a=>(U(lo,`Updating offset: ${a}`),this.localStore.indexManager.updateCollectionGroup(e,t,a))).next(()=>o.size)}))}Ma(e,t){let n=e;return t.changes.forEach((s,i)=>{const o=kg(i);wl(o,n)>0&&(n=o)}),new Mt(n.readTime,n.documentKey,Math.max(t.batchId,e.largestBatchId))}}class UC{constructor(){this.activeTargetIds=gw()}Ba(e){this.activeTargetIds=this.activeTargetIds.add(e)}Ua(e){this.activeTargetIds=this.activeTargetIds.delete(e)}La(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class g_{constructor(){this.fu=new UC,this.mu={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,n){}addLocalQueryTarget(e,t=!0){return t&&this.fu.Ba(e),this.mu[e]||"not-current"}updateQueryState(e,t,n){this.mu[e]=t}removeLocalQueryTarget(e){this.fu.Ua(e)}isLocalQueryTarget(e){return this.fu.activeTargetIds.has(e)}clearQueryState(e){delete this.mu[e]}getAllActiveQueryTargets(){return this.fu.activeTargetIds}isActiveQueryTarget(e){return this.fu.activeTargetIds.has(e)}start(){return this.fu=new UC,Promise.resolve()}handleUserChange(e,t,n){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function cv(){return typeof window<"u"?window:null}function au(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ns{static emptySet(e){return new ns(e.comparator)}constructor(e){this.comparator=e?(t,n)=>e(t,n)||W.comparator(t.key,n.key):(t,n)=>W.comparator(t.key,n.key),this.keyedMap=Hs(),this.sortedSet=new Oe(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal((t,n)=>(e(t),!1))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof ns)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),n=e.sortedSet.getIterator();for(;t.hasNext();){const s=t.getNext().key,i=n.getNext().key;if(!s.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach(t=>{e.push(t.toString())}),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const n=new ns;return n.comparator=this.comparator,n.keyedMap=e,n.sortedSet=t,n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class HC{constructor(){this.pu=new Oe(W.comparator)}track(e){const t=e.doc.key,n=this.pu.get(t);n?e.type!==0&&n.type===3?this.pu=this.pu.insert(t,e):e.type===3&&n.type!==1?this.pu=this.pu.insert(t,{type:n.type,doc:e.doc}):e.type===2&&n.type===2?this.pu=this.pu.insert(t,{type:2,doc:e.doc}):e.type===2&&n.type===0?this.pu=this.pu.insert(t,{type:0,doc:e.doc}):e.type===1&&n.type===0?this.pu=this.pu.remove(t):e.type===1&&n.type===2?this.pu=this.pu.insert(t,{type:1,doc:n.doc}):e.type===0&&n.type===1?this.pu=this.pu.insert(t,{type:2,doc:e.doc}):ee(63341,{we:e,gu:n}):this.pu=this.pu.insert(t,e)}yu(){const e=[];return this.pu.inorderTraversal((t,n)=>{e.push(n)}),e}}class ui{constructor(e,t,n,s,i,o,a,u,B){this.query=e,this.docs=t,this.oldDocs=n,this.docChanges=s,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=a,this.excludesMetadataChanges=u,this.hasCachedResults=B}static fromInitialDocuments(e,t,n,s,i){const o=[];return t.forEach(a=>{o.push({type:0,doc:a})}),new ui(e,t,ns.emptySet(t),o,n,s,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&oc(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,n=e.docChanges;if(t.length!==n.length)return!1;for(let s=0;s<t.length;s++)if(t[s].type!==n[s].type||!t[s].doc.isEqual(n[s].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Bv{constructor(){this.wu=void 0,this.bu=[]}Su(){return this.bu.some(e=>e.vu())}}class lv{constructor(){this.queries=qC(),this.onlineState="Unknown",this.Du=new Set}terminate(){(function(t,n){const s=oe(t),i=s.queries;s.queries=qC(),i.forEach((o,a)=>{for(const u of a.bu)u.onError(n)})})(this,new H(k.ABORTED,"Firestore shutting down"))}}function qC(){return new Gn(r=>xm(r),oc)}async function _h(r,e){const t=oe(r);let n=3;const s=e.query;let i=t.queries.get(s);i?!i.Su()&&e.vu()&&(n=2):(i=new Bv,n=e.vu()?0:1);try{switch(n){case 0:i.wu=await t.onListen(s,!0);break;case 1:i.wu=await t.onListen(s,!1);break;case 2:await t.onFirstRemoteStoreListen(s)}}catch(o){const a=mh(o,`Initialization of query '${je(e.query)?bn(e.query):so(e.query)}' failed`);return void e.onError(a)}t.queries.set(s,i),i.bu.push(e),e.xu(t.onlineState),i.wu&&e.Cu(i.wu)&&Ih(t)}async function Eh(r,e){const t=oe(r),n=e.query;let s=3;const i=t.queries.get(n);if(i){const o=i.bu.indexOf(e);o>=0&&(i.bu.splice(o,1),i.bu.length===0?s=e.vu()?0:1:!i.Su()&&e.vu()&&(s=2))}switch(s){case 0:return t.queries.delete(n),t.onUnlisten(n,!0);case 1:return t.queries.delete(n),t.onUnlisten(n,!1);case 2:return t.onLastRemoteStoreUnlisten(n);default:return}}function hv(r,e){const t=oe(r);let n=!1;for(const s of e){const i=s.query,o=t.queries.get(i);if(o){for(const a of o.bu)a.Cu(s)&&(n=!0);o.wu=s}}n&&Ih(t)}function dv(r,e,t){const n=oe(r),s=n.queries.get(e);if(s)for(const i of s.bu)i.onError(t);n.queries.delete(e)}function Ih(r){r.Du.forEach(e=>{e.next()})}var ol;(function(r){r.Default="default",r.Cache="cache"})(ol||(ol={}));class Dh{constructor(e,t,n){this.query=e,this.Fu=t,this.Ou=!1,this.Mu=null,this.onlineState="Unknown",this.options=n||{}}Cu(e){if(!this.options.includeMetadataChanges){const n=[];for(const s of e.docChanges)s.type!==3&&n.push(s);e=new ui(e.query,e.docs,e.oldDocs,n,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Ou?this.Nu(e)&&(this.Fu.next(e),t=!0):this.Lu(e,this.onlineState)&&(this.Bu(e),t=!0),this.Mu=e,t}onError(e){this.Fu.error(e)}xu(e){this.onlineState=e;let t=!1;return this.Mu&&!this.Ou&&this.Lu(this.Mu,e)&&(this.Bu(this.Mu),t=!0),t}Lu(e,t){if(!e.fromCache||!this.vu())return!0;const n=t!=="Offline";return(!this.options.waitForSyncWhenOnline||!n)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}Nu(e){if(e.docChanges.length>0)return!0;const t=this.Mu&&this.Mu.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}Bu(e){e=ui.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Ou=!0,this.Fu.next(e)}vu(){return this.options.source!==ol.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class m_{constructor(e){this.key=e}}class __{constructor(e){this.key=e}}class fv{constructor(e,t){this.query=e,this.zu=t,this.ju=null,this.hasCachedResults=!1,this.current=!1,this.Hu=Be(),this.mutatedKeys=Be(),this.Ju=je(e)?rl(e):Rl(e),this.Yu=new ns(this.Ju)}get Zu(){return this.zu}Xu(e,t){const n=t?t.ec:new HC,s=t?t.Yu:this.Yu;let i=t?t.mutatedKeys:this.mutatedKeys,o=s,a=!1;const[u,B]=this.tc(this.query,s);e.inorderTraversal((d,C)=>{const g=s.get(d),m=r_(this.query,C)?C:null,v=!!g&&this.mutatedKeys.has(g.key),N=!!m&&(m.hasLocalMutations||this.mutatedKeys.has(m.key)&&m.hasCommittedMutations);let q=!1;g&&m?g.data.isEqual(m.data)?v!==N&&(n.track({type:3,doc:m}),q=!0):this.nc(g,m)||(n.track({type:2,doc:m}),q=!0,(u&&this.Ju(m,u)>0||B&&this.Ju(m,B)<0)&&(a=!0)):!g&&m?(n.track({type:0,doc:m}),q=!0):g&&!m&&(n.track({type:1,doc:g}),q=!0,(u||B)&&(a=!0)),q&&(m?(o=o.add(m),i=N?i.add(d):i.delete(d)):(o=o.delete(d),i=i.delete(d)))});const l=this.rc(this.query);if(l)if(je(this.query)){const d=[];o.forEach(m=>d.push(m));const C=n_(this.query,d);let g=new ns(rl(this.query));for(const m of C)g=g.add(m);o.forEach(m=>{g.has(m.key)||(i=i.delete(m.key),n.track({type:1,doc:m}))}),o=g}else{const d=this.sc(this.query);for(;o.size>l;){const C=d==="F"?o.last():o.first();o=o.delete(C.key),i=i.delete(C.key),n.track({type:1,doc:C})}}return{Yu:o,ec:n,Oo:a,mutatedKeys:i}}rc(e){var t;return je(e)?(t=dB(e))==null?void 0:t.limit:e.limit||void 0}sc(e){if(je(e)){const t=dB(e);return t&&t.limit<0?"L":"F"}return e.limitType}tc(e,t){var n;if(je(e)){const s=(n=dB(e))==null?void 0:n.limit;return[t.size===s?t.last():null,null]}return[e.limitType==="F"&&t.size===this.rc(this.query)?t.last():null,e.limitType==="L"&&t.size===this.rc(this.query)?t.first():null]}nc(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,n,s){const i=this.Yu;this.Yu=e.Yu,this.mutatedKeys=e.mutatedKeys;const o=e.ec.yu();o.sort((l,d)=>function(g,m){const v=N=>{switch(N){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return ee(20277,{we:N})}};return v(g)-v(m)}(l.type,d.type)||this.Ju(l.doc,d.doc)),this._c(n),s=s??!1;const a=t&&!s?this.oc():[],u=this.Hu.size===0&&this.current&&!s?1:0,B=u!==this.ju;return this.ju=u,o.length!==0||B?{snapshot:new ui(this.query,e.Yu,i,o,e.mutatedKeys,u===0,B,!1,!!n&&n.resumeToken.approximateByteSize()>0),ac:a}:{ac:a}}xu(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Yu:this.Yu,ec:new HC,mutatedKeys:this.mutatedKeys,Oo:!1},!1)):{ac:[]}}uc(e){return!this.zu.has(e)&&!!this.Yu.has(e)&&!this.Yu.get(e).hasLocalMutations}_c(e){e&&(e.addedDocuments.forEach(t=>this.zu=this.zu.add(t)),e.modifiedDocuments.forEach(t=>{}),e.removedDocuments.forEach(t=>this.zu=this.zu.delete(t)),this.current=e.current)}oc(){if(!this.current)return[];const e=this.Hu;this.Hu=Be(),this.Yu.forEach(n=>{this.uc(n.key)&&(this.Hu=this.Hu.add(n.key))});const t=[];return e.forEach(n=>{this.Hu.has(n)||t.push(new __(n))}),this.Hu.forEach(n=>{e.has(n)||t.push(new m_(n))}),t}cc(e){this.zu=e.Wo,this.Hu=Be();const t=this.Xu(e.documents);return this.applyChanges(t,!0)}lc(){return ui.fromInitialDocuments(this.query,this.Yu,this.mutatedKeys,this.ju===0,this.hasCachedResults)}}const yh="SyncEngine";class Cv{constructor(e,t,n){this.query=e,this.targetId=t,this.view=n}}class pv{constructor(e){this.key=e,this.Ec=!1}}class gv{constructor(e,t,n,s,i,o){this.localStore=e,this.remoteStore=t,this.eventManager=n,this.sharedClientState=s,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.hc={},this.Tc=new Gn(a=>xm(a),oc),this.Pc=new Map,this.Ic=new Set,this.Rc=new Oe(W.comparator),this.Ac=new Map,this.Vc=new ah,this.dc={},this.fc=new Map,this.mc=kn.bs(),this.onlineState="Unknown",this.gc=void 0}get isPrimaryClient(){return this.gc===!0}}async function mv(r,e,t=!0){const n=T_(r);let s;const i=n.Tc.get(e);return i?(n.sharedClientState.addLocalQueryTarget(i.targetId),s=i.view.lc()):s=await E_(n,e,t,!0),s}async function _v(r,e){const t=T_(r);await E_(t,e,!0,!1)}async function E_(r,e,t,n){const s=await KR(r.localStore,je(e)?e:Kt(e)),i=s.targetId,o=r.sharedClientState.addLocalQueryTarget(i,t);let a;return n&&(a=await Ev(r,e,i,o==="current",s.resumeToken)),r.isPrimaryClient&&t&&l_(r.remoteStore,s),a}async function Ev(r,e,t,n,s){r.yc=(d,C,g)=>async function(v,N,q,J){let X=N.view.Xu(q);X.Oo&&(X=await MC(v.localStore,N.query,!1).then(({documents:T})=>N.view.Xu(T,X)));const se=J&&J.targetChanges.get(N.targetId),ue=J&&J.targetMismatches.get(N.targetId)!=null,ce=N.view.applyChanges(X,v.isPrimaryClient,se,ue);return JC(v,N.targetId,ce.ac),ce.snapshot}(r,d,C,g);const i=await MC(r.localStore,e,!0),o=new fv(e,i.Wo),a=o.Xu(i.documents),u=Zo.createSynthesizedTargetChangeForCurrentChange(t,n&&r.onlineState!=="Offline",s),B=o.applyChanges(a,r.isPrimaryClient,u);JC(r,t,B.ac);const l=new Cv(e,t,o);return r.Tc.set(e,l),r.Pc.has(t)?r.Pc.get(t).push(e):r.Pc.set(t,[e]),B.snapshot}async function Iv(r,e,t){const n=oe(r),s=n.Tc.get(e),i=n.Pc.get(s.targetId);if(i.length>1)return n.Pc.set(s.targetId,i.filter(o=>!oc(o,e))),void n.Tc.delete(e);n.isPrimaryClient?(n.sharedClientState.removeLocalQueryTarget(s.targetId),n.sharedClientState.isActiveQueryTarget(s.targetId)||await sl(n.localStore,s.targetId,!1).then(()=>{n.sharedClientState.clearQueryState(s.targetId),t&&hh(n.remoteStore,s.targetId),al(n,s.targetId)}).catch(Es)):(al(n,s.targetId),await sl(n.localStore,s.targetId,!0))}async function Dv(r,e){const t=oe(r),n=t.Tc.get(e),s=t.Pc.get(n.targetId);t.isPrimaryClient&&s.length===1&&(t.sharedClientState.removeLocalQueryTarget(n.targetId),hh(t.remoteStore,n.targetId))}async function yv(r,e,t){const n=A_(r);try{const s=await function(o,a){const u=oe(o),B=_e.now(),l=a.reduce((g,m)=>g.add(m.key),Be());let d,C;return u.persistence.runTransaction("Locally write mutations","readwrite",g=>{let m=Qe(),v=Be();return u.ko.getEntries(g,l).next(N=>{m=N,m.forEach((q,J)=>{J.isValidDocument()||(v=v.add(q))})}).next(()=>u.localDocuments.getOverlayedDocuments(g,m)).next(N=>{d=N;const q=[];for(const J of a){const X=$y(J,d.get(J.key).overlayedDocument);X!=null&&q.push(new Mn(J.key,X,Dg(X.value.mapValue),Fe.exists(!0)))}return u.mutationQueue.addMutationBatch(g,B,q,a)}).next(N=>{C=N;const q=N.applyToLocalDocumentSet(d,v);return u.documentOverlayCache.saveOverlays(g,N.batchId,q)})}).then(()=>({batchId:C.batchId,changes:Hg(d)}))}(n.localStore,e);n.sharedClientState.addPendingMutation(s.batchId),function(o,a,u){let B=o.dc[o.currentUser.toKey()];B||(B=new Oe(ae)),B=B.insert(a,u),o.dc[o.currentUser.toKey()]=B}(n,s.batchId,t),await ca(n,s.changes),await ua(n.remoteStore)}catch(s){const i=mh(s,"Failed to persist write");t.reject(i)}}async function I_(r,e){const t=oe(r);try{const n=await qR(t.localStore,e);e.targetChanges.forEach((s,i)=>{const o=t.Ac.get(i);o&&(j(s.addedDocuments.size+s.modifiedDocuments.size+s.removedDocuments.size<=1,22616),s.addedDocuments.size>0?o.Ec=!0:s.modifiedDocuments.size>0?j(o.Ec,14607):s.removedDocuments.size>0&&(j(o.Ec,42227),o.Ec=!1))}),await ca(t,n,e)}catch(n){await Es(n)}}function jC(r,e,t){const n=oe(r);if(n.isPrimaryClient&&t===0||!n.isPrimaryClient&&t===1){const s=[];n.Tc.forEach((i,o)=>{const a=o.view.xu(e);a.snapshot&&s.push(a.snapshot)}),function(o,a){const u=oe(o);u.onlineState=a;let B=!1;u.queries.forEach((l,d)=>{for(const C of d.bu)C.xu(a)&&(B=!0)}),B&&Ih(u)}(n.eventManager,e),s.length&&n.hc.Tn(s),n.onlineState=e,n.isPrimaryClient&&n.sharedClientState.setOnlineState(e)}}async function wv(r,e,t){const n=oe(r);n.sharedClientState.updateQueryState(e,"rejected",t);const s=n.Ac.get(e),i=s&&s.key;if(i){let o=new Oe(W.comparator);o=o.insert(i,Ne.newNoDocument(i,te.min()));const a=Be().add(i),u=new Xo(te.min(),new Map,new Oe(ae),o,Qe(),a);await I_(n,u),n.Rc=n.Rc.remove(i),n.Ac.delete(e),wh(n)}else await sl(n.localStore,e,!1).then(()=>al(n,e,t)).catch(Es)}async function Tv(r,e){const t=oe(r),n=e.batch.batchId;try{const s=await HR(t.localStore,e);y_(t,n,null),D_(t,n),t.sharedClientState.updateMutationState(n,"acknowledged"),await ca(t,s)}catch(s){await Es(s)}}async function Av(r,e,t){const n=oe(r);try{const s=await function(o,a){const u=oe(o);return u.persistence.runTransaction("Reject batch","readwrite-primary",B=>{let l;return u.mutationQueue.lookupMutationBatch(B,a).next(d=>(j(d!==null,37113),l=d.keys(),u.mutationQueue.removeMutationBatch(B,d))).next(()=>u.mutationQueue.performConsistencyCheck(B)).next(()=>u.documentOverlayCache.removeOverlaysForBatchId(B,l,a)).next(()=>u.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(B,l)).next(()=>u.localDocuments.getDocuments(B,l))})}(n.localStore,e);y_(n,e,t),D_(n,e),n.sharedClientState.updateMutationState(e,"rejected",t),await ca(n,s)}catch(s){await Es(s)}}function D_(r,e){(r.fc.get(e)||[]).forEach(t=>{t.resolve()}),r.fc.delete(e)}function y_(r,e,t){const n=oe(r);let s=n.dc[n.currentUser.toKey()];if(s){const i=s.get(e);i&&(t?i.reject(t):i.resolve(),s=s.remove(e)),n.dc[n.currentUser.toKey()]=s}}function al(r,e,t=null){r.sharedClientState.removeLocalQueryTarget(e);for(const n of r.Pc.get(e))r.Tc.delete(n),t&&r.hc.wc(n,t);r.Pc.delete(e),r.isPrimaryClient&&r.Vc.e_(e).forEach(n=>{r.Vc.containsKey(n)||w_(r,n)})}function w_(r,e){r.Ic.delete(e.path.canonicalString());const t=r.Rc.get(e);t!==null&&(hh(r.remoteStore,t),r.Rc=r.Rc.remove(e),r.Ac.delete(t),wh(r))}function JC(r,e,t){for(const n of t)n instanceof m_?(r.Vc.addReference(n.key,e),Rv(r,n)):n instanceof __?(U(yh,"Document no longer in limbo: "+n.key),r.Vc.removeReference(n.key,e),r.Vc.containsKey(n.key)||w_(r,n.key)):ee(19791,{bc:n})}function Rv(r,e){const t=e.key,n=t.path.canonicalString();r.Rc.get(t)||r.Ic.has(n)||(U(yh,"New document in limbo: "+t),r.Ic.add(n),wh(r))}function wh(r){for(;r.Ic.size>0&&r.Rc.size<r.maxConcurrentLimboResolutions;){const e=r.Ic.values().next().value;r.Ic.delete(e);const t=new W(de.fromString(e)),n=r.mc.next();r.Ac.set(n,new pv(t)),r.Rc=r.Rc.insert(t,n),l_(r.remoteStore,new ln(Kt(Yo(t.path)),n,"TargetPurposeLimboResolution",jt.wn))}}async function ca(r,e,t){const n=oe(r),s=[],i=[],o=[];n.Tc.isEmpty()||(n.Tc.forEach((a,u)=>{o.push(n.yc(u,e,t).then(B=>{var l;if((B||t)&&n.isPrimaryClient){const d=B?!B.fromCache:(l=t==null?void 0:t.targetChanges.get(u.targetId))==null?void 0:l.current;n.sharedClientState.updateQueryState(u.targetId,d?"current":"not-current")}if(B){s.push(B);const d=Bh.mo(u.targetId,B);i.push(d)}}))}),await Promise.all(o),n.hc.Tn(s),await async function(u,B){const l=oe(u);try{await l.persistence.runTransaction("notifyLocalViewChanges","readwrite",d=>b.forEach(B,C=>b.forEach(C.Vo,g=>l.persistence.referenceDelegate.addReference(d,C.targetId,g)).next(()=>b.forEach(C.fo,g=>l.persistence.referenceDelegate.removeReference(d,C.targetId,g)))))}catch(d){if(!br(d))throw d;U(lh,"Failed to update sequence numbers: "+d)}for(const d of B){const C=d.targetId;if(!d.fromCache){const g=l.Lo.get(C),m=g.snapshotVersion,v=g.withLastLimboFreeSnapshotVersion(m);l.Lo=l.Lo.insert(C,v)}}}(n.localStore,i))}async function vv(r,e){const t=oe(r);if(!t.currentUser.isEqual(e)){U(yh,"User change. New user:",e.toKey());const n=await c_(t.localStore,e);t.currentUser=e,function(i,o){i.fc.forEach(a=>{a.forEach(u=>{u.reject(new H(k.CANCELLED,o))})}),i.fc.clear()}(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,n.removedBatchIds,n.addedBatchIds),await ca(t,n.$o)}}function Pv(r,e){const t=oe(r),n=t.Ac.get(e);if(n&&n.Ec)return Be().add(n.key);{let s=Be();const i=t.Pc.get(e);if(!i)return s;for(const o of i??[]){const a=t.Tc.get(o);s=s.unionWith(a.view.Zu)}return s}}function T_(r){const e=oe(r);return e.remoteStore.remoteSyncer.applyRemoteEvent=I_.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=Pv.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=wv.bind(null,e),e.hc.Tn=hv.bind(null,e.eventManager),e.hc.wc=dv.bind(null,e.eventManager),e}function A_(r){const e=oe(r);return e.remoteStore.remoteSyncer.applySuccessfulWrite=Tv.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=Av.bind(null,e),e}class Mo{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=Xu(e.databaseInfo.databaseId),this.sharedClientState=this.vc(e),this.persistence=this.Dc(e),await this.persistence.start(),this.localStore=this.xc(e),this.gcScheduler=this.Cc(e,this.localStore),this.indexBackfillerScheduler=this.Fc(e,this.localStore)}Cc(e,t){return null}Fc(e,t){return null}xc(e){return u_(this.persistence,new a_,e.initialUser,this.serializer)}Dc(e){return new uh(fc.b_,this.serializer)}vc(e){return new g_}async terminate(){var e,t;(e=this.gcScheduler)==null||e.stop(),(t=this.indexBackfillerScheduler)==null||t.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Mo.provider={build:()=>new Mo};class bv extends Mo{constructor(e){super(),this.cacheSizeBytes=e}Cc(e,t){j(this.persistence.referenceDelegate instanceof Su,46915);const n=this.persistence.referenceDelegate.garbageCollector;return new dm(n,e.asyncQueue,t)}Dc(e){const t=this.cacheSizeBytes!==void 0?ht.withCacheSize(this.cacheSizeBytes):ht.DEFAULT;return new uh(n=>Su.b_(n,t),this.serializer)}}class Sv extends Mo{constructor(e,t,n){super(),this.Oc=e,this.cacheSizeBytes=t,this.forceOwnership=n,this.kind="persistent",this.synchronizeTabs=!1}async initialize(e){await super.initialize(e),await this.Oc.initialize(this,e),await A_(this.Oc.syncEngine),await ua(this.Oc.remoteStore),await this.persistence.eo(()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve()))}xc(e){return u_(this.persistence,new a_,e.initialUser,this.serializer)}Cc(e,t){const n=this.persistence.referenceDelegate.garbageCollector;return new dm(n,e.asyncQueue,t)}Fc(e,t){const n=new uv(t,this.persistence);return new av(e.asyncQueue,n)}Dc(e){const t=xR(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey),n=this.cacheSizeBytes!==void 0?ht.withCacheSize(this.cacheSizeBytes):ht.DEFAULT;return new ch(this.synchronizeTabs,t,e.clientId,n,e.asyncQueue,cv(),au(),this.serializer,this.sharedClientState,!!this.forceOwnership)}vc(e){return new g_}}class Nu{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=n=>jC(this.syncEngine,n,1),this.remoteStore.remoteSyncer.handleCredentialChange=vv.bind(null,this.syncEngine),await ov(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return function(){return new lv}()}createDatastore(e){const t=Xu(e.databaseInfo.databaseId),n=Kw(e.databaseInfo);return Yw(e.authCredentials,e.appCheckCredentials,n,t)}createRemoteStore(e){return function(n,s,i,o,a){return new QR(n,s,i,o,a)}(this.localStore,this.datastore,e.asyncQueue,t=>jC(this.syncEngine,t,0),function(){return aC.Ye()?new aC:new Hw}())}createSyncEngine(e,t){return function(s,i,o,a,u,B,l){const d=new gv(s,i,o,a,u,B);return l&&(d.gc=!0),d}(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){var e,t;await async function(s){const i=oe(s);U(_n,"RemoteStore shutting down."),i.la.add(5),await aa(i),i.ha.shutdown(),i.Ta.set("Unknown")}(this.remoteStore),(e=this.datastore)==null||e.terminate(),(t=this.eventManager)==null||t.terminate()}}Nu.provider={build:()=>new Nu};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Ov=class{constructor(e){this.datastore=e,this.readVersions=new Map,this.mutations=[],this.committed=!1,this.lastTransactionError=null,this.writtenDocs=new Set}async lookup(e){if(this.ensureCommitNotCalled(),this.mutations.length>0)throw this.lastTransactionError=new H(k.INVALID_ARGUMENT,"Firestore transactions require all reads to be executed before all writes."),this.lastTransactionError;const t=await async function(s,i){const o=oe(s),a={documents:i.map(d=>ri(o.serializer,d))},u=await o._t("BatchGetDocuments",o.serializer.databaseId,de.emptyPath(),a,i.length),B=new Map;u.forEach(d=>{const C=Aw(o.serializer,d);B.set(C.key.toString(),C)});const l=[];return i.forEach(d=>{const C=B.get(d.toString());j(!!C,55234,{key:d}),l.push(C)}),l}(this.datastore,e);return t.forEach(n=>this.recordVersion(n)),t}set(e,t){this.write(t.toMutation(e,this.precondition(e))),this.writtenDocs.add(e.toString())}update(e,t){try{this.write(t.toMutation(e,this.preconditionForUpdate(e)))}catch(n){this.lastTransactionError=n}this.writtenDocs.add(e.toString())}delete(e){this.write(new hi(e,this.precondition(e))),this.writtenDocs.add(e.toString())}async commit(){if(this.ensureCommitNotCalled(),this.lastTransactionError)throw this.lastTransactionError;const e=this.readVersions;this.mutations.forEach(t=>{e.delete(t.key.toString())}),e.forEach((t,n)=>{const s=W.fromPath(n);this.mutations.push(new Dl(s,this.precondition(s)))}),await async function(n,s){const i=oe(n),o={writes:s.map(a=>Po(i.serializer,a))};await i.nt("Commit",i.serializer.databaseId,de.emptyPath(),o)}(this.datastore,this.mutations),this.committed=!0}recordVersion(e){let t;if(e.isFoundDocument())t=e.version;else{if(!e.isNoDocument())throw ee(50498,{Mc:e.constructor.name});t=te.min()}const n=this.readVersions.get(e.key.toString());if(n){if(!t.isEqual(n))throw new H(k.ABORTED,"Document version changed between two reads.")}else this.readVersions.set(e.key.toString(),t)}precondition(e){const t=this.readVersions.get(e.toString());return!this.writtenDocs.has(e.toString())&&t?t.isEqual(te.min())?Fe.exists(!1):Fe.updateTime(t):Fe.none()}preconditionForUpdate(e){const t=this.readVersions.get(e.toString());if(!this.writtenDocs.has(e.toString())&&t){if(t.isEqual(te.min()))throw new H(k.INVALID_ARGUMENT,"Can't update a document that doesn't exist.");return Fe.updateTime(t)}return Fe.exists(!0)}write(e){this.ensureCommitNotCalled(),this.mutations.push(e)}ensureCommitNotCalled(){}};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nv{constructor(e,t,n,s,i){this.asyncQueue=e,this.datastore=t,this.options=n,this.updateFunction=s,this.deferred=i,this.Nc=n.maxAttempts,this.Ht=new Ol(this.asyncQueue,"transaction_retry")}Lc(){this.Nc-=1,this.Bc()}Bc(){this.Ht.kt(async()=>{const e=new Ov(this.datastore),t=this.Uc(e);t&&t.then(n=>{this.asyncQueue.enqueueAndForget(()=>e.commit().then(()=>{this.deferred.resolve(n)}).catch(s=>{this.kc(s)}))}).catch(n=>{this.kc(n)})})}Uc(e){try{const t=this.updateFunction(e);return!Qo(t)&&t.catch&&t.then?t:(this.deferred.reject(Error("Transaction callback must return a Promise")),null)}catch(t){return this.deferred.reject(t),null}}kc(e){this.Nc>0&&this.qc(e)?(this.Nc-=1,this.asyncQueue.enqueueAndForget(()=>(this.Bc(),Promise.resolve()))):this.deferred.reject(e)}qc(e){if((e==null?void 0:e.name)==="FirebaseError"){const t=e.code;return t==="aborted"||t==="failed-precondition"||t==="already-exists"||!Mg(t)}return!1}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Rr="FirestoreClient";class Fv{constructor(e,t,n,s,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=n,this._databaseInfo=s,this.user=ut.UNAUTHENTICATED,this.clientId=gl.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(n,async o=>{U(Rr,"Received user=",o.uid),await this.authCredentialListener(o),this.user=o}),this.appCheckCredentials.start(n,o=>(U(Rr,"Received new app check token=",o),this.appCheckCredentialListener(o,this.user)))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new zt;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted(async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const n=mh(t,"Failed to shutdown persistence");e.reject(n)}}),e.promise}}async function gB(r,e){r.asyncQueue.verifyOperationInProgress(),U(Rr,"Initializing OfflineComponentProvider");const t=r.configuration;await e.initialize(t);let n=t.initialUser;r.setCredentialChangeListener(async s=>{n.isEqual(s)||(await c_(e.localStore,s),n=s)}),e.persistence.setDatabaseDeletedListener(()=>r.terminate()),r._offlineComponents=e}async function KC(r,e){r.asyncQueue.verifyOperationInProgress();const t=await Lv(r);U(Rr,"Initializing OnlineComponentProvider"),await e.initialize(t,r.configuration),r.setCredentialChangeListener(n=>GC(e.remoteStore,n)),r.setAppCheckTokenChangeListener((n,s)=>GC(e.remoteStore,s)),r._onlineComponents=e}async function Lv(r){if(!r._offlineComponents)if(r._uninitializedComponentsProvider){U(Rr,"Using user provided OfflineComponentProvider");try{await gB(r,r._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!function(s){return s.name==="FirebaseError"?s.code===k.FAILED_PRECONDITION||s.code===k.UNIMPLEMENTED:!(typeof DOMException<"u"&&s instanceof DOMException)||s.code===22||s.code===20||s.code===11}(t))throw t;tn("Error using user provided cache. Falling back to memory cache: "+t),await gB(r,new Mo)}}else U(Rr,"Using default OfflineComponentProvider"),await gB(r,new bv(void 0));return r._offlineComponents}async function Th(r){return r._onlineComponents||(r._uninitializedComponentsProvider?(U(Rr,"Using user provided OnlineComponentProvider"),await KC(r,r._uninitializedComponentsProvider._online)):(U(Rr,"Using default OnlineComponentProvider"),await KC(r,new Nu))),r._onlineComponents}function kv(r){return Th(r).then(e=>e.syncEngine)}function R_(r){return Th(r).then(e=>e.datastore)}async function Fu(r){const e=await Th(r),t=e.eventManager;return t.onListen=mv.bind(null,e.syncEngine),t.onUnlisten=Iv.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=_v.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=Dv.bind(null,e.syncEngine),t}function xv(r,e,t,n){const s=new ph(n),i=new Dh(e,s,t);return r.asyncQueue.enqueueAndForget(async()=>_h(await Fu(r),i)),()=>{s.Va(),r.asyncQueue.enqueueAndForget(async()=>Eh(await Fu(r),i))}}function Vv(r,e,t={}){const n=new zt;return r.asyncQueue.enqueueAndForget(async()=>function(i,o,a,u,B){const l=new ph({next:C=>{l.Va(),o.enqueueAndForget(()=>Eh(i,d));const g=C.docs.has(a);!g&&C.fromCache?B.reject(new H(k.UNAVAILABLE,"Failed to get document because the client is offline.")):g&&C.fromCache&&u&&u.source==="server"?B.reject(new H(k.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):B.resolve(C)},error:C=>B.reject(C)}),d=new Dh(Yo(a.path),l,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return _h(i,d)}(await Fu(r),r.asyncQueue,e,t,n)),n.promise}function v_(r,e,t={}){const n=new zt;return r.asyncQueue.enqueueAndForget(async()=>function(i,o,a,u,B){const l=new ph({next:C=>{l.Va(),o.enqueueAndForget(()=>Eh(i,d)),C.fromCache&&u.source==="server"?B.reject(new H(k.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):B.resolve(C)},error:C=>B.reject(C)}),d=new Dh(a instanceof ao?xA(a):a,l,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return _h(i,d)}(await Fu(r),r.asyncQueue,e,t,n)),n.promise}function Mv(r,e,t){const n=new zt;return r.asyncQueue.enqueueAndForget(async()=>{try{const s=await R_(r);n.resolve(async function(o,a,u){var v;const B=oe(o),{request:l,ve:d,parent:C}=Pw(B.serializer,uw(a),u);B.connection.Ze||delete l.parent;const g=(await B._t("RunAggregationQuery",B.serializer.databaseId,C,l,1)).filter(N=>!!N.result);j(g.length===1,64727);const m=(v=g[0].result)==null?void 0:v.aggregateFields;return Object.keys(m).reduce((N,q)=>(N[d[q]]=m[q],N),{})}(s,e,t))}catch(s){n.reject(s)}}),n.promise}function Gv(r,e){const t=new zt;return r.asyncQueue.enqueueAndForget(async()=>yv(await kv(r),e,t)),t.promise}function Uv(r,e,t){const n=new zt;return r.asyncQueue.enqueueAndForget(async()=>{const s=await R_(r);new Nv(r.asyncQueue,s,t,e,n).Lc()}),n.promise}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Lu=class{constructor(e,t,n,s,i){this._firestore=e,this._userDataWriter=t,this._key=n,this._document=s,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new Le(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new Hv(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){var e;return((e=this._document)==null?void 0:e.data.clone().value.mapValue.fields)??void 0}get(e){if(this._document){const t=this._document.data.field(Fn("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}},Hv=class extends Lu{data(){return super.data()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class P_{convertValue(e,t="none"){switch(Ke(e)){case 0:return null;case 1:return e.booleanValue;case 2:return Re(e.integerValue||e.doubleValue);case 3:return this.convertTimestamp(e.timestampValue);case 4:return this.convertServerTimestamp(e,t);case 5:return e.stringValue;case 6:return this.convertBytes(Nn(e.bytesValue));case 7:return this.convertReference(e.referenceValue);case 8:return this.convertGeoPoint(e.geoPointValue);case 9:return this.convertArray(e.arrayValue,t);case 11:return this.convertObject(e.mapValue,t);case 10:return this.convertVectorValue(e.mapValue);default:throw ee(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const n={};return Pr(e,(s,i)=>{n[s]=this.convertValue(i,t)}),n}convertVectorValue(e){var n,s,i;const t=(i=(s=(n=e.fields)==null?void 0:n[cs].arrayValue)==null?void 0:s.values)==null?void 0:i.map(o=>Re(o.doubleValue));return new Pt(t)}convertGeoPoint(e){return new fn(Re(e.latitude),Re(e.longitude))}convertArray(e,t){return(e.values||[]).map(n=>this.convertValue(n,t))}convertServerTimestamp(e,t){switch(t){case"previous":const n=Wo(e);return n==null?null:this.convertValue(n,t);case"estimate":return this.convertTimestamp(Ys(e));default:return null}}convertTimestamp(e){const t=On(e);return new _e(t.seconds,t.nanos)}convertDocumentKey(e,t){const n=de.fromString(e);j(nm(n),9688,{name:e});const s=new us(n.get(1),n.get(3)),i=new W(n.popFirst(5));return s.isEqual(t)||Dt(`A document reference to ${i} refers to a different database (${s.projectId}/${s.database}), which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pc(r,e,t){let n;return n=r?t&&(t.merge||t.mergeFields)?r.toFirestore(e,t):r.toFirestore(e):e,n}class qv extends P_{constructor(e){super(),this.firestore=e}convertBytes(e){return new xt(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Le(this.firestore,null,t)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zC="AsyncQueue";class WC{constructor(e=Promise.resolve()){this.$c=[],this.Kc=!1,this.Qc=[],this.Wc=null,this.Gc=!1,this.zc=!1,this.jc=[],this.Ht=new Ol(this,"async_queue_retry"),this.Hc=()=>{const n=au();n&&U(zC,"Visibility state changed to "+n.visibilityState),this.Ht.$t()},this.Jc=e;const t=au();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this.Hc)}get isShuttingDown(){return this.Kc}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Yc(),this.Zc(e)}enterRestrictedMode(e){if(!this.Kc){this.Kc=!0,this.zc=e||!1;const t=au();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.Hc)}}enqueue(e){if(this.Yc(),this.Kc)return new Promise(()=>{});const t=new zt;return this.Zc(()=>this.Kc&&this.zc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise)).then(()=>t.promise)}enqueueRetryable(e){this.enqueueAndForget(()=>(this.$c.push(e),this.Xc()))}async Xc(){if(this.$c.length!==0){try{await this.$c[0](),this.$c.shift(),this.Ht.reset()}catch(e){if(!br(e))throw e;U(zC,"Operation failed with retryable error: "+e)}this.$c.length>0&&this.Ht.kt(()=>this.Xc())}}Zc(e){const t=this.Jc.then(()=>(this.Gc=!0,e().catch(n=>{throw this.Wc=n,this.Gc=!1,Dt("INTERNAL UNHANDLED ERROR: ",QC(n)),n}).then(n=>(this.Gc=!1,n))));return this.Jc=t,t}enqueueAfterDelay(e,t,n){this.Yc(),this.jc.indexOf(e)>-1&&(t=0);const s=gh.createAndSchedule(this,e,t,n,i=>this.el(i));return this.Qc.push(s),s}Yc(){this.Wc&&ee(47125,{tl:QC(this.Wc)})}verifyOperationInProgress(){}async nl(){let e;do e=this.Jc,await e;while(e!==this.Jc)}rl(e){for(const t of this.Qc)if(t.timerId===e)return!0;return!1}il(e){return this.nl().then(()=>{this.Qc.sort((t,n)=>t.targetTimeMs-n.targetTimeMs);for(const t of this.Qc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.nl()})}sl(e){this.jc.push(e)}el(e){const t=this.Qc.indexOf(e);this.Qc.splice(t,1)}}function QC(r){let e=r.message||"";return r.stack&&(e=r.stack.includes(r.message)?r.stack:r.message+`
`+r.stack),e}class Gt extends ec{constructor(e,t,n,s){super(e,t,n,s),this.type="firestore",this._queue=new WC,this._persistenceKey=(s==null?void 0:s.name)||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new WC(e),this._firestoreClient=void 0,await e}}}function FO(r,e,t){t||(t=Io);const n=jo(r,"firestore");if(n.isInitialized(t)){const s=n.getImmediate({identifier:t}),i=n.getOptions(t);if(pn(i,e))return s;throw new H(k.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(e.cacheSizeBytes!==void 0&&e.localCache!==void 0)throw new H(k.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(e.cacheSizeBytes!==void 0&&e.cacheSizeBytes!==-1&&e.cacheSizeBytes<hm)throw new H(k.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return e.host&&vr(e.host)&&ju(e.host),n.initialize({options:e,instanceIdentifier:t})}function LO(r,e){const t=typeof r=="object"?r:hl(),n=typeof r=="string"?r:Io,s=jo(t,"firestore").getImmediate({identifier:n});if(!s._initialized){const i=kp("firestore");i&&sT(s,...i)}return s}function Sr(r){if(r._terminated)throw new H(k.FAILED_PRECONDITION,"The client has already been terminated.");return r._firestoreClient||jv(r),r._firestoreClient}function jv(r){var n,s,i,o;const e=r._freezeSettings(),t=Zw(r._databaseId,((n=r._app)==null?void 0:n.options.appId)||"",r._persistenceKey,(s=r._app)==null?void 0:s.options.apiKey,e);r._componentsProvider||(i=e.localCache)!=null&&i._offlineComponentProvider&&((o=e.localCache)!=null&&o._onlineComponentProvider)&&(r._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),r._firestoreClient=new Fv(r._authCredentials,r._appCheckCredentials,r._queue,t,r._componentsProvider&&function(u){const B=u==null?void 0:u._online.build();return{_offline:u==null?void 0:u._offline.build(B),_online:B}}(r._componentsProvider))}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _i extends P_{constructor(e){super(),this.firestore=e}convertBytes(e){return new xt(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new Le(this.firestore,null,t)}}class Js{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class gr extends Lu{constructor(e,t,n,s,i,o){super(e,t,n,s,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new uu(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const n=this._document.data.field(Fn("DocumentSnapshot.get",e));if(n!==null)return this._userDataWriter.convertValue(n,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new H(k.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=gr._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}gr._jsonSchemaVersion="firestore/documentSnapshot/1.0",gr._jsonSchema={type:Je("string",gr._jsonSchemaVersion),bundleSource:Je("string","DocumentSnapshot"),bundleName:Je("string"),bundle:Je("string")};class uu extends gr{data(e={}){return super.data(e)}}class mr{constructor(e,t,n,s){this._firestore=e,this._userDataWriter=t,this._snapshot=s,this.metadata=new Js(s.hasPendingWrites,s.fromCache),this.query=n}get docs(){const e=[];return this.forEach(t=>e.push(t)),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach(n=>{e.call(t,new uu(this._firestore,this._userDataWriter,n.key,n,new Js(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))})}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new H(k.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=function(s,i){if(s._snapshot.oldDocs.isEmpty()){let o=0;return s._snapshot.docChanges.map(a=>{je(s._snapshot.query)?rl(s._snapshot.query):Rl(s.query._query);const u=new uu(s._firestore,s._userDataWriter,a.doc.key,a.doc,new Js(s._snapshot.mutatedKeys.has(a.doc.key),s._snapshot.fromCache),s.query.converter);return a.doc,{type:"added",doc:u,oldIndex:-1,newIndex:o++}})}{let o=s._snapshot.oldDocs;return s._snapshot.docChanges.filter(a=>i||a.type!==3).map(a=>{const u=new uu(s._firestore,s._userDataWriter,a.doc.key,a.doc,new Js(s._snapshot.mutatedKeys.has(a.doc.key),s._snapshot.fromCache),s.query.converter);let B=-1,l=-1;return a.type!==0&&(B=o.indexOf(a.doc.key),o=o.delete(a.doc.key)),a.type!==1&&(o=o.add(a.doc),l=o.indexOf(a.doc.key)),{type:Jv(a.type),doc:u,oldIndex:B,newIndex:l}})}}(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new H(k.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=mr._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=gl.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],n=[],s=[];return this.docs.forEach(i=>{i._document!==null&&(t.push(i._document),n.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),s.push(i.ref.path))}),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function Jv(r){switch(r){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return ee(61501,{type:r})}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */mr._jsonSchemaVersion="firestore/querySnapshot/1.0",mr._jsonSchema={type:Je("string",mr._jsonSchemaVersion),bundleSource:Je("string","QuerySnapshot"),bundleName:Je("string"),bundle:Je("string")};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kv{constructor(e="count",t){this._internalFieldPath=t,this.type="AggregateField",this.aggregateType=e}}class zv{constructor(e,t,n){this._userDataWriter=t,this._data=n,this.type="AggregateQuerySnapshot",this.query=e}data(){return this._userDataWriter.convertObjectMap(this._data)}_fieldsProto(){return new We({mapValue:{fields:this._data}}).clone().value.mapValue.fields}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function b_(r){if(r.limitType==="L"&&r.explicitOrderBy.length===0)throw new H(k.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class Ah{}class Rh extends Ah{}function kO(r,e,...t){let n=[];e instanceof Ah&&n.push(e),n=n.concat(t),function(i){const o=i.filter(u=>u instanceof vh).length,a=i.filter(u=>u instanceof gc).length;if(o>1||o>0&&a>0)throw new H(k.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")}(n);for(const s of n)r=s._apply(r);return r}class gc extends Rh{constructor(e,t,n){super(),this._field=e,this._op=t,this._value=n,this.type="where"}static _create(e,t,n){return new gc(e,t,n)}_apply(e){const t=this._parse(e);return S_(e._query,t),new Dn(e.firestore,e.converter,HB(e._query,t))}_parse(e){const t=Ci(e.firestore);return function(i,o,a,u,B,l,d){let C;if(B.isKeyField()){if(l==="array-contains"||l==="array-contains-any")throw new H(k.INVALID_ARGUMENT,`Invalid Query. You can't perform '${l}' queries on documentId().`);if(l==="in"||l==="not-in"){YC(d,l);const m=[];for(const v of d)m.push($C(u,i,v));C={arrayValue:{values:m}}}else C=$C(u,i,d)}else l!=="in"&&l!=="not-in"&&l!=="array-contains-any"||YC(d,l),C=cT(a,o,d,l==="in"||l==="not-in");return Ce.create(B,l,C)}(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}function xO(r,e,t){const n=e,s=Fn("where",r);return gc._create(s,n,t)}class vh extends Ah{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new vh(e,t)}_parse(e){const t=this._queryConstraints.map(n=>n._parse(e)).filter(n=>n.getFilters().length>0);return t.length===1?t[0]:ye.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:(function(s,i){let o=s;const a=i.getFlattenedFilters();for(const u of a)S_(o,u),o=HB(o,u)}(e._query,t),new Dn(e.firestore,e.converter,HB(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class Ph extends Rh{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new Ph(e,t)}_apply(e){const t=function(s,i,o){if(s.startAt!==null)throw new H(k.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(s.endAt!==null)throw new H(k.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new Ao(i,o)}(e._query,this._field,this._direction);return new Dn(e.firestore,e.converter,cw(e._query,t))}}function VO(r,e="asc"){const t=e,n=Fn("orderBy",r);return Ph._create(n,t)}class bh extends Rh{constructor(e,t,n){super(),this.type=e,this._limit=t,this._limitType=n}static _create(e,t,n){return new bh(e,t,n)}_apply(e){return new Dn(e.firestore,e.converter,Du(e._query,this._limit,this._limitType))}}function MO(r){return xy("limit",r),bh._create("limit",r,"F")}function $C(r,e,t){if(typeof(t=re(t))=="string"){if(t==="")throw new H(k.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!xg(e)&&t.indexOf("/")!==-1)throw new H(k.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const n=e.path.child(de.fromString(t));if(!W.isDocumentKey(n))throw new H(k.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${n}' is not because it has an odd number of segments (${n.length}).`);return yo(r,new W(n))}if(t instanceof Le)return yo(r,t._key);throw new H(k.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${Ju(t)}.`)}function YC(r,e){if(!Array.isArray(r)||r.length===0)throw new H(k.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function S_(r,e){const t=function(s,i){for(const o of s)for(const a of o.getFlattenedFilters())if(i.indexOf(a.op)>=0)return a.op;return null}(r.filters,function(s){switch(s){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}}(e.op));if(t!==null)throw t===e.op?new H(k.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new H(k.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}function Wv(){return new Kv("count")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function XC(r){return function(t,n){if(typeof t!="object"||t===null)return!1;const s=t;for(const i of n)if(i in s&&typeof s[i]=="function")return!0;return!1}(r,["next","error","complete"])}function GO(r){return Qv(r,{count:Wv()})}function Qv(r,e){const t=Ye(r.firestore,Gt),n=Sr(t),s=lg(e,(i,o)=>new by(o,i.aggregateType,i._internalFieldPath));return Mv(n,r._query,s).then(i=>function(a,u,B){const l=new _i(a);return new zv(u,l,B)}(t,r,i))}class $v{constructor(e){let t;this.kind="persistent",e!=null&&e.tabManager?(e.tabManager._initialize(e),t=e.tabManager):(t=Xv(void 0),t._initialize(e)),this._onlineComponentProvider=t._onlineComponentProvider,this._offlineComponentProvider=t._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function UO(r){return new $v(r)}class Yv{constructor(e){this.forceOwnership=e,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=Nu.provider,this._offlineComponentProvider={build:t=>new Sv(t,e==null?void 0:e.cacheSizeBytes,this.forceOwnership)}}}function Xv(r){return new Yv(r==null?void 0:r.forceOwnership)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Zv={maxAttempts:5};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eP{constructor(e,t){this._firestore=e,this._commitHandler=t,this._mutations=[],this._committed=!1,this._dataReader=Ci(e)}set(e,t,n){this._verifyNotCommitted();const s=cr(e,this._firestore),i=pc(s.converter,t,n),o=nc(this._dataReader,"WriteBatch.set",s._key,i,s.converter!==null,n);return this._mutations.push(o.toMutation(s._key,Fe.none())),this}update(e,t,n,...s){this._verifyNotCommitted();const i=cr(e,this._firestore);let o;return o=typeof(t=re(t))=="string"||t instanceof fi?Ml(this._dataReader,"WriteBatch.update",i._key,t,n,s):Vl(this._dataReader,"WriteBatch.update",i._key,t),this._mutations.push(o.toMutation(i._key,Fe.exists(!0))),this}delete(e){this._verifyNotCommitted();const t=cr(e,this._firestore);return this._mutations=this._mutations.concat(new hi(t._key,Fe.none())),this}commit(){return this._verifyNotCommitted(),this._committed=!0,this._mutations.length>0?this._commitHandler(this._mutations):Promise.resolve()}_verifyNotCommitted(){if(this._committed)throw new H(k.FAILED_PRECONDITION,"A write batch can no longer be used after commit() has been called.")}}function cr(r,e){if((r=re(r)).firestore!==e)throw new H(k.INVALID_ARGUMENT,"Provided document reference is from a different Firestore instance.");return r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let tP=class{constructor(e,t){this._firestore=e,this._transaction=t,this._dataReader=Ci(e)}get(e){const t=cr(e,this._firestore),n=new qv(this._firestore);return this._transaction.lookup([t._key]).then(s=>{if(!s||s.length!==1)return ee(24041);const i=s[0];if(i.isFoundDocument())return new Lu(this._firestore,n,i.key,i,t.converter);if(i.isNoDocument())return new Lu(this._firestore,n,t._key,null,t.converter);throw ee(18433,{doc:i})})}set(e,t,n){const s=cr(e,this._firestore),i=pc(s.converter,t,n),o=nc(this._dataReader,"Transaction.set",s._key,i,s.converter!==null,n);return this._transaction.set(s._key,o),this}update(e,t,n,...s){const i=cr(e,this._firestore);let o;return o=typeof(t=re(t))=="string"||t instanceof fi?Ml(this._dataReader,"Transaction.update",i._key,t,n,s):Vl(this._dataReader,"Transaction.update",i._key,t),this._transaction.update(i._key,o),this}delete(e){const t=cr(e,this._firestore);return this._transaction.delete(t._key),this}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nP extends tP{constructor(e,t){super(e,t),this._firestore=e}get(e){const t=cr(e,this._firestore),n=new _i(this._firestore);return super.get(e).then(s=>new gr(this._firestore,n,t._key,s._document,new Js(!1,!1),t.converter))}}function qO(r,e,t){r=Ye(r,Gt);const n={...Zv,...t};(function(o){if(o.maxAttempts<1)throw new H(k.INVALID_ARGUMENT,"Max attempts must be at least 1")})(n);const s=Sr(r);return Uv(s,i=>e(new nP(r,i)),n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function jO(r){r=Ye(r,Le);const e=Ye(r.firestore,Gt),t=Sr(e);return Vv(t,r._key).then(n=>O_(e,r,n))}function JO(r){r=Ye(r,Dn);const e=Ye(r.firestore,Gt),t=Sr(e),n=new _i(e);return b_(r._query),v_(t,r._query).then(s=>new mr(e,n,r,s))}function KO(r){r=Ye(r,Dn);const e=Ye(r.firestore,Gt),t=Sr(e),n=new _i(e);return v_(t,r._query,{source:"server"}).then(s=>new mr(e,n,r,s))}function zO(r,e,t){r=Ye(r,Le);const n=Ye(r.firestore,Gt),s=pc(r.converter,e,t),i=Ci(n);return Ba(n,[nc(i,"setDoc",r._key,s,r.converter!==null,t).toMutation(r._key,Fe.none())])}function WO(r,e,t,...n){r=Ye(r,Le);const s=Ye(r.firestore,Gt),i=Ci(s);let o;return o=typeof(e=re(e))=="string"||e instanceof fi?Ml(i,"updateDoc",r._key,e,t,n):Vl(i,"updateDoc",r._key,e),Ba(s,[o.toMutation(r._key,Fe.exists(!0))])}function QO(r){return Ba(Ye(r.firestore,Gt),[new hi(r._key,Fe.none())])}function $O(r,e){const t=Ye(r.firestore,Gt),n=iT(r),s=pc(r.converter,e),i=Ci(r.firestore);return Ba(t,[nc(i,"addDoc",n._key,s,r.converter!==null,{}).toMutation(n._key,Fe.exists(!1))]).then(()=>n)}function YO(r,...e){var B,l,d;r=re(r);let t={includeMetadataChanges:!1,source:"default"},n=0;typeof e[n]!="object"||XC(e[n])||(t=e[n++]);const s={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(XC(e[n])){const C=e[n];e[n]=(B=C.next)==null?void 0:B.bind(C),e[n+1]=(l=C.error)==null?void 0:l.bind(C),e[n+2]=(d=C.complete)==null?void 0:d.bind(C)}let i,o,a;if(r instanceof Le)o=Ye(r.firestore,Gt),a=Yo(r._key.path),i={next:C=>{e[n]&&e[n](O_(o,r,C))},error:e[n+1],complete:e[n+2]};else{const C=Ye(r,Dn);o=Ye(C.firestore,Gt),a=C._query;const g=new _i(o);i={next:m=>{e[n]&&e[n](new mr(o,g,C,m))},error:e[n+1],complete:e[n+2]},b_(r._query)}const u=Sr(o);return xv(u,a,s,i)}function Ba(r,e){const t=Sr(r);return Gv(t,e)}function O_(r,e,t){const n=t.docs.get(e._key),s=new _i(r);return new gr(r,s,e._key,n,new Js(t.hasPendingWrites,t.fromCache),e.converter)}function XO(r){return r=Ye(r,Gt),Sr(r),new eP(r,e=>Ba(r,e))}const ZC="@firebase/firestore",ep="4.17.2";(function(e,t=!0){Sy(ms),is(new Er("firestore",(n,{instanceIdentifier:s,options:i})=>{const o=n.getProvider("app").getImmediate(),a=new Gt(new Vw(n.getProvider("auth-internal")),new Uw(o,n.getProvider("app-check-internal")),Gy(o,s),o);return i={useFetchStreams:t,...i},a._setSettings(i),a},"PUBLIC").setMultipleInstances(!0)),hn(ZC,ep,e),hn(ZC,ep,"esm2020")})();var rP="firebase",sP="12.19.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */hn(rP,sP,"app");function N_(){return{"dependent-sdk-initialized-before-auth":"Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."}}const iP=N_,F_=new qo("auth","Firebase",N_());/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ku=new Bl("@firebase/auth");function cu(r,...e){ku.logLevel<=fe.WARN&&ku.warn(`Auth (${ms}): ${r}`,...e)}function Bu(r,...e){ku.logLevel<=fe.ERROR&&ku.error(`Auth (${ms}): ${r}`,...e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qt(r,...e){throw Sh(r,...e)}function wt(r,...e){return Sh(r,...e)}function mc(r,e,t){const n={...iP(),[e]:t};return new qo("auth","Firebase",n).create(e,{appName:r.name})}function Tt(r){return mc(r,"operation-not-supported-in-this-environment","Operations that alter the current user are not supported in conjunction with FirebaseServerApp")}function la(r,e,t){const n=t;if(!(e instanceof n))throw n.name!==e.constructor.name&&Qt(r,"argument-error"),mc(r,"argument-error",`Type of ${e.constructor.name} does not match expected instance.Did you pass a reference from a different Auth SDK?`)}function Sh(r,...e){if(typeof r!="string"){const t=e[0],n=[...e.slice(1)];return n[0]&&(n[0].appName=r.name),r._errorFactory.create(t,...n)}return F_.create(r,...e)}function Y(r,e,...t){if(!r)throw Sh(e,...t)}function An(r){const e="INTERNAL ASSERTION FAILED: "+r;throw Bu(e),new Error(e)}function xn(r,e){r||An(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Go(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.href)||""}function Oh(){return tp()==="http:"||tp()==="https:"}function tp(){var r;return typeof self<"u"&&((r=self.location)==null?void 0:r.protocol)||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function oP(){return typeof navigator<"u"&&navigator&&"onLine"in navigator&&typeof navigator.onLine=="boolean"&&(Oh()||VI()||"connection"in navigator)?navigator.onLine:!0}function aP(){if(typeof navigator>"u")return null;const r=navigator;return r.languages&&r.languages[0]||r.language||null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ha{constructor(e,t){this.shortDelay=e,this.longDelay=t,xn(t>e,"Short delay should be less than long delay!"),this.isMobile=kI()||MI()}get(){return oP()?this.isMobile?this.longDelay:this.shortDelay:Math.min(5e3,this.shortDelay)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nh(r,e){xn(r.emulator,"Emulator should always be set here");const{url:t}=r.emulator;return e?`${t}${e.startsWith("/")?e.slice(1):e}`:t}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class L_{static initialize(e,t,n){this.fetchImpl=e,t&&(this.headersImpl=t),n&&(this.responseImpl=n)}static fetch(){if(this.fetchImpl)return this.fetchImpl;if(typeof self<"u"&&"fetch"in self)return self.fetch;if(typeof globalThis<"u"&&globalThis.fetch)return globalThis.fetch;if(typeof fetch<"u")return fetch;An("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static headers(){if(this.headersImpl)return this.headersImpl;if(typeof self<"u"&&"Headers"in self)return self.Headers;if(typeof globalThis<"u"&&globalThis.Headers)return globalThis.Headers;if(typeof Headers<"u")return Headers;An("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}static response(){if(this.responseImpl)return this.responseImpl;if(typeof self<"u"&&"Response"in self)return self.Response;if(typeof globalThis<"u"&&globalThis.Response)return globalThis.Response;if(typeof Response<"u")return Response;An("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uP={CREDENTIAL_MISMATCH:"custom-token-mismatch",MISSING_CUSTOM_TOKEN:"internal-error",INVALID_IDENTIFIER:"invalid-email",MISSING_CONTINUE_URI:"internal-error",INVALID_PASSWORD:"wrong-password",MISSING_PASSWORD:"missing-password",INVALID_LOGIN_CREDENTIALS:"invalid-credential",EMAIL_EXISTS:"email-already-in-use",PASSWORD_LOGIN_DISABLED:"operation-not-allowed",INVALID_IDP_RESPONSE:"invalid-credential",INVALID_PENDING_TOKEN:"invalid-credential",FEDERATED_USER_ID_ALREADY_LINKED:"credential-already-in-use",MISSING_REQ_TYPE:"internal-error",EMAIL_NOT_FOUND:"user-not-found",RESET_PASSWORD_EXCEED_LIMIT:"too-many-requests",EXPIRED_OOB_CODE:"expired-action-code",INVALID_OOB_CODE:"invalid-action-code",MISSING_OOB_CODE:"internal-error",CREDENTIAL_TOO_OLD_LOGIN_AGAIN:"requires-recent-login",INVALID_ID_TOKEN:"invalid-user-token",TOKEN_EXPIRED:"user-token-expired",USER_NOT_FOUND:"user-token-expired",TOO_MANY_ATTEMPTS_TRY_LATER:"too-many-requests",PASSWORD_DOES_NOT_MEET_REQUIREMENTS:"password-does-not-meet-requirements",INVALID_CODE:"invalid-verification-code",INVALID_SESSION_INFO:"invalid-verification-id",INVALID_TEMPORARY_PROOF:"invalid-credential",MISSING_SESSION_INFO:"missing-verification-id",SESSION_EXPIRED:"code-expired",MISSING_ANDROID_PACKAGE_NAME:"missing-android-pkg-name",UNAUTHORIZED_DOMAIN:"unauthorized-continue-uri",INVALID_OAUTH_CLIENT_ID:"invalid-oauth-client-id",ADMIN_ONLY_OPERATION:"admin-restricted-operation",INVALID_MFA_PENDING_CREDENTIAL:"invalid-multi-factor-session",MFA_ENROLLMENT_NOT_FOUND:"multi-factor-info-not-found",MISSING_MFA_ENROLLMENT_ID:"missing-multi-factor-info",MISSING_MFA_PENDING_CREDENTIAL:"missing-multi-factor-session",SECOND_FACTOR_EXISTS:"second-factor-already-in-use",SECOND_FACTOR_LIMIT_EXCEEDED:"maximum-second-factor-count-exceeded",BLOCKING_FUNCTION_ERROR_RESPONSE:"internal-error",RECAPTCHA_NOT_ENABLED:"recaptcha-not-enabled",MISSING_RECAPTCHA_TOKEN:"missing-recaptcha-token",INVALID_RECAPTCHA_TOKEN:"invalid-recaptcha-token",INVALID_RECAPTCHA_ACTION:"invalid-recaptcha-action",MISSING_CLIENT_TYPE:"missing-client-type",MISSING_RECAPTCHA_VERSION:"missing-recaptcha-version",INVALID_RECAPTCHA_VERSION:"invalid-recaptcha-version",INVALID_REQ_TYPE:"invalid-req-type"};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cP=["/v1/accounts:signInWithCustomToken","/v1/accounts:signInWithEmailLink","/v1/accounts:signInWithIdp","/v1/accounts:signInWithPassword","/v1/accounts:signInWithPhoneNumber","/v1/token"],BP=new ha(3e4,6e4);function et(r,e){return r.tenantId&&!e.tenantId?{...e,tenantId:r.tenantId}:e}async function tt(r,e,t,n,s={}){return k_(r,s,async()=>{let i={},o={};n&&(e==="GET"?o=n:i={body:JSON.stringify(n)});const a=ci({...o,key:r.config.apiKey}).slice(1),u=await r._getAdditionalHeaders();u["Content-Type"]="application/json",r.languageCode&&(u["X-Firebase-Locale"]=r.languageCode);const B={method:e,headers:u,...i};return xI()||(B.referrerPolicy="strict-origin-when-cross-origin"),r.emulatorConfig&&vr(r.emulatorConfig.host)&&(B.credentials="include"),L_.fetch()(await x_(r,r.config.apiHost,t,a),B)})}async function k_(r,e,t){r._canInitEmulator=!1;const n={...uP,...e};try{const s=new hP(r),i=await Promise.race([t(),s.promise]);s.clearNetworkTimeout();const o=await i.json();if("needConfirmation"in o)throw eo(r,"account-exists-with-different-credential",o);if(i.ok&&!("errorMessage"in o))return o;{const a=i.ok?o.errorMessage:o.error.message,[u,B]=a.split(" : ");if(u==="FEDERATED_USER_ID_ALREADY_LINKED")throw eo(r,"credential-already-in-use",o);if(u==="EMAIL_EXISTS")throw eo(r,"email-already-in-use",o);if(u==="USER_DISABLED")throw eo(r,"user-disabled",o);const l=n[u]||u.toLowerCase().replace(/[_\s]+/g,"-");if(B)throw mc(r,l,B);Qt(r,l)}}catch(s){if(s instanceof In)throw s;Qt(r,"network-request-failed",{message:String(s)})}}async function Un(r,e,t,n,s={}){const i=await tt(r,e,t,n,s);return"mfaPendingCredential"in i&&Qt(r,"multi-factor-auth-required",{_serverResponse:i}),i}async function x_(r,e,t,n){const s=`${e}${t}?${n}`,i=r,o=i.config.emulator?Nh(r.config,s):`${r.config.apiScheme}://${s}`;return cP.includes(t)&&(await i._persistenceManagerAvailable,i._getPersistenceType()==="COOKIE")?i._getPersistence()._getFinalTarget(o).toString():o}function lP(r){switch(r){case"ENFORCE":return"ENFORCE";case"AUDIT":return"AUDIT";case"OFF":return"OFF";default:return"ENFORCEMENT_STATE_UNSPECIFIED"}}class hP{clearNetworkTimeout(){clearTimeout(this.timer)}constructor(e){this.auth=e,this.timer=null,this.promise=new Promise((t,n)=>{this.timer=setTimeout(()=>n(wt(this.auth,"network-request-failed")),BP.get())})}}function eo(r,e,t){const n={appName:r.name};t.email&&(n.email=t.email),t.phoneNumber&&(n.phoneNumber=t.phoneNumber);const s=wt(r,e,n);return s.customData._tokenResponse=t,s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function np(r){return r!==void 0&&r.getResponse!==void 0}function rp(r){return r!==void 0&&r.enterprise!==void 0}class V_{constructor(e){if(this.siteKey="",this.recaptchaEnforcementState=[],e.recaptchaKey===void 0)throw new Error("recaptchaKey undefined");this.siteKey=e.recaptchaKey.split("/")[3],this.recaptchaEnforcementState=e.recaptchaEnforcementState}getProviderEnforcementState(e){if(!this.recaptchaEnforcementState||this.recaptchaEnforcementState.length===0)return null;for(const t of this.recaptchaEnforcementState)if(t.provider&&t.provider===e)return lP(t.enforcementState);return null}isProviderEnabled(e){return this.getProviderEnforcementState(e)==="ENFORCE"||this.getProviderEnforcementState(e)==="AUDIT"}isAnyProviderEnabled(){return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")||this.isProviderEnabled("PHONE_PROVIDER")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function dP(r){return(await tt(r,"GET","/v1/recaptchaParams")).recaptchaSiteKey||""}async function M_(r,e){return tt(r,"GET","/v2/recaptchaConfig",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fP(r,e){return tt(r,"POST","/v1/accounts:delete",e)}async function CP(r,e){return tt(r,"POST","/v1/accounts:update",e)}async function xu(r,e){return tt(r,"POST","/v1/accounts:lookup",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ho(r){if(r)try{const e=new Date(Number(r));if(!isNaN(e.getTime()))return e.toUTCString()}catch{}}async function pP(r,e=!1){const t=re(r),n=await t.getIdToken(e),s=_c(n);Y(s&&s.exp&&s.auth_time&&s.iat,t.auth,"internal-error");const i=typeof s.firebase=="object"?s.firebase:void 0,o=i==null?void 0:i.sign_in_provider;return{claims:s,token:n,authTime:ho(mB(s.auth_time)),issuedAtTime:ho(mB(s.iat)),expirationTime:ho(mB(s.exp)),signInProvider:o||null,signInSecondFactor:(i==null?void 0:i.sign_in_second_factor)||null}}function mB(r){return Number(r)*1e3}function _c(r){const[e,t,n]=r.split(".");if(e===void 0||t===void 0||n===void 0)return Bu("JWT malformed, contained fewer than 3 sections"),null;try{const s=Np(t);return s?JSON.parse(s):(Bu("Failed to decode base64 JWT payload"),null)}catch(s){return Bu("Caught error parsing JWT payload as JSON",s==null?void 0:s.toString()),null}}function sp(r){const e=_c(r);return Y(e,"internal-error"),Y(typeof e.exp<"u","internal-error"),Y(typeof e.iat<"u","internal-error"),Number(e.exp)-Number(e.iat)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ps(r,e,t=!1){if(t)return e;try{return await e}catch(n){throw n instanceof In&&gP(n)&&r.auth.currentUser===r&&await r.auth.signOut(),n}}function gP({code:r}){return r==="auth/user-disabled"||r==="auth/user-token-expired"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mP{constructor(e){this.user=e,this.isRunning=!1,this.timerId=null,this.errorBackoff=3e4}_start(){this.isRunning||(this.isRunning=!0,this.schedule())}_stop(){this.isRunning&&(this.isRunning=!1,this.timerId!==null&&clearTimeout(this.timerId))}getInterval(e){if(e){const t=this.errorBackoff;return this.errorBackoff=Math.min(this.errorBackoff*2,96e4),t}else{this.errorBackoff=3e4;const n=(this.user.stsTokenManager.expirationTime??0)-Date.now()-3e5;return Math.max(0,n)}}schedule(e=!1){if(!this.isRunning)return;const t=this.getInterval(e);this.timerId=setTimeout(async()=>{await this.iteration()},t)}async iteration(){try{await this.user.getIdToken(!0)}catch(e){(e==null?void 0:e.code)==="auth/network-request-failed"&&this.schedule(!0);return}this.schedule()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ul{constructor(e,t){this.createdAt=e,this.lastLoginAt=t,this._initializeTime()}_initializeTime(){this.lastSignInTime=ho(this.lastLoginAt),this.creationTime=ho(this.createdAt)}_copy(e){this.createdAt=e.createdAt,this.lastLoginAt=e.lastLoginAt,this._initializeTime()}toJSON(){return{createdAt:this.createdAt,lastLoginAt:this.lastLoginAt}}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Uo(r){var d;const e=r.auth,t=await r.getIdToken(),n=await ps(r,xu(e,{idToken:t}));Y(n==null?void 0:n.users.length,e,"internal-error");const s=n.users[0];r._notifyReloadListener(s);const i=(d=s.providerUserInfo)!=null&&d.length?G_(s.providerUserInfo):[],o=EP(r.providerData,i),a=r.isAnonymous,u=!(r.email&&s.passwordHash)&&!(o!=null&&o.length),B=a?u:!1,l={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:o,metadata:new ul(s.createdAt,s.lastLoginAt),isAnonymous:B};Object.assign(r,l)}async function _P(r){const e=re(r);await Uo(e),await e.auth._persistUserIfCurrent(e),e.auth._notifyListenersIfCurrent(e)}function EP(r,e){return[...r.filter(n=>!e.some(s=>s.providerId===n.providerId)),...e]}function G_(r){return r.map(({providerId:e,...t})=>({providerId:e,uid:t.rawId||"",displayName:t.displayName||null,email:t.email||null,phoneNumber:t.phoneNumber||null,photoURL:t.photoUrl||null}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function IP(r,e){const t=await k_(r,{},async()=>{const n=ci({grant_type:"refresh_token",refresh_token:e}).slice(1),{tokenApiHost:s,apiKey:i}=r.config,o=await x_(r,s,"/v1/token",`key=${i}`),a=await r._getAdditionalHeaders();a["Content-Type"]="application/x-www-form-urlencoded";const u={method:"POST",headers:a,body:n};return r.emulatorConfig&&vr(r.emulatorConfig.host)&&(u.credentials="include"),L_.fetch()(o,u)});return{accessToken:t.access_token,expiresIn:t.expires_in,refreshToken:t.refresh_token}}async function DP(r,e){return tt(r,"POST","/v2/accounts:revokeToken",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zs{constructor(){this.refreshToken=null,this.accessToken=null,this.expirationTime=null}get isExpired(){return!this.expirationTime||Date.now()>this.expirationTime-3e4}updateFromServerResponse(e){Y(e.idToken,"internal-error"),Y(typeof e.idToken<"u","internal-error"),Y(typeof e.refreshToken<"u","internal-error");const t="expiresIn"in e&&typeof e.expiresIn<"u"?Number(e.expiresIn):sp(e.idToken);this.updateTokensAndExpiration(e.idToken,e.refreshToken,t)}updateFromIdToken(e){Y(e.length!==0,"internal-error");const t=sp(e);this.updateTokensAndExpiration(e,null,t)}async getToken(e,t=!1){return!t&&this.accessToken&&!this.isExpired?this.accessToken:(Y(this.refreshToken,e,"user-token-expired"),this.refreshToken?(await this.refresh(e,this.refreshToken),this.accessToken):null)}clearRefreshToken(){this.refreshToken=null}async refresh(e,t){const{accessToken:n,refreshToken:s,expiresIn:i}=await IP(e,t);this.updateTokensAndExpiration(n,s,Number(i))}updateTokensAndExpiration(e,t,n){this.refreshToken=t||null,this.accessToken=e||null,this.expirationTime=Date.now()+n*1e3}static fromJSON(e,t){const{refreshToken:n,accessToken:s,expirationTime:i}=t,o=new zs;return n&&(Y(typeof n=="string","internal-error",{appName:e}),o.refreshToken=n),s&&(Y(typeof s=="string","internal-error",{appName:e}),o.accessToken=s),i&&(Y(typeof i=="number","internal-error",{appName:e}),o.expirationTime=i),o}toJSON(){return{refreshToken:this.refreshToken,accessToken:this.accessToken,expirationTime:this.expirationTime}}_assign(e){this.accessToken=e.accessToken,this.refreshToken=e.refreshToken,this.expirationTime=e.expirationTime}_clone(){return Object.assign(new zs,this.toJSON())}_performRefresh(){return An("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zn(r,e){Y(typeof r=="string"||typeof r>"u","internal-error",{appName:e})}class en{constructor({uid:e,auth:t,stsTokenManager:n,...s}){this.providerId="firebase",this.proactiveRefresh=new mP(this),this.reloadUserInfo=null,this.reloadListener=null,this.uid=e,this.auth=t,this.stsTokenManager=n,this.accessToken=n.accessToken,this.displayName=s.displayName||null,this.email=s.email||null,this.emailVerified=s.emailVerified||!1,this.phoneNumber=s.phoneNumber||null,this.photoURL=s.photoURL||null,this.isAnonymous=s.isAnonymous||!1,this.tenantId=s.tenantId||null,this.providerData=s.providerData?[...s.providerData]:[],this.metadata=new ul(s.createdAt||void 0,s.lastLoginAt||void 0)}async getIdToken(e){const t=await ps(this,this.stsTokenManager.getToken(this.auth,e));return Y(t,this.auth,"internal-error"),this.accessToken!==t&&(this.accessToken=t,await this.auth._persistUserIfCurrent(this),this.auth._notifyListenersIfCurrent(this)),t}getIdTokenResult(e){return pP(this,e)}reload(){return _P(this)}_assign(e){this!==e&&(Y(this.uid===e.uid,this.auth,"internal-error"),this.displayName=e.displayName,this.photoURL=e.photoURL,this.email=e.email,this.emailVerified=e.emailVerified,this.phoneNumber=e.phoneNumber,this.isAnonymous=e.isAnonymous,this.tenantId=e.tenantId,this.providerData=e.providerData.map(t=>({...t})),this.metadata._copy(e.metadata),this.stsTokenManager._assign(e.stsTokenManager))}_clone(e){const t=new en({...this,auth:e,stsTokenManager:this.stsTokenManager._clone()});return t.metadata._copy(this.metadata),t}_onReload(e){Y(!this.reloadListener,this.auth,"internal-error"),this.reloadListener=e,this.reloadUserInfo&&(this._notifyReloadListener(this.reloadUserInfo),this.reloadUserInfo=null)}_notifyReloadListener(e){this.reloadListener?this.reloadListener(e):this.reloadUserInfo=e}_startProactiveRefresh(){this.proactiveRefresh._start()}_stopProactiveRefresh(){this.proactiveRefresh._stop()}async _updateTokensIfNecessary(e,t=!1){let n=!1;e.idToken&&e.idToken!==this.stsTokenManager.accessToken&&(this.stsTokenManager.updateFromServerResponse(e),n=!0),t&&await Uo(this),await this.auth._persistUserIfCurrent(this),n&&this.auth._notifyListenersIfCurrent(this)}async delete(){if(Ge(this.auth.app))return Promise.reject(Tt(this.auth));const e=await this.getIdToken();return await ps(this,fP(this.auth,{idToken:e})),this.stsTokenManager.clearRefreshToken(),this.auth.signOut()}toJSON(){return{uid:this.uid,email:this.email||void 0,emailVerified:this.emailVerified,displayName:this.displayName||void 0,isAnonymous:this.isAnonymous,photoURL:this.photoURL||void 0,phoneNumber:this.phoneNumber||void 0,tenantId:this.tenantId||void 0,providerData:this.providerData.map(e=>({...e})),stsTokenManager:this.stsTokenManager.toJSON(),_redirectEventId:this._redirectEventId,...this.metadata.toJSON(),apiKey:this.auth.config.apiKey,appName:this.auth.name}}get refreshToken(){return this.stsTokenManager.refreshToken||""}static _fromJSON(e,t){const n=t.displayName??void 0,s=t.email??void 0,i=t.phoneNumber??void 0,o=t.photoURL??void 0,a=t.tenantId??void 0,u=t._redirectEventId??void 0,B=t.createdAt??void 0,l=t.lastLoginAt??void 0,{uid:d,emailVerified:C,isAnonymous:g,providerData:m,stsTokenManager:v}=t;Y(d&&v,e,"internal-error");const N=zs.fromJSON(this.name,v);Y(typeof d=="string",e,"internal-error"),Zn(n,e.name),Zn(s,e.name),Y(typeof C=="boolean",e,"internal-error"),Y(typeof g=="boolean",e,"internal-error"),Zn(i,e.name),Zn(o,e.name),Zn(a,e.name),Zn(u,e.name),Zn(B,e.name),Zn(l,e.name);const q=new en({uid:d,auth:e,email:s,emailVerified:C,displayName:n,isAnonymous:g,photoURL:o,phoneNumber:i,tenantId:a,stsTokenManager:N,createdAt:B,lastLoginAt:l});return m&&Array.isArray(m)&&(q.providerData=m.map(J=>({...J}))),u&&(q._redirectEventId=u),q}static async _fromIdTokenResponse(e,t,n=!1){const s=new zs;s.updateFromServerResponse(t);const i=new en({uid:t.localId,auth:e,stsTokenManager:s,isAnonymous:n});return await Uo(i),i}static async _fromGetAccountInfoResponse(e,t,n){const s=t.users[0];Y(s.localId!==void 0,"internal-error");const i=s.providerUserInfo!==void 0?G_(s.providerUserInfo):[],o=!(s.email&&s.passwordHash)&&!(i!=null&&i.length),a=new zs;a.updateFromIdToken(n);const u=new en({uid:s.localId,auth:e,stsTokenManager:a,isAnonymous:o}),B={uid:s.localId,displayName:s.displayName||null,photoURL:s.photoUrl||null,email:s.email||null,emailVerified:s.emailVerified||!1,phoneNumber:s.phoneNumber||null,tenantId:s.tenantId||null,providerData:i,metadata:new ul(s.createdAt,s.lastLoginAt),isAnonymous:!(s.email&&s.passwordHash)&&!(i!=null&&i.length)};return Object.assign(u,B),u}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ip=new Map;function Rn(r){xn(r instanceof Function,"Expected a class definition");let e=ip.get(r);return e?(xn(e instanceof r,"Instance stored in cache mismatched with class"),e):(e=new r,ip.set(r,e),e)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U_{constructor(){this.type="NONE",this.storage={}}async _isAvailable(){return!0}async _set(e,t){this.storage[e]=t}async _get(e){const t=this.storage[e];return t===void 0?null:t}async _remove(e){delete this.storage[e]}_addListener(e,t){}_removeListener(e,t){}}U_.type="NONE";const op=U_;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function lu(r,e,t){return`firebase:${r}:${e}:${t}`}class rs{constructor(e,t,n){this.persistence=e,this.auth=t,this.userKey=n;const{config:s,name:i}=this.auth;this.fullUserKey=lu(this.userKey,s.apiKey,i),this.fullPersistenceKey=lu("persistence",s.apiKey,i),this.boundEventHandler=t._onStorageEvent.bind(t);try{this.persistence._addListener(this.fullUserKey,this.boundEventHandler)}catch{}}setCurrentUser(e){return this.persistence._set(this.fullUserKey,e.toJSON())}async getCurrentUser(){const e=await this.persistence._get(this.fullUserKey);if(!e)return null;if(typeof e=="string"){const t=await xu(this.auth,{idToken:e}).catch(()=>{});return t?en._fromGetAccountInfoResponse(this.auth,t,e):null}return en._fromJSON(this.auth,e)}removeCurrentUser(){return this.persistence._remove(this.fullUserKey)}savePersistenceForRedirect(){return this.persistence._set(this.fullPersistenceKey,this.persistence.type)}async setPersistence(e){if(this.persistence===e)return;const t=await this.getCurrentUser();if(await this.removeCurrentUser(),this.persistence=e,t)return this.setCurrentUser(t)}delete(){try{this.persistence._removeListener(this.fullUserKey,this.boundEventHandler)}catch{}}static async create(e,t,n="authUser"){if(!t.length)return new rs(Rn(op),e,n);const s=(await Promise.all(t.map(async B=>{try{if(await B._isAvailable())return B}catch{return}}))).filter(B=>B);let i=s[0]||Rn(op);const o=lu(n,e.config.apiKey,e.name);let a=null;for(const B of t)try{const l=await B._get(o);if(l){let d;if(typeof l=="string"){const C=await xu(e,{idToken:l}).catch(()=>{});if(!C)break;d=await en._fromGetAccountInfoResponse(e,C,l)}else d=en._fromJSON(e,l);B!==i&&(a=d),i=B;break}}catch{}const u=s.filter(B=>B._shouldAllowMigration);return!i._shouldAllowMigration||!u.length?new rs(i,e,n):(i=u[0],a&&await i._set(o,a.toJSON()),await Promise.all(t.map(async B=>{if(B!==i)try{await B._remove(o)}catch{}})),new rs(i,e,n))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ap(r){const e=r.toLowerCase();if(e.includes("opera/")||e.includes("opr/")||e.includes("opios/"))return"Opera";if(J_(e))return"IEMobile";if(e.includes("msie")||e.includes("trident/"))return"IE";if(e.includes("edge/"))return"Edge";if(H_(e))return"Firefox";if(e.includes("silk/"))return"Silk";if(z_(e))return"Blackberry";if(W_(e))return"Webos";if(q_(e))return"Safari";if((e.includes("chrome/")||j_(e))&&!e.includes("edge/"))return"Chrome";if(K_(e))return"Android";{const t=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,n=r.match(t);if((n==null?void 0:n.length)===2)return n[1]}return"Other"}function H_(r=Xe()){return/firefox\//i.test(r)}function q_(r=Xe()){const e=r.toLowerCase();return e.includes("safari/")&&!e.includes("chrome/")&&!e.includes("crios/")&&!e.includes("android")}function j_(r=Xe()){return/crios\//i.test(r)}function J_(r=Xe()){return/iemobile/i.test(r)}function K_(r=Xe()){return/android/i.test(r)}function z_(r=Xe()){return/blackberry/i.test(r)}function W_(r=Xe()){return/webos/i.test(r)}function Fh(r=Xe()){return/iphone|ipad|ipod/i.test(r)||/macintosh/i.test(r)&&/mobile/i.test(r)}function yP(r=Xe()){var e;return Fh(r)&&!!((e=window.navigator)!=null&&e.standalone)}function wP(){return GI()&&document.documentMode===10}function Q_(r=Xe()){return Fh(r)||K_(r)||W_(r)||z_(r)||/windows phone/i.test(r)||J_(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $_(r,e=[]){let t;switch(r){case"Browser":t=ap(Xe());break;case"Worker":t=`${ap(Xe())}-${r}`;break;default:t=r}const n=e.length?e.join(","):"FirebaseCore-web";return`${t}/JsCore/${ms}/${n}`}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class TP{constructor(e){this.auth=e,this.queue=[]}pushCallback(e,t){const n=i=>new Promise((o,a)=>{try{const u=e(i);o(u)}catch(u){a(u)}});n.onAbort=t,this.queue.push(n);const s=this.queue.length-1;return()=>{this.queue[s]=()=>Promise.resolve()}}async runMiddleware(e){if(this.auth.currentUser===e)return;const t=[];try{for(const n of this.queue)await n(e),n.onAbort&&t.push(n.onAbort)}catch(n){t.reverse();for(const s of t)try{s()}catch{}throw this.auth._errorFactory.create("login-blocked",{originalMessage:n==null?void 0:n.message})}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function AP(r,e={}){return tt(r,"GET","/v2/passwordPolicy",et(r,e))}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const RP=6;class vP{constructor(e){var n;const t=e.customStrengthOptions;this.customStrengthOptions={},this.customStrengthOptions.minPasswordLength=t.minPasswordLength??RP,t.maxPasswordLength&&(this.customStrengthOptions.maxPasswordLength=t.maxPasswordLength),t.containsLowercaseCharacter!==void 0&&(this.customStrengthOptions.containsLowercaseLetter=t.containsLowercaseCharacter),t.containsUppercaseCharacter!==void 0&&(this.customStrengthOptions.containsUppercaseLetter=t.containsUppercaseCharacter),t.containsNumericCharacter!==void 0&&(this.customStrengthOptions.containsNumericCharacter=t.containsNumericCharacter),t.containsNonAlphanumericCharacter!==void 0&&(this.customStrengthOptions.containsNonAlphanumericCharacter=t.containsNonAlphanumericCharacter),this.enforcementState=e.enforcementState,this.enforcementState==="ENFORCEMENT_STATE_UNSPECIFIED"&&(this.enforcementState="OFF"),this.allowedNonAlphanumericCharacters=((n=e.allowedNonAlphanumericCharacters)==null?void 0:n.join(""))??"",this.forceUpgradeOnSignin=e.forceUpgradeOnSignin??!1,this.schemaVersion=e.schemaVersion}validatePassword(e){const t={isValid:!0,passwordPolicy:this};return this.validatePasswordLengthOptions(e,t),this.validatePasswordCharacterOptions(e,t),t.isValid&&(t.isValid=t.meetsMinPasswordLength??!0),t.isValid&&(t.isValid=t.meetsMaxPasswordLength??!0),t.isValid&&(t.isValid=t.containsLowercaseLetter??!0),t.isValid&&(t.isValid=t.containsUppercaseLetter??!0),t.isValid&&(t.isValid=t.containsNumericCharacter??!0),t.isValid&&(t.isValid=t.containsNonAlphanumericCharacter??!0),t}validatePasswordLengthOptions(e,t){const n=this.customStrengthOptions.minPasswordLength,s=this.customStrengthOptions.maxPasswordLength;n&&(t.meetsMinPasswordLength=e.length>=n),s&&(t.meetsMaxPasswordLength=e.length<=s)}validatePasswordCharacterOptions(e,t){this.updatePasswordCharacterOptionsStatuses(t,!1,!1,!1,!1);let n;for(let s=0;s<e.length;s++)n=e.charAt(s),this.updatePasswordCharacterOptionsStatuses(t,n>="a"&&n<="z",n>="A"&&n<="Z",n>="0"&&n<="9",this.allowedNonAlphanumericCharacters.includes(n))}updatePasswordCharacterOptionsStatuses(e,t,n,s,i){this.customStrengthOptions.containsLowercaseLetter&&(e.containsLowercaseLetter||(e.containsLowercaseLetter=t)),this.customStrengthOptions.containsUppercaseLetter&&(e.containsUppercaseLetter||(e.containsUppercaseLetter=n)),this.customStrengthOptions.containsNumericCharacter&&(e.containsNumericCharacter||(e.containsNumericCharacter=s)),this.customStrengthOptions.containsNonAlphanumericCharacter&&(e.containsNonAlphanumericCharacter||(e.containsNonAlphanumericCharacter=i))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class PP{constructor(e,t,n,s){this.app=e,this.heartbeatServiceProvider=t,this.appCheckServiceProvider=n,this.config=s,this.currentUser=null,this.emulatorConfig=null,this.operations=Promise.resolve(),this.authStateSubscription=new up(this),this.idTokenSubscription=new up(this),this.beforeStateQueue=new TP(this),this.redirectUser=null,this.isProactiveRefreshEnabled=!1,this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION=1,this._canInitEmulator=!0,this._isInitialized=!1,this._deleted=!1,this._initializationPromise=null,this._popupRedirectResolver=null,this._errorFactory=F_,this._agentRecaptchaConfig=null,this._tenantRecaptchaConfigs={},this._projectPasswordPolicy=null,this._tenantPasswordPolicies={},this._resolvePersistenceManagerAvailable=void 0,this.lastNotifiedUid=void 0,this.languageCode=null,this.tenantId=null,this.settings={appVerificationDisabledForTesting:!1},this.frameworks=[],this.name=e.name,this.clientVersion=s.sdkClientVersion,this._persistenceManagerAvailable=new Promise(i=>this._resolvePersistenceManagerAvailable=i)}_initializeWithPersistence(e,t){return t&&(this._popupRedirectResolver=Rn(t)),this._initializationPromise=this.queue(async()=>{var n,s,i;if(!this._deleted){try{this.persistenceManager=await rs.create(this,e)}catch(o){cu(`Failed to initialize persistence: ${o}`),this.persistenceManager=await rs.create(this,[])}finally{(n=this._resolvePersistenceManagerAvailable)==null||n.call(this)}if(!this._deleted){if((s=this._popupRedirectResolver)!=null&&s._shouldInitProactively)try{await this._popupRedirectResolver._initialize(this)}catch{}try{await this.initializeCurrentUser(t)}catch(o){cu(`Failed to initialize current user: ${o}`),await this.directlySetCurrentUser(null).catch(()=>{})}this.lastNotifiedUid=((i=this.currentUser)==null?void 0:i.uid)||null,!this._deleted&&(this._isInitialized=!0)}}}),this._initializationPromise}async _onStorageEvent(){if(this._deleted)return;const e=await this.assertedPersistence.getCurrentUser();if(!(!this.currentUser&&!e)){if(this.currentUser&&e&&this.currentUser.uid===e.uid){this._currentUser._assign(e),await this.currentUser.getIdToken();return}await this._updateCurrentUser(e,!0)}}async initializeCurrentUserFromIdToken(e){try{const t=await xu(this,{idToken:e}),n=await en._fromGetAccountInfoResponse(this,t,e);await this.directlySetCurrentUser(n)}catch(t){console.warn("FirebaseServerApp could not login user with provided authIdToken: ",t),await this.directlySetCurrentUser(null)}}async initializeCurrentUser(e){var i;if(Ge(this.app)){const o=this.app.settings.authIdToken;return o?new Promise(a=>{setTimeout(()=>this.initializeCurrentUserFromIdToken(o).then(a,a))}):this.directlySetCurrentUser(null)}const t=await this.assertedPersistence.getCurrentUser();let n=t,s=!1;if(e&&this.config.authDomain){await this.getOrInitRedirectPersistenceManager();const o=(i=this.redirectUser)==null?void 0:i._redirectEventId,a=n==null?void 0:n._redirectEventId,u=await this.tryRedirectSignIn(e);(!o||o===a)&&(u!=null&&u.user)&&(n=u.user,s=!0)}if(!n)return this.directlySetCurrentUser(null);if(!n._redirectEventId){if(s)try{await this.beforeStateQueue.runMiddleware(n)}catch(o){n=t,this._popupRedirectResolver._overrideRedirectResult(this,()=>Promise.reject(o))}return n?this.reloadAndSetCurrentUserOrClear(n):this.directlySetCurrentUser(null)}return Y(this._popupRedirectResolver,this,"argument-error"),await this.getOrInitRedirectPersistenceManager(),this.redirectUser&&this.redirectUser._redirectEventId===n._redirectEventId?this.directlySetCurrentUser(n):this.reloadAndSetCurrentUserOrClear(n)}async tryRedirectSignIn(e){let t=null;try{t=await this._popupRedirectResolver._completeRedirectFn(this,e,!0)}catch{await this._setRedirectUser(null)}return t}async reloadAndSetCurrentUserOrClear(e){try{await Uo(e)}catch(t){if((t==null?void 0:t.code)!=="auth/network-request-failed")return this.directlySetCurrentUser(null)}return this.directlySetCurrentUser(e)}useDeviceLanguage(){this.languageCode=aP()}async _delete(){this._deleted=!0}async updateCurrentUser(e){if(Ge(this.app))return Promise.reject(Tt(this));const t=e?re(e):null;return t&&Y(t.auth.config.apiKey===this.config.apiKey,this,"invalid-user-token"),this._updateCurrentUser(t&&t._clone(this))}async _updateCurrentUser(e,t=!1){if(!this._deleted)return e&&Y(this.tenantId===e.tenantId,this,"tenant-id-mismatch"),t||await this.beforeStateQueue.runMiddleware(e),this.queue(async()=>{await this.directlySetCurrentUser(e),this.notifyAuthListeners()})}async signOut(){return Ge(this.app)?Promise.reject(Tt(this)):(await this.beforeStateQueue.runMiddleware(null),(this.redirectPersistenceManager||this._popupRedirectResolver)&&await this._setRedirectUser(null),this._updateCurrentUser(null,!0))}setPersistence(e){return Ge(this.app)?Promise.reject(Tt(this)):this.queue(async()=>{await this.assertedPersistence.setPersistence(Rn(e))})}_getRecaptchaConfig(){return this.tenantId==null?this._agentRecaptchaConfig:this._tenantRecaptchaConfigs[this.tenantId]}async validatePassword(e){this._getPasswordPolicyInternal()||await this._updatePasswordPolicy();const t=this._getPasswordPolicyInternal();return t.schemaVersion!==this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION?Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version",{})):t.validatePassword(e)}_getPasswordPolicyInternal(){return this.tenantId===null?this._projectPasswordPolicy:this._tenantPasswordPolicies[this.tenantId]}async _updatePasswordPolicy(){const e=await AP(this),t=new vP(e);this.tenantId===null?this._projectPasswordPolicy=t:this._tenantPasswordPolicies[this.tenantId]=t}_getPersistenceType(){return this.assertedPersistence.persistence.type}_getPersistence(){return this.assertedPersistence.persistence}_updateErrorMap(e){this._errorFactory=new qo("auth","Firebase",e())}onAuthStateChanged(e,t,n){return this.registerStateListener(this.authStateSubscription,e,t,n)}beforeAuthStateChanged(e,t){return this.beforeStateQueue.pushCallback(e,t)}onIdTokenChanged(e,t,n){return this.registerStateListener(this.idTokenSubscription,e,t,n)}authStateReady(){return new Promise((e,t)=>{if(this.currentUser)e();else{const n=this.onAuthStateChanged(()=>{n(),e()},t)}})}async revokeAccessToken(e){if(this.currentUser){const t=await this.currentUser.getIdToken(),n={providerId:"apple.com",tokenType:"ACCESS_TOKEN",token:e,idToken:t};this.tenantId!=null&&(n.tenantId=this.tenantId),await DP(this,n)}}toJSON(){var e;return{apiKey:this.config.apiKey,authDomain:this.config.authDomain,appName:this.name,currentUser:(e=this._currentUser)==null?void 0:e.toJSON()}}async _setRedirectUser(e,t){const n=await this.getOrInitRedirectPersistenceManager(t);return e===null?n.removeCurrentUser():n.setCurrentUser(e)}async getOrInitRedirectPersistenceManager(e){if(!this.redirectPersistenceManager){const t=e&&Rn(e)||this._popupRedirectResolver;Y(t,this,"argument-error"),this.redirectPersistenceManager=await rs.create(this,[Rn(t._redirectPersistence)],"redirectUser"),this.redirectUser=await this.redirectPersistenceManager.getCurrentUser()}return this.redirectPersistenceManager}async _redirectUserForId(e){var t,n;return this._isInitialized&&await this.queue(async()=>{}),((t=this._currentUser)==null?void 0:t._redirectEventId)===e?this._currentUser:((n=this.redirectUser)==null?void 0:n._redirectEventId)===e?this.redirectUser:null}async _persistUserIfCurrent(e){if(e===this.currentUser)return this.queue(async()=>this.directlySetCurrentUser(e))}_notifyListenersIfCurrent(e){e===this.currentUser&&this.notifyAuthListeners()}_key(){return`${this.config.authDomain}:${this.config.apiKey}:${this.name}`}_startProactiveRefresh(){this.isProactiveRefreshEnabled=!0,this.currentUser&&this._currentUser._startProactiveRefresh()}_stopProactiveRefresh(){this.isProactiveRefreshEnabled=!1,this.currentUser&&this._currentUser._stopProactiveRefresh()}get _currentUser(){return this.currentUser}notifyAuthListeners(){var t;if(!this._isInitialized)return;this.idTokenSubscription.next(this.currentUser);const e=((t=this.currentUser)==null?void 0:t.uid)??null;this.lastNotifiedUid!==e&&(this.lastNotifiedUid=e,this.authStateSubscription.next(this.currentUser))}registerStateListener(e,t,n,s){if(this._deleted)return()=>{};const i=typeof t=="function"?t:t.next.bind(t);let o=!1;const a=this._isInitialized?Promise.resolve():this._initializationPromise;if(Y(a,this,"internal-error"),a.then(()=>{o||i(this.currentUser)}).catch(u=>{if(!o)if(typeof t!="function"&&t.error)t.error(u);else if(n)n(u);else throw u}),typeof t=="function"){const u=e.addObserver(t,n,s);return()=>{o=!0,u()}}else{const u=e.addObserver(t);return()=>{o=!0,u()}}}async directlySetCurrentUser(e){if(this.currentUser&&this.currentUser!==e&&this._currentUser._stopProactiveRefresh(),e&&this.isProactiveRefreshEnabled&&e._startProactiveRefresh(),this.currentUser=e,this.persistenceManager)try{e?await this.persistenceManager.setCurrentUser(e):await this.persistenceManager.removeCurrentUser()}catch(t){const n=(t==null?void 0:t.message)||String(t),s=mc(this,"internal-error",`An internal AuthError has occurred: ${n}`);throw s.customData={originalError:t},s}}queue(e){return this.operations=this.operations.then(e,e),this.operations}get assertedPersistence(){return Y(this.persistenceManager,this,"internal-error"),this.persistenceManager}_logFramework(e){!e||this.frameworks.includes(e)||(this.frameworks.push(e),this.frameworks.sort(),this.clientVersion=$_(this.config.clientPlatform,this._getFrameworks()))}_getFrameworks(){return this.frameworks}async _getAdditionalHeaders(){var s;const e={"X-Client-Version":this.clientVersion};this.app.options.appId&&(e["X-Firebase-gmpid"]=this.app.options.appId);const t=await((s=this.heartbeatServiceProvider.getImmediate({optional:!0}))==null?void 0:s.getHeartbeatsHeader());t&&(e["X-Firebase-Client"]=t);const n=await this._getAppCheckToken();return n&&(e["X-Firebase-AppCheck"]=n),e}async _getAppCheckToken(){var t;if(Ge(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=await((t=this.appCheckServiceProvider.getImmediate({optional:!0}))==null?void 0:t.getToken());return e!=null&&e.error&&cu(`Error while retrieving App Check token: ${e.error}`),e==null?void 0:e.token}}function ot(r){return re(r)}class up{constructor(e){this.auth=e,this.observer=null,this.addObserver=JI(t=>this.observer=t)}get next(){return Y(this.observer,this.auth,"internal-error"),this.observer.next.bind(this.observer)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let da={async loadJS(){throw new Error("Unable to load external scripts")},recaptchaV2Script:"",recaptchaEnterpriseScript:"",gapiScript:""};function bP(r){da=r}function Lh(r){return da.loadJS(r)}function SP(){return da.recaptchaV2Script}function OP(){return da.recaptchaEnterpriseScript}function NP(){return da.gapiScript}function Y_(r){return`__${r}${Math.floor(Math.random()*1e6)}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const FP=500,LP=6e4,za=1e12;class kP{constructor(e){this.auth=e,this.counter=za,this._widgets=new Map}render(e,t){const n=this.counter;return this._widgets.set(n,new MP(e,this.auth.name,t||{})),this.counter++,n}reset(e){var n;const t=e||za;(n=this._widgets.get(t))==null||n.delete(),this._widgets.delete(t)}getResponse(e){var n;const t=e||za;return((n=this._widgets.get(t))==null?void 0:n.getResponse())||""}async execute(e){var n;const t=e||za;return(n=this._widgets.get(t))==null||n.execute(),""}}class xP{constructor(){this.enterprise=new VP}ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}class VP{ready(e){e()}execute(e,t){return Promise.resolve("token")}render(e,t){return""}}class MP{constructor(e,t,n){this.params=n,this.timerId=null,this.deleted=!1,this.responseToken=null,this.clickHandler=()=>{this.execute()};const s=typeof e=="string"?document.getElementById(e):e;Y(s,"argument-error",{appName:t}),this.container=s,this.isVisible=this.params.size!=="invisible",this.isVisible?this.execute():this.container.addEventListener("click",this.clickHandler)}getResponse(){return this.checkIfDeleted(),this.responseToken}delete(){this.checkIfDeleted(),this.deleted=!0,this.timerId&&(clearTimeout(this.timerId),this.timerId=null),this.container.removeEventListener("click",this.clickHandler)}execute(){this.checkIfDeleted(),!this.timerId&&(this.timerId=window.setTimeout(()=>{this.responseToken=GP(50);const{callback:e,"expired-callback":t}=this.params;if(e)try{e(this.responseToken)}catch{}this.timerId=window.setTimeout(()=>{if(this.timerId=null,this.responseToken=null,t)try{t()}catch{}this.isVisible&&this.execute()},LP)},FP))}checkIfDeleted(){if(this.deleted)throw new Error("reCAPTCHA mock was already deleted!")}}function GP(r){const e=[],t="1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";for(let n=0;n<r;n++)e.push(t.charAt(Math.floor(Math.random()*t.length)));return e.join("")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const UP="recaptcha-enterprise",fo="NO_RECAPTCHA",cp="onFirebaseAuthREInstanceReady";class wn{constructor(e){this.type=UP,this.auth=ot(e)}async verify(e="verify",t=!1){async function n(i){if(!t){if(i.tenantId==null&&i._agentRecaptchaConfig!=null)return i._agentRecaptchaConfig.siteKey;if(i.tenantId!=null&&i._tenantRecaptchaConfigs[i.tenantId]!==void 0)return i._tenantRecaptchaConfigs[i.tenantId].siteKey}return new Promise(async(o,a)=>{M_(i,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}).then(u=>{if(u.recaptchaKey===void 0)a(new Error("recaptcha Enterprise site key undefined"));else{const B=new V_(u);return i.tenantId==null?i._agentRecaptchaConfig=B:i._tenantRecaptchaConfigs[i.tenantId]=B,o(B.siteKey)}}).catch(u=>{a(u)})})}function s(i,o,a){const u=window.grecaptcha;rp(u)?u.enterprise.ready(()=>{u.enterprise.execute(i,{action:e}).then(B=>{o(B)}).catch(()=>{o(fo)})}):a(Error("No reCAPTCHA enterprise script loaded."))}return this.auth.settings.appVerificationDisabledForTesting?new xP().execute("siteKey",{action:"verify"}):new Promise((i,o)=>{n(this.auth).then(async a=>{if(!t&&rp(window.grecaptcha)&&wn.scriptInjectionDeferred)await wn.scriptInjectionDeferred.promise,s(a,i,o);else{if(typeof window>"u"){o(new Error("RecaptchaVerifier is only supported in browser"));return}let u=OP();u.length!==0&&(u+=a+`&onload=${cp}`),wn.scriptInjectionDeferred=new Mp,window[cp]=()=>{var B;(B=wn.scriptInjectionDeferred)==null||B.resolve()},Lh(u).then(()=>{var B;return(B=wn.scriptInjectionDeferred)==null?void 0:B.promise}).then(()=>{s(a,i,o)}).catch(B=>{o(B)})}}).catch(a=>{o(a)})})}}wn.scriptInjectionDeferred=null;async function Ki(r,e,t,n=!1,s=!1){const i=new wn(r);let o;if(s)o=fo;else try{o=await i.verify(t)}catch{o=await i.verify(t,!0)}const a={...e};if(t==="mfaSmsEnrollment"||t==="mfaSmsSignIn"){if("phoneEnrollmentInfo"in a){const u=a.phoneEnrollmentInfo.phoneNumber,B=a.phoneEnrollmentInfo.recaptchaToken;Object.assign(a,{phoneEnrollmentInfo:{phoneNumber:u,recaptchaToken:B,captchaResponse:o,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}else if("phoneSignInInfo"in a){const u=a.phoneSignInInfo.recaptchaToken;Object.assign(a,{phoneSignInInfo:{recaptchaToken:u,captchaResponse:o,clientType:"CLIENT_TYPE_WEB",recaptchaVersion:"RECAPTCHA_ENTERPRISE"}})}return a}return n?Object.assign(a,{captchaResp:o}):Object.assign(a,{captchaResponse:o}),Object.assign(a,{clientType:"CLIENT_TYPE_WEB"}),Object.assign(a,{recaptchaVersion:"RECAPTCHA_ENTERPRISE"}),a}async function _r(r,e,t,n,s){var i,o;if(s==="EMAIL_PASSWORD_PROVIDER")if((i=r._getRecaptchaConfig())!=null&&i.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")){const a=await Ki(r,e,t,t==="getOobCode");return n(r,a)}else return n(r,e).catch(async a=>{if(a.code==="auth/missing-recaptcha-token"){console.log(`${t} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`);const u=await Ki(r,e,t,t==="getOobCode");return n(r,u)}else return Promise.reject(a)});else if(s==="PHONE_PROVIDER")if((o=r._getRecaptchaConfig())!=null&&o.isProviderEnabled("PHONE_PROVIDER")){const a=await Ki(r,e,t);return n(r,a).catch(async u=>{var B;if(((B=r._getRecaptchaConfig())==null?void 0:B.getProviderEnforcementState("PHONE_PROVIDER"))==="AUDIT"&&(u.code==="auth/missing-recaptcha-token"||u.code==="auth/invalid-app-credential")){console.log(`Failed to verify with reCAPTCHA Enterprise. Automatically triggering the reCAPTCHA v2 flow to complete the ${t} flow.`);const l=await Ki(r,e,t,!1,!0);return n(r,l)}return Promise.reject(u)})}else{const a=await Ki(r,e,t,!1,!0);return n(r,a)}else return Promise.reject(s+" provider is not supported.")}async function HP(r){const e=ot(r),t=await M_(e,{clientType:"CLIENT_TYPE_WEB",version:"RECAPTCHA_ENTERPRISE"}),n=new V_(t);e.tenantId==null?e._agentRecaptchaConfig=n:e._tenantRecaptchaConfigs[e.tenantId]=n,n.isAnyProviderEnabled()&&new wn(e).verify()}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qP(r,e){const t=jo(r,"auth");if(t.isInitialized()){const s=t.getImmediate(),i=t.getOptions();if(pn(i,e??{}))return s;Qt(s,"already-initialized")}return t.initialize({options:e})}function jP(r,e){const t=(e==null?void 0:e.persistence)||[],n=(Array.isArray(t)?t:[t]).map(Rn);e!=null&&e.errorMap&&r._updateErrorMap(e.errorMap),r._initializeWithPersistence(n,e==null?void 0:e.popupRedirectResolver)}function JP(r,e,t){const n=ot(r);Y(/^https?:\/\//.test(e),n,"invalid-emulator-scheme");const s=!1,i=X_(e),{host:o,port:a}=KP(e),u=a===null?"":`:${a}`,B={url:`${i}//${o}${u}/`},l=Object.freeze({host:o,port:a,protocol:i.replace(":",""),options:Object.freeze({disableWarnings:s})});if(!n._canInitEmulator){Y(n.config.emulator&&n.emulatorConfig,n,"emulator-config-failed"),Y(pn(B,n.config.emulator)&&pn(l,n.emulatorConfig),n,"emulator-config-failed");return}n.config.emulator=B,n.emulatorConfig=l,n.settings.appVerificationDisabledForTesting=!0,vr(o)?ju(`${i}//${o}${u}`):zP()}function X_(r){const e=r.indexOf(":");return e<0?"":r.substr(0,e+1)}function KP(r){const e=X_(r),t=/(\/\/)?([^?#/]+)/.exec(r.substr(e.length));if(!t)return{host:"",port:null};const n=t[2].split("@").pop()||"",s=/^(\[[^\]]+\])(:|$)/.exec(n);if(s){const i=s[1];return{host:i,port:Bp(n.substr(i.length+1))}}else{const[i,o]=n.split(":");return{host:i,port:Bp(o)}}}function Bp(r){if(!r)return null;const e=Number(r);return isNaN(e)?null:e}function zP(){function r(){const e=document.createElement("p"),t=e.style;e.innerText="Running in emulator mode. Do not use with production credentials.",t.position="fixed",t.width="100%",t.backgroundColor="#ffffff",t.border=".1em solid #000000",t.color="#b50000",t.bottom="0px",t.left="0px",t.margin="0px",t.zIndex="10000",t.textAlign="center",e.classList.add("firebase-emulator-warning"),document.body.appendChild(e)}typeof console<"u"&&typeof console.info=="function"&&console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."),typeof window<"u"&&typeof document<"u"&&(document.readyState==="loading"?window.addEventListener("DOMContentLoaded",r):r())}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ec{constructor(e,t){this.providerId=e,this.signInMethod=t}toJSON(){return An("not implemented")}_getIdTokenResponse(e){return An("not implemented")}_linkToIdToken(e,t){return An("not implemented")}_getReauthenticationResolver(e){return An("not implemented")}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function WP(r,e){return tt(r,"POST","/v1/accounts:resetPassword",et(r,e))}async function QP(r,e){return tt(r,"POST","/v1/accounts:update",e)}async function $P(r,e){return tt(r,"POST","/v1/accounts:signUp",e)}async function YP(r,e){return tt(r,"POST","/v1/accounts:update",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function XP(r,e){return Un(r,"POST","/v1/accounts:signInWithPassword",et(r,e))}async function Ic(r,e){return tt(r,"POST","/v1/accounts:sendOobCode",et(r,e))}async function ZP(r,e){return Ic(r,e)}async function eb(r,e){return Ic(r,e)}async function tb(r,e){return Ic(r,e)}async function nb(r,e){return Ic(r,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function rb(r,e){return Un(r,"POST","/v1/accounts:signInWithEmailLink",et(r,e))}async function sb(r,e){return Un(r,"POST","/v1/accounts:signInWithEmailLink",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ho extends Ec{constructor(e,t,n,s=null){super("password",n),this._email=e,this._password=t,this._tenantId=s}static _fromEmailAndPassword(e,t){return new Ho(e,t,"password")}static _fromEmailAndCode(e,t,n=null){return new Ho(e,t,"emailLink",n)}toJSON(){return{email:this._email,password:this._password,signInMethod:this.signInMethod,tenantId:this._tenantId}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;if(t!=null&&t.email&&(t!=null&&t.password)){if(t.signInMethod==="password")return this._fromEmailAndPassword(t.email,t.password);if(t.signInMethod==="emailLink")return this._fromEmailAndCode(t.email,t.password,t.tenantId)}return null}async _getIdTokenResponse(e){switch(this.signInMethod){case"password":const t={returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return _r(e,t,"signInWithPassword",XP,"EMAIL_PASSWORD_PROVIDER");case"emailLink":return rb(e,{email:this._email,oobCode:this._password});default:Qt(e,"internal-error")}}async _linkToIdToken(e,t){switch(this.signInMethod){case"password":const n={idToken:t,returnSecureToken:!0,email:this._email,password:this._password,clientType:"CLIENT_TYPE_WEB"};return _r(e,n,"signUpPassword",$P,"EMAIL_PASSWORD_PROVIDER");case"emailLink":return sb(e,{idToken:t,email:this._email,oobCode:this._password});default:Qt(e,"internal-error")}}_getReauthenticationResolver(e){return this._getIdTokenResponse(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ws(r,e){return Un(r,"POST","/v1/accounts:signInWithIdp",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ib="http://localhost";class Vn extends Ec{constructor(){super(...arguments),this.pendingToken=null}static _fromParams(e){const t=new Vn(e.providerId,e.signInMethod);return e.idToken||e.accessToken?(e.idToken&&(t.idToken=e.idToken),e.accessToken&&(t.accessToken=e.accessToken),e.nonce&&!e.pendingToken&&(t.nonce=e.nonce),e.pendingToken&&(t.pendingToken=e.pendingToken)):e.oauthToken&&e.oauthTokenSecret?(t.accessToken=e.oauthToken,t.secret=e.oauthTokenSecret):Qt("argument-error"),t}toJSON(){return{idToken:this.idToken,accessToken:this.accessToken,secret:this.secret,nonce:this.nonce,pendingToken:this.pendingToken,providerId:this.providerId,signInMethod:this.signInMethod}}static fromJSON(e){const t=typeof e=="string"?JSON.parse(e):e,{providerId:n,signInMethod:s,...i}=t;if(!n||!s)return null;const o=new Vn(n,s);return o.idToken=i.idToken||void 0,o.accessToken=i.accessToken||void 0,o.secret=i.secret,o.nonce=i.nonce,o.pendingToken=i.pendingToken||null,o}_getIdTokenResponse(e){const t=this.buildRequest();return Ws(e,t)}_linkToIdToken(e,t){const n=this.buildRequest();return n.idToken=t,Ws(e,n)}_getReauthenticationResolver(e){const t=this.buildRequest();return t.autoCreate=!1,Ws(e,t)}buildRequest(){const e={requestUri:ib,returnSecureToken:!0};if(this.pendingToken)e.pendingToken=this.pendingToken;else{const t={};this.idToken&&(t.id_token=this.idToken),this.accessToken&&(t.access_token=this.accessToken),this.secret&&(t.oauth_token_secret=this.secret),t.providerId=this.providerId,this.nonce&&!this.pendingToken&&(t.nonce=this.nonce),e.postBody=ci(t)}return e}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function lp(r,e){return tt(r,"POST","/v1/accounts:sendVerificationCode",et(r,e))}async function ob(r,e){return Un(r,"POST","/v1/accounts:signInWithPhoneNumber",et(r,e))}async function ab(r,e){const t=await Un(r,"POST","/v1/accounts:signInWithPhoneNumber",et(r,e));if(t.temporaryProof)throw eo(r,"account-exists-with-different-credential",t);return t}const ub={USER_NOT_FOUND:"user-not-found"};async function cb(r,e){const t={...e,operation:"REAUTH"};return Un(r,"POST","/v1/accounts:signInWithPhoneNumber",et(r,t),ub)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Co extends Ec{constructor(e){super("phone","phone"),this.params=e}static _fromVerification(e,t){return new Co({verificationId:e,verificationCode:t})}static _fromTokenResponse(e,t){return new Co({phoneNumber:e,temporaryProof:t})}_getIdTokenResponse(e){return ob(e,this._makeVerificationRequest())}_linkToIdToken(e,t){return ab(e,{idToken:t,...this._makeVerificationRequest()})}_getReauthenticationResolver(e){return cb(e,this._makeVerificationRequest())}_makeVerificationRequest(){const{temporaryProof:e,phoneNumber:t,verificationId:n,verificationCode:s}=this.params;return e&&t?{temporaryProof:e,phoneNumber:t}:{sessionInfo:n,code:s}}toJSON(){const e={providerId:this.providerId};return this.params.phoneNumber&&(e.phoneNumber=this.params.phoneNumber),this.params.temporaryProof&&(e.temporaryProof=this.params.temporaryProof),this.params.verificationCode&&(e.verificationCode=this.params.verificationCode),this.params.verificationId&&(e.verificationId=this.params.verificationId),e}static fromJSON(e){typeof e=="string"&&(e=JSON.parse(e));const{verificationId:t,verificationCode:n,phoneNumber:s,temporaryProof:i}=e;return!n&&!t&&!s&&!i?null:new Co({verificationId:t,verificationCode:n,phoneNumber:s,temporaryProof:i})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bb(r){switch(r){case"recoverEmail":return"RECOVER_EMAIL";case"resetPassword":return"PASSWORD_RESET";case"signIn":return"EMAIL_SIGNIN";case"verifyEmail":return"VERIFY_EMAIL";case"verifyAndChangeEmail":return"VERIFY_AND_CHANGE_EMAIL";case"revertSecondFactorAddition":return"REVERT_SECOND_FACTOR_ADDITION";default:return null}}function lb(r){const e=Wi(Qi(r)).link,t=e?Wi(Qi(e)).deep_link_id:null,n=Wi(Qi(r)).deep_link_id;return(n?Wi(Qi(n)).link:null)||n||t||e||r}class Dc{constructor(e){const t=Wi(Qi(e)),n=t.apiKey??null,s=t.oobCode??null,i=Bb(t.mode??null);Y(n&&s&&i,"argument-error"),this.apiKey=n,this.operation=i,this.code=s,this.continueUrl=t.continueUrl??null,this.languageCode=t.lang??null,this.tenantId=t.tenantId??null}static parseLink(e){const t=lb(e);try{return new Dc(t)}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ts{constructor(){this.providerId=Ts.PROVIDER_ID}static credential(e,t){return Ho._fromEmailAndPassword(e,t)}static credentialWithLink(e,t){const n=Dc.parseLink(t);return Y(n,"argument-error"),Ho._fromEmailAndCode(e,n.code,n.tenantId)}}Ts.PROVIDER_ID="password";Ts.EMAIL_PASSWORD_SIGN_IN_METHOD="password";Ts.EMAIL_LINK_SIGN_IN_METHOD="emailLink";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class As{constructor(e){this.providerId=e,this.defaultLanguageCode=null,this.customParameters={}}setDefaultLanguage(e){this.defaultLanguageCode=e}setCustomParameters(e){return this.customParameters=e,this}getCustomParameters(){return this.customParameters}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ei extends As{constructor(){super(...arguments),this.scopes=[]}addScope(e){return this.scopes.includes(e)||this.scopes.push(e),this}getScopes(){return[...this.scopes]}}class hu extends Ei{static credentialFromJSON(e){const t=typeof e=="string"?JSON.parse(e):e;return Y("providerId"in t&&"signInMethod"in t,"argument-error"),Vn._fromParams(t)}credential(e){return this._credential({...e,nonce:e.rawNonce})}_credential(e){return Y(e.idToken||e.accessToken,"argument-error"),Vn._fromParams({...e,providerId:this.providerId,signInMethod:this.providerId})}static credentialFromResult(e){return hu.oauthCredentialFromTaggedObject(e)}static credentialFromError(e){return hu.oauthCredentialFromTaggedObject(e.customData||{})}static oauthCredentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:n,oauthTokenSecret:s,pendingToken:i,nonce:o,providerId:a}=e;if(!n&&!s&&!t&&!i||!a)return null;try{return new hu(a)._credential({idToken:t,accessToken:n,nonce:o,pendingToken:i})}catch{return null}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sr extends Ei{constructor(){super("facebook.com")}static credential(e){return Vn._fromParams({providerId:sr.PROVIDER_ID,signInMethod:sr.FACEBOOK_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return sr.credentialFromTaggedObject(e)}static credentialFromError(e){return sr.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return sr.credential(e.oauthAccessToken)}catch{return null}}}sr.FACEBOOK_SIGN_IN_METHOD="facebook.com";sr.PROVIDER_ID="facebook.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ir extends Ei{constructor(){super("google.com"),this.addScope("profile")}static credential(e,t){return Vn._fromParams({providerId:ir.PROVIDER_ID,signInMethod:ir.GOOGLE_SIGN_IN_METHOD,idToken:e,accessToken:t})}static credentialFromResult(e){return ir.credentialFromTaggedObject(e)}static credentialFromError(e){return ir.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthIdToken:t,oauthAccessToken:n}=e;if(!t&&!n)return null;try{return ir.credential(t,n)}catch{return null}}}ir.GOOGLE_SIGN_IN_METHOD="google.com";ir.PROVIDER_ID="google.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class or extends Ei{constructor(){super("github.com")}static credential(e){return Vn._fromParams({providerId:or.PROVIDER_ID,signInMethod:or.GITHUB_SIGN_IN_METHOD,accessToken:e})}static credentialFromResult(e){return or.credentialFromTaggedObject(e)}static credentialFromError(e){return or.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e||!("oauthAccessToken"in e)||!e.oauthAccessToken)return null;try{return or.credential(e.oauthAccessToken)}catch{return null}}}or.GITHUB_SIGN_IN_METHOD="github.com";or.PROVIDER_ID="github.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ar extends Ei{constructor(){super("twitter.com")}static credential(e,t){return Vn._fromParams({providerId:ar.PROVIDER_ID,signInMethod:ar.TWITTER_SIGN_IN_METHOD,oauthToken:e,oauthTokenSecret:t})}static credentialFromResult(e){return ar.credentialFromTaggedObject(e)}static credentialFromError(e){return ar.credentialFromTaggedObject(e.customData||{})}static credentialFromTaggedObject({_tokenResponse:e}){if(!e)return null;const{oauthAccessToken:t,oauthTokenSecret:n}=e;if(!t||!n)return null;try{return ar.credential(t,n)}catch{return null}}}ar.TWITTER_SIGN_IN_METHOD="twitter.com";ar.PROVIDER_ID="twitter.com";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Z_(r,e){return Un(r,"POST","/v1/accounts:signUp",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class En{constructor(e){this.user=e.user,this.providerId=e.providerId,this._tokenResponse=e._tokenResponse,this.operationType=e.operationType}static async _fromIdTokenResponse(e,t,n,s=!1){const i=await en._fromIdTokenResponse(e,n,s),o=hp(n);return new En({user:i,providerId:o,_tokenResponse:n,operationType:t})}static async _forOperation(e,t,n){await e._updateTokensIfNecessary(n,!0);const s=hp(n);return new En({user:e,providerId:s,_tokenResponse:n,operationType:t})}}function hp(r){return r.providerId?r.providerId:"phoneNumber"in r?"phone":null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ZO(r){var s;if(Ge(r.app))return Promise.reject(Tt(r));const e=ot(r);if(await e._initializationPromise,(s=e.currentUser)!=null&&s.isAnonymous)return new En({user:e.currentUser,providerId:null,operationType:"signIn"});const t=await Z_(e,{returnSecureToken:!0}),n=await En._fromIdTokenResponse(e,"signIn",t,!0);return await e._updateCurrentUser(n.user),n}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vu extends In{constructor(e,t,n,s){super(t.code,t.message),this.operationType=n,this.user=s,Object.setPrototypeOf(this,Vu.prototype),this.customData={appName:e.name,tenantId:e.tenantId??void 0,_serverResponse:t.customData._serverResponse,operationType:n}}static _fromErrorAndOperation(e,t,n,s){return new Vu(e,t,n,s)}}function eE(r,e,t,n){return(e==="reauthenticate"?t._getReauthenticationResolver(r):t._getIdTokenResponse(r)).catch(i=>{throw i.code==="auth/multi-factor-auth-required"?Vu._fromErrorAndOperation(r,i,e,n):i})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function tE(r){return new Set(r.map(({providerId:e})=>e).filter(e=>!!e))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function eN(r,e){const t=re(r);await yc(!0,t,e);const{providerUserInfo:n}=await CP(t.auth,{idToken:await t.getIdToken(),deleteProvider:[e]}),s=tE(n||[]);return t.providerData=t.providerData.filter(i=>s.has(i.providerId)),s.has("phone")||(t.phoneNumber=null),await t.auth._persistUserIfCurrent(t),t}async function nE(r,e,t=!1){const n=await ps(r,e._linkToIdToken(r.auth,await r.getIdToken()),t);return En._forOperation(r,"link",n)}async function yc(r,e,t){await Uo(e);const n=tE(e.providerData),s=r===!1?"provider-already-linked":"no-such-provider";Y(n.has(t)===r,e.auth,s)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function rE(r,e,t=!1){const{auth:n}=r;if(Ge(n.app))return Promise.reject(Tt(n));const s="reauthenticate";try{const i=await ps(r,eE(n,s,e,r),t);Y(i.idToken,n,"internal-error");const o=_c(i.idToken);Y(o,n,"internal-error");const{sub:a}=o;return Y(r.uid===a,n,"user-mismatch"),En._forOperation(r,s,i)}catch(i){throw(i==null?void 0:i.code)==="auth/user-not-found"&&Qt(n,"user-mismatch"),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sE(r,e,t=!1){if(Ge(r.app))return Promise.reject(Tt(r));const n="signIn",s=await eE(r,n,e),i=await En._fromIdTokenResponse(r,n,s);return t||await r._updateCurrentUser(i.user),i}async function kh(r,e){return sE(ot(r),e)}async function hb(r,e){const t=re(r);return await yc(!1,t,e.providerId),nE(t,e)}async function tN(r,e){return rE(re(r),e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function db(r,e){return Un(r,"POST","/v1/accounts:signInWithCustomToken",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function nN(r,e){if(Ge(r.app))return Promise.reject(Tt(r));const t=ot(r),n=await db(t,{token:e,returnSecureToken:!0}),s=await En._fromIdTokenResponse(t,"signIn",n);return await t._updateCurrentUser(s.user),s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wc(r,e,t){var n;Y(((n=t.url)==null?void 0:n.length)>0,r,"invalid-continue-uri"),Y(typeof t.dynamicLinkDomain>"u"||t.dynamicLinkDomain.length>0,r,"invalid-dynamic-link-domain"),Y(typeof t.linkDomain>"u"||t.linkDomain.length>0,r,"invalid-hosting-link-domain"),e.continueUrl=t.url,e.dynamicLinkDomain=t.dynamicLinkDomain,e.linkDomain=t.linkDomain,e.canHandleCodeInApp=t.handleCodeInApp,t.iOS&&(Y(t.iOS.bundleId.length>0,r,"missing-ios-bundle-id"),e.iOSBundleId=t.iOS.bundleId),t.android&&(Y(t.android.packageName.length>0,r,"missing-android-pkg-name"),e.androidInstallApp=t.android.installApp,e.androidMinimumVersionCode=t.android.minimumVersion,e.androidPackageName=t.android.packageName)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function xh(r){const e=ot(r);e._getPasswordPolicyInternal()&&await e._updatePasswordPolicy()}async function rN(r,e,t){const n=ot(r),s={requestType:"PASSWORD_RESET",email:e,clientType:"CLIENT_TYPE_WEB"};t&&wc(n,s,t),await _r(n,s,"getOobCode",eb,"EMAIL_PASSWORD_PROVIDER")}async function sN(r,e,t){await WP(re(r),{oobCode:e,newPassword:t}).catch(async n=>{throw n.code==="auth/password-does-not-meet-requirements"&&xh(r),n})}async function iN(r,e){await YP(re(r),{oobCode:e})}async function oN(r,e,t){if(Ge(r.app))return Promise.reject(Tt(r));const n=ot(r),o=await _r(n,{returnSecureToken:!0,email:e,password:t,clientType:"CLIENT_TYPE_WEB"},"signUpPassword",Z_,"EMAIL_PASSWORD_PROVIDER").catch(u=>{throw u.code==="auth/password-does-not-meet-requirements"&&xh(r),u}),a=await En._fromIdTokenResponse(n,"signIn",o);return await n._updateCurrentUser(a.user),a}function aN(r,e,t){return Ge(r.app)?Promise.reject(Tt(r)):kh(re(r),Ts.credential(e,t)).catch(async n=>{throw n.code==="auth/password-does-not-meet-requirements"&&xh(r),n})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function uN(r,e,t){const n=ot(r),s={requestType:"EMAIL_SIGNIN",email:e,clientType:"CLIENT_TYPE_WEB"};function i(o,a){Y(a.handleCodeInApp,n,"argument-error"),a&&wc(n,o,a)}i(s,t),await _r(n,s,"getOobCode",tb,"EMAIL_PASSWORD_PROVIDER")}function cN(r,e){const t=Dc.parseLink(e);return(t==null?void 0:t.operation)==="EMAIL_SIGNIN"}async function BN(r,e,t){if(Ge(r.app))return Promise.reject(Tt(r));const n=re(r),s=Ts.credentialWithLink(e,t||Go());return Y(s._tenantId===(n.tenantId||null),n,"tenant-id-mismatch"),kh(n,s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fb(r,e){return tt(r,"POST","/v1/accounts:createAuthUri",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function lN(r,e){const t=Oh()?Go():"http://localhost",n={identifier:e,continueUri:t},{signinMethods:s}=await fb(re(r),n);return s||[]}async function hN(r,e){const t=re(r),s={requestType:"VERIFY_EMAIL",idToken:await r.getIdToken()};e&&wc(t.auth,s,e);const{email:i}=await ZP(t.auth,s);i!==r.email&&await r.reload()}async function dN(r,e,t){const n=re(r),i={requestType:"VERIFY_AND_CHANGE_EMAIL",idToken:await r.getIdToken(),newEmail:e};t&&wc(n.auth,i,t);const{email:o}=await nb(n.auth,i);o!==r.email&&await r.reload()}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Cb(r,e){return tt(r,"POST","/v1/accounts:update",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function fN(r,e){const{displayName:t,photoURL:n}=e;if(t===void 0&&n===void 0)return;const s=re(r),o={idToken:await s.getIdToken(),displayName:t,photoUrl:n,returnSecureToken:!0},a=await ps(s,Cb(s.auth,o));s.displayName=a.displayName||null,s.photoURL=a.photoUrl||null;const u=s.providerData.find(({providerId:B})=>B==="password");u&&(u.displayName=s.displayName,u.photoURL=s.photoURL),await s._updateTokensIfNecessary(a)}function CN(r,e){const t=re(r);return Ge(t.auth.app)?Promise.reject(Tt(t.auth)):iE(t,e,null)}function pN(r,e){return iE(re(r),null,e)}async function iE(r,e,t){const{auth:n}=r,i={idToken:await r.getIdToken(),returnSecureToken:!0};e&&(i.email=e),t&&(i.password=t);const o=await ps(r,QP(n,i));await r._updateTokensIfNecessary(o,!0)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pb(r){var s,i;if(!r)return null;const{providerId:e}=r,t=r.rawUserInfo?JSON.parse(r.rawUserInfo):{},n=r.isNewUser||r.kind==="identitytoolkit#SignupNewUserResponse";if(!e&&(r!=null&&r.idToken)){const o=(i=(s=_c(r.idToken))==null?void 0:s.firebase)==null?void 0:i.sign_in_provider;if(o){const a=o!=="anonymous"&&o!=="custom"?o:null;return new Qs(n,a)}}if(!e)return null;switch(e){case"facebook.com":return new gb(n,t);case"github.com":return new mb(n,t);case"google.com":return new _b(n,t);case"twitter.com":return new Eb(n,t,r.screenName||null);case"custom":case"anonymous":return new Qs(n,null);default:return new Qs(n,e,t)}}class Qs{constructor(e,t,n={}){this.isNewUser=e,this.providerId=t,this.profile=n}}class oE extends Qs{constructor(e,t,n,s){super(e,t,n),this.username=s}}class gb extends Qs{constructor(e,t){super(e,"facebook.com",t)}}class mb extends oE{constructor(e,t){super(e,"github.com",t,typeof(t==null?void 0:t.login)=="string"?t==null?void 0:t.login:null)}}class _b extends Qs{constructor(e,t){super(e,"google.com",t)}}class Eb extends oE{constructor(e,t,n){super(e,"twitter.com",t,n)}}function gN(r){const{user:e,_tokenResponse:t}=r;return e.isAnonymous&&!t?{providerId:null,isNewUser:!1,profile:null}:pb(t)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function mN(r,e){return re(r).setPersistence(e)}function Ib(r,e,t,n){return re(r).onIdTokenChanged(e,t,n)}function Db(r,e,t){return re(r).beforeAuthStateChanged(e,t)}function _N(r,e,t,n){return re(r).onAuthStateChanged(e,t,n)}function EN(r){return re(r).signOut()}function IN(r,e){return ot(r).revokeAccessToken(e)}async function DN(r){return re(r).delete()}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function dp(r,e){return tt(r,"POST","/v2/accounts/mfaEnrollment:start",et(r,e))}const Mu="__sak";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class aE{constructor(e,t){this.storageRetriever=e,this.type=t}_isAvailable(){try{return this.storage?(this.storage.setItem(Mu,"1"),this.storage.removeItem(Mu),Promise.resolve(!0)):Promise.resolve(!1)}catch{return Promise.resolve(!1)}}_set(e,t){return this.storage.setItem(e,JSON.stringify(t)),Promise.resolve()}_get(e){const t=this.storage.getItem(e);return Promise.resolve(t?JSON.parse(t):null)}_remove(e){return this.storage.removeItem(e),Promise.resolve()}get storage(){return this.storageRetriever()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yb=1e3,wb=10;class uE extends aE{constructor(){super(()=>window.localStorage,"LOCAL"),this.boundEventHandler=(e,t)=>this.onStorageEvent(e,t),this.listeners={},this.localCache={},this.pollTimer=null,this.fallbackToPolling=Q_(),this._shouldAllowMigration=!0}forAllChangedKeys(e){for(const t of Object.keys(this.listeners)){const n=this.storage.getItem(t),s=this.localCache[t];n!==s&&e(t,s,n)}}onStorageEvent(e,t=!1){if(!e.key){this.forAllChangedKeys((o,a,u)=>{this.notifyListeners(o,u)});return}const n=e.key;t?this.detachListener():this.stopPolling();const s=()=>{const o=this.storage.getItem(n);!t&&this.localCache[n]===o||this.notifyListeners(n,o)},i=this.storage.getItem(n);wP()&&i!==e.newValue&&e.newValue!==e.oldValue?setTimeout(s,wb):s()}notifyListeners(e,t){this.localCache[e]=t;const n=this.listeners[e];if(n)for(const s of Array.from(n))s(t&&JSON.parse(t))}startPolling(){this.stopPolling(),this.pollTimer=setInterval(()=>{this.forAllChangedKeys((e,t,n)=>{this.onStorageEvent(new StorageEvent("storage",{key:e,oldValue:t,newValue:n}),!0)})},yb)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}attachListener(){window.addEventListener("storage",this.boundEventHandler)}detachListener(){window.removeEventListener("storage",this.boundEventHandler)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.fallbackToPolling?this.startPolling():this.attachListener()),this.listeners[e]||(this.listeners[e]=new Set,this.localCache[e]=this.storage.getItem(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.detachListener(),this.stopPolling())}async _set(e,t){await super._set(e,t),this.localCache[e]=JSON.stringify(t)}async _get(e){const t=await super._get(e);return this.localCache[e]=JSON.stringify(t),t}async _remove(e){await super._remove(e),delete this.localCache[e]}}uE.type="LOCAL";const Tb=uE;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cE extends aE{constructor(){super(()=>window.sessionStorage,"SESSION")}_addListener(e,t){}_removeListener(e,t){}}cE.type="SESSION";const BE=cE;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ab(r){return Promise.all(r.map(async e=>{try{return{fulfilled:!0,value:await e}}catch(t){return{fulfilled:!1,reason:t}}}))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tc{constructor(e){this.eventTarget=e,this.handlersMap={},this.boundEventHandler=this.handleEvent.bind(this)}static _getInstance(e){const t=this.receivers.find(s=>s.isListeningto(e));if(t)return t;const n=new Tc(e);return this.receivers.push(n),n}isListeningto(e){return this.eventTarget===e}async handleEvent(e){const t=e,{eventId:n,eventType:s,data:i}=t.data,o=this.handlersMap[s];if(!(o!=null&&o.size))return;t.ports[0].postMessage({status:"ack",eventId:n,eventType:s});const a=Array.from(o).map(async B=>B(t.origin,i)),u=await Ab(a);t.ports[0].postMessage({status:"done",eventId:n,eventType:s,response:u})}_subscribe(e,t){Object.keys(this.handlersMap).length===0&&this.eventTarget.addEventListener("message",this.boundEventHandler),this.handlersMap[e]||(this.handlersMap[e]=new Set),this.handlersMap[e].add(t)}_unsubscribe(e,t){this.handlersMap[e]&&t&&this.handlersMap[e].delete(t),(!t||this.handlersMap[e].size===0)&&delete this.handlersMap[e],Object.keys(this.handlersMap).length===0&&this.eventTarget.removeEventListener("message",this.boundEventHandler)}}Tc.receivers=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ac(r="",e=10){let t="";for(let n=0;n<e;n++)t+=Math.floor(Math.random()*10);return r+t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rb{constructor(e){this.target=e,this.handlers=new Set}removeMessageHandler(e){e.messageChannel&&(e.messageChannel.port1.removeEventListener("message",e.onMessage),e.messageChannel.port1.close()),this.handlers.delete(e)}async _send(e,t,n=50){const s=typeof MessageChannel<"u"?new MessageChannel:null;if(!s)throw new Error("connection_unavailable");let i,o;return new Promise((a,u)=>{const B=Ac("",20);s.port1.start();const l=setTimeout(()=>{u(new Error("unsupported_event"))},n);o={messageChannel:s,onMessage(d){const C=d;if(C.data.eventId===B)switch(C.data.status){case"ack":clearTimeout(l),i=setTimeout(()=>{u(new Error("timeout"))},3e3);break;case"done":clearTimeout(i),a(C.data.response);break;default:clearTimeout(l),clearTimeout(i),u(new Error("invalid_response"));break}}},this.handlers.add(o),s.port1.addEventListener("message",o.onMessage),this.target.postMessage({eventType:e,eventId:B,data:t},[s.port2])}).finally(()=>{o&&this.removeMessageHandler(o)})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function He(){return window}function vb(r){He().location.href=r}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vh(){return typeof He().WorkerGlobalScope<"u"&&typeof He().importScripts=="function"}async function Pb(){if(!(navigator!=null&&navigator.serviceWorker))return null;try{return(await navigator.serviceWorker.ready).active}catch{return null}}function bb(){var r;return((r=navigator==null?void 0:navigator.serviceWorker)==null?void 0:r.controller)||null}function Sb(){return Vh()?self:null}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lE="firebaseLocalStorageDb",Ob=1,Gu="firebaseLocalStorage",hE="fbase_key";class fa{constructor(e){this.request=e}toPromise(){return new Promise((e,t)=>{this.request.addEventListener("success",()=>{e(this.request.result)}),this.request.addEventListener("error",()=>{t(this.request.error)})})}}function Rc(r,e){return r.transaction([Gu],e?"readwrite":"readonly").objectStore(Gu)}function Nb(){const r=indexedDB.deleteDatabase(lE);return new fa(r).toPromise()}function dE(){const r=indexedDB.open(lE,Ob);return new Promise((e,t)=>{r.addEventListener("error",()=>{t(r.error)}),r.addEventListener("upgradeneeded",()=>{const n=r.result;try{n.createObjectStore(Gu,{keyPath:hE})}catch(s){t(s)}}),r.addEventListener("success",async()=>{const n=r.result;n.objectStoreNames.contains(Gu)?e(n):(n.close(),await Nb(),e(await dE()))})})}async function fp(r,e,t){const n=Rc(r,!0).put({[hE]:e,value:t});return new fa(n).toPromise()}async function Fb(r,e){const t=Rc(r,!1).get(e),n=await new fa(t).toPromise();return n===void 0?null:n.value}function Cp(r,e){const t=Rc(r,!0).delete(e);return new fa(t).toPromise()}const Lb=800,kb=3;class fE{registerLifecycleListeners(){typeof window<"u"&&typeof window.addEventListener=="function"&&(window.addEventListener("pagehide",this.onPageHide),window.addEventListener("pageshow",this.onPageShow))}unregisterLifecycleListeners(){typeof window<"u"&&typeof window.removeEventListener=="function"&&(window.removeEventListener("pagehide",this.onPageHide),window.removeEventListener("pageshow",this.onPageShow))}constructor(){this.type="LOCAL",this.dbPromise=null,this._shouldAllowMigration=!0,this.listeners={},this.localCache={},this.pollTimer=null,this.isClosing=!1,this.pendingWrites=0,this.receiver=null,this.sender=null,this.serviceWorkerReceiverAvailable=!1,this.activeServiceWorker=null,this.onPageHide=()=>{this.isClosing=!0,this.stopPolling(),this.dbPromise&&(this.dbPromise.then(e=>e.close()).catch(()=>{}),this.dbPromise=null)},this.onPageShow=()=>{this.isClosing&&(this.isClosing=!1,Object.keys(this.listeners).length>0&&this.startPolling())},this._workerInitializationPromise=this.initializeServiceWorkerMessaging().then(()=>{},()=>{})}async _openDb(){return this.dbPromise?this.dbPromise:(this.dbPromise=dE(),this.dbPromise.catch(()=>{this.dbPromise=null}),this.dbPromise)}async _withRetries(e){let t=0;for(;;)try{const n=await this._openDb();return await e(n)}catch(n){if(t++>kb)throw n;if(this.dbPromise){const s=this.dbPromise;this.dbPromise=null;try{(await s).close()}catch{}}}}async initializeServiceWorkerMessaging(){return Vh()?this.initializeReceiver():this.initializeSender()}async initializeReceiver(){this.receiver=Tc._getInstance(Sb()),this.receiver._subscribe("keyChanged",async(e,t)=>({keyProcessed:(await this._poll()).includes(t.key)})),this.receiver._subscribe("ping",async(e,t)=>["keyChanged"])}async initializeSender(){var t,n;if(this.activeServiceWorker=await Pb(),!this.activeServiceWorker)return;this.sender=new Rb(this.activeServiceWorker);const e=await this.sender._send("ping",{},800);e&&(t=e[0])!=null&&t.fulfilled&&(n=e[0])!=null&&n.value.includes("keyChanged")&&(this.serviceWorkerReceiverAvailable=!0)}async notifyServiceWorker(e){if(!(!this.sender||!this.activeServiceWorker||bb()!==this.activeServiceWorker))try{await this.sender._send("keyChanged",{key:e},this.serviceWorkerReceiverAvailable?800:50)}catch{}}async _isAvailable(){try{return indexedDB?(await this._withRetries(async e=>{await fp(e,Mu,"1"),await Cp(e,Mu)}),!0):!1}catch{}return!1}async _withPendingWrite(e){this.pendingWrites++;try{await e()}finally{this.pendingWrites--}}async _set(e,t){return this._withPendingWrite(async()=>(await this._withRetries(n=>fp(n,e,t)),this.localCache[e]=t,this.notifyServiceWorker(e)))}async _get(e){const t=await this._withRetries(n=>Fb(n,e));return this.localCache[e]=t,t}async _remove(e){return this._withPendingWrite(async()=>(await this._withRetries(t=>Cp(t,e)),delete this.localCache[e],this.notifyServiceWorker(e)))}async _poll(){if(this.isClosing)return[];try{const e=await this._withRetries(s=>{const i=Rc(s,!1).getAll();return new fa(i).toPromise()});if(this.isClosing)return[];if(!e)return[];if(this.pendingWrites!==0)return[];const t=[],n=new Set;if(e.length!==0)for(const{fbase_key:s,value:i}of e)n.add(s),JSON.stringify(this.localCache[s])!==JSON.stringify(i)&&(this.notifyListeners(s,i),t.push(s));for(const s of Object.keys(this.localCache))this.localCache[s]&&!n.has(s)&&(this.notifyListeners(s,null),t.push(s));return t}catch(e){return this.isClosing||cu(`Firebase Auth cross-tab polling failed with error: ${e}`),[]}}notifyListeners(e,t){this.localCache[e]=t;const n=this.listeners[e];if(n)for(const s of Array.from(n))s(t)}startPolling(){this.stopPolling(),this.pollTimer=setInterval(async()=>this._poll(),Lb)}stopPolling(){this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}_addListener(e,t){Object.keys(this.listeners).length===0&&(this.startPolling(),this.registerLifecycleListeners()),this.listeners[e]||(this.listeners[e]=new Set,this._get(e)),this.listeners[e].add(t)}_removeListener(e,t){this.listeners[e]&&(this.listeners[e].delete(t),this.listeners[e].size===0&&delete this.listeners[e]),Object.keys(this.listeners).length===0&&(this.stopPolling(),this.unregisterLifecycleListeners())}}fE.type="LOCAL";const xb=fE;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function pp(r,e){return tt(r,"POST","/v2/accounts/mfaSignIn:start",et(r,e))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _B=Y_("rcb"),Vb=new ha(3e4,6e4);class Mb{constructor(){var e;this.hostLanguage="",this.counter=0,this.librarySeparatelyLoaded=!!((e=He().grecaptcha)!=null&&e.render)}load(e,t=""){return Y(Gb(t),e,"argument-error"),this.shouldResolveImmediately(t)&&np(He().grecaptcha)?Promise.resolve(He().grecaptcha):new Promise((n,s)=>{const i=He().setTimeout(()=>{s(wt(e,"network-request-failed"))},Vb.get());He()[_B]=()=>{He().clearTimeout(i),delete He()[_B];const a=He().grecaptcha;if(!a||!np(a)){s(wt(e,"internal-error"));return}const u=a.render;a.render=(B,l)=>{const d=u(B,l);return this.counter++,d},this.hostLanguage=t,n(a)};const o=`${SP()}?${ci({onload:_B,render:"explicit",hl:t})}`;Lh(o).catch(()=>{clearTimeout(i),s(wt(e,"internal-error"))})})}clearedOneInstance(){this.counter--}shouldResolveImmediately(e){var t;return!!((t=He().grecaptcha)!=null&&t.render)&&(e===this.hostLanguage||this.counter>0||this.librarySeparatelyLoaded)}}function Gb(r){return r.length<=6&&/^\s*[a-zA-Z0-9\-]*\s*$/.test(r)}class Ub{async load(e){return new kP(e)}clearedOneInstance(){}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const po="recaptcha",Hb={theme:"light",type:"image"};class yN{constructor(e,t,n={...Hb}){this.parameters=n,this.type=po,this.destroyed=!1,this.widgetId=null,this.tokenChangeListeners=new Set,this.renderPromise=null,this.recaptcha=null,this.auth=ot(e),this.isInvisible=this.parameters.size==="invisible",Y(typeof document<"u",this.auth,"operation-not-supported-in-this-environment");const s=typeof t=="string"?document.getElementById(t):t;Y(s,this.auth,"argument-error"),this.container=s,this.parameters.callback=this.makeTokenCallback(this.parameters.callback),this._recaptchaLoader=this.auth.settings.appVerificationDisabledForTesting?new Ub:new Mb,this.validateStartingState()}async verify(){this.assertNotDestroyed();const e=await this.render(),t=this.getAssertedRecaptcha(),n=t.getResponse(e);return n||new Promise(s=>{const i=o=>{o&&(this.tokenChangeListeners.delete(i),s(o))};this.tokenChangeListeners.add(i),this.isInvisible&&t.execute(e)})}render(){try{this.assertNotDestroyed()}catch(e){return Promise.reject(e)}return this.renderPromise?this.renderPromise:(this.renderPromise=this.makeRenderPromise().catch(e=>{throw this.renderPromise=null,e}),this.renderPromise)}_reset(){this.assertNotDestroyed(),this.widgetId!==null&&this.getAssertedRecaptcha().reset(this.widgetId)}clear(){this.assertNotDestroyed(),this.destroyed=!0,this._recaptchaLoader.clearedOneInstance(),this.isInvisible||this.container.childNodes.forEach(e=>{this.container.removeChild(e)})}validateStartingState(){Y(!this.parameters.sitekey,this.auth,"argument-error"),Y(this.isInvisible||!this.container.hasChildNodes(),this.auth,"argument-error"),Y(typeof document<"u",this.auth,"operation-not-supported-in-this-environment")}makeTokenCallback(e){return t=>{if(this.tokenChangeListeners.forEach(n=>n(t)),typeof e=="function")e(t);else if(typeof e=="string"){const n=He()[e];typeof n=="function"&&n(t)}}}assertNotDestroyed(){Y(!this.destroyed,this.auth,"internal-error")}async makeRenderPromise(){if(await this.init(),!this.widgetId){let e=this.container;if(!this.isInvisible){const t=document.createElement("div");e.appendChild(t),e=t}this.widgetId=this.getAssertedRecaptcha().render(e,this.parameters)}return this.widgetId}async init(){Y(Oh()&&!Vh(),this.auth,"internal-error"),await qb(),this.recaptcha=await this._recaptchaLoader.load(this.auth,this.auth.languageCode||void 0);const e=await dP(this.auth);Y(e,this.auth,"internal-error"),this.parameters.sitekey=e}getAssertedRecaptcha(){return Y(this.recaptcha,this.auth,"internal-error"),this.recaptcha}}function qb(){let r=null;return new Promise(e=>{if(document.readyState==="complete"){e();return}r=()=>e(),window.addEventListener("load",r)}).catch(e=>{throw r&&window.removeEventListener("load",r),e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class CE{constructor(e,t){this.verificationId=e,this.onConfirmation=t}confirm(e){const t=Co._fromVerification(this.verificationId,e);return this.onConfirmation(t)}}async function wN(r,e,t){if(Ge(r.app))return Promise.reject(Tt(r));const n=ot(r),s=await pE(n,e,re(t));return new CE(s,i=>kh(n,i))}async function TN(r,e,t){const n=re(r);await yc(!1,n,"phone");const s=await pE(n.auth,e,re(t));return new CE(s,i=>hb(n,i))}async function pE(r,e,t){var n;if(!r._getRecaptchaConfig())try{await HP(r)}catch{console.log("Failed to initialize reCAPTCHA Enterprise config. Triggering the reCAPTCHA v2 verification.")}try{let s;if(typeof e=="string"?s={phoneNumber:e}:s=e,"session"in s){const i=s.session;if("phoneNumber"in s){Y(i.type==="enroll",r,"internal-error");const o={idToken:i.credential,phoneEnrollmentInfo:{phoneNumber:s.phoneNumber,clientType:"CLIENT_TYPE_WEB"}};return(await _r(r,o,"mfaSmsEnrollment",async(l,d)=>{if(d.phoneEnrollmentInfo.captchaResponse===fo){Y((t==null?void 0:t.type)===po,l,"argument-error");const C=await EB(l,d,t);return dp(l,C)}return dp(l,d)},"PHONE_PROVIDER").catch(l=>Promise.reject(l))).phoneSessionInfo.sessionInfo}else{Y(i.type==="signin",r,"internal-error");const o=((n=s.multiFactorHint)==null?void 0:n.uid)||s.multiFactorUid;Y(o,r,"missing-multi-factor-info");const a={mfaPendingCredential:i.credential,mfaEnrollmentId:o,phoneSignInInfo:{clientType:"CLIENT_TYPE_WEB"}};return(await _r(r,a,"mfaSmsSignIn",async(d,C)=>{if(C.phoneSignInInfo.captchaResponse===fo){Y((t==null?void 0:t.type)===po,d,"argument-error");const g=await EB(d,C,t);return pp(d,g)}return pp(d,C)},"PHONE_PROVIDER").catch(d=>Promise.reject(d))).phoneResponseInfo.sessionInfo}}else{const i={phoneNumber:s.phoneNumber,clientType:"CLIENT_TYPE_WEB"};return(await _r(r,i,"sendVerificationCode",async(B,l)=>{if(l.captchaResponse===fo){Y((t==null?void 0:t.type)===po,B,"argument-error");const d=await EB(B,l,t);return lp(B,d)}return lp(B,l)},"PHONE_PROVIDER").catch(B=>Promise.reject(B))).sessionInfo}}finally{t==null||t._reset()}}async function EB(r,e,t){Y(t.type===po,r,"argument-error");const n=await t.verify();Y(typeof n=="string",r,"argument-error");const s={...e};if("phoneEnrollmentInfo"in s){const i=s.phoneEnrollmentInfo.phoneNumber,o=s.phoneEnrollmentInfo.captchaResponse,a=s.phoneEnrollmentInfo.clientType,u=s.phoneEnrollmentInfo.recaptchaVersion;return Object.assign(s,{phoneEnrollmentInfo:{phoneNumber:i,recaptchaToken:n,captchaResponse:o,clientType:a,recaptchaVersion:u}}),s}else if("phoneSignInInfo"in s){const i=s.phoneSignInInfo.captchaResponse,o=s.phoneSignInInfo.clientType,a=s.phoneSignInInfo.recaptchaVersion;return Object.assign(s,{phoneSignInInfo:{recaptchaToken:n,captchaResponse:i,clientType:o,recaptchaVersion:a}}),s}else return Object.assign(s,{recaptchaToken:n}),s}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ii(r,e){return e?Rn(e):(Y(r._popupRedirectResolver,r,"argument-error"),r._popupRedirectResolver)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mh extends Ec{constructor(e){super("custom","custom"),this.params=e}_getIdTokenResponse(e){return Ws(e,this._buildIdpRequest())}_linkToIdToken(e,t){return Ws(e,this._buildIdpRequest(t))}_getReauthenticationResolver(e){return Ws(e,this._buildIdpRequest())}_buildIdpRequest(e){const t={requestUri:this.params.requestUri,sessionId:this.params.sessionId,postBody:this.params.postBody,tenantId:this.params.tenantId,pendingToken:this.params.pendingToken,returnSecureToken:!0,returnIdpCredential:!0};return e&&(t.idToken=e),t}}function jb(r){return sE(r.auth,new Mh(r),r.bypassAuthState)}function Jb(r){const{auth:e,user:t}=r;return Y(t,e,"internal-error"),rE(t,new Mh(r),r.bypassAuthState)}async function Kb(r){const{auth:e,user:t}=r;return Y(t,e,"internal-error"),nE(t,new Mh(r),r.bypassAuthState)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gE{constructor(e,t,n,s,i=!1){this.auth=e,this.resolver=n,this.user=s,this.bypassAuthState=i,this.pendingPromise=null,this.eventManager=null,this.filter=Array.isArray(t)?t:[t]}execute(){return new Promise(async(e,t)=>{this.pendingPromise={resolve:e,reject:t};try{this.eventManager=await this.resolver._initialize(this.auth),await this.onExecution(),this.eventManager.registerConsumer(this)}catch(n){this.reject(n)}})}async onAuthEvent(e){const{urlResponse:t,sessionId:n,postBody:s,tenantId:i,error:o,type:a}=e;if(o){this.reject(o);return}const u={auth:this.auth,requestUri:t,sessionId:n,tenantId:i||void 0,postBody:s||void 0,user:this.user,bypassAuthState:this.bypassAuthState};try{this.resolve(await this.getIdpTask(a)(u))}catch(B){this.reject(B)}}onError(e){this.reject(e)}getIdpTask(e){switch(e){case"signInViaPopup":case"signInViaRedirect":return jb;case"linkViaPopup":case"linkViaRedirect":return Kb;case"reauthViaPopup":case"reauthViaRedirect":return Jb;default:Qt(this.auth,"internal-error")}}resolve(e){xn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.resolve(e),this.unregisterAndCleanUp()}reject(e){xn(this.pendingPromise,"Pending promise was never set"),this.pendingPromise.reject(e),this.unregisterAndCleanUp()}unregisterAndCleanUp(){this.eventManager&&this.eventManager.unregisterConsumer(this),this.pendingPromise=null,this.cleanUp()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zb=new ha(2e3,1e4);async function AN(r,e,t){if(Ge(r.app))return Promise.reject(wt(r,"operation-not-supported-in-this-environment"));const n=ot(r);la(r,e,As);const s=Ii(n,t);return new vn(n,"signInViaPopup",e,s).executeNotNull()}async function RN(r,e,t){const n=re(r);if(Ge(n.auth.app))return Promise.reject(wt(n.auth,"operation-not-supported-in-this-environment"));la(n.auth,e,As);const s=Ii(n.auth,t);return new vn(n.auth,"reauthViaPopup",e,s,n).executeNotNull()}async function vN(r,e,t){const n=re(r);la(n.auth,e,As);const s=Ii(n.auth,t);return new vn(n.auth,"linkViaPopup",e,s,n).executeNotNull()}class vn extends gE{constructor(e,t,n,s,i){super(e,t,s,i),this.provider=n,this.authWindow=null,this.pollId=null,vn.currentPopupAction&&vn.currentPopupAction.cancel(),vn.currentPopupAction=this}async executeNotNull(){const e=await this.execute();return Y(e,this.auth,"internal-error"),e}async onExecution(){xn(this.filter.length===1,"Popup operations only handle one event");const e=Ac();this.authWindow=await this.resolver._openPopup(this.auth,this.provider,this.filter[0],e),this.authWindow.associatedEvent=e,this.resolver._originValidation(this.auth).catch(t=>{this.reject(t)}),this.resolver._isIframeWebStorageSupported(this.auth,t=>{t||this.reject(wt(this.auth,"web-storage-unsupported"))}),this.pollUserCancellation()}get eventId(){var e;return((e=this.authWindow)==null?void 0:e.associatedEvent)||null}cancel(){this.reject(wt(this.auth,"cancelled-popup-request"))}cleanUp(){this.authWindow&&this.authWindow.close(),this.pollId&&window.clearTimeout(this.pollId),this.authWindow=null,this.pollId=null,vn.currentPopupAction=null}pollUserCancellation(){const e=()=>{var t,n;if((n=(t=this.authWindow)==null?void 0:t.window)!=null&&n.closed){this.pollId=window.setTimeout(()=>{this.pollId=null,this.reject(wt(this.auth,"popup-closed-by-user"))},8e3);return}this.pollId=window.setTimeout(e,zb.get())};e()}}vn.currentPopupAction=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Wb="pendingRedirect",du=new Map;class Qb extends gE{constructor(e,t,n=!1){super(e,["signInViaRedirect","linkViaRedirect","reauthViaRedirect","unknown"],t,void 0,n),this.eventId=null}async execute(){let e=du.get(this.auth._key());if(!e){try{const n=await $b(this.resolver,this.auth)?await super.execute():null;e=()=>Promise.resolve(n)}catch(t){e=()=>Promise.reject(t)}du.set(this.auth._key(),e)}return this.bypassAuthState||du.set(this.auth._key(),()=>Promise.resolve(null)),e()}async onAuthEvent(e){if(e.type==="signInViaRedirect")return super.onAuthEvent(e);if(e.type==="unknown"){this.resolve(null);return}if(e.eventId){const t=await this.auth._redirectUserForId(e.eventId);if(t)return this.user=t,super.onAuthEvent(e);this.resolve(null)}}async onExecution(){}cleanUp(){}}async function $b(r,e){const t=EE(e),n=_E(r);if(!await n._isAvailable())return!1;const s=await n._get(t)==="true";return await n._remove(t),s}async function mE(r,e){return _E(r)._set(EE(e),"true")}function Yb(r,e){du.set(r._key(),e)}function _E(r){return Rn(r._redirectPersistence)}function EE(r){return lu(Wb,r.config.apiKey,r.name)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function PN(r,e,t){return Xb(r,e,t)}async function Xb(r,e,t){if(Ge(r.app))return Promise.reject(Tt(r));const n=ot(r);la(r,e,As),await n._initializationPromise;const s=Ii(n,t);return await mE(s,n),s._openRedirect(n,e,"signInViaRedirect")}function bN(r,e,t){return Zb(r,e,t)}async function Zb(r,e,t){const n=re(r);la(n.auth,e,As),await n.auth._initializationPromise;const s=Ii(n.auth,t);await yc(!1,n,e.providerId),await mE(s,n.auth);const i=await eS(n);return s._openRedirect(n.auth,e,"linkViaRedirect",i)}async function SN(r,e){return await ot(r)._initializationPromise,IE(r,e,!1)}async function IE(r,e,t=!1){if(Ge(r.app))return Promise.reject(Tt(r));const n=ot(r),s=Ii(n,e),o=await new Qb(n,s,t).execute();return o&&!t&&(delete o.user._redirectEventId,await n._persistUserIfCurrent(o.user),await n._setRedirectUser(null,e)),o}async function eS(r){const e=Ac(`${r.uid}:::`);return r._redirectEventId=e,await r.auth._setRedirectUser(r),await r.auth._persistUserIfCurrent(r),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const tS=10*60*1e3;class nS{constructor(e){this.auth=e,this.cachedEventUids=new Set,this.consumers=new Set,this.queuedRedirectEvent=null,this.hasHandledPotentialRedirect=!1,this.lastProcessedEventTime=Date.now()}registerConsumer(e){this.consumers.add(e),this.queuedRedirectEvent&&this.isEventForConsumer(this.queuedRedirectEvent,e)&&(this.sendToConsumer(this.queuedRedirectEvent,e),this.saveEventToCache(this.queuedRedirectEvent),this.queuedRedirectEvent=null)}unregisterConsumer(e){this.consumers.delete(e)}onEvent(e){if(this.hasEventBeenHandled(e))return!1;let t=!1;return this.consumers.forEach(n=>{this.isEventForConsumer(e,n)&&(t=!0,this.sendToConsumer(e,n),this.saveEventToCache(e))}),this.hasHandledPotentialRedirect||!rS(e)||(this.hasHandledPotentialRedirect=!0,t||(this.queuedRedirectEvent=e,t=!0)),t}sendToConsumer(e,t){var n;if(e.error&&!DE(e)){const s=((n=e.error.code)==null?void 0:n.split("auth/")[1])||"internal-error";t.onError(wt(this.auth,s))}else t.onAuthEvent(e)}isEventForConsumer(e,t){const n=t.eventId===null||!!e.eventId&&e.eventId===t.eventId;return t.filter.includes(e.type)&&n}hasEventBeenHandled(e){return Date.now()-this.lastProcessedEventTime>=tS&&this.cachedEventUids.clear(),this.cachedEventUids.has(gp(e))}saveEventToCache(e){this.cachedEventUids.add(gp(e)),this.lastProcessedEventTime=Date.now()}}function gp(r){return[r.type,r.eventId,r.sessionId,r.tenantId].filter(e=>e).join("-")}function DE({type:r,error:e}){return r==="unknown"&&(e==null?void 0:e.code)==="auth/no-auth-event"}function rS(r){switch(r.type){case"signInViaRedirect":case"linkViaRedirect":case"reauthViaRedirect":return!0;case"unknown":return DE(r);default:return!1}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sS(r,e={}){return tt(r,"GET","/v1/projects",e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const iS=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,oS=/^https?/;async function aS(r){if(r.config.emulator)return;const{authorizedDomains:e}=await sS(r);for(const t of e)try{if(uS(t))return}catch{}Qt(r,"unauthorized-domain")}function uS(r){const e=Go(),{protocol:t,hostname:n}=new URL(e);if(r.startsWith("chrome-extension://")){const o=new URL(r);return o.hostname===""&&n===""?t==="chrome-extension:"&&r.replace("chrome-extension://","")===e.replace("chrome-extension://",""):t==="chrome-extension:"&&o.hostname===n}if(!oS.test(t))return!1;if(iS.test(r))return n===r;const s=r.replace(/\./g,"\\.");return new RegExp("^(.+\\."+s+"|"+s+")$","i").test(n)}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cS=new ha(3e4,6e4);function mp(){const r=He().___jsl;if(r!=null&&r.H){for(const e of Object.keys(r.H))if(r.H[e].r=r.H[e].r||[],r.H[e].L=r.H[e].L||[],r.H[e].r=[...r.H[e].L],r.CP)for(let t=0;t<r.CP.length;t++)r.CP[t]=null}}function BS(r){return new Promise((e,t)=>{var s,i,o;function n(){mp(),gapi.load("gapi.iframes",{callback:()=>{e(gapi.iframes.getContext())},ontimeout:()=>{mp(),t(wt(r,"network-request-failed"))},timeout:cS.get()})}if((i=(s=He().gapi)==null?void 0:s.iframes)!=null&&i.Iframe)e(gapi.iframes.getContext());else if((o=He().gapi)!=null&&o.load)n();else{const a=Y_("iframefcb");return He()[a]=()=>{gapi.load?n():t(wt(r,"network-request-failed"))},Lh(`${NP()}?onload=${a}`).catch(u=>t(u))}}).catch(e=>{throw fu=null,e})}let fu=null;function lS(r){return fu=fu||BS(r),fu}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hS=new ha(5e3,15e3),dS="__/auth/iframe",fS="emulator/auth/iframe",CS={style:{position:"absolute",top:"-100px",width:"1px",height:"1px"},"aria-hidden":"true",tabindex:"-1"},pS=new Map([["identitytoolkit.googleapis.com","p"],["staging-identitytoolkit.sandbox.googleapis.com","s"],["test-identitytoolkit.sandbox.googleapis.com","t"]]);function gS(r){const e=r.config;Y(e.authDomain,r,"auth-domain-config-required");const t=e.emulator?Nh(e,fS):`https://${r.config.authDomain}/${dS}`,n={apiKey:e.apiKey,appName:r.name,v:ms},s=pS.get(r.config.apiHost);s&&(n.eid=s);const i=r._getFrameworks();return i.length&&(n.fw=i.join(",")),`${t}?${ci(n).slice(1)}`}async function mS(r){const e=await lS(r),t=He().gapi;return Y(t,r,"internal-error"),e.open({where:document.body,url:gS(r),messageHandlersFilter:t.iframes.CROSS_ORIGIN_IFRAMES_FILTER,attributes:CS,dontclear:!0},n=>new Promise(async(s,i)=>{await n.restyle({setHideOnLeave:!1});const o=wt(r,"network-request-failed"),a=He().setTimeout(()=>{i(o)},hS.get());function u(){He().clearTimeout(a),s(n)}n.ping(u).then(u,()=>{i(o)})}))}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _S={location:"yes",resizable:"yes",statusbar:"yes",toolbar:"no"},ES=500,IS=600,DS="_blank",yS="http://localhost";class _p{constructor(e){this.window=e,this.associatedEvent=null}close(){if(this.window)try{this.window.close()}catch{}}}function wS(r,e,t,n=ES,s=IS){const i=Math.max((window.screen.availHeight-s)/2,0).toString(),o=Math.max((window.screen.availWidth-n)/2,0).toString();let a="";const u={..._S,width:n.toString(),height:s.toString(),top:i,left:o},B=Xe().toLowerCase();t&&(a=j_(B)?DS:t),H_(B)&&(e=e||yS,u.scrollbars="yes");const l=Object.entries(u).reduce((C,[g,m])=>`${C}${g}=${m},`,"");if(yP(B)&&a!=="_self")return TS(e||"",a),new _p(null);const d=window.open(e||"",a,l);Y(d,r,"popup-blocked");try{d.focus()}catch{}return new _p(d)}function TS(r,e){const t=document.createElement("a");t.href=r,t.target=e;const n=document.createEvent("MouseEvent");n.initMouseEvent("click",!0,!0,window,1,0,0,0,0,!1,!1,!1,!1,1,null),t.dispatchEvent(n)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const AS="__/auth/handler",RS="emulator/auth/handler",vS=encodeURIComponent("fac");async function Ep(r,e,t,n,s,i){Y(r.config.authDomain,r,"auth-domain-config-required"),Y(r.config.apiKey,r,"invalid-api-key");const o={apiKey:r.config.apiKey,appName:r.name,authType:t,redirectUrl:n,v:ms,eventId:s};if(e instanceof As){e.setDefaultLanguage(r.languageCode),o.providerId=e.providerId||"",jI(e.getCustomParameters())||(o.customParameters=JSON.stringify(e.getCustomParameters()));for(const[l,d]of Object.entries({}))o[l]=d}if(e instanceof Ei){const l=e.getScopes().filter(d=>d!=="");l.length>0&&(o.scopes=l.join(","))}r.tenantId&&(o.tid=r.tenantId);const a=o;for(const l of Object.keys(a))a[l]===void 0&&delete a[l];const u=await r._getAppCheckToken(),B=u?`#${vS}=${encodeURIComponent(u)}`:"";return`${PS(r)}?${ci(a).slice(1)}${B}`}function PS({config:r}){return r.emulator?Nh(r,RS):`https://${r.authDomain}/${AS}`}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const IB="webStorageSupport";class bS{constructor(){this.eventManagers={},this.iframes={},this.originValidationPromises={},this._redirectPersistence=BE,this._completeRedirectFn=IE,this._overrideRedirectResult=Yb}async _openPopup(e,t,n,s){var o;xn((o=this.eventManagers[e._key()])==null?void 0:o.manager,"_initialize() not called before _openPopup()");const i=await Ep(e,t,n,Go(),s);return wS(e,i,Ac())}async _openRedirect(e,t,n,s){await this._originValidation(e);const i=await Ep(e,t,n,Go(),s);return vb(i),new Promise(()=>{})}_initialize(e){const t=e._key();if(this.eventManagers[t]){const{manager:s,promise:i}=this.eventManagers[t];return s?Promise.resolve(s):(xn(i,"If manager is not set, promise should be"),i)}const n=this.initAndGetManager(e);return this.eventManagers[t]={promise:n},n.catch(()=>{delete this.eventManagers[t]}),n}async initAndGetManager(e){const t=await mS(e),n=new nS(e);return t.register("authEvent",s=>(Y(s==null?void 0:s.authEvent,e,"invalid-auth-event"),{status:n.onEvent(s.authEvent)?"ACK":"ERROR"}),gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER),this.eventManagers[e._key()]={manager:n},this.iframes[e._key()]=t,n}_isIframeWebStorageSupported(e,t){this.iframes[e._key()].send(IB,{type:IB},s=>{var o;const i=(o=s==null?void 0:s[0])==null?void 0:o[IB];i!==void 0&&t(!!i),Qt(e,"internal-error")},gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)}_originValidation(e){const t=e._key();return this.originValidationPromises[t]||(this.originValidationPromises[t]=aS(e)),this.originValidationPromises[t]}get _shouldInitProactively(){return Q_()||q_()||Fh()}}const SS=bS;var Ip="@firebase/auth",Dp="1.13.6";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class OS{constructor(e){this.auth=e,this.internalListeners=new Map}getUid(){var e;return this.assertAuthConfigured(),((e=this.auth.currentUser)==null?void 0:e.uid)||null}async getToken(e){return this.assertAuthConfigured(),await this.auth._initializationPromise,this.auth.currentUser?{accessToken:await this.auth.currentUser.getIdToken(e)}:null}addAuthTokenListener(e){if(this.assertAuthConfigured(),this.internalListeners.has(e))return;const t=this.auth.onIdTokenChanged(n=>{e((n==null?void 0:n.stsTokenManager.accessToken)||null)});this.internalListeners.set(e,t),this.updateProactiveRefresh()}removeAuthTokenListener(e){this.assertAuthConfigured();const t=this.internalListeners.get(e);t&&(this.internalListeners.delete(e),t(),this.updateProactiveRefresh())}assertAuthConfigured(){Y(this.auth._initializationPromise,"dependent-sdk-initialized-before-auth")}updateProactiveRefresh(){this.internalListeners.size>0?this.auth._startProactiveRefresh():this.auth._stopProactiveRefresh()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function NS(r){switch(r){case"Node":return"node";case"ReactNative":return"rn";case"Worker":return"webworker";case"Cordova":return"cordova";case"WebExtension":return"web-extension";default:return}}function FS(r){is(new Er("auth",(e,{options:t})=>{const n=e.getProvider("app").getImmediate(),s=e.getProvider("heartbeat"),i=e.getProvider("app-check-internal"),{apiKey:o,authDomain:a}=n.options;Y(o&&!o.includes(":"),"invalid-api-key",{appName:n.name});const u={apiKey:o,authDomain:a,clientPlatform:r,apiHost:"identitytoolkit.googleapis.com",tokenApiHost:"securetoken.googleapis.com",apiScheme:"https",sdkClientVersion:$_(r)},B=new PP(n,s,i,u);return jP(B,t),B},"PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e,t,n)=>{e.getProvider("auth-internal").initialize()})),is(new Er("auth-internal",e=>{const t=ot(e.getProvider("auth").getImmediate());return(n=>new OS(n))(t)},"PRIVATE").setInstantiationMode("EXPLICIT")),hn(Ip,Dp,NS(r)),hn(Ip,Dp,"esm2020")}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const LS=5*60,kS=Vp("authIdTokenMaxAge")||LS;let yp=null;const xS=r=>async e=>{const t=e&&await e.getIdTokenResult(),n=t&&(new Date().getTime()-Date.parse(t.issuedAtTime))/1e3;if(n&&n>kS)return;const s=t==null?void 0:t.token;yp!==s&&(yp=s,await fetch(r,{method:s?"POST":"DELETE",headers:s?{Authorization:`Bearer ${s}`}:{}}))};function ON(r=hl()){const e=jo(r,"auth");if(e.isInitialized())return e.getImmediate();const t=qP(r,{popupRedirectResolver:SS,persistence:[xb,Tb,BE]}),n=Vp("authTokenSyncURL");if(n&&typeof isSecureContext=="boolean"&&isSecureContext){const i=new URL(n,location.origin);if(location.origin===i.origin){const o=xS(i.toString());Db(t,o,()=>o(t.currentUser)),Ib(t,a=>o(a))}}const s=Lp("auth");return s&&JP(t,`http://${s}`),t}function VS(){var r;return((r=document.getElementsByTagName("head"))==null?void 0:r[0])??document}bP({loadJS(r){return new Promise((e,t)=>{const n=document.createElement("script");n.setAttribute("src",r),n.onload=e,n.onerror=s=>{const i=wt("internal-error");i.customData=s,t(i)},n.type="text/javascript",n.charset="UTF-8",VS().appendChild(n)})},gapiScript:"https://apis.google.com/js/api.js",recaptchaV2Script:"https://www.google.com/recaptcha/api.js",recaptchaEnterpriseScript:"https://www.google.com/recaptcha/enterprise.js?render="});FS("Browser");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const yE="firebasestorage.googleapis.com",wE="storageBucket",MS=2*60*1e3,GS=10*60*1e3,US=1e3;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ke extends In{constructor(e,t,n=0){super(DB(e),`Firebase Storage: ${t} (${DB(e)})`),this.status_=n,this.customData={serverResponse:null},this._baseMessage=this.message,Object.setPrototypeOf(this,ke.prototype)}get status(){return this.status_}set status(e){this.status_=e}_codeEquals(e){return DB(e)===this.code}get serverResponse(){return this.customData.serverResponse}set serverResponse(e){this.customData.serverResponse=e,this.customData.serverResponse?this.message=`${this._baseMessage}
${this.customData.serverResponse}`:this.message=this._baseMessage}}var ve;(function(r){r.UNKNOWN="unknown",r.OBJECT_NOT_FOUND="object-not-found",r.BUCKET_NOT_FOUND="bucket-not-found",r.PROJECT_NOT_FOUND="project-not-found",r.QUOTA_EXCEEDED="quota-exceeded",r.UNAUTHENTICATED="unauthenticated",r.UNAUTHORIZED="unauthorized",r.UNAUTHORIZED_APP="unauthorized-app",r.RETRY_LIMIT_EXCEEDED="retry-limit-exceeded",r.INVALID_CHECKSUM="invalid-checksum",r.CANCELED="canceled",r.INVALID_EVENT_NAME="invalid-event-name",r.INVALID_URL="invalid-url",r.INVALID_DEFAULT_BUCKET="invalid-default-bucket",r.NO_DEFAULT_BUCKET="no-default-bucket",r.CANNOT_SLICE_BLOB="cannot-slice-blob",r.SERVER_FILE_WRONG_SIZE="server-file-wrong-size",r.NO_DOWNLOAD_URL="no-download-url",r.INVALID_ARGUMENT="invalid-argument",r.INVALID_ARGUMENT_COUNT="invalid-argument-count",r.APP_DELETED="app-deleted",r.INVALID_ROOT_OPERATION="invalid-root-operation",r.INVALID_FORMAT="invalid-format",r.INTERNAL_ERROR="internal-error",r.UNSUPPORTED_ENVIRONMENT="unsupported-environment"})(ve||(ve={}));function DB(r){return"storage/"+r}function Gh(){const r="An unknown error occurred, please check the error payload for server response.";return new ke(ve.UNKNOWN,r)}function HS(r){return new ke(ve.OBJECT_NOT_FOUND,"Object '"+r+"' does not exist.")}function qS(r){return new ke(ve.QUOTA_EXCEEDED,"Quota for bucket '"+r+"' exceeded, please view quota on https://firebase.google.com/pricing/.")}function jS(){const r="User is not authenticated, please authenticate using Firebase Authentication and try again.";return new ke(ve.UNAUTHENTICATED,r)}function JS(){return new ke(ve.UNAUTHORIZED_APP,"This app does not have permission to access Firebase Storage on this project.")}function KS(r){return new ke(ve.UNAUTHORIZED,"User does not have permission to access '"+r+"'.")}function TE(){return new ke(ve.RETRY_LIMIT_EXCEEDED,"Max retry time for operation exceeded, please try again.")}function AE(){return new ke(ve.CANCELED,"User canceled the upload/download.")}function zS(r){return new ke(ve.INVALID_URL,"Invalid URL '"+r+"'.")}function WS(r){return new ke(ve.INVALID_DEFAULT_BUCKET,"Invalid default bucket '"+r+"'.")}function QS(){return new ke(ve.NO_DEFAULT_BUCKET,"No default bucket found. Did you set the '"+wE+"' property when initializing the app?")}function RE(){return new ke(ve.CANNOT_SLICE_BLOB,"Cannot slice blob for upload. Please retry the upload.")}function $S(){return new ke(ve.SERVER_FILE_WRONG_SIZE,"Server recorded incorrect upload file size, please retry the upload.")}function YS(){return new ke(ve.NO_DOWNLOAD_URL,"The given file does not have any download URLs.")}function XS(r){return new ke(ve.UNSUPPORTED_ENVIRONMENT,`${r} is missing. Make sure to install the required polyfills. See https://firebase.google.com/docs/web/environments-js-sdk#polyfills for more information.`)}function Uu(r){return new ke(ve.INVALID_ARGUMENT,r)}function vE(){return new ke(ve.APP_DELETED,"The Firebase app was deleted.")}function PE(r){return new ke(ve.INVALID_ROOT_OPERATION,"The operation '"+r+"' cannot be performed on a root reference, create a non-root reference using child, such as .child('file.png').")}function go(r,e){return new ke(ve.INVALID_FORMAT,"String does not match format '"+r+"': "+e)}function zi(r){throw new ke(ve.INTERNAL_ERROR,"Internal error: "+r)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ft{constructor(e,t){this.bucket=e,this.path_=t}get path(){return this.path_}get isRoot(){return this.path.length===0}fullServerUrl(){const e=encodeURIComponent;return"/b/"+e(this.bucket)+"/o/"+e(this.path)}bucketOnlyServerUrl(){return"/b/"+encodeURIComponent(this.bucket)+"/o"}static makeFromBucketSpec(e,t){let n;try{n=ft.makeFromUrl(e,t)}catch{return new ft(e,"")}if(n.path==="")return n;throw WS(e)}static makeFromUrl(e,t){let n=null;const s="([A-Za-z0-9.\\-_]+)";function i(se){se.path.charAt(se.path.length-1)==="/"&&(se.path_=se.path_.slice(0,-1))}const o="(/(.*))?$",a=new RegExp("^gs://"+s+o,"i"),u={bucket:1,path:3};function B(se){se.path_=decodeURIComponent(se.path)}const l="v[A-Za-z0-9_]+",d=t.replace(/[.]/g,"\\."),C="(/([^?#]*).*)?$",g=new RegExp(`^https?://${d}/${l}/b/${s}/o${C}`,"i"),m={bucket:1,path:3},v=t===yE?"(?:storage.googleapis.com|storage.cloud.google.com)":t,N="([^?#]*)",q=new RegExp(`^https?://${v}/${s}/${N}`,"i"),X=[{regex:a,indices:u,postModify:i},{regex:g,indices:m,postModify:B},{regex:q,indices:{bucket:1,path:2},postModify:B}];for(let se=0;se<X.length;se++){const ue=X[se],ce=ue.regex.exec(e);if(ce){const T=ce[ue.indices.bucket];let I=ce[ue.indices.path];I||(I=""),n=new ft(T,I),ue.postModify(n);break}}if(n==null)throw zS(e);return n}}class ZS{constructor(e){this.promise_=Promise.reject(e)}getPromise(){return this.promise_}cancel(e=!1){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function e0(r,e,t){let n=1,s=null,i=null,o=!1,a=0;function u(){return a===2}let B=!1;function l(...N){B||(B=!0,e.apply(null,N))}function d(N){s=setTimeout(()=>{s=null,r(g,u())},N)}function C(){i&&clearTimeout(i)}function g(N,...q){if(B){C();return}if(N){C(),l.call(null,N,...q);return}if(u()||o){C(),l.call(null,N,...q);return}n<64&&(n*=2);let X;a===1?(a=2,X=0):X=(n+Math.random())*1e3,d(X)}let m=!1;function v(N){m||(m=!0,C(),!B&&(s!==null?(N||(a=2),clearTimeout(s),d(0)):N||(a=1)))}return d(0),i=setTimeout(()=>{o=!0,v(!0)},t),v}function t0(r){r(!1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function n0(r){return r!==void 0}function r0(r){return typeof r=="function"}function s0(r){return typeof r=="object"&&!Array.isArray(r)}function vc(r){return typeof r=="string"||r instanceof String}function wp(r){return Uh()&&r instanceof Blob}function Uh(){return typeof Blob<"u"}function cl(r,e,t,n){if(n<e)throw Uu(`Invalid value for '${r}'. Expected ${e} or greater.`);if(n>t)throw Uu(`Invalid value for '${r}'. Expected ${t} or less.`)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Hn(r,e,t){let n=e;return t==null&&(n=`https://${e}`),`${t}://${n}/v0${r}`}function bE(r){const e=encodeURIComponent;let t="?";for(const n in r)if(r.hasOwnProperty(n)){const s=e(n)+"="+e(r[n]);t=t+s+"&"}return t=t.slice(0,-1),t}var ss;(function(r){r[r.NO_ERROR=0]="NO_ERROR",r[r.NETWORK_ERROR=1]="NETWORK_ERROR",r[r.ABORT=2]="ABORT"})(ss||(ss={}));/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function SE(r,e){const t=r>=500&&r<600,s=[408,429].indexOf(r)!==-1,i=e.indexOf(r)!==-1;return t||s||i}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class i0{constructor(e,t,n,s,i,o,a,u,B,l,d,C=!0,g=!1){this.url_=e,this.method_=t,this.headers_=n,this.body_=s,this.successCodes_=i,this.additionalRetryCodes_=o,this.callback_=a,this.errorCallback_=u,this.timeout_=B,this.progressCallback_=l,this.connectionFactory_=d,this.retry=C,this.isUsingEmulator=g,this.pendingConnection_=null,this.backoffId_=null,this.canceled_=!1,this.appDelete_=!1,this.promise_=new Promise((m,v)=>{this.resolve_=m,this.reject_=v,this.start_()})}start_(){const e=(n,s)=>{if(s){n(!1,new Wa(!1,null,!0));return}const i=this.connectionFactory_();this.pendingConnection_=i;const o=a=>{const u=a.loaded,B=a.lengthComputable?a.total:-1;this.progressCallback_!==null&&this.progressCallback_(u,B)};this.progressCallback_!==null&&i.addUploadProgressListener(o),i.send(this.url_,this.method_,this.isUsingEmulator,this.body_,this.headers_).then(()=>{this.progressCallback_!==null&&i.removeUploadProgressListener(o),this.pendingConnection_=null;const a=i.getErrorCode()===ss.NO_ERROR,u=i.getStatus();if(!a||SE(u,this.additionalRetryCodes_)&&this.retry){const l=i.getErrorCode()===ss.ABORT;n(!1,new Wa(!1,null,l));return}const B=this.successCodes_.indexOf(u)!==-1;n(!0,new Wa(B,i))})},t=(n,s)=>{const i=this.resolve_,o=this.reject_,a=s.connection;if(s.wasSuccessCode)try{const u=this.callback_(a,a.getResponse());n0(u)?i(u):i()}catch(u){o(u)}else if(a!==null){const u=Gh();u.serverResponse=a.getErrorText(),this.errorCallback_?o(this.errorCallback_(a,u)):o(u)}else if(s.canceled){const u=this.appDelete_?vE():AE();o(u)}else{const u=TE();o(u)}};this.canceled_?t(!1,new Wa(!1,null,!0)):this.backoffId_=e0(e,t,this.timeout_)}getPromise(){return this.promise_}cancel(e){this.canceled_=!0,this.appDelete_=e||!1,this.backoffId_!==null&&t0(this.backoffId_),this.pendingConnection_!==null&&this.pendingConnection_.abort()}}class Wa{constructor(e,t,n){this.wasSuccessCode=e,this.connection=t,this.canceled=!!n}}function o0(r,e){e!==null&&e.length>0&&(r.Authorization="Firebase "+e)}function a0(r,e){r["X-Firebase-Storage-Version"]="webjs/"+(e??"AppManager")}function u0(r,e){e&&(r["X-Firebase-GMPID"]=e)}function c0(r,e){e!==null&&(r["X-Firebase-AppCheck"]=e)}function B0(r,e,t,n,s,i,o=!0,a=!1){const u=bE(r.urlParams),B=r.url+u,l=Object.assign({},r.headers);return u0(l,e),o0(l,t),a0(l,i),c0(l,n),new i0(B,r.method,l,r.body,r.successCodes,r.additionalRetryCodes,r.handler,r.errorHandler,r.timeout,r.progressCallback,s,o,a)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function l0(){return typeof BlobBuilder<"u"?BlobBuilder:typeof WebKitBlobBuilder<"u"?WebKitBlobBuilder:void 0}function h0(...r){const e=l0();if(e!==void 0){const t=new e;for(let n=0;n<r.length;n++)t.append(r[n]);return t.getBlob()}else{if(Uh())return new Blob(r);throw new ke(ve.UNSUPPORTED_ENVIRONMENT,"This browser doesn't seem to support creating Blobs")}}function d0(r,e,t){return r.webkitSlice?r.webkitSlice(e,t):r.mozSlice?r.mozSlice(e,t):r.slice?r.slice(e,t):null}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function f0(r){if(typeof atob>"u")throw XS("base-64");return atob(r)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jt={RAW:"raw",BASE64:"base64",BASE64URL:"base64url",DATA_URL:"data_url"};class yB{constructor(e,t){this.data=e,this.contentType=t||null}}function Hh(r,e){switch(r){case Jt.RAW:return new yB(OE(e));case Jt.BASE64:case Jt.BASE64URL:return new yB(NE(r,e));case Jt.DATA_URL:return new yB(p0(e),g0(e))}throw Gh()}function OE(r){const e=[];for(let t=0;t<r.length;t++){let n=r.charCodeAt(t);if(n<=127)e.push(n);else if(n<=2047)e.push(192|n>>6,128|n&63);else if((n&64512)===55296)if(!(t<r.length-1&&(r.charCodeAt(t+1)&64512)===56320))e.push(239,191,189);else{const i=n,o=r.charCodeAt(++t);n=65536|(i&1023)<<10|o&1023,e.push(240|n>>18,128|n>>12&63,128|n>>6&63,128|n&63)}else(n&64512)===56320?e.push(239,191,189):e.push(224|n>>12,128|n>>6&63,128|n&63)}return new Uint8Array(e)}function C0(r){let e;try{e=decodeURIComponent(r)}catch{throw go(Jt.DATA_URL,"Malformed data URL.")}return OE(e)}function NE(r,e){switch(r){case Jt.BASE64:{const s=e.indexOf("-")!==-1,i=e.indexOf("_")!==-1;if(s||i)throw go(r,"Invalid character '"+(s?"-":"_")+"' found: is it base64url encoded?");break}case Jt.BASE64URL:{const s=e.indexOf("+")!==-1,i=e.indexOf("/")!==-1;if(s||i)throw go(r,"Invalid character '"+(s?"+":"/")+"' found: is it base64 encoded?");e=e.replace(/-/g,"+").replace(/_/g,"/");break}}let t;try{t=f0(e)}catch(s){throw s.message.includes("polyfill")?s:go(r,"Invalid character found")}const n=new Uint8Array(t.length);for(let s=0;s<t.length;s++)n[s]=t.charCodeAt(s);return n}class FE{constructor(e){this.base64=!1,this.contentType=null;const t=e.match(/^data:([^,]+)?,/);if(t===null)throw go(Jt.DATA_URL,"Must be formatted 'data:[<mediatype>][;base64],<data>");const n=t[1]||null;n!=null&&(this.base64=m0(n,";base64"),this.contentType=this.base64?n.substring(0,n.length-7):n),this.rest=e.substring(e.indexOf(",")+1)}}function p0(r){const e=new FE(r);return e.base64?NE(Jt.BASE64,e.rest):C0(e.rest)}function g0(r){return new FE(r).contentType}function m0(r,e){return r.length>=e.length?r.substring(r.length-e.length)===e:!1}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class on{constructor(e,t){let n=0,s="";wp(e)?(this.data_=e,n=e.size,s=e.type):e instanceof ArrayBuffer?(t?this.data_=new Uint8Array(e):(this.data_=new Uint8Array(e.byteLength),this.data_.set(new Uint8Array(e))),n=this.data_.length):e instanceof Uint8Array&&(t?this.data_=e:(this.data_=new Uint8Array(e.length),this.data_.set(e)),n=e.length),this.size_=n,this.type_=s}size(){return this.size_}type(){return this.type_}slice(e,t){if(wp(this.data_)){const n=this.data_,s=d0(n,e,t);return s===null?null:new on(s)}else{const n=new Uint8Array(this.data_.buffer,e,t-e);return new on(n,!0)}}static getBlob(...e){if(Uh()){const t=e.map(n=>n instanceof on?n.data_:n);return new on(h0.apply(null,t))}else{const t=e.map(o=>vc(o)?Hh(Jt.RAW,o).data:o.data_);let n=0;t.forEach(o=>{n+=o.byteLength});const s=new Uint8Array(n);let i=0;return t.forEach(o=>{for(let a=0;a<o.length;a++)s[i++]=o[a]}),new on(s,!0)}}uploadData(){return this.data_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function qh(r){let e;try{e=JSON.parse(r)}catch{return null}return s0(e)?e:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _0(r){if(r.length===0)return null;const e=r.lastIndexOf("/");return e===-1?"":r.slice(0,e)}function E0(r,e){const t=e.split("/").filter(n=>n.length>0).join("/");return r.length===0?t:r+"/"+t}function LE(r){const e=r.lastIndexOf("/",r.length-2);return e===-1?r:r.slice(e+1)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function I0(r,e){return e}class Et{constructor(e,t,n,s){this.server=e,this.local=t||e,this.writable=!!n,this.xform=s||I0}}let Qa=null;function D0(r){return!vc(r)||r.length<2?r:LE(r)}function Ca(){if(Qa)return Qa;const r=[];r.push(new Et("bucket")),r.push(new Et("generation")),r.push(new Et("metageneration")),r.push(new Et("name","fullPath",!0));function e(i,o){return D0(o)}const t=new Et("name");t.xform=e,r.push(t);function n(i,o){return o!==void 0?Number(o):o}const s=new Et("size");return s.xform=n,r.push(s),r.push(new Et("timeCreated")),r.push(new Et("updated")),r.push(new Et("md5Hash",null,!0)),r.push(new Et("cacheControl",null,!0)),r.push(new Et("contentDisposition",null,!0)),r.push(new Et("contentEncoding",null,!0)),r.push(new Et("contentLanguage",null,!0)),r.push(new Et("contentType",null,!0)),r.push(new Et("metadata","customMetadata",!0)),Qa=r,Qa}function y0(r,e){function t(){const n=r.bucket,s=r.fullPath,i=new ft(n,s);return e._makeStorageReference(i)}Object.defineProperty(r,"ref",{get:t})}function w0(r,e,t){const n={};n.type="file";const s=t.length;for(let i=0;i<s;i++){const o=t[i];n[o.local]=o.xform(n,e[o.server])}return y0(n,r),n}function kE(r,e,t){const n=qh(e);return n===null?null:w0(r,n,t)}function T0(r,e,t,n){const s=qh(e);if(s===null||!vc(s.downloadTokens))return null;const i=s.downloadTokens;if(i.length===0)return null;const o=encodeURIComponent;return i.split(",").map(B=>{const l=r.bucket,d=r.fullPath,C="/b/"+o(l)+"/o/"+o(d),g=Hn(C,t,n),m=bE({alt:"media",token:B});return g+m})[0]}function jh(r,e){const t={},n=e.length;for(let s=0;s<n;s++){const i=e[s];i.writable&&(t[i.server]=r[i.local])}return JSON.stringify(t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Tp="prefixes",Ap="items";function A0(r,e,t){const n={prefixes:[],items:[],nextPageToken:t.nextPageToken};if(t[Tp])for(const s of t[Tp]){const i=s.replace(/\/$/,""),o=r._makeStorageReference(new ft(e,i));n.prefixes.push(o)}if(t[Ap])for(const s of t[Ap]){const i=r._makeStorageReference(new ft(e,s.name));n.items.push(i)}return n}function R0(r,e,t){const n=qh(t);return n===null?null:A0(r,e,n)}class yn{constructor(e,t,n,s){this.url=e,this.method=t,this.handler=n,this.timeout=s,this.urlParams={},this.headers={},this.body=null,this.errorHandler=null,this.progressCallback=null,this.successCodes=[200],this.additionalRetryCodes=[]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Cn(r){if(!r)throw Gh()}function Pc(r,e){function t(n,s){const i=kE(r,s,e);return Cn(i!==null),i}return t}function v0(r,e){function t(n,s){const i=R0(r,e,s);return Cn(i!==null),i}return t}function P0(r,e){function t(n,s){const i=kE(r,s,e);return Cn(i!==null),T0(i,s,r.host,r._protocol)}return t}function Di(r){function e(t,n){let s;return t.getStatus()===401?t.getErrorText().includes("Firebase App Check token is invalid")?s=JS():s=jS():t.getStatus()===402?s=qS(r.bucket):t.getStatus()===403?s=KS(r.path):s=n,s.status=t.getStatus(),s.serverResponse=n.serverResponse,s}return e}function pa(r){const e=Di(r);function t(n,s){let i=e(n,s);return n.getStatus()===404&&(i=HS(r.path)),i.serverResponse=s.serverResponse,i}return t}function xE(r,e,t){const n=e.fullServerUrl(),s=Hn(n,r.host,r._protocol),i="GET",o=r.maxOperationRetryTime,a=new yn(s,i,Pc(r,t),o);return a.errorHandler=pa(e),a}function b0(r,e,t,n,s){const i={};e.isRoot?i.prefix="":i.prefix=e.path+"/",t.length>0&&(i.delimiter=t),n&&(i.pageToken=n),s&&(i.maxResults=s);const o=e.bucketOnlyServerUrl(),a=Hn(o,r.host,r._protocol),u="GET",B=r.maxOperationRetryTime,l=new yn(a,u,v0(r,e.bucket),B);return l.urlParams=i,l.errorHandler=Di(e),l}function VE(r,e,t){const n=e.fullServerUrl(),s=Hn(n,r.host,r._protocol)+"?alt=media",i="GET",o=r.maxOperationRetryTime,a=new yn(s,i,(u,B)=>B,o);return a.errorHandler=pa(e),t!==void 0&&(a.headers.Range=`bytes=0-${t}`,a.successCodes=[200,206]),a}function S0(r,e,t){const n=e.fullServerUrl(),s=Hn(n,r.host,r._protocol),i="GET",o=r.maxOperationRetryTime,a=new yn(s,i,P0(r,t),o);return a.errorHandler=pa(e),a}function O0(r,e,t,n){const s=e.fullServerUrl(),i=Hn(s,r.host,r._protocol),o="PATCH",a=jh(t,n),u={"Content-Type":"application/json; charset=utf-8"},B=r.maxOperationRetryTime,l=new yn(i,o,Pc(r,n),B);return l.headers=u,l.body=a,l.errorHandler=pa(e),l}function N0(r,e){const t=e.fullServerUrl(),n=Hn(t,r.host,r._protocol),s="DELETE",i=r.maxOperationRetryTime;function o(u,B){}const a=new yn(n,s,o,i);return a.successCodes=[200,204],a.errorHandler=pa(e),a}function F0(r,e){return r&&r.contentType||e&&e.type()||"application/octet-stream"}function ME(r,e,t){const n=Object.assign({},t);return n.fullPath=r.path,n.size=e.size(),n.contentType||(n.contentType=F0(null,e)),n}function GE(r,e,t,n,s){const i=e.bucketOnlyServerUrl(),o={"X-Goog-Upload-Protocol":"multipart"};function a(){let X="";for(let se=0;se<2;se++)X=X+Math.random().toString().slice(2);return X}const u=a();o["Content-Type"]="multipart/related; boundary="+u;const B=ME(e,n,s),l=jh(B,t),d="--"+u+`\r
Content-Type: application/json; charset=utf-8\r
\r
`+l+`\r
--`+u+`\r
Content-Type: `+B.contentType+`\r
\r
`,C=`\r
--`+u+"--",g=on.getBlob(d,n,C);if(g===null)throw RE();const m={name:B.fullPath},v=Hn(i,r.host,r._protocol),N="POST",q=r.maxUploadRetryTime,J=new yn(v,N,Pc(r,t),q);return J.urlParams=m,J.headers=o,J.body=g.uploadData(),J.errorHandler=Di(e),J}class Hu{constructor(e,t,n,s){this.current=e,this.total=t,this.finalized=!!n,this.metadata=s||null}}function Jh(r,e){let t=null;try{t=r.getResponseHeader("X-Goog-Upload-Status")}catch{Cn(!1)}return Cn(!!t&&(e||["active"]).indexOf(t)!==-1),t}function L0(r,e,t,n,s){const i=e.bucketOnlyServerUrl(),o=ME(e,n,s),a={name:o.fullPath},u=Hn(i,r.host,r._protocol),B="POST",l={"X-Goog-Upload-Protocol":"resumable","X-Goog-Upload-Command":"start","X-Goog-Upload-Header-Content-Length":`${n.size()}`,"X-Goog-Upload-Header-Content-Type":o.contentType,"Content-Type":"application/json; charset=utf-8"},d=jh(o,t),C=r.maxUploadRetryTime;function g(v){Jh(v);let N;try{N=v.getResponseHeader("X-Goog-Upload-URL")}catch{Cn(!1)}return Cn(vc(N)),N}const m=new yn(u,B,g,C);return m.urlParams=a,m.headers=l,m.body=d,m.errorHandler=Di(e),m}function k0(r,e,t,n){const s={"X-Goog-Upload-Command":"query"};function i(B){const l=Jh(B,["active","final"]);let d=null;try{d=B.getResponseHeader("X-Goog-Upload-Size-Received")}catch{Cn(!1)}d||Cn(!1);const C=Number(d);return Cn(!isNaN(C)),new Hu(C,n.size(),l==="final")}const o="POST",a=r.maxUploadRetryTime,u=new yn(t,o,i,a);return u.headers=s,u.errorHandler=Di(e),u}const Rp=256*1024;function x0(r,e,t,n,s,i,o,a){const u=new Hu(0,0);if(o?(u.current=o.current,u.total=o.total):(u.current=0,u.total=n.size()),n.size()!==u.total)throw $S();const B=u.total-u.current;let l=B;s>0&&(l=Math.min(l,s));const d=u.current,C=d+l;let g="";l===0?g="finalize":B===l?g="upload, finalize":g="upload";const m={"X-Goog-Upload-Command":g,"X-Goog-Upload-Offset":`${u.current}`},v=n.slice(d,C);if(v===null)throw RE();function N(se,ue){const ce=Jh(se,["active","final"]),T=u.current+l,I=n.size();let y;return ce==="final"?y=Pc(e,i)(se,ue):y=null,new Hu(T,I,ce==="final",y)}const q="POST",J=e.maxUploadRetryTime,X=new yn(t,q,N,J);return X.headers=m,X.body=v.uploadData(),X.progressCallback=a||null,X.errorHandler=Di(r),X}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const V0={STATE_CHANGED:"state_changed"},It={RUNNING:"running",PAUSED:"paused",SUCCESS:"success",CANCELED:"canceled",ERROR:"error"};function wB(r){switch(r){case"running":case"pausing":case"canceling":return It.RUNNING;case"paused":return It.PAUSED;case"success":return It.SUCCESS;case"canceled":return It.CANCELED;case"error":return It.ERROR;default:return It.ERROR}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class M0{constructor(e,t,n){if(r0(e)||t!=null||n!=null)this.next=e,this.error=t??void 0,this.complete=n??void 0;else{const i=e;this.next=i.next,this.error=i.error,this.complete=i.complete}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Vs(r){return(...e)=>{Promise.resolve().then(()=>r(...e))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kh{constructor(){this.sent_=!1,this.xhr_=new XMLHttpRequest,this.initXhr(),this.errorCode_=ss.NO_ERROR,this.sendPromise_=new Promise(e=>{this.xhr_.addEventListener("abort",()=>{this.errorCode_=ss.ABORT,e()}),this.xhr_.addEventListener("error",()=>{this.errorCode_=ss.NETWORK_ERROR,e()}),this.xhr_.addEventListener("load",()=>{e()})})}send(e,t,n,s,i){if(this.sent_)throw zi("cannot .send() more than once");if(vr(e)&&n&&(this.xhr_.withCredentials=!0),this.sent_=!0,this.xhr_.open(t,e,!0),i!==void 0)for(const o in i)i.hasOwnProperty(o)&&this.xhr_.setRequestHeader(o,i[o].toString());return s!==void 0?this.xhr_.send(s):this.xhr_.send(),this.sendPromise_}getErrorCode(){if(!this.sent_)throw zi("cannot .getErrorCode() before sending");return this.errorCode_}getStatus(){if(!this.sent_)throw zi("cannot .getStatus() before sending");try{return this.xhr_.status}catch{return-1}}getResponse(){if(!this.sent_)throw zi("cannot .getResponse() before sending");return this.xhr_.response}getErrorText(){if(!this.sent_)throw zi("cannot .getErrorText() before sending");return this.xhr_.statusText}abort(){this.xhr_.abort()}getResponseHeader(e){return this.xhr_.getResponseHeader(e)}addUploadProgressListener(e){this.xhr_.upload!=null&&this.xhr_.upload.addEventListener("progress",e)}removeUploadProgressListener(e){this.xhr_.upload!=null&&this.xhr_.upload.removeEventListener("progress",e)}}class G0 extends Kh{initXhr(){this.xhr_.responseType="text"}}function Yt(){return new G0}class U0 extends Kh{initXhr(){this.xhr_.responseType="arraybuffer"}}function H0(){return new U0}class q0 extends Kh{initXhr(){this.xhr_.responseType="blob"}}function j0(){return new q0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class UE{isExponentialBackoffExpired(){return this.sleepTime>this.maxSleepTime}constructor(e,t,n=null){this._transferred=0,this._needToFetchStatus=!1,this._needToFetchMetadata=!1,this._observers=[],this._error=void 0,this._uploadUrl=void 0,this._request=void 0,this._chunkMultiplier=1,this._resolve=void 0,this._reject=void 0,this._ref=e,this._blob=t,this._metadata=n,this._mappings=Ca(),this._resumable=this._shouldDoResumable(this._blob),this._state="running",this._errorHandler=s=>{if(this._request=void 0,this._chunkMultiplier=1,s._codeEquals(ve.CANCELED))this._needToFetchStatus=!0,this.completeTransitions_();else{const i=this.isExponentialBackoffExpired();if(SE(s.status,[]))if(i)s=TE();else{this.sleepTime=Math.max(this.sleepTime*2,US),this._needToFetchStatus=!0,this.completeTransitions_();return}this._error=s,this._transition("error")}},this._metadataErrorHandler=s=>{this._request=void 0,s._codeEquals(ve.CANCELED)?this.completeTransitions_():(this._error=s,this._transition("error"))},this.sleepTime=0,this.maxSleepTime=this._ref.storage.maxUploadRetryTime,this._promise=new Promise((s,i)=>{this._resolve=s,this._reject=i,this._start()}),this._promise.then(null,()=>{})}_makeProgressCallback(){const e=this._transferred;return t=>this._updateProgress(e+t)}_shouldDoResumable(e){return e.size()>256*1024}_start(){this._state==="running"&&this._request===void 0&&(this._resumable?this._uploadUrl===void 0?this._createResumable():this._needToFetchStatus?this._fetchStatus():this._needToFetchMetadata?this._fetchMetadata():this.pendingTimeout=setTimeout(()=>{this.pendingTimeout=void 0,this._continueUpload()},this.sleepTime):this._oneShotUpload())}_resolveToken(e){Promise.all([this._ref.storage._getAuthToken(),this._ref.storage._getAppCheckToken()]).then(([t,n])=>{switch(this._state){case"running":e(t,n);break;case"canceling":this._transition("canceled");break;case"pausing":this._transition("paused");break}})}_createResumable(){this._resolveToken((e,t)=>{const n=L0(this._ref.storage,this._ref._location,this._mappings,this._blob,this._metadata),s=this._ref.storage._makeRequest(n,Yt,e,t);this._request=s,s.getPromise().then(i=>{this._request=void 0,this._uploadUrl=i,this._needToFetchStatus=!1,this.completeTransitions_()},this._errorHandler)})}_fetchStatus(){const e=this._uploadUrl;this._resolveToken((t,n)=>{const s=k0(this._ref.storage,this._ref._location,e,this._blob),i=this._ref.storage._makeRequest(s,Yt,t,n);this._request=i,i.getPromise().then(o=>{o=o,this._request=void 0,this._updateProgress(o.current),this._needToFetchStatus=!1,o.finalized&&(this._needToFetchMetadata=!0),this.completeTransitions_()},this._errorHandler)})}_continueUpload(){const e=Rp*this._chunkMultiplier,t=new Hu(this._transferred,this._blob.size()),n=this._uploadUrl;this._resolveToken((s,i)=>{let o;try{o=x0(this._ref._location,this._ref.storage,n,this._blob,e,this._mappings,t,this._makeProgressCallback())}catch(u){this._error=u,this._transition("error");return}const a=this._ref.storage._makeRequest(o,Yt,s,i,!1);this._request=a,a.getPromise().then(u=>{this._increaseMultiplier(),this._request=void 0,this._updateProgress(u.current),u.finalized?(this._metadata=u.metadata,this._transition("success")):this.completeTransitions_()},this._errorHandler)})}_increaseMultiplier(){Rp*this._chunkMultiplier*2<32*1024*1024&&(this._chunkMultiplier*=2)}_fetchMetadata(){this._resolveToken((e,t)=>{const n=xE(this._ref.storage,this._ref._location,this._mappings),s=this._ref.storage._makeRequest(n,Yt,e,t);this._request=s,s.getPromise().then(i=>{this._request=void 0,this._metadata=i,this._transition("success")},this._metadataErrorHandler)})}_oneShotUpload(){this._resolveToken((e,t)=>{const n=GE(this._ref.storage,this._ref._location,this._mappings,this._blob,this._metadata),s=this._ref.storage._makeRequest(n,Yt,e,t);this._request=s,s.getPromise().then(i=>{this._request=void 0,this._metadata=i,this._updateProgress(this._blob.size()),this._transition("success")},this._errorHandler)})}_updateProgress(e){const t=this._transferred;this._transferred=e,this._transferred!==t&&this._notifyObservers()}_transition(e){if(this._state!==e)switch(e){case"canceling":case"pausing":this._state=e,this._request!==void 0?this._request.cancel():this.pendingTimeout&&(clearTimeout(this.pendingTimeout),this.pendingTimeout=void 0,this.completeTransitions_());break;case"running":const t=this._state==="paused";this._state=e,t&&(this._notifyObservers(),this._start());break;case"paused":this._state=e,this._notifyObservers();break;case"canceled":this._error=AE(),this._state=e,this._notifyObservers();break;case"error":this._state=e,this._notifyObservers();break;case"success":this._state=e,this._notifyObservers();break}}completeTransitions_(){switch(this._state){case"pausing":this._transition("paused");break;case"canceling":this._transition("canceled");break;case"running":this._start();break}}get snapshot(){const e=wB(this._state);return{bytesTransferred:this._transferred,totalBytes:this._blob.size(),state:e,metadata:this._metadata,task:this,ref:this._ref}}on(e,t,n,s){const i=new M0(t||void 0,n||void 0,s||void 0);return this._addObserver(i),()=>{this._removeObserver(i)}}then(e,t){return this._promise.then(e,t)}catch(e){return this.then(null,e)}_addObserver(e){this._observers.push(e),this._notifyObserver(e)}_removeObserver(e){const t=this._observers.indexOf(e);t!==-1&&this._observers.splice(t,1)}_notifyObservers(){this._finishPromise(),this._observers.slice().forEach(t=>{this._notifyObserver(t)})}_finishPromise(){if(this._resolve!==void 0){let e=!0;switch(wB(this._state)){case It.SUCCESS:Vs(this._resolve.bind(null,this.snapshot))();break;case It.CANCELED:case It.ERROR:const t=this._reject;Vs(t.bind(null,this._error))();break;default:e=!1;break}e&&(this._resolve=void 0,this._reject=void 0)}}_notifyObserver(e){switch(wB(this._state)){case It.RUNNING:case It.PAUSED:e.next&&Vs(e.next.bind(e,this.snapshot))();break;case It.SUCCESS:e.complete&&Vs(e.complete.bind(e))();break;case It.CANCELED:case It.ERROR:e.error&&Vs(e.error.bind(e,this._error))();break;default:e.error&&Vs(e.error.bind(e,this._error))()}}resume(){const e=this._state==="paused"||this._state==="pausing";return e&&this._transition("running"),e}pause(){const e=this._state==="running";return e&&this._transition("pausing"),e}cancel(){const e=this._state==="running"||this._state==="pausing";return e&&this._transition("canceling"),e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gs{constructor(e,t){this._service=e,t instanceof ft?this._location=t:this._location=ft.makeFromUrl(t,e.host)}toString(){return"gs://"+this._location.bucket+"/"+this._location.path}_newRef(e,t){return new gs(e,t)}get root(){const e=new ft(this._location.bucket,"");return this._newRef(this._service,e)}get bucket(){return this._location.bucket}get fullPath(){return this._location.path}get name(){return LE(this._location.path)}get storage(){return this._service}get parent(){const e=_0(this._location.path);if(e===null)return null;const t=new ft(this._location.bucket,e);return new gs(this._service,t)}_throwIfRoot(e){if(this._location.path==="")throw PE(e)}}function J0(r,e){r._throwIfRoot("getBytes");const t=VE(r.storage,r._location,e);return r.storage.makeRequestWithTokens(t,H0).then(n=>e!==void 0?n.slice(0,e):n)}function K0(r,e){r._throwIfRoot("getBlob");const t=VE(r.storage,r._location,e);return r.storage.makeRequestWithTokens(t,j0).then(n=>e!==void 0?n.slice(0,e):n)}function HE(r,e,t){r._throwIfRoot("uploadBytes");const n=GE(r.storage,r._location,Ca(),new on(e,!0),t);return r.storage.makeRequestWithTokens(n,Yt).then(s=>({metadata:s,ref:r}))}function z0(r,e,t){return r._throwIfRoot("uploadBytesResumable"),new UE(r,new on(e),t)}function W0(r,e,t=Jt.RAW,n){r._throwIfRoot("uploadString");const s=Hh(t,e),i={...n};return i.contentType==null&&s.contentType!=null&&(i.contentType=s.contentType),HE(r,s.data,i)}function Q0(r){const e={prefixes:[],items:[]};return qE(r,e).then(()=>e)}async function qE(r,e,t){const s=await jE(r,{pageToken:t});e.prefixes.push(...s.prefixes),e.items.push(...s.items),s.nextPageToken!=null&&await qE(r,e,s.nextPageToken)}function jE(r,e){e!=null&&typeof e.maxResults=="number"&&cl("options.maxResults",1,1e3,e.maxResults);const t=e||{},n=b0(r.storage,r._location,"/",t.pageToken,t.maxResults);return r.storage.makeRequestWithTokens(n,Yt)}function $0(r){r._throwIfRoot("getMetadata");const e=xE(r.storage,r._location,Ca());return r.storage.makeRequestWithTokens(e,Yt)}function Y0(r,e){r._throwIfRoot("updateMetadata");const t=O0(r.storage,r._location,e,Ca());return r.storage.makeRequestWithTokens(t,Yt)}function X0(r){r._throwIfRoot("getDownloadURL");const e=S0(r.storage,r._location,Ca());return r.storage.makeRequestWithTokens(e,Yt).then(t=>{if(t===null)throw YS();return t})}function Z0(r){r._throwIfRoot("deleteObject");const e=N0(r.storage,r._location);return r.storage.makeRequestWithTokens(e,Yt)}function JE(r,e){const t=E0(r._location.path,e),n=new ft(r._location.bucket,t);return new gs(r.storage,n)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eO(r){return/^[A-Za-z]+:\/\//.test(r)}function tO(r,e){return new gs(r,e)}function KE(r,e){if(r instanceof zh){const t=r;if(t._bucket==null)throw QS();const n=new gs(t,t._bucket);return e!=null?KE(n,e):n}else return e!==void 0?JE(r,e):r}function nO(r,e){if(e&&eO(e)){if(r instanceof zh)return tO(r,e);throw Uu("To use ref(service, url), the first argument must be a Storage instance.")}else return KE(r,e)}function vp(r,e){const t=e==null?void 0:e[wE];return t==null?null:ft.makeFromBucketSpec(t,r)}function rO(r,e,t,n={}){r.host=`${e}:${t}`;const s=vr(e);s&&ju(`https://${r.host}/b`),r._isUsingEmulator=!0,r._protocol=s?"https":"http";const{mockUserToken:i}=n;i&&(r._overrideAuthToken=typeof i=="string"?i:Gp(i,r.app.options.projectId))}class zh{constructor(e,t,n,s,i,o=!1){this.app=e,this._authProvider=t,this._appCheckProvider=n,this._url=s,this._firebaseVersion=i,this._isUsingEmulator=o,this._bucket=null,this._host=yE,this._protocol="https",this._appId=null,this._deleted=!1,this._maxOperationRetryTime=MS,this._maxUploadRetryTime=GS,this._requests=new Set,s!=null?this._bucket=ft.makeFromBucketSpec(s,this._host):this._bucket=vp(this._host,this.app.options)}get host(){return this._host}set host(e){this._host=e,this._url!=null?this._bucket=ft.makeFromBucketSpec(this._url,e):this._bucket=vp(e,this.app.options)}get maxUploadRetryTime(){return this._maxUploadRetryTime}set maxUploadRetryTime(e){cl("time",0,Number.POSITIVE_INFINITY,e),this._maxUploadRetryTime=e}get maxOperationRetryTime(){return this._maxOperationRetryTime}set maxOperationRetryTime(e){cl("time",0,Number.POSITIVE_INFINITY,e),this._maxOperationRetryTime=e}async _getAuthToken(){if(this._overrideAuthToken)return this._overrideAuthToken;const e=this._authProvider.getImmediate({optional:!0});if(e){const t=await e.getToken();if(t!==null)return t.accessToken}return null}async _getAppCheckToken(){if(Ge(this.app)&&this.app.settings.appCheckToken)return this.app.settings.appCheckToken;const e=this._appCheckProvider.getImmediate({optional:!0});return e?(await e.getToken()).token:null}_delete(){return this._deleted||(this._deleted=!0,this._requests.forEach(e=>e.cancel()),this._requests.clear()),Promise.resolve()}_makeStorageReference(e){return new gs(this,e)}_makeRequest(e,t,n,s,i=!0){if(this._deleted)return new ZS(vE());{const o=B0(e,this._appId,n,s,t,this._firebaseVersion,i,this._isUsingEmulator);return this._requests.add(o),o.getPromise().then(()=>this._requests.delete(o),()=>this._requests.delete(o)),o}}async makeRequestWithTokens(e,t){const[n,s]=await Promise.all([this._getAuthToken(),this._getAppCheckToken()]);return this._makeRequest(e,t,n,s).getPromise()}}const Pp="@firebase/storage",bp="0.14.5";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zE="storage";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sO(r,e){return r=re(r),J0(r,e)}function iO(r,e,t){return r=re(r),HE(r,e,t)}function oO(r,e,t,n){return r=re(r),W0(r,e,t,n)}function aO(r,e,t){return r=re(r),z0(r,e,t)}function uO(r){return r=re(r),$0(r)}function cO(r,e){return r=re(r),Y0(r,e)}function BO(r,e){return r=re(r),jE(r,e)}function lO(r){return r=re(r),Q0(r)}function hO(r){return r=re(r),X0(r)}function dO(r){return r=re(r),Z0(r)}function fO(r,e){return r=re(r),nO(r,e)}function CO(r,e){return JE(r,e)}function pO(r=hl(),e){r=re(r);const n=jo(r,zE).getImmediate({identifier:e}),s=kp("storage");return s&&WE(n,...s),n}function WE(r,e,t,n={}){rO(r,e,t,n)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gO(r,e){return r=re(r),K0(r,e)}function mO(r,e){throw new Error("getStream() is only supported by NodeJS builds")}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _O(r,{instanceIdentifier:e}){const t=r.getProvider("app").getImmediate(),n=r.getProvider("auth-internal"),s=r.getProvider("app-check-internal");return new zh(t,n,s,e,ms)}function EO(){is(new Er(zE,_O,"PUBLIC").setMultipleInstances(!0)),hn(Pp,bp,""),hn(Pp,bp,"esm2020")}EO();const NN=Object.freeze(Object.defineProperty({__proto__:null,StorageError:ke,get StorageErrorCode(){return ve},StringFormat:Jt,_FbsBlob:on,_Location:ft,_TaskEvent:V0,_TaskState:It,_UploadTask:UE,_dataFromString:Hh,_getChild:CO,_invalidArgument:Uu,_invalidRootOperation:PE,connectStorageEmulator:WE,deleteObject:dO,getBlob:gO,getBytes:sO,getDownloadURL:hO,getMetadata:uO,getStorage:pO,getStream:mO,list:BO,listAll:lO,ref:fO,updateMetadata:cO,uploadBytes:iO,uploadBytesResumable:aO,uploadString:oO},Symbol.toStringTag,{value:"Module"}));export{IN as $,pN as A,lO as B,dO as C,DN as D,tN as E,Ts as F,RN as G,ir as H,rN as I,SS as J,fn as K,KO as L,ON as M,iN as N,oN as O,sN as P,lN as Q,SN as R,hu as S,_e as T,cN as U,sr as V,or as W,yN as X,TN as Y,ar as Z,_P as _,JO as a,hN as a0,uN as a1,mN as a2,ZO as a3,nN as a4,aN as a5,BN as a6,wN as a7,eN as a8,CN as a9,JP as aa,PN as ab,AN as ac,bN as ad,vN as ae,hb as af,Vn as ag,gN as ah,op as ai,xb as aj,BE as ak,Tb as al,kh as am,bO as an,NN as ao,DO as ap,hl as aq,KD as ar,EN as as,qP as at,FO as au,UO as av,Xv as aw,LO as ax,_N as ay,RO as b,TO as c,iT as d,QO as e,vO as f,jO as g,XO as h,AO as i,PO as j,VO as k,MO as l,GO as m,$O as n,YO as o,fO as p,kO as q,qO as r,zO as s,pO as t,WO as u,iO as v,xO as w,hO as x,fN as y,dN as z};
