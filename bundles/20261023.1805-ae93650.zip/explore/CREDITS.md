# Explore photo credits

Free-license photos from Wikimedia Commons used on the Explore page (tips, stories & articles). Checked Oct 20, 2026: no people featured, no churches/crosses, no Star of David, no alcohol.

- tip-flying-1.webp — "A wing tip of an airplane (40118125441).jpg" by U.S. Department of Agriculture — Public domain — https://commons.wikimedia.org/wiki/File:A_wing_tip_of_an_airplane_(40118125441).jpg
- tip-flying-2.webp — "Airplane wing sky and clouds.jpg" by Tobias1984 — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Airplane_wing_sky_and_clouds.jpg
- tip-flying-3.webp — "Sunset view from an airplane window above the clouds.jpg" by Salwa Farwaneh Dameh — CC0 — https://commons.wikimedia.org/wiki/File:Sunset_view_from_an_airplane_window_above_the_clouds.jpg
- airport-board.webp — "Departures board at Canberra Airport February 2020.jpg" by Nick-D — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Departures_board_at_Canberra_Airport_February_2020.jpg
- packing-suitcase.webp — "Holiday Packing List - Packing Luggage for Vacation.jpg" by Familydestinationsguide.com Images — CC BY 2.0 — https://commons.wikimedia.org/wiki/File:Holiday_Packing_List_-_Packing_Luggage_for_Vacation.jpg
- shabbos-candles-1.webp — "ShabbatcandlesC.jpg" by Gilabrand — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:ShabbatcandlesC.jpg
- shabbos-candlesticks.webp — "Shabbat candlesticks.JPG" by איתן פרמן — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Shabbat_candlesticks.JPG
- davening-tallis-bag.webp — "Tallit-bag.jpg" by Makaristos — Public domain — https://commons.wikimedia.org/wiki/File:Tallit-bag.jpg
- davening-bags-siddur.webp — "Judaism in Ashdod, September 2024 39.jpg" by Chenspec — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Judaism_in_Ashdod,_September_2024_39.jpg
- food-challah.webp — "Challah Bread Six Braid 1.JPG" by Aviv Hod — CC BY 3.0 — https://commons.wikimedia.org/wiki/File:Challah_Bread_Six_Braid_1.JPG
- food-bagels.webp — "(A bagel also spelled beigel, is a bread product originating in the Jewish communities of Poland).jpg" by David Adam Kess — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:(A_bagel_also_spelled_beigel,_is_a_bread_product_originating_in_the_Jewish_communities_of_Poland).jpg
- place-switzerland.webp — "Bergtocht van Arosa via Scheideggseeli (2080 meter) en Ochsenalp (1941 meter) naar Tschiertschen 22.jpg" by Dominicus Johannes Bergsma — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Bergtocht_van_Arosa_via_Scheideggseeli_(2080_meter)_en_Ochsenalp_(1941_meter)_naar_Tschiertschen_22.jpg
- place-madeira.webp — "Cliffs and houses of the coast of Faial, Santana, Madeira, 2023 May.jpg" by Ximonic (Simo Räsänen) — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Cliffs_and_houses_of_the_coast_of_Faial,_Santana,_Madeira,_2023_May.jpg
- place-croatia.webp — "Plitvice Waterfalls.jpg" by Noa Sel — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Plitvice_Waterfalls.jpg
- place-utah.webp — "Delicate Arch in Arches National Park 3.jpg" by “Jon Zander (Digon3)” — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Delicate_Arch_in_Arches_National_Park_3.jpg
- place-california.webp — "Bixby Creek Bridge 2013.jpg" by Tuxyso — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Bixby_Creek_Bridge_2013.jpg
- place-gibraltar.webp — "Gibraltar View of the Rock from La Linea.jpg" by Ymblanter — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Gibraltar_View_of_the_Rock_from_La_Linea.jpg
- place-paris.webp — "Eiffel tower from trocadero.jpg" by NonOmnisMoriar — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Eiffel_tower_from_trocadero.jpg
- place-rome.webp — "Rome Colosseum exterior 2.jpg" by Nicholas Hartmann — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Rome_Colosseum_exterior_2.jpg
- place-venice.webp — "Gondolas on Grand Canal - Venice, Italy - panoramio.jpg" by Sergey Ashmarin — CC BY-SA 3.0 — https://commons.wikimedia.org/wiki/File:Gondolas_on_Grand_Canal_-_Venice,_Italy_-_panoramio.jpg
- place-budapest.webp — "Hungarian Parliament Building 2023-9.jpg" by Pierre Blaché — CC0 — https://commons.wikimedia.org/wiki/File:Hungarian_Parliament_Building_2023-9.jpg
- place-portugal.webp — "Scenic coastal cliffs of the Ponta da Piedade and lighthouse at sunset, Lagos, Faro, Portugal, February 2025 (54460437310).jpg" by Sergei Gussev — CC BY 2.0 — https://commons.wikimedia.org/wiki/File:Scenic_coastal_cliffs_of_the_Ponta_da_Piedade_and_lighthouse_at_sunset,_Lagos,_Faro,_Portugal,_February_2025_(54460437310).jpg
- place-lancaster.webp — "Farmland viewed from Stevens Road in Ephrata Township PA.jpeg" by Dough4872 — CC BY-SA 4.0 — https://commons.wikimedia.org/wiki/File:Farmland_viewed_from_Stevens_Road_in_Ephrata_Township_PA.jpeg
